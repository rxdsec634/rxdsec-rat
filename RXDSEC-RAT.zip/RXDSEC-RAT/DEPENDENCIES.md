# RXDSEC RAT Dependencies

This document lists all dependencies required for the RXDSEC RAT system. To install all modules at once, you can use:

```bash
pip install -r requirements.txt
```

Or create a requirements.txt file with the following content:

```
# Core Web Framework
flask==2.3.2
flask-socketio==5.3.5
eventlet==0.33.3
gevent==23.9.1
gunicorn==21.2.0

# Cryptography and Security
cryptography==41.0.2
pycryptodome==3.18.0
pyopenssl==23.2.0
bcrypt==4.0.1

# Image Processing
pillow==10.0.0
qrcode==7.4.2
steganography==0.2.1

# Android APK Tools
androguard==3.4.0
apktool==1.2.0

# Data Processing and Utilities
requests==2.31.0
beautifulsoup4==4.12.2
python-dateutil==2.8.2
numpy==1.24.3
pandas==2.0.2

# Database
sqlalchemy==2.0.15
# sqlite3 is included in Python standard library

# Networking and Communication
websockets==11.0.3
python-socketio==5.8.0
httpx==0.24.1

# System Utilities
psutil==5.9.5
pyinstaller==5.13.0
python-dotenv==1.0.0

# Testing
pytest==7.3.1
pytest-cov==4.1.0

# Documentation
sphinx==7.0.1
sphinx-rtd-theme==1.2.2

# Development Tools
black==23.3.0
pylint==2.17.4
flake8==6.0.0
```

## System Dependencies

In addition to Python modules, the following system dependencies are required:

### For APK Building and Manipulation

- Java Development Kit (JDK) 8 or higher
- Android SDK (for APK building and signing)
- Apktool (for APK decompilation and repackaging)
- Zipalign (for APK optimization)
- jarsigner (for APK signing)

### For Photo Payload Generation

- ImageMagick (for advanced image manipulation)
- ExifTool (for metadata manipulation)

## Installation Instructions

### Debian/Ubuntu:

```bash
# Install system dependencies
sudo apt update
sudo apt install -y openjdk-11-jdk android-sdk apktool zipalign jarsigner imagemagick exiftool

# Install Python modules
pip install -r requirements.txt
```

### macOS:

```bash
# Install system dependencies
brew install openjdk android-sdk apktool imagemagick exiftool

# Install Python modules
pip install -r requirements.txt
```

### Windows:

```powershell
# Install Python modules
pip install -r requirements.txt

# System dependencies should be installed separately:
# - JDK: https://adoptopenjdk.net/
# - Android SDK: https://developer.android.com/studio
# - Apktool: https://ibotpeaches.github.io/Apktool/
# - ImageMagick: https://imagemagick.org/script/download.php
# - ExifTool: https://exiftool.org/
```

## Troubleshooting

If you encounter installation issues:

1. Make sure your Python version is 3.9 or higher
2. Try installing dependencies one by one if there are conflicts
3. For specific module errors, check the module's documentation for platform-specific installation instructions