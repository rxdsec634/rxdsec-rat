// socket.js - WebSocket client for Tarjon RAT C2 server

(function() {
    // Web socket connection
    let socket = null;
    let reconnectAttempts = 0;
    let maxReconnectAttempts = 10;
    let reconnectInterval = 3000; // 3 seconds
    
    // Event handlers
    const eventHandlers = {
        'connect': [],
        'disconnect': [],
        'device_update': [],
        'command_result': [],
        'error': [],
        'status': []
    };
    
    // Initialize WebSocket connection
    function initSocket() {
        // Determine WebSocket URL based on current location
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/socket.io/`;
        
        console.log('Connecting to WebSocket at:', wsUrl);
        
        try {
            // Close existing socket if necessary
            if (socket && socket.readyState !== WebSocket.CLOSED) {
                socket.close();
            }
            
            // Create new WebSocket connection
            socket = io({
                transports: ['websocket', 'polling'],
                reconnection: true,
                reconnectionAttempts: maxReconnectAttempts,
                reconnectionDelay: reconnectInterval,
                timeout: 20000
            });
            
            // Setup event handlers
            socket.on('connect', function() {
                console.log('WebSocket connected');
                reconnectAttempts = 0;
                triggerEvent('connect');
            });
            
            socket.on('disconnect', function() {
                console.log('WebSocket disconnected');
                triggerEvent('disconnect');
            });
            
            socket.on('device_update', function(data) {
                triggerEvent('device_update', data);
            });
            
            socket.on('command_result', function(data) {
                triggerEvent('command_result', data);
            });
            
            socket.on('error', function(data) {
                console.error('WebSocket error:', data);
                triggerEvent('error', data);
            });
            
            socket.on('status', function(data) {
                triggerEvent('status', data);
            });
            
            return true;
        } catch (error) {
            console.error('Error initializing WebSocket:', error);
            return false;
        }
    }
    
    // Function to trigger events to registered handlers
    function triggerEvent(eventName, data) {
        if (eventHandlers[eventName]) {
            eventHandlers[eventName].forEach(function(handler) {
                try {
                    handler(data);
                } catch (e) {
                    console.error(`Error in ${eventName} handler:`, e);
                }
            });
        }
    }
    
    // Register event handler
    function on(eventName, callback) {
        if (eventHandlers[eventName]) {
            eventHandlers[eventName].push(callback);
        } else {
            console.warn(`Unknown event type: ${eventName}`);
        }
        return this; // For chaining
    }
    
    // Send command to server
    function sendCommand(deviceId, command) {
        if (!socket || socket.disconnected) {
            console.error('Cannot send command: WebSocket disconnected');
            return false;
        }
        
        socket.emit('send_command', {
            device_id: deviceId,
            command: command
        });
        
        return true;
    }
    
    // Reconnect to WebSocket
    function reconnect() {
        if (reconnectAttempts >= maxReconnectAttempts) {
            console.error('Max reconnect attempts reached');
            return false;
        }
        
        reconnectAttempts++;
        setTimeout(function() {
            console.log(`Reconnect attempt ${reconnectAttempts}...`);
            initSocket();
        }, reconnectInterval);
        
        return true;
    }
    
    // Check if socket is connected
    function isConnected() {
        return socket && socket.connected;
    }
    
    // Expose the public API
    window.tarjonSocket = {
        init: initSocket,
        on: on,
        sendCommand: sendCommand,
        reconnect: reconnect,
        isConnected: isConnected
    };
})();