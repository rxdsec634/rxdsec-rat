import sqlite3
import os
from typing import Dict, List, Any, Optional, Union
import logging

# Configure logging
logger = logging.getLogger(__name__)

class Database:
    """Base database class for C2 server"""
    
    def __init__(self, db_file: str):
        """Initialize database connection"""
        self.db_file = db_file
        self._ensure_dir()
        self.connection = None
        self.cursor = None
    
    def _ensure_dir(self):
        """Ensure database directory exists"""
        db_dir = os.path.dirname(self.db_file)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir)
    
    def connect(self):
        """Connect to the database"""
        try:
            self.connection = sqlite3.connect(self.db_file)
            self.connection.row_factory = sqlite3.Row
            self.cursor = self.connection.cursor()
        except sqlite3.Error as e:
            logger.error(f"Database connection error: {e}")
            raise
    
    def disconnect(self):
        """Disconnect from the database"""
        if self.connection:
            self.connection.close()
            self.connection = None
            self.cursor = None
    
    def execute(self, query: str, params=()) -> sqlite3.Cursor:
        """Execute a query with parameters"""
        if not self.connection:
            self.connect()
        try:
            return self.cursor.execute(query, params)
        except sqlite3.Error as e:
            logger.error(f"Database query error: {e}")
            logger.error(f"Query: {query}, Params: {params}")
            raise
    
    def execute_many(self, query: str, params_list: List[tuple]) -> sqlite3.Cursor:
        """Execute a query with multiple parameter sets"""
        if not self.connection:
            self.connect()
        try:
            return self.cursor.executemany(query, params_list)
        except sqlite3.Error as e:
            logger.error(f"Database executemany error: {e}")
            raise
    
    def commit(self):
        """Commit changes to the database"""
        if self.connection:
            self.connection.commit()
    
    def rollback(self):
        """Rollback changes to the database"""
        if self.connection:
            self.connection.rollback()
    
    def fetch_one(self, query: str, params=()) -> Optional[Dict[str, Any]]:
        """Fetch a single row as a dictionary"""
        cursor = self.execute(query, params)
        row = cursor.fetchone()
        if row:
            return dict(row)
        return None
    
    def fetch_all(self, query: str, params=()) -> List[Dict[str, Any]]:
        """Fetch all rows as dictionaries"""
        cursor = self.execute(query, params)
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    def fetch_column(self, query: str, params=()) -> List[Any]:
        """Fetch a single column from all rows"""
        cursor = self.execute(query, params)
        return [row[0] for row in cursor.fetchall()]
    
    def get_last_row_id(self) -> int:
        """Get the row ID of the last insert"""
        if self.cursor:
            return self.cursor.lastrowid
        return -1