package com.tarjon.admin.utils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/**
 * Utility class for capturing screenshots and recording the screen.
 * Uses MediaProjection API for screen capture operations.
 */
public class ScreenCapture {

    private static final String TAG = "ScreenCapture";
    
    private Context context;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private MediaRecorder mediaRecorder;
    private ImageReader imageReader;
    
    private int width;
    private int height;
    private int density;
    private int resultCode;
    private Intent resultData;
    
    private boolean isRecording = false;
    private String currentRecordingPath;
    
    public ScreenCapture(Context context) {
        this.context = context;
        
        // Get display metrics
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        display.getMetrics(metrics);
        
        this.width = metrics.widthPixels;
        this.height = metrics.heightPixels;
        this.density = metrics.densityDpi;
    }
    
    /**
     * Set the media projection permission result
     * (Must be called from an activity after permission dialog)
     */
    public void setMediaProjectionResult(int resultCode, Intent resultData) {
        this.resultCode = resultCode;
        this.resultData = resultData;
    }
    
    /**
     * Capture a screenshot at specified resolution
     * @param resolution Resolution (720p, 360p, or original)
     * @return Path to saved screenshot or error message
     */
    public String captureScreenshot(String resolution) {
        if (resultCode == 0 || resultData == null) {
            return "Error: Media projection not available. Run the app and grant permissions first.";
        }
        
        // Adjust resolution if needed
        int captureWidth = width;
        int captureHeight = height;
        
        if (resolution.equals("720p")) {
            captureWidth = 720;
            captureHeight = 1280;
        } else if (resolution.equals("360p")) {
            captureWidth = 360;
            captureHeight = 640;
        }
        
        try {
            MediaProjectionManager projectionManager = 
                    (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            
            imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2);
            
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "screencapture",
                    captureWidth,
                    captureHeight,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    null
            );
            
            // Capture image with delay to ensure virtual display is ready
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    captureImageFromReader();
                }
            }, 300);
            
            // Wait for image capture
            Thread.sleep(500);
            
            // Return the path to the image
            return Environment.getExternalStorageDirectory().toString() + "/screenshot_" + 
                    new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
            
        } catch (Exception e) {
            Log.e(TAG, "Error capturing screenshot: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Capture image from the ImageReader
     */
    private void captureImageFromReader() {
        try {
            Image image = imageReader.acquireLatestImage();
            if (image != null) {
                try {
                    // Process the image
                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * width;
                    
                    // Create bitmap with the captured image data
                    Bitmap bitmap = Bitmap.createBitmap(
                            width + rowPadding / pixelStride,
                            height,
                            Bitmap.Config.ARGB_8888
                    );
                    bitmap.copyPixelsFromBuffer(buffer);
                    
                    // Save bitmap to file
                    String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                    String fileName = "screenshot_" + timestamp + ".jpg";
                    File file = new File(Environment.getExternalStorageDirectory(), fileName);
                    
                    FileOutputStream fos = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
                    fos.flush();
                    fos.close();
                    
                    // Log success
                    Log.d(TAG, "Screenshot saved: " + file.getAbsolutePath());
                    
                } finally {
                    // Always close the image
                    image.close();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error processing screenshot: " + e.getMessage());
        } finally {
            // Clean up
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
        }
    }
    
    /**
     * Start screen recording
     * @param durationSeconds Duration in seconds (or "0" for continuous)
     * @return Success message or error
     */
    public String startScreenRecording(String durationSeconds) {
        if (isRecording) {
            return "Error: Already recording";
        }
        
        if (resultCode == 0 || resultData == null) {
            return "Error: Media projection not available. Run the app and grant permissions first.";
        }
        
        int duration = 30; // Default duration
        try {
            duration = Integer.parseInt(durationSeconds);
        } catch (NumberFormatException e) {
            Log.e(TAG, "Invalid duration format: " + durationSeconds);
        }
        
        try {
            // Setup MediaRecorder
            mediaRecorder = new MediaRecorder();
            
            mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            
            // Create directory for recordings if it doesn't exist
            File recordingsDir = new File(Environment.getExternalStorageDirectory(), "recordings");
            if (!recordingsDir.exists()) {
                recordingsDir.mkdirs();
            }
            
            // Generate output file name
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            currentRecordingPath = recordingsDir.getAbsolutePath() + "/recording_" + timestamp + ".mp4";
            
            mediaRecorder.setOutputFile(currentRecordingPath);
            mediaRecorder.setVideoSize(width, height);
            mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            mediaRecorder.setVideoEncodingBitRate(5 * 1000000); // 5 Mbps
            mediaRecorder.setVideoFrameRate(30);
            
            mediaRecorder.prepare();
            
            // Create virtual display
            MediaProjectionManager projectionManager = 
                    (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "screenrecord",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    mediaRecorder.getSurface(),
                    null,
                    null
            );
            
            // Start recording
            mediaRecorder.start();
            isRecording = true;
            
            // Set up automatic stop if duration > 0
            if (duration > 0) {
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isRecording) {
                            stopScreenRecording();
                        }
                    }
                }, duration * 1000);
            }
            
            return "Recording started, saving to: " + currentRecordingPath;
            
        } catch (Exception e) {
            Log.e(TAG, "Error starting screen recording: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Stop screen recording
     * @return Success message or error
     */
    public String stopScreenRecording() {
        if (!isRecording) {
            return "Error: Not recording";
        }
        
        try {
            // Stop recording
            mediaRecorder.stop();
            mediaRecorder.reset();
            mediaRecorder.release();
            mediaRecorder = null;
            
            // Release virtual display
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            
            // Stop media projection
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
            
            isRecording = false;
            
            return "Recording stopped, saved to: " + currentRecordingPath;
            
        } catch (Exception e) {
            Log.e(TAG, "Error stopping screen recording: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
}
