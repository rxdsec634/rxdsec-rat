package com.tarjon.admin.utils;

import android.Manifest;
import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import androidx.core.app.ActivityCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.NetworkInterface;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * Collects device information and hardware details
 */
public class DeviceInfoCollector {
    private static final String TAG = "DeviceInfoCollector";
    
    private final Context context;
    
    public DeviceInfoCollector(Context context) {
        this.context = context;
    }
    
    /**
     * Collect all device information in a JSON object
     * @return JSONObject with all device information
     */
    public JSONObject collectAllDeviceInfo() throws JSONException {
        JSONObject deviceInfo = new JSONObject();
        
        // Basic device info
        deviceInfo.put("device", getDeviceInfo());
        
        // Network info
        deviceInfo.put("network", getNetworkInfo());
        
        // Software info
        deviceInfo.put("software", getSoftwareInfo());
        
        // Hardware info
        deviceInfo.put("hardware", getHardwareInfo());
        
        // Storage info
        deviceInfo.put("storage", getStorageInfo());
        
        // Battery info
        deviceInfo.put("battery", getBatteryInfo());
        
        // SIM info
        deviceInfo.put("sim", getSimInfo());
        
        // Sensor info
        deviceInfo.put("sensors", getSensorInfo());
        
        // Installed apps
        deviceInfo.put("installedApps", getInstalledApplications().getJSONArray("apps").length());
        
        // Root status
        deviceInfo.put("isRooted", isDeviceRooted());
        
        // Current timestamp
        deviceInfo.put("timestamp", System.currentTimeMillis());
        
        return deviceInfo;
    }
    
    /**
     * Get basic device information
     */
    private JSONObject getDeviceInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        // Basic device info
        info.put("manufacturer", Build.MANUFACTURER);
        info.put("brand", Build.BRAND);
        info.put("model", Build.MODEL);
        info.put("product", Build.PRODUCT);
        info.put("device", Build.DEVICE);
        info.put("board", Build.BOARD);
        info.put("hardware", Build.HARDWARE);
        info.put("serial", getSerialNumber());
        info.put("fingerprint", Build.FINGERPRINT);
        info.put("androidId", Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID));
        info.put("buildId", Build.ID);
        info.put("buildTime", Build.TIME);
        info.put("buildType", Build.TYPE);
        info.put("buildTags", Build.TAGS);
        info.put("buildUser", Build.USER);
        info.put("buildHost", Build.HOST);
        
        // Device identifiers
        info.put("imei", getImei());
        info.put("macAddress", getMacAddress());
        
        // Screen info
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(metrics);
        
        info.put("screenWidth", metrics.widthPixels);
        info.put("screenHeight", metrics.heightPixels);
        info.put("screenDensity", metrics.densityDpi);
        info.put("screenDensityDpi", metrics.density);
        
        // Language and locale info
        info.put("language", Locale.getDefault().getLanguage());
        info.put("country", Locale.getDefault().getCountry());
        info.put("locale", Locale.getDefault().toString());
        info.put("timezone", TimeZone.getDefault().getID());
        info.put("timezoneOffset", TimeZone.getDefault().getRawOffset() / 1000 / 60 / 60);
        
        return info;
    }
    
    /**
     * Get network information
     */
    private JSONObject getNetworkInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        // Connectivity status
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
        
        info.put("isConnected", isConnected);
        
        if (isConnected && activeNetwork != null) {
            info.put("type", activeNetwork.getTypeName());
            info.put("subtype", activeNetwork.getSubtypeName());
            info.put("state", activeNetwork.getState().toString());
            info.put("extraInfo", activeNetwork.getExtraInfo());
            info.put("isRoaming", activeNetwork.isRoaming());
            info.put("isFailover", activeNetwork.isFailover());
        }
        
        // IP addresses
        try {
            // Use web service to get external IP
            info.put("deviceIPs", getDeviceIpAddresses());
        } catch (Exception e) {
            info.put("deviceIPs", new JSONArray());
        }
        
        return info;
    }
    
    /**
     * Get software information
     */
    private JSONObject getSoftwareInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        // Android OS info
        info.put("androidVersion", Build.VERSION.RELEASE);
        info.put("apiLevel", Build.VERSION.SDK_INT);
        info.put("buildNumber", Build.DISPLAY);
        info.put("securityPatch", Build.VERSION.SECURITY_PATCH);
        
        // Kernel info
        try {
            Process process = Runtime.getRuntime().exec("uname -a");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }
            reader.close();
            process.waitFor();
            info.put("kernel", output.toString());
        } catch (Exception e) {
            info.put("kernel", "Unknown");
        }
        
        // CPU architecture
        info.put("cpuAbi", Build.SUPPORTED_ABIS[0]);
        JSONArray abis = new JSONArray();
        for (String abi : Build.SUPPORTED_ABIS) {
            abis.put(abi);
        }
        info.put("supportedAbis", abis);
        
        return info;
    }
    
    /**
     * Get hardware information
     */
    private JSONObject getHardwareInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        // CPU info
        try {
            info.put("cpuInfo", getCpuInfo());
        } catch (Exception e) {
            info.put("cpuInfo", new JSONObject());
        }
        
        // Memory info
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        
        info.put("totalMemory", memoryInfo.totalMem);
        info.put("availableMemory", memoryInfo.availMem);
        info.put("lowMemory", memoryInfo.lowMemory);
        info.put("threshold", memoryInfo.threshold);
        
        // Format memory for display
        info.put("totalMemoryFormatted", formatSize(memoryInfo.totalMem));
        info.put("availableMemoryFormatted", formatSize(memoryInfo.availMem));
        
        return info;
    }
    
    /**
     * Get storage information
     */
    private JSONObject getStorageInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        // Internal storage
        File internalPath = Environment.getDataDirectory();
        StatFs internalStats = new StatFs(internalPath.getPath());
        long internalBlockSize = internalStats.getBlockSizeLong();
        long internalTotalBlocks = internalStats.getBlockCountLong();
        long internalAvailableBlocks = internalStats.getAvailableBlocksLong();
        
        long internalTotalSize = internalBlockSize * internalTotalBlocks;
        long internalAvailableSize = internalBlockSize * internalAvailableBlocks;
        
        JSONObject internalStorage = new JSONObject();
        internalStorage.put("path", internalPath.getAbsolutePath());
        internalStorage.put("total", internalTotalSize);
        internalStorage.put("available", internalAvailableSize);
        internalStorage.put("totalFormatted", formatSize(internalTotalSize));
        internalStorage.put("availableFormatted", formatSize(internalAvailableSize));
        internalStorage.put("usagePercentage", 100 - ((internalAvailableSize * 100) / internalTotalSize));
        
        info.put("internal", internalStorage);
        
        // External storage (if available)
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File externalPath = Environment.getExternalStorageDirectory();
            StatFs externalStats = new StatFs(externalPath.getPath());
            long externalBlockSize = externalStats.getBlockSizeLong();
            long externalTotalBlocks = externalStats.getBlockCountLong();
            long externalAvailableBlocks = externalStats.getAvailableBlocksLong();
            
            long externalTotalSize = externalBlockSize * externalTotalBlocks;
            long externalAvailableSize = externalBlockSize * externalAvailableBlocks;
            
            JSONObject externalStorage = new JSONObject();
            externalStorage.put("path", externalPath.getAbsolutePath());
            externalStorage.put("total", externalTotalSize);
            externalStorage.put("available", externalAvailableSize);
            externalStorage.put("totalFormatted", formatSize(externalTotalSize));
            externalStorage.put("availableFormatted", formatSize(externalAvailableSize));
            externalStorage.put("usagePercentage", 100 - ((externalAvailableSize * 100) / externalTotalSize));
            
            info.put("external", externalStorage);
        } else {
            info.put("external", JSONObject.NULL);
        }
        
        // SD Card (if available)
        File[] externalFilesDirs = context.getExternalFilesDirs(null);
        if (externalFilesDirs.length > 1 && externalFilesDirs[1] != null) {
            try {
                File sdCardPath = externalFilesDirs[1];
                String path = sdCardPath.getAbsolutePath();
                
                // Get the root of SD card
                int index = path.indexOf("/Android/data");
                if (index > 0) {
                    path = path.substring(0, index);
                }
                
                StatFs sdCardStats = new StatFs(path);
                long sdCardBlockSize = sdCardStats.getBlockSizeLong();
                long sdCardTotalBlocks = sdCardStats.getBlockCountLong();
                long sdCardAvailableBlocks = sdCardStats.getAvailableBlocksLong();
                
                long sdCardTotalSize = sdCardBlockSize * sdCardTotalBlocks;
                long sdCardAvailableSize = sdCardBlockSize * sdCardAvailableBlocks;
                
                JSONObject sdCardStorage = new JSONObject();
                sdCardStorage.put("path", path);
                sdCardStorage.put("total", sdCardTotalSize);
                sdCardStorage.put("available", sdCardAvailableSize);
                sdCardStorage.put("totalFormatted", formatSize(sdCardTotalSize));
                sdCardStorage.put("availableFormatted", formatSize(sdCardAvailableSize));
                sdCardStorage.put("usagePercentage", 100 - ((sdCardAvailableSize * 100) / sdCardTotalSize));
                
                info.put("sdCard", sdCardStorage);
            } catch (Exception e) {
                info.put("sdCard", JSONObject.NULL);
            }
        } else {
            info.put("sdCard", JSONObject.NULL);
        }
        
        return info;
    }
    
    /**
     * Get battery information
     */
    private JSONObject getBatteryInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, filter);
        
        if (batteryStatus != null) {
            // Battery level
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            float batteryPct = level * 100 / (float) scale;
            
            info.put("level", batteryPct);
            info.put("raw_level", level);
            info.put("scale", scale);
            
            // Charging status
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || 
                    status == BatteryManager.BATTERY_STATUS_FULL;
            
            info.put("isCharging", isCharging);
            
            // How are we charging?
            int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
            boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
            boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;
            boolean wirelessCharge = false;
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                wirelessCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_WIRELESS;
            }
            
            info.put("usbCharge", usbCharge);
            info.put("acCharge", acCharge);
            info.put("wirelessCharge", wirelessCharge);
            
            // Battery health
            int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String healthString;
            
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    healthString = "Good";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    healthString = "Overheat";
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    healthString = "Dead";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    healthString = "Over Voltage";
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    healthString = "Unspecified Failure";
                    break;
                case BatteryManager.BATTERY_HEALTH_COLD:
                    healthString = "Cold";
                    break;
                default:
                    healthString = "Unknown";
                    break;
            }
            
            info.put("health", healthString);
            info.put("rawHealth", health);
            
            // Battery technology
            String technology = batteryStatus.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
            info.put("technology", technology != null ? technology : "Unknown");
            
            // Battery temperature
            int temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            float temperatureC = temperature / 10.0f;
            info.put("temperature", temperatureC);
            
            // Battery voltage
            int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            info.put("voltage", voltage);
        }
        
        return info;
    }
    
    /**
     * Get SIM card information
     */
    private JSONObject getSimInfo() throws JSONException {
        JSONObject info = new JSONObject();
        
        // Check permission
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != 
                PackageManager.PERMISSION_GRANTED) {
            info.put("permissionDenied", true);
            return info;
        }
        
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (tm != null) {
            // Basic SIM info
            info.put("operatorName", tm.getNetworkOperatorName());
            info.put("operatorCode", tm.getNetworkOperator());
            info.put("simOperatorName", tm.getSimOperatorName());
            info.put("simOperatorCode", tm.getSimOperator());
            info.put("simCountryIso", tm.getSimCountryIso());
            info.put("networkCountryIso", tm.getNetworkCountryIso());
            info.put("phoneType", getPhoneTypeName(tm.getPhoneType()));
            info.put("networkType", getNetworkTypeName(tm.getNetworkType()));
            info.put("isNetworkRoaming", tm.isNetworkRoaming());
            
            // SIM state
            int simState = tm.getSimState();
            String simStateStr;
            
            switch (simState) {
                case TelephonyManager.SIM_STATE_ABSENT:
                    simStateStr = "Absent";
                    break;
                case TelephonyManager.SIM_STATE_NETWORK_LOCKED:
                    simStateStr = "Network Locked";
                    break;
                case TelephonyManager.SIM_STATE_PIN_REQUIRED:
                    simStateStr = "PIN Required";
                    break;
                case TelephonyManager.SIM_STATE_PUK_REQUIRED:
                    simStateStr = "PUK Required";
                    break;
                case TelephonyManager.SIM_STATE_READY:
                    simStateStr = "Ready";
                    break;
                case TelephonyManager.SIM_STATE_UNKNOWN:
                    simStateStr = "Unknown";
                    break;
                default:
                    simStateStr = "Unknown";
                    break;
            }
            
            info.put("simState", simStateStr);
            info.put("rawSimState", simState);
            
            // Phone number (may be null on many devices)
            String phoneNumber = tm.getLine1Number();
            if (phoneNumber != null && !phoneNumber.isEmpty()) {
                info.put("phoneNumber", phoneNumber);
            } else {
                info.put("phoneNumber", "Unknown");
            }
            
            // IMSI (if available)
            String subscriberId = tm.getSubscriberId();
            if (subscriberId != null) {
                info.put("imsi", subscriberId);
            }
            
            // SIM serial (if available)
            String simSerial = tm.getSimSerialNumber();
            if (simSerial != null) {
                info.put("simSerial", simSerial);
            }
        }
        
        return info;
    }
    
    /**
     * Get sensor information
     */
    private JSONObject getSensorInfo() throws JSONException {
        JSONObject info = new JSONObject();
        JSONArray sensors = new JSONArray();
        
        SensorManager sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> deviceSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);
        
        for (Sensor sensor : deviceSensors) {
            JSONObject sensorInfo = new JSONObject();
            sensorInfo.put("name", sensor.getName());
            sensorInfo.put("vendor", sensor.getVendor());
            sensorInfo.put("type", sensor.getType());
            sensorInfo.put("typeName", getSensorTypeName(sensor.getType()));
            sensorInfo.put("version", sensor.getVersion());
            sensorInfo.put("power", sensor.getPower());
            sensorInfo.put("resolution", sensor.getResolution());
            sensorInfo.put("maxRange", sensor.getMaximumRange());
            
            sensors.put(sensorInfo);
        }
        
        info.put("count", deviceSensors.size());
        info.put("sensors", sensors);
        
        return info;
    }
    
    /**
     * Get information about installed applications
     * @return JSONObject with list of installed applications
     */
    public JSONObject getInstalledApplications() throws JSONException {
        JSONObject info = new JSONObject();
        JSONArray apps = new JSONArray();
        
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        
        for (ApplicationInfo appInfo : installedApps) {
            try {
                JSONObject app = new JSONObject();
                app.put("packageName", appInfo.packageName);
                app.put("name", pm.getApplicationLabel(appInfo).toString());
                app.put("isSystemApp", (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                
                // Get version info
                try {
                    PackageInfo packageInfo = pm.getPackageInfo(appInfo.packageName, 0);
                    app.put("versionName", packageInfo.versionName);
                    app.put("versionCode", packageInfo.versionCode);
                    app.put("firstInstallTime", packageInfo.firstInstallTime);
                    app.put("lastUpdateTime", packageInfo.lastUpdateTime);
                } catch (Exception e) {
                    app.put("versionName", "Unknown");
                    app.put("versionCode", 0);
                }
                
                // Get app icon
                /*
                try {
                    Drawable icon = pm.getApplicationIcon(appInfo.packageName);
                    // Convert to bitmap and Base64 if needed
                } catch (Exception e) {
                    // Icon not available
                }
                */
                
                apps.put(app);
            } catch (Exception e) {
                // Skip this app if there's an error
            }
        }
        
        info.put("count", apps.length());
        info.put("apps", apps);
        
        return info;
    }
    
    /**
     * Get detailed information about a specific package
     * @param packageName Package name to query
     * @return JSONObject with package details
     */
    public JSONObject getPackageInfo(String packageName) throws JSONException {
        JSONObject info = new JSONObject();
        
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = pm.getPackageInfo(packageName, 
                    PackageManager.GET_PERMISSIONS | 
                    PackageManager.GET_ACTIVITIES | 
                    PackageManager.GET_SERVICES | 
                    PackageManager.GET_RECEIVERS);
            
            ApplicationInfo appInfo = packageInfo.applicationInfo;
            
            // Basic info
            info.put("packageName", packageInfo.packageName);
            info.put("name", pm.getApplicationLabel(appInfo).toString());
            info.put("versionName", packageInfo.versionName);
            info.put("versionCode", packageInfo.versionCode);
            info.put("firstInstallTime", packageInfo.firstInstallTime);
            info.put("lastUpdateTime", packageInfo.lastUpdateTime);
            info.put("isSystemApp", (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
            
            // App paths
            info.put("sourceDir", appInfo.sourceDir);
            info.put("dataDir", appInfo.dataDir);
            
            // Permissions
            if (packageInfo.requestedPermissions != null) {
                JSONArray permissions = new JSONArray();
                for (String permission : packageInfo.requestedPermissions) {
                    permissions.put(permission);
                }
                info.put("permissions", permissions);
                info.put("permissionCount", permissions.length());
            } else {
                info.put("permissions", new JSONArray());
                info.put("permissionCount", 0);
            }
            
            // Activities
            if (packageInfo.activities != null) {
                JSONArray activities = new JSONArray();
                for (android.content.pm.ActivityInfo activity : packageInfo.activities) {
                    activities.put(activity.name);
                }
                info.put("activities", activities);
                info.put("activityCount", activities.length());
            } else {
                info.put("activities", new JSONArray());
                info.put("activityCount", 0);
            }
            
            // Services
            if (packageInfo.services != null) {
                JSONArray services = new JSONArray();
                for (android.content.pm.ServiceInfo service : packageInfo.services) {
                    services.put(service.name);
                }
                info.put("services", services);
                info.put("serviceCount", services.length());
            } else {
                info.put("services", new JSONArray());
                info.put("serviceCount", 0);
            }
            
            // Receivers
            if (packageInfo.receivers != null) {
                JSONArray receivers = new JSONArray();
                for (android.content.pm.ActivityInfo receiver : packageInfo.receivers) {
                    receivers.put(receiver.name);
                }
                info.put("receivers", receivers);
                info.put("receiverCount", receivers.length());
            } else {
                info.put("receivers", new JSONArray());
                info.put("receiverCount", 0);
            }
            
        } catch (Exception e) {
            info.put("error", "Could not get package info: " + e.getMessage());
        }
        
        return info;
    }
    
    /**
     * Get device contacts
     * @return JSONObject with contacts information
     */
    public JSONObject getContacts() throws JSONException {
        JSONObject info = new JSONObject();
        JSONArray contacts = new JSONArray();
        
        // Check permission
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != 
                PackageManager.PERMISSION_GRANTED) {
            info.put("permissionDenied", true);
            info.put("contacts", contacts);
            return info;
        }
        
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, 
                null, 
                null, 
                null, 
                null);
        
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                JSONObject contact = new JSONObject();
                
                String id = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                
                contact.put("id", id);
                contact.put("name", name);
                
                // Check for phone numbers
                if (Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    JSONArray phoneNumbers = new JSONArray();
                    
                    Cursor phoneCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id},
                            null);
                    
                    if (phoneCursor != null) {
                        while (phoneCursor.moveToNext()) {
                            JSONObject phoneInfo = new JSONObject();
                            
                            String phoneNumber = phoneCursor.getString(
                                    phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                            int phoneType = phoneCursor.getInt(
                                    phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE));
                            
                            phoneInfo.put("number", phoneNumber);
                            phoneInfo.put("type", getPhoneTypeLabel(phoneType));
                            
                            phoneNumbers.put(phoneInfo);
                        }
                        phoneCursor.close();
                    }
                    
                    contact.put("phoneNumbers", phoneNumbers);
                }
                
                // Check for email addresses
                JSONArray emailAddresses = new JSONArray();
                
                Cursor emailCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                        new String[]{id},
                        null);
                
                if (emailCursor != null) {
                    while (emailCursor.moveToNext()) {
                        JSONObject emailInfo = new JSONObject();
                        
                        String emailAddress = emailCursor.getString(
                                emailCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.DATA));
                        int emailType = emailCursor.getInt(
                                emailCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.TYPE));
                        
                        emailInfo.put("address", emailAddress);
                        emailInfo.put("type", getEmailTypeLabel(emailType));
                        
                        emailAddresses.put(emailInfo);
                    }
                    emailCursor.close();
                }
                
                contact.put("emailAddresses", emailAddresses);
                
                // Add contact to list
                contacts.put(contact);
            }
            
            cursor.close();
        }
        
        info.put("count", contacts.length());
        info.put("contacts", contacts);
        
        return info;
    }
    
    /**
     * Check if device is rooted
     * @return true if device has root access
     */
    public boolean isDeviceRooted() {
        return checkRootMethod1() || checkRootMethod2() || checkRootMethod3();
    }
    
    /**
     * Root check method 1: Check for su binary
     */
    private boolean checkRootMethod1() {
        String[] paths = { "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su",
                "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
                "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su" };
        
        for (String path : paths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Root check method 2: Try to execute su command
     */
    private boolean checkRootMethod2() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[] { "/system/xbin/which", "su" });
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return in.readLine() != null;
        } catch (Exception e) {
            return false;
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
    }
    
    /**
     * Root check method 3: Check for known root apps packages
     */
    private boolean checkRootMethod3() {
        PackageManager pm = context.getPackageManager();
        String[] rootApps = { "com.noshufou.android.su", "com.thirdparty.superuser",
                "eu.chainfire.supersu", "com.koushikdutta.superuser", "com.zachspong.temprootremovejb",
                "com.ramdroid.appquarantine" };
        
        for (String rootApp : rootApps) {
            try {
                pm.getPackageInfo(rootApp, 0);
                return true;
            } catch (PackageManager.NameNotFoundException e) {
                // Package not found, continue checking
            }
        }
        
        return false;
    }
    
    /**
     * Get device IP addresses
     */
    private JSONArray getDeviceIpAddresses() throws JSONException {
        JSONArray addresses = new JSONArray();
        
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<java.net.InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (java.net.InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        
                        if (isIPv4) {
                            JSONObject addrInfo = new JSONObject();
                            addrInfo.put("address", sAddr);
                            addrInfo.put("interface", intf.getName());
                            addrInfo.put("displayName", intf.getDisplayName());
                            addrInfo.put("type", "IPv4");
                            addresses.put(addrInfo);
                        } else {
                            // For IPv6, exclude link-local addresses
                            int delim = sAddr.indexOf('%');
                            String scopeId = delim < 0 ? "" : sAddr.substring(delim);
                            String cleanAddr = delim < 0 ? sAddr : sAddr.substring(0, delim);
                            
                            if (!cleanAddr.startsWith("fe80")) {
                                JSONObject addrInfo = new JSONObject();
                                addrInfo.put("address", cleanAddr);
                                addrInfo.put("interface", intf.getName());
                                addrInfo.put("displayName", intf.getDisplayName());
                                addrInfo.put("type", "IPv6");
                                addrInfo.put("scopeId", scopeId);
                                addresses.put(addrInfo);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            // Failed to get network interfaces
        }
        
        return addresses;
    }
    
    /**
     * Get CPU information from /proc/cpuinfo
     */
    private JSONObject getCpuInfo() throws JSONException, IOException {
        JSONObject info = new JSONObject();
        Map<String, String> cpuInfo = new HashMap<>();
        
        BufferedReader reader = new BufferedReader(new FileReader("/proc/cpuinfo"));
        String line;
        
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(":", 2);
            if (parts.length == 2) {
                String key = parts[0].trim();
                String value = parts[1].trim();
                cpuInfo.put(key, value);
            }
        }
        
        reader.close();
        
        // Parse the CPU info
        info.put("processor", cpuInfo.getOrDefault("Processor", "Unknown"));
        info.put("hardware", cpuInfo.getOrDefault("Hardware", "Unknown"));
        info.put("cores", Runtime.getRuntime().availableProcessors());
        
        // Additional CPU details if available
        if (cpuInfo.containsKey("model name")) {
            info.put("model", cpuInfo.get("model name"));
        }
        
        if (cpuInfo.containsKey("cpu MHz")) {
            info.put("frequency", cpuInfo.get("cpu MHz") + " MHz");
        }
        
        if (cpuInfo.containsKey("Features")) {
            JSONArray features = new JSONArray();
            for (String feature : cpuInfo.get("Features").split(" ")) {
                features.put(feature);
            }
            info.put("features", features);
        }
        
        return info;
    }
    
    /**
     * Get device serial number (requires READ_PHONE_STATE permission)
     */
    private String getSerialNumber() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != 
                PackageManager.PERMISSION_GRANTED) {
            return "Permission Denied";
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return Build.getSerial();
        } else {
            return Build.SERIAL;
        }
    }
    
    /**
     * Get device IMEI (requires READ_PHONE_STATE permission)
     */
    private String getImei() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != 
                PackageManager.PERMISSION_GRANTED) {
            return "Permission Denied";
        }
        
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (tm == null) {
            return "Not Available";
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                return tm.getImei();
            } catch (Exception e) {
                return "Not Available";
            }
        } else {
            try {
                return tm.getDeviceId();
            } catch (Exception e) {
                return "Not Available";
            }
        }
    }
    
    /**
     * Get MAC address of the device
     */
    private String getMacAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                if (!intf.getName().equalsIgnoreCase("wlan0")) {
                    continue;
                }
                
                byte[] mac = intf.getHardwareAddress();
                if (mac == null) {
                    return "Not Available";
                }
                
                StringBuilder buf = new StringBuilder();
                for (byte b : mac) {
                    buf.append(String.format("%02X:", b));
                }
                
                if (buf.length() > 0) {
                    buf.deleteCharAt(buf.length() - 1);
                }
                
                return buf.toString();
            }
        } catch (Exception e) {
            // Ignore
        }
        
        return "Not Available";
    }
    
    /**
     * Get phone type name from constant
     */
    private String getPhoneTypeName(int phoneType) {
        switch (phoneType) {
            case TelephonyManager.PHONE_TYPE_NONE:
                return "None";
            case TelephonyManager.PHONE_TYPE_GSM:
                return "GSM";
            case TelephonyManager.PHONE_TYPE_CDMA:
                return "CDMA";
            case TelephonyManager.PHONE_TYPE_SIP:
                return "SIP";
            default:
                return "Unknown";
        }
    }
    
    /**
     * Get network type name from constant
     */
    private String getNetworkTypeName(int networkType) {
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_GPRS:
                return "GPRS";
            case TelephonyManager.NETWORK_TYPE_EDGE:
                return "EDGE";
            case TelephonyManager.NETWORK_TYPE_UMTS:
                return "UMTS";
            case TelephonyManager.NETWORK_TYPE_HSDPA:
                return "HSDPA";
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                return "HSUPA";
            case TelephonyManager.NETWORK_TYPE_HSPA:
                return "HSPA";
            case TelephonyManager.NETWORK_TYPE_CDMA:
                return "CDMA";
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
                return "EVDO_0";
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
                return "EVDO_A";
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
                return "EVDO_B";
            case TelephonyManager.NETWORK_TYPE_1xRTT:
                return "1xRTT";
            case TelephonyManager.NETWORK_TYPE_IDEN:
                return "IDEN";
            case TelephonyManager.NETWORK_TYPE_LTE:
                return "LTE";
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                return "EHRPD";
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                return "HSPAP";
            case TelephonyManager.NETWORK_TYPE_GSM:
                return "GSM";
            case TelephonyManager.NETWORK_TYPE_TD_SCDMA:
                return "TD_SCDMA";
            case TelephonyManager.NETWORK_TYPE_IWLAN:
                return "IWLAN";
            default:
                return "Unknown";
        }
    }
    
    /**
     * Get sensor type name from constant
     */
    private String getSensorTypeName(int sensorType) {
        switch (sensorType) {
            case Sensor.TYPE_ACCELEROMETER:
                return "Accelerometer";
            case Sensor.TYPE_AMBIENT_TEMPERATURE:
                return "Ambient Temperature";
            case Sensor.TYPE_GRAVITY:
                return "Gravity";
            case Sensor.TYPE_GYROSCOPE:
                return "Gyroscope";
            case Sensor.TYPE_LIGHT:
                return "Light";
            case Sensor.TYPE_LINEAR_ACCELERATION:
                return "Linear Acceleration";
            case Sensor.TYPE_MAGNETIC_FIELD:
                return "Magnetic Field";
            case Sensor.TYPE_PRESSURE:
                return "Pressure";
            case Sensor.TYPE_PROXIMITY:
                return "Proximity";
            case Sensor.TYPE_RELATIVE_HUMIDITY:
                return "Relative Humidity";
            case Sensor.TYPE_ROTATION_VECTOR:
                return "Rotation Vector";
            case Sensor.TYPE_STEP_COUNTER:
                return "Step Counter";
            case Sensor.TYPE_STEP_DETECTOR:
                return "Step Detector";
            default:
                return "Unknown";
        }
    }
    
    /**
     * Get phone type label from constant
     */
    private String getPhoneTypeLabel(int phoneType) {
        switch (phoneType) {
            case ContactsContract.CommonDataKinds.Phone.TYPE_HOME:
                return "Home";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE:
                return "Mobile";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK:
                return "Work";
            case ContactsContract.CommonDataKinds.Phone.TYPE_FAX_WORK:
                return "Work Fax";
            case ContactsContract.CommonDataKinds.Phone.TYPE_FAX_HOME:
                return "Home Fax";
            case ContactsContract.CommonDataKinds.Phone.TYPE_PAGER:
                return "Pager";
            case ContactsContract.CommonDataKinds.Phone.TYPE_OTHER:
                return "Other";
            case ContactsContract.CommonDataKinds.Phone.TYPE_CALLBACK:
                return "Callback";
            case ContactsContract.CommonDataKinds.Phone.TYPE_CAR:
                return "Car";
            case ContactsContract.CommonDataKinds.Phone.TYPE_COMPANY_MAIN:
                return "Company Main";
            case ContactsContract.CommonDataKinds.Phone.TYPE_ISDN:
                return "ISDN";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MAIN:
                return "Main";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK_MOBILE:
                return "Work Mobile";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK_PAGER:
                return "Work Pager";
            case ContactsContract.CommonDataKinds.Phone.TYPE_ASSISTANT:
                return "Assistant";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MMS:
                return "MMS";
            default:
                return "Custom";
        }
    }
    
    /**
     * Get email type label from constant
     */
    private String getEmailTypeLabel(int emailType) {
        switch (emailType) {
            case ContactsContract.CommonDataKinds.Email.TYPE_HOME:
                return "Home";
            case ContactsContract.CommonDataKinds.Email.TYPE_WORK:
                return "Work";
            case ContactsContract.CommonDataKinds.Email.TYPE_OTHER:
                return "Other";
            case ContactsContract.CommonDataKinds.Email.TYPE_MOBILE:
                return "Mobile";
            default:
                return "Custom";
        }
    }
    
    /**
     * Format file size for human readability
     */
    private String formatSize(long size) {
        if (size <= 0) {
            return "0 B";
        }
        
        final String[] units = new String[] { "B", "KB", "MB", "GB", "TB" };
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + 
                " " + units[digitGroups];
    }
    
    /**
     * Get battery level (0-100)
     */
    public float getBatteryLevel() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, filter);
        
        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            
            return level * 100 / (float) scale;
        }
        
        return 0.0f;
    }
    
    /**
     * Check if device is charging
     */
    public boolean isCharging() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, filter);
        
        if (batteryStatus != null) {
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            return status == BatteryManager.BATTERY_STATUS_CHARGING || 
                    status == BatteryManager.BATTERY_STATUS_FULL;
        }
        
        return false;
    }
}