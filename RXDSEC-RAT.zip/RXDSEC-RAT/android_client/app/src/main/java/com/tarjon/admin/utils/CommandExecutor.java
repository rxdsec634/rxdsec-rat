package com.tarjon.admin.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/**
 * Utility class for executing shell commands on the device.
 * Provides a way to run system commands and ADB-like functionality.
 */
public class CommandExecutor {

    private static final String TAG = "CommandExecutor";
    private Context context;

    public CommandExecutor(Context context) {
        this.context = context;
    }

    /**
     * Execute a shell command and return the output
     * @param command The command to execute
     * @return The command output or error message
     */
    public String executeShellCommand(String command) {
        Log.d(TAG, "Executing command: " + command);
        
        StringBuilder output = new StringBuilder();
        Process process = null;
        
        try {
            // Execute the command in a process
            process = Runtime.getRuntime().exec("sh");
            DataOutputStream os = new DataOutputStream(process.getOutputStream());
            
            // Write the command to the shell
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            
            // Read command output
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            // Read error output if command failed
            if (process.waitFor(10, TimeUnit.SECONDS) && process.exitValue() != 0) {
                output.append("---- ERROR OUTPUT ----\n");
                while ((line = errorReader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            
        } catch (IOException | InterruptedException e) {
            Log.e(TAG, "Error executing command: " + e.getMessage());
            output.append("Error: ").append(e.getMessage());
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        
        return output.toString();
    }
    
    /**
     * Execute ADB-like commands that may require special permissions
     * @param command The ADB-like command to execute
     * @return The command result or error message
     */
    public String executeAdbCommand(String command) {
        Log.d(TAG, "Executing ADB command: " + command);
        
        if (command.startsWith("am start")) {
            return executeAmStart(command);
        } else if (command.startsWith("input")) {
            return executeInputCommand(command);
        } else if (command.startsWith("pm")) {
            return executePmCommand(command);
        } else {
            // Fall back to regular shell execution for other commands
            return executeShellCommand(command);
        }
    }
    
    /**
     * Execute an 'am start' command to launch an app or activity
     */
    private String executeAmStart(String command) {
        try {
            // Parse the command to extract package or component
            String[] parts = command.split(" ");
            String packageOrComponent = "";
            
            for (int i = 0; i < parts.length; i++) {
                if (parts[i].equals("-n")) {
                    if (i + 1 < parts.length) {
                        packageOrComponent = parts[i + 1];
                        break;
                    }
                }
            }
            
            if (!packageOrComponent.isEmpty()) {
                // Launch the specified activity or app
                Intent intent = new Intent();
                
                if (packageOrComponent.contains("/")) {
                    // Component specification (package/activity)
                    intent.setClassName(
                            packageOrComponent.substring(0, packageOrComponent.indexOf("/")),
                            packageOrComponent
                    );
                } else {
                    // Just a package name
                    intent.setPackage(packageOrComponent);
                    intent = context.getPackageManager().getLaunchIntentForPackage(packageOrComponent);
                }
                
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    return "Activity started: " + packageOrComponent;
                } else {
                    return "Error: Could not create intent for " + packageOrComponent;
                }
            } else {
                return "Error: Could not parse am start command";
            }
        } catch (Exception e) {
            Log.e(TAG, "Error executing am start: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Execute an 'input' command to simulate user input
     */
    private String executeInputCommand(String command) {
        // This would require Accessibility Service or other permissions
        // Not directly executable without those permissions
        return "Input commands require Accessibility Service to be enabled";
    }
    
    /**
     * Execute a 'pm' command to manage packages
     */
    private String executePmCommand(String command) {
        String[] parts = command.split(" ");
        
        if (parts.length < 3) {
            return "Error: Invalid pm command format";
        }
        
        String operation = parts[1];
        String packageName = parts[2];
        
        if ("disable".equals(operation)) {
            return disablePackage(packageName);
        } else if ("enable".equals(operation)) {
            return enablePackage(packageName);
        } else if ("uninstall".equals(operation)) {
            return uninstallPackage(packageName);
        } else {
            // Other pm commands may not be directly executable
            return executeShellCommand(command);
        }
    }
    
    /**
     * Disable a package
     */
    private String disablePackage(String packageName) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                boolean success = context.getPackageManager().setApplicationEnabledSetting(
                        packageName,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER,
                        0
                );
                return success ? "Package disabled: " + packageName : "Failed to disable package";
            } else {
                return "This operation requires Android N or higher";
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Enable a package
     */
    private String enablePackage(String packageName) {
        try {
            boolean success = context.getPackageManager().setApplicationEnabledSetting(
                    packageName,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    0
            );
            return success ? "Package enabled: " + packageName : "Failed to enable package";
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Uninstall a package
     */
    private String uninstallPackage(String packageName) {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE);
            intent.setData(Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return "Uninstall dialog opened for: " + packageName;
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Open device settings for a specific action
     */
    public void openSettings(String settingAction) {
        try {
            Intent intent = new Intent(settingAction);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening settings: " + e.getMessage());
        }
    }
}
