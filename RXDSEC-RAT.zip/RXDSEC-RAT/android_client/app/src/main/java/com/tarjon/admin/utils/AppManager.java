package com.tarjon.admin.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for managing applications on the device.
 * Provides functionality to list, install, uninstall, and manage apps.
 */
public class AppManager {

    private static final String TAG = "AppManager";
    
    private Context context;
    
    public AppManager(Context context) {
        this.context = context;
    }
    
    /**
     * List all installed applications on the device
     * @param includeSystemApps Whether to include system apps
     * @return JSON array of installed apps
     */
    public JSONArray listInstalledApps(boolean includeSystemApps) {
        JSONArray appsArray = new JSONArray();
        
        try {
            PackageManager packageManager = context.getPackageManager();
            List<PackageInfo> installedPackages = packageManager.getInstalledPackages(0);
            
            for (PackageInfo packageInfo : installedPackages) {
                // Skip system apps if not requested
                if (!includeSystemApps && (packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
                    continue;
                }
                
                JSONObject appInfo = new JSONObject();
                appInfo.put("package_name", packageInfo.packageName);
                appInfo.put("version_name", packageInfo.versionName);
                appInfo.put("version_code", packageInfo.versionCode);
                appInfo.put("app_name", packageInfo.applicationInfo.loadLabel(packageManager).toString());
                appInfo.put("is_system_app", (packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                
                // Get additional info
                appInfo.put("first_install_time", packageInfo.firstInstallTime);
                appInfo.put("last_update_time", packageInfo.lastUpdateTime);
                
                // Check if app is enabled
                appInfo.put("enabled", packageInfo.applicationInfo.enabled);
                
                appsArray.put(appInfo);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error listing installed apps: " + e.getMessage());
        }
        
        return appsArray;
    }
    
    /**
     * Install APK file from a given path
     * @param apkFilePath Path to the APK file
     * @return Result message
     */
    public String installApp(String apkFilePath) {
        try {
            File apkFile = new File(apkFilePath);
            if (!apkFile.exists()) {
                return "Error: APK file not found at " + apkFilePath;
            }
            
            // Method depends on Android version
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // Use PackageInstaller for Android N and above
                return installPackageN(apkFilePath);
            } else {
                // Use traditional method for older versions
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return "Installation dialog opened for " + apkFilePath;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error installing app: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Install package using the PackageInstaller API (Android N+)
     */
    private String installPackageN(String apkFilePath) throws IOException {
        PackageInstaller packageInstaller = context.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        
        // Create a new session
        int sessionId = packageInstaller.createSession(params);
        PackageInstaller.Session session = packageInstaller.openSession(sessionId);
        
        // Copy APK data to session
        InputStream in = new FileInputStream(apkFilePath);
        OutputStream out = session.openWrite("package", 0, -1);
        
        byte[] buffer = new byte[65536];
        int c;
        while ((c = in.read(buffer)) != -1) {
            out.write(buffer, 0, c);
        }
        
        session.fsync(out);
        in.close();
        out.close();
        
        // Create intent for installation result
        Intent intent = new Intent(context, AppInstallReceiver.class);
        intent.setAction("INSTALL_COMPLETE");
        
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, 
                sessionId, 
                intent, 
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
        );
        
        // Commit the session
        session.commit(pendingIntent.getIntentSender());
        
        return "Installing " + apkFilePath + " (session ID: " + sessionId + ")";
    }
    
    /**
     * Uninstall an application
     * @param packageName Package name to uninstall
     * @return Result message
     */
    public String uninstallApp(String packageName) {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE);
            intent.setData(Uri.parse("package:" + packageName));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            
            return "Uninstall dialog opened for " + packageName;
        } catch (Exception e) {
            Log.e(TAG, "Error uninstalling app: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Launch an application by package name
     * @param packageName Package name to launch
     * @return Result message
     */
    public String launchApp(String packageName) {
        try {
            PackageManager packageManager = context.getPackageManager();
            Intent launchIntent = packageManager.getLaunchIntentForPackage(packageName);
            
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launchIntent);
                return "Launched " + packageName;
            } else {
                return "Error: No launchable activity found for " + packageName;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error launching app: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Close/kill an application by package name
     * @param packageName Package name to close
     * @return Result message
     */
    public String closeApp(String packageName) {
        try {
            ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KILLBACKGROUND_PROCESS) {
                activityManager.killBackgroundProcesses(packageName);
                return "Sent kill signal to " + packageName;
            } else {
                // Older method (deprecated)
                activityManager.killBackgroundProcesses(packageName);
                return "Sent kill signal to " + packageName + " (legacy method)";
            }
        } catch (Exception e) {
            Log.e(TAG, "Error closing app: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Enable or disable an application
     * @param packageName Package name to enable/disable
     * @param enable True to enable, false to disable
     * @return Result message
     */
    public String setAppEnabled(String packageName, boolean enable) {
        try {
            PackageManager packageManager = context.getPackageManager();
            
            int newState = enable ? 
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED : 
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER;
            
            packageManager.setApplicationEnabledSetting(
                    packageName, 
                    newState, 
                    0
            );
            
            return (enable ? "Enabled " : "Disabled ") + packageName;
        } catch (Exception e) {
            Log.e(TAG, "Error setting app enabled state: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Get a list of running apps and processes
     * @return JSON array of running apps
     */
    public JSONArray getRunningApps() {
        JSONArray runningApps = new JSONArray();
        
        try {
            ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager packageManager = context.getPackageManager();
            
            // Get running processes
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
            
            if (runningProcesses != null) {
                for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                    JSONObject process = new JSONObject();
                    process.put("pid", processInfo.pid);
                    process.put("process_name", processInfo.processName);
                    
                    // Try to get app name
                    try {
                        ApplicationInfo appInfo = packageManager.getApplicationInfo(processInfo.processName, 0);
                        process.put("app_name", packageManager.getApplicationLabel(appInfo).toString());
                    } catch (Exception e) {
                        process.put("app_name", "Unknown");
                    }
                    
                    process.put("importance", getImportanceString(processInfo.importance));
                    
                    // Add all packages in this process
                    JSONArray packages = new JSONArray();
                    if (processInfo.pkgList != null) {
                        for (String pkg : processInfo.pkgList) {
                            packages.put(pkg);
                        }
                    }
                    process.put("packages", packages);
                    
                    runningApps.put(process);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting running apps: " + e.getMessage());
        }
        
        return runningApps;
    }
    
    /**
     * Convert ActivityManager importance value to a readable string
     */
    private String getImportanceString(int importance) {
        switch (importance) {
            case ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND:
                return "foreground";
            case ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE:
                return "visible";
            case ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE:
                return "service";
            case ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND:
                return "background";
            case ActivityManager.RunningAppProcessInfo.IMPORTANCE_EMPTY:
                return "empty";
            default:
                return "unknown";
        }
    }
    
    /**
     * Clear app data for a specific package
     * @param packageName Package name to clear
     * @return Result message
     */
    public String clearAppData(String packageName) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
                activityManager.clearApplicationUserData(packageName, null);
                return "Requested to clear data for " + packageName;
            } else {
                // For older Android versions, use intent to open app settings
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + packageName));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return "Opened settings for " + packageName + ". Please clear data manually.";
            }
        } catch (Exception e) {
            Log.e(TAG, "Error clearing app data: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Broadcast receiver for package installation results
     */
    public static class AppInstallReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("INSTALL_COMPLETE".equals(intent.getAction())) {
                int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                String message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                
                if (status == PackageInstaller.STATUS_SUCCESS) {
                    Log.d(TAG, "Installation succeeded");
                } else {
                    Log.e(TAG, "Installation failed: " + message);
                }
            }
        }
    }
}
