package com.tarjon.admin.utils;

import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Manages encryption and decryption operations for secure data transmission
 * and storage in the RAT.
 */
public class EncryptionManager {

    private static final String TAG = "EncryptionManager";
    
    // Encryption constants
    private static final String ALGORITHM = "AES";
    private static final String CIPHER_TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int GCM_TAG_LENGTH = 128; // bits
    private static final int KEY_SIZE = 256; // bits
    private static final int IV_LENGTH = 12; // bytes
    
    // Pre-shared key for deriving the encryption key
    private static final String PRE_SHARED_KEY = "tarjon_rat_secure_key_2023"; // This would be customized for each deployment
    
    // Cached encryption key
    private SecretKey encryptionKey;
    
    /**
     * Initialize the EncryptionManager
     */
    public EncryptionManager() {
        try {
            // Derive the encryption key from the pre-shared key
            this.encryptionKey = deriveKeyFromPreSharedKey(PRE_SHARED_KEY);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing encryption manager: " + e.getMessage(), e);
            // Generate a random key as fallback
            this.encryptionKey = generateRandomKey();
        }
    }
    
    /**
     * Encrypt a string
     * @param plaintext Text to encrypt
     * @return Base64-encoded encrypted string with IV prepended
     */
    public String encrypt(String plaintext) {
        try {
            // Generate random IV
            byte[] iv = new byte[IV_LENGTH];
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.nextBytes(iv);
            
            // Initialize cipher with GCM mode
            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.ENCRYPT_MODE, encryptionKey, gcmParameterSpec);
            
            // Encrypt
            byte[] plaintextBytes = plaintext.getBytes(StandardCharsets.UTF_8);
            byte[] encryptedBytes = cipher.doFinal(plaintextBytes);
            
            // Combine IV and encrypted data
            byte[] combined = new byte[iv.length + encryptedBytes.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(encryptedBytes, 0, combined, iv.length, encryptedBytes.length);
            
            // Return as Base64
            return Base64.encodeToString(combined, Base64.NO_WRAP);
            
        } catch (Exception e) {
            Log.e(TAG, "Encryption error: " + e.getMessage(), e);
            return plaintext; // Return original text on error
        }
    }
    
    /**
     * Decrypt a string
     * @param ciphertext Base64-encoded encrypted string with IV prepended
     * @return Original plaintext
     */
    public String decrypt(String ciphertext) {
        try {
            // Decode from Base64
            byte[] combined = Base64.decode(ciphertext, Base64.NO_WRAP);
            
            // Extract IV
            byte[] iv = new byte[IV_LENGTH];
            System.arraycopy(combined, 0, iv, 0, iv.length);
            
            // Extract encrypted data
            byte[] encryptedBytes = new byte[combined.length - iv.length];
            System.arraycopy(combined, iv.length, encryptedBytes, 0, encryptedBytes.length);
            
            // Initialize cipher with GCM mode
            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.DECRYPT_MODE, encryptionKey, gcmParameterSpec);
            
            // Decrypt
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            
            // Return as string
            return new String(decryptedBytes, StandardCharsets.UTF_8);
            
        } catch (Exception e) {
            Log.e(TAG, "Decryption error: " + e.getMessage(), e);
            return ciphertext; // Return original text on error
        }
    }
    
    /**
     * Encrypt data with a specific key
     * @param data Data to encrypt
     * @param key Encryption key
     * @return Encrypted data with IV prepended
     */
    public byte[] encryptWithKey(byte[] data, SecretKey key) {
        try {
            // Generate random IV
            byte[] iv = new byte[IV_LENGTH];
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.nextBytes(iv);
            
            // Initialize cipher with GCM mode
            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);
            
            // Encrypt
            byte[] encryptedBytes = cipher.doFinal(data);
            
            // Combine IV and encrypted data
            byte[] combined = new byte[iv.length + encryptedBytes.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(encryptedBytes, 0, combined, iv.length, encryptedBytes.length);
            
            return combined;
            
        } catch (NoSuchAlgorithmException | NoSuchPaddingException |
                InvalidKeyException | InvalidAlgorithmParameterException |
                IllegalBlockSizeException | BadPaddingException e) {
            Log.e(TAG, "Error encrypting with key: " + e.getMessage(), e);
            return data; // Return original data on error
        }
    }
    
    /**
     * Decrypt data with a specific key
     * @param combined Encrypted data with IV prepended
     * @param key Decryption key
     * @return Original data
     */
    public byte[] decryptWithKey(byte[] combined, SecretKey key) {
        try {
            // Extract IV
            byte[] iv = new byte[IV_LENGTH];
            System.arraycopy(combined, 0, iv, 0, iv.length);
            
            // Extract encrypted data
            byte[] encryptedBytes = new byte[combined.length - iv.length];
            System.arraycopy(combined, iv.length, encryptedBytes, 0, encryptedBytes.length);
            
            // Initialize cipher with GCM mode
            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
            
            // Decrypt
            return cipher.doFinal(encryptedBytes);
            
        } catch (NoSuchAlgorithmException | NoSuchPaddingException |
                InvalidKeyException | InvalidAlgorithmParameterException |
                IllegalBlockSizeException | BadPaddingException e) {
            Log.e(TAG, "Error decrypting with key: " + e.getMessage(), e);
            return combined; // Return original data on error
        }
    }
    
    /**
     * Generate a random encryption key
     * @return Random SecretKey
     */
    public SecretKey generateRandomKey() {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
            keyGenerator.init(KEY_SIZE);
            return keyGenerator.generateKey();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error generating random key: " + e.getMessage(), e);
            
            // Fallback to a pre-generated key
            byte[] keyBytes = new byte[KEY_SIZE / 8];
            new SecureRandom().nextBytes(keyBytes);
            return new SecretKeySpec(keyBytes, ALGORITHM);
        }
    }
    
    /**
     * Derive an encryption key from the pre-shared key
     * @param preSharedKey String to derive key from
     * @return SecretKey derived from the pre-shared key
     */
    private SecretKey deriveKeyFromPreSharedKey(String preSharedKey) throws NoSuchAlgorithmException {
        // Use SHA-256 to get a fixed-length key
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] keyBytes = digest.digest(preSharedKey.getBytes(StandardCharsets.UTF_8));
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }
    
    /**
     * Get the current encryption key
     * @return Current SecretKey
     */
    public SecretKey getEncryptionKey() {
        return encryptionKey;
    }
    
    /**
     * Set a custom encryption key
     * @param key New SecretKey
     */
    public void setEncryptionKey(SecretKey key) {
        this.encryptionKey = key;
    }
    
    /**
     * Set a custom encryption key from bytes
     * @param keyBytes Raw key bytes
     */
    public void setEncryptionKey(byte[] keyBytes) {
        this.encryptionKey = new SecretKeySpec(keyBytes, ALGORITHM);
    }
    
    /**
     * Change the pre-shared key and update the encryption key
     * @param newPreSharedKey New pre-shared key
     * @return Success or failure
     */
    public boolean changePreSharedKey(String newPreSharedKey) {
        try {
            this.encryptionKey = deriveKeyFromPreSharedKey(newPreSharedKey);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error changing pre-shared key: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Generate a secure hash of data
     * @param data Data to hash
     * @return Base64-encoded hash
     */
    public String generateHash(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hashBytes, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error generating hash: " + e.getMessage(), e);
            return "";
        }
    }
    
    /**
     * Check if encryption is working properly
     * @return True if encryption is working
     */
    public boolean testEncryption() {
        try {
            String testString = "Test encryption functionality";
            String encrypted = encrypt(testString);
            String decrypted = decrypt(encrypted);
            return testString.equals(decrypted);
        } catch (Exception e) {
            Log.e(TAG, "Encryption test failed: " + e.getMessage(), e);
            return false;
        }
    }
}