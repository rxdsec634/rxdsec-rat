package com.tarjon.admin.crypto;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.MGF1ParameterSpec;
import java.util.Arrays;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.SecretKeySpec;

/**
 * Advanced encryption manager that significantly improves upon CraxRAT's encryption capabilities
 * with multi-layer encryption, key rotation, and post-quantum considerations.
 */
public class AdvancedEncryptionManager {
    private static final String TAG = "AdvancedCrypto";
    private static AdvancedEncryptionManager instance;
    
    // Algorithms
    private static final String AES_GCM_ALGORITHM = "AES/GCM/NoPadding";
    private static final String AES_CTR_ALGORITHM = "AES/CTR/NoPadding";
    private static final String RSA_ALGORITHM = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
    private static final String HMAC_ALGORITHM = "HmacSHA384";
    
    // Key specs
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String RSA_KEY_ALIAS = "com.tarjon.admin.RSA_KEY";
    private static final String AES_KEY_ALIAS = "com.tarjon.admin.AES_KEY";
    
    // Constants
    private static final int GCM_TAG_LENGTH = 128;
    private static final int GCM_IV_LENGTH = 12;
    private static final int AES_KEY_SIZE = 256;
    private static final int RSA_KEY_SIZE = 3072; // Larger than standard for future-proofing
    
    // Preference keys
    private static final String PREFS_NAME = "com.tarjon.admin.crypto.prefs";
    private static final String KEY_ROTATION_TIME = "key_rotation_timestamp";
    private static final String CURRENT_KEY_ID = "current_key_id";
    
    // Settings
    private static final long KEY_ROTATION_PERIOD = TimeUnit.DAYS.toMillis(7); // Rotate keys weekly
    
    private final Context context;
    private final SecureRandom secureRandom;
    private final SharedPreferences preferences;
    
    private AdvancedEncryptionManager(Context context) {
        this.context = context.getApplicationContext();
        this.secureRandom = new SecureRandom();
        this.preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    /**
     * Get singleton instance
     */
    public static synchronized AdvancedEncryptionManager getInstance(Context context) {
        if (instance == null) {
            instance = new AdvancedEncryptionManager(context);
        }
        return instance;
    }
    
    /**
     * Initialize encryption subsystem and verify/create keys
     */
    public void initialize() {
        try {
            // Check if key rotation is needed
            if (isKeyRotationNeeded()) {
                rotateKeys();
            }
            
            // Verify keys exist or create them
            verifyAndCreateKeys();
            
            Log.d(TAG, "Advanced encryption system initialized");
        } catch (Exception e) {
            Log.e(TAG, "Error initializing encryption system", e);
        }
    }
    
    /**
     * Multi-layer encryption that's significantly more secure than CraxRAT's implementation
     * 
     * @param data Plain text data to encrypt
     * @return Encrypted data with multiple layers of protection
     */
    public String encryptData(String data) {
        try {
            if (data == null || data.isEmpty()) {
                return null;
            }
            
            byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
            
            // Layer 1: AES-GCM encryption with unique IV
            byte[] firstLayerResult = encryptWithAesGcm(dataBytes);
            
            // Layer 2: Add HMAC for integrity verification
            byte[] secondLayerResult = addHmacAuthentication(firstLayerResult);
            
            // Layer 3: Encrypt with RSA for asymmetric protection
            byte[] thirdLayerResult = encryptWithRsa(secondLayerResult);
            
            // Convert to Base64 for transmission
            return Base64.encodeToString(thirdLayerResult, Base64.NO_WRAP);
            
        } catch (Exception e) {
            Log.e(TAG, "Encryption error", e);
            return null;
        }
    }
    
    /**
     * Decrypt data that was encrypted with the multi-layer approach
     * 
     * @param encryptedData Base64 encoded encrypted data
     * @return Decrypted plain text
     */
    public String decryptData(String encryptedData) {
        try {
            if (encryptedData == null || encryptedData.isEmpty()) {
                return null;
            }
            
            // Convert from Base64
            byte[] encryptedBytes = Base64.decode(encryptedData, Base64.NO_WRAP);
            
            // Layer 3 (reverse): Decrypt RSA layer
            byte[] afterRsaDecryption = decryptWithRsa(encryptedBytes);
            
            // Layer 2 (reverse): Verify HMAC and remove it
            byte[] afterHmacVerification = verifyAndRemoveHmac(afterRsaDecryption);
            
            // Layer 1 (reverse): Decrypt AES-GCM layer
            byte[] plainBytes = decryptWithAesGcm(afterHmacVerification);
            
            // Convert back to string
            return new String(plainBytes, StandardCharsets.UTF_8);
            
        } catch (Exception e) {
            Log.e(TAG, "Decryption error", e);
            return null;
        }
    }
    
    /**
     * First layer: AES-GCM encryption (authenticated encryption)
     */
    private byte[] encryptWithAesGcm(byte[] data) throws Exception {
        // Get or generate AES key
        SecretKey aesKey = getOrCreateAesKey();
        
        // Generate a random IV
        byte[] iv = new byte[GCM_IV_LENGTH];
        secureRandom.nextBytes(iv);
        
        // Initialize GCM cipher
        Cipher cipher = Cipher.getInstance(AES_GCM_ALGORITHM);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, parameterSpec);
        
        // Add additional authenticated data (AAD) for extra security
        String keyId = preferences.getString(CURRENT_KEY_ID, "0");
        cipher.updateAAD(keyId.getBytes(StandardCharsets.UTF_8));
        
        // Encrypt
        byte[] encryptedData = cipher.doFinal(data);
        
        // Combine IV and encrypted data for storage/transmission
        ByteBuffer byteBuffer = ByteBuffer.allocate(iv.length + encryptedData.length);
        byteBuffer.put(iv);
        byteBuffer.put(encryptedData);
        
        return byteBuffer.array();
    }
    
    /**
     * Second layer: Add HMAC for additional integrity protection
     */
    private byte[] addHmacAuthentication(byte[] data) throws Exception {
        // Get HMAC key (derived from AES key for simplicity)
        SecretKey aesKey = getOrCreateAesKey();
        byte[] hmacKey = deriveHmacKey(aesKey);
        
        // Initialize HMAC
        Mac mac = Mac.getInstance(HMAC_ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(hmacKey, HMAC_ALGORITHM);
        mac.init(keySpec);
        
        // Generate HMAC
        byte[] hmac = mac.doFinal(data);
        
        // Combine data and HMAC
        ByteBuffer byteBuffer = ByteBuffer.allocate(4 + data.length + hmac.length);
        byteBuffer.putInt(data.length);
        byteBuffer.put(data);
        byteBuffer.put(hmac);
        
        return byteBuffer.array();
    }
    
    /**
     * Third layer: RSA encryption for asymmetric protection
     */
    private byte[] encryptWithRsa(byte[] data) throws Exception {
        // Get RSA public key
        PublicKey publicKey = getOrCreateRsaKeyPair().getPublic();
        
        // Initialize RSA cipher with advanced padding
        Cipher cipher = Cipher.getInstance(RSA_ALGORITHM);
        OAEPParameterSpec oaepParams = new OAEPParameterSpec(
                "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);
        cipher.init(Cipher.ENCRYPT_MODE, publicKey, oaepParams);
        
        // For large data, we need to chunk it since RSA has size limitations
        return processRsaInChunks(cipher, data, true);
    }
    
    /**
     * Reverse of first layer: AES-GCM decryption
     */
    private byte[] decryptWithAesGcm(byte[] encryptedData) throws Exception {
        // Get AES key
        SecretKey aesKey = getOrCreateAesKey();
        
        // Extract IV from the encrypted data
        ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedData);
        byte[] iv = new byte[GCM_IV_LENGTH];
        byteBuffer.get(iv);
        
        // Extract encrypted content
        byte[] ciphertext = new byte[byteBuffer.remaining()];
        byteBuffer.get(ciphertext);
        
        // Initialize GCM cipher for decryption
        Cipher cipher = Cipher.getInstance(AES_GCM_ALGORITHM);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.DECRYPT_MODE, aesKey, parameterSpec);
        
        // Add the same AAD used during encryption
        String keyId = preferences.getString(CURRENT_KEY_ID, "0");
        cipher.updateAAD(keyId.getBytes(StandardCharsets.UTF_8));
        
        // Decrypt
        return cipher.doFinal(ciphertext);
    }
    
    /**
     * Reverse of second layer: Verify HMAC and remove it
     */
    private byte[] verifyAndRemoveHmac(byte[] authenticatedData) throws Exception {
        // Get HMAC key (derived from AES key for simplicity)
        SecretKey aesKey = getOrCreateAesKey();
        byte[] hmacKey = deriveHmacKey(aesKey);
        
        // Extract data length
        ByteBuffer byteBuffer = ByteBuffer.wrap(authenticatedData);
        int dataLength = byteBuffer.getInt();
        
        // Extract original data
        byte[] originalData = new byte[dataLength];
        byteBuffer.get(originalData);
        
        // Extract stored HMAC
        byte[] storedHmac = new byte[byteBuffer.remaining()];
        byteBuffer.get(storedHmac);
        
        // Compute HMAC on the original data for verification
        Mac mac = Mac.getInstance(HMAC_ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(hmacKey, HMAC_ALGORITHM);
        mac.init(keySpec);
        byte[] calculatedHmac = mac.doFinal(originalData);
        
        // Verify HMAC
        if (!MessageDigest.isEqual(storedHmac, calculatedHmac)) {
            throw new SecurityException("HMAC verification failed - data integrity compromised");
        }
        
        return originalData;
    }
    
    /**
     * Reverse of third layer: RSA decryption
     */
    private byte[] decryptWithRsa(byte[] encryptedData) throws Exception {
        // Get RSA private key
        PrivateKey privateKey = getOrCreateRsaKeyPair().getPrivate();
        
        // Initialize RSA cipher with the same padding used for encryption
        Cipher cipher = Cipher.getInstance(RSA_ALGORITHM);
        OAEPParameterSpec oaepParams = new OAEPParameterSpec(
                "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);
        cipher.init(Cipher.DECRYPT_MODE, privateKey, oaepParams);
        
        // Decrypt chunks
        return processRsaInChunks(cipher, encryptedData, false);
    }
    
    /**
     * Process data in chunks for RSA operations due to size limitations
     */
    private byte[] processRsaInChunks(Cipher cipher, byte[] data, boolean encrypt) throws Exception {
        int blockSize = encrypt ? 
                cipher.getBlockSize() - 66 : // Account for OAEP padding overhead
                cipher.getBlockSize();
        
        // For small data that fits in one block
        if (data.length <= blockSize && encrypt) {
            return cipher.doFinal(data);
        }
        
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        
        if (encrypt) {
            // Encryption: break data into chunks that fit in RSA blocks
            for (int i = 0; i < data.length; i += blockSize) {
                int chunkSize = Math.min(blockSize, data.length - i);
                byte[] chunk = new byte[chunkSize];
                System.arraycopy(data, i, chunk, 0, chunkSize);
                
                byte[] encryptedChunk = cipher.doFinal(chunk);
                
                // Store length and encrypted chunk
                outputStream.write(ByteBuffer.allocate(4).putInt(encryptedChunk.length).array());
                outputStream.write(encryptedChunk);
            }
        } else {
            // Decryption: decode chunks based on stored lengths
            ByteBuffer buffer = ByteBuffer.wrap(data);
            while (buffer.hasRemaining()) {
                int chunkLength = buffer.getInt();
                byte[] encryptedChunk = new byte[chunkLength];
                buffer.get(encryptedChunk);
                
                byte[] decryptedChunk = cipher.doFinal(encryptedChunk);
                outputStream.write(decryptedChunk);
            }
        }
        
        return outputStream.toByteArray();
    }
    
    /**
     * Get or create AES key for symmetric encryption
     */
    private SecretKey getOrCreateAesKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);
        
        // Try to get existing key
        if (keyStore.containsAlias(AES_KEY_ALIAS)) {
            KeyStore.SecretKeyEntry keyEntry = (KeyStore.SecretKeyEntry) keyStore.getEntry(
                    AES_KEY_ALIAS, null);
            return keyEntry.getSecretKey();
        }
        
        // If no key exists, generate a new one
        KeyGenerator keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
        
        KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(
                AES_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM, KeyProperties.BLOCK_MODE_CTR)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(AES_KEY_SIZE)
                .setRandomizedEncryptionRequired(true);
        
        // Set key validity period
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        end.add(Calendar.YEAR, 10); // 10-year validity
        builder.setKeyValidityStart(start.getTime());
        builder.setKeyValidityEnd(end.getTime());
        
        keyGenerator.init(builder.build());
        return keyGenerator.generateKey();
    }
    
    /**
     * Get or create RSA key pair for asymmetric encryption
     */
    private KeyPair getOrCreateRsaKeyPair() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);
        
        // Try to get existing key
        if (keyStore.containsAlias(RSA_KEY_ALIAS)) {
            // Get public key
            PublicKey publicKey = keyStore.getCertificate(RSA_KEY_ALIAS).getPublicKey();
            
            // Get private key
            PrivateKey privateKey = ((KeyStore.PrivateKeyEntry) keyStore.getEntry(
                    RSA_KEY_ALIAS, null)).getPrivateKey();
            
            return new KeyPair(publicKey, privateKey);
        }
        
        // If no key exists, generate a new one
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_RSA, ANDROID_KEYSTORE);
        
        KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(
                RSA_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                .setKeySize(RSA_KEY_SIZE);
        
        // Set key validity period
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        end.add(Calendar.YEAR, 10); // 10-year validity
        builder.setKeyValidityStart(start.getTime());
        builder.setKeyValidityEnd(end.getTime());
        
        keyPairGenerator.initialize(builder.build());
        return keyPairGenerator.generateKeyPair();
    }
    
    /**
     * Verify keys exist and create them if needed
     */
    private void verifyAndCreateKeys() throws Exception {
        // Verify/create AES key
        getOrCreateAesKey();
        
        // Verify/create RSA key pair
        getOrCreateRsaKeyPair();
        
        // Initialize key ID if not present
        if (!preferences.contains(CURRENT_KEY_ID)) {
            String keyId = generateKeyId();
            preferences.edit().putString(CURRENT_KEY_ID, keyId).apply();
        }
    }
    
    /**
     * Generate a derived key for HMAC operations
     */
    private byte[] deriveHmacKey(SecretKey baseKey) throws Exception {
        // We can't directly access the bytes of AndroidKeyStore keys,
        // so this uses a method that works with the key reference
        
        // Initialize a cipher with the AES key
        Cipher cipher = Cipher.getInstance(AES_CTR_ALGORITHM);
        byte[] iv = new byte[16]; // All zeros IV for key derivation
        Arrays.fill(iv, (byte) 0);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, baseKey, ivSpec);
        
        // Encrypt a fixed input to derive HMAC key material
        byte[] input = "HMAC_KEY_DERIVATION_CONSTANT".getBytes(StandardCharsets.UTF_8);
        return cipher.doFinal(input);
    }
    
    /**
     * Check if key rotation is needed based on time
     */
    private boolean isKeyRotationNeeded() {
        long lastRotationTime = preferences.getLong(KEY_ROTATION_TIME, 0);
        long currentTime = System.currentTimeMillis();
        
        return (currentTime - lastRotationTime) > KEY_ROTATION_PERIOD;
    }
    
    /**
     * Rotate encryption keys - a feature not present in CraxRAT
     */
    private void rotateKeys() throws Exception {
        Log.d(TAG, "Rotating encryption keys");
        
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);
        
        // Delete old keys if they exist
        if (keyStore.containsAlias(AES_KEY_ALIAS)) {
            keyStore.deleteEntry(AES_KEY_ALIAS);
        }
        if (keyStore.containsAlias(RSA_KEY_ALIAS)) {
            keyStore.deleteEntry(RSA_KEY_ALIAS);
        }
        
        // Generate new keys
        getOrCreateAesKey();
        getOrCreateRsaKeyPair();
        
        // Update key ID
        String newKeyId = generateKeyId();
        preferences.edit()
                .putString(CURRENT_KEY_ID, newKeyId)
                .putLong(KEY_ROTATION_TIME, System.currentTimeMillis())
                .apply();
    }
    
    /**
     * Generate a random key ID
     */
    private String generateKeyId() {
        byte[] randomBytes = new byte[8];
        secureRandom.nextBytes(randomBytes);
        return Base64.encodeToString(randomBytes, Base64.NO_WRAP);
    }
    
    /**
     * Generate password-based key for file encryption/database security
     * (stronger than CraxRAT's simple password hashing)
     */
    public SecretKey generateKeyFromPassword(String password, byte[] salt) throws Exception {
        // Use PBKDF2 with high iteration count for password-based key
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] key = password.getBytes(StandardCharsets.UTF_8);
        
        // Multiple iterations of hashing for additional security
        for (int i = 0; i < 10000; i++) {
            digest.reset();
            digest.update(key);
            digest.update(salt);
            key = digest.digest();
        }
        
        return new SecretKeySpec(key, "AES");
    }
}