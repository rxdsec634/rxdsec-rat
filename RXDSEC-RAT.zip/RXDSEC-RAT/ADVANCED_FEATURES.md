# RXDSEC RAT Advanced Features

This document outlines the advanced features and capabilities of RXDSEC RAT beyond standard functionality.

## Template-Only Mode

RXDSEC RAT includes a fallback "template-only" mode when Android build tools (Java, Apktool, Zipalign, Jarsigner, AAPT) are not available on the system. This ensures the RAT remains functional in environments without the full Android SDK.

### How Template-Only Mode Works:

1. **Automatic Detection**: The system automatically detects missing build tools during startup
2. **Pre-built Templates**: Uses pre-built APK templates stored in the `apk_templates` directory
3. **Metadata Injection**: Injects C2 server URL and other configuration via metadata files
4. **Seamless API**: The same API endpoints work regardless of mode, with identical response formats

### Benefits:

- **Universal Compatibility**: Works on systems without Android build tools
- **Reduced Dependencies**: Minimal system requirements
- **Consistent Interface**: Same API and user experience in all environments

## Photo-Based Access

The RAT includes sophisticated photo payload generation with multiple embedding methods:

1. **Visible QR Codes**: Embeds visible QR codes in images that link to RAT APKs
2. **Steganography**: Hides payload URLs in images using advanced steganography techniques
3. **Metadata Embedding**: Embeds payload information in image metadata
4. **Campaign Tracking**: Generates unique identifiers to track distribution campaigns

## Advanced Encryption

The RAT implements multi-layered encryption with post-quantum resistance:

1. **Data-in-Transit**: All communications between the RAT client and C2 server use AES-256 encryption
2. **Key Rotation**: Automatic key rotation on configurable intervals
3. **Post-Quantum Algorithms**: Includes lattice-based cryptography for future-proofing against quantum computing
4. **Secure Key Storage**: Hardware-backed key storage on supported devices

## Stealth Techniques

Several advanced stealth techniques are implemented:

1. **Process Name Randomization**: Dynamic process name changes to avoid detection
2. **Emulator Detection**: Multiple methods to detect when running in an emulator or sandbox
3. **Security Tool Detection**: Identifies and evades common security analysis tools
4. **Memory Scanning Evasion**: Advanced techniques to avoid memory scanning
5. **Zero-Permission Operations**: Collects significant data without requiring permissions

## Enhanced Command & Control

The C2 infrastructure includes:

1. **Socket.IO Communication**: Real-time bidirectional communication
2. **Multi-Protocol Fallbacks**: Automatic fallback to alternative communication methods
3. **Domain Fronting**: Ability to disguise C2 traffic through legitimate services
4. **Tor Integration**: Optional routing through Tor network
5. **Custom Protocol Implementation**: Proprietary protocol to avoid signature detection

## System Requirements

### Minimum Requirements:
- Python 3.11+
- Cryptography library
- Flask and Flask-SocketIO

### For Full Functionality (APK Building):
- Java JDK 8+
- Android SDK Build Tools (apktool, zipalign, jarsigner, aapt)
- Required Python libraries (see DEPENDENCIES.md)

### For Template-Only Mode:
- Python 3.11+
- Cryptography library
- Flask and Flask-SocketIO
- Pre-built APK templates in the `apk_templates` directory

## Installation Options

1. **Full Installation**: `./install.sh` or `.\install.ps1` for complete functionality
2. **Minimal Installation**: `pip install -r requirements.txt` for template-only mode
3. **Docker Deployment**: `docker-compose up` for containerized deployment

## Extending Functionality

The modular architecture allows for easy extension:

1. Add custom injection templates in `injection_templates/`
2. Create custom APK templates in `apk_templates/`
3. Extend the CommandHandler class for new command types
4. Implement additional DataProcessor handlers for new data types

---

_Note: All features are designed for authorized security research and penetration testing only. Use responsibly and legally._