#!/usr/bin/env python3
import zipfile
import os
import sys

def check_apk(apk_path):
    """Check if an APK file is valid and display its contents"""
    print(f"Checking APK: {apk_path}")
    
    # Check file existence
    if not os.path.exists(apk_path):
        print(f"ERROR: File does not exist: {apk_path}")
        return False
    
    # Check file size
    size = os.path.getsize(apk_path)
    print(f"File size: {size} bytes")
    
    if size == 0:
        print("ERROR: File is empty (0 bytes)")
        return False
    
    # Try to open as ZIP
    try:
        with zipfile.ZipFile(apk_path, 'r') as z:
            # Get file list
            files = z.namelist()
            print(f"\nAPK contains {len(files)} files:")
            
            for file in files:
                info = z.getinfo(file)
                print(f" - {file} ({info.file_size} bytes)")
            
            # Check for essential Android files
            essential_files = ['AndroidManifest.xml', 'classes.dex']
            missing = [f for f in essential_files if f not in files]
            
            if missing:
                print(f"\nWARNING: Missing essential files: {', '.join(missing)}")
            else:
                print("\nAll essential files present.")
            
            return True
    except zipfile.BadZipFile:
        print("ERROR: Not a valid ZIP/APK file")
        return False
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return False

if __name__ == "__main__":
    # Check the template APK
    template_path = "c2_server/apk_templates/default_template.apk"
    if len(sys.argv) > 1:
        template_path = sys.argv[1]
    
    check_apk(template_path)